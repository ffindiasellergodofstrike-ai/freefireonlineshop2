# LinkNest Pro — Product & Payment Setup Guide

## 1. What this product does
This template creates a personal profile/link page where a user can display:
- Personal bio
- Website and social links
- WhatsApp and email
- Digital products
- Product prices
- Buy buttons connected to an external checkout/payment URL

## 2. Adding a product
Open `website/index.html` and duplicate/edit a `<article class="product">` block.

Change:
- Product title
- Description
- Price
- Cover text
- Payment/checkout URL

Example:
`<a class="buy-btn" href="YOUR_REAL_PAYMENT_OR_CHECKOUT_URL">Buy Now</a>`

## 3. Payment links
The demo uses placeholder URLs only. Replace them with the seller's real payment/checkout links.

Supported conceptually:
- Payment-provider hosted checkout links
- Merchant checkout pages
- Payment pages supplied by the seller's payment provider

Do not put secret API keys, merchant secret keys, webhook secrets, Firebase Admin credentials or private credentials into this static HTML.

## 4. Digital delivery
A payment link by itself does not securely deliver a digital file. For automatic delivery, use a payment provider + trusted backend/server or a digital-download service that verifies payment before releasing the file.

## 5. Free hosting
The same static website can be deployed to GitHub Pages, Netlify or Cloudflare Pages. Follow the deployment guide.

## 6. Buyer customization
Replace all:
- Name
- Handle
- Bio
- Social URLs
- WhatsApp number
- Email
- Product information
- Payment URLs
- Footer text
- Avatar initials

## 7. Testing checklist
Before publishing:
- Test every link.
- Test every Buy Now button.
- Test on Android and iPhone.
- Test light/dark mode.
- Confirm the payment destination belongs to the seller.
- Confirm no secret keys are present in the website source.
- Confirm the digital product is delivered only after verified payment.
