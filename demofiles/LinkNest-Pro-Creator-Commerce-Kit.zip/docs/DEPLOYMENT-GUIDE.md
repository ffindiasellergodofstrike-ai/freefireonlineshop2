# Free Deployment Guide

## GitHub Pages
1. Create a GitHub repository.
2. Upload the contents of `website/` to the repository root.
3. Open Settings → Pages.
4. Select deployment from the main branch and root folder.
5. Save and wait for GitHub Pages to publish.
6. Open the generated HTTPS URL.

## Netlify
1. Create a Netlify account.
2. Use a Git repository or manual deployment.
3. Upload/deploy the `website/` folder.
4. Open the generated URL and test the site.

## Cloudflare Pages
1. Create a Cloudflare account.
2. Create a Pages project.
3. Connect the repository or use the current supported upload workflow.
4. Deploy and test the URL.

## Custom domain
A custom domain is optional. Add it through the selected hosting provider and follow its DNS instructions.
