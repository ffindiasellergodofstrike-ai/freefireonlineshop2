# LinkNest Pro — Creator Bio & Digital Store Template

A professional, original, mobile-first profile/link page with a built-in demo digital-product showcase.

The buyer can use it as a personal bio page and also display products with prices and external payment/checkout buttons.

## Features
- Premium responsive UI
- Profile and bio section
- Social links
- WhatsApp and email buttons
- Product cards
- Demo digital products
- Price display
- External payment/checkout links
- Dark/light mode
- SEO metadata
- Open Graph metadata
- Favicon
- No framework or external dependency

## Folder structure
- `website/` — complete deployable website
- `docs/PRODUCT-SETUP-GUIDE.md` — products/payment setup
- `docs/DEPLOYMENT-GUIDE.md` — free hosting guide
- `docs/PRODUCT-LISTING.md` — ready product listing copy
- `docs/LICENSE-TEMPLATE.txt` — commercial license starting template

## Quick start
Open `website/index.html`, replace the sample profile/links/products/payment URLs, then deploy the `website` folder to your chosen static host.

## Security
Never put payment secrets, API keys, webhook secrets, Firebase Admin credentials or other private credentials in this static site.
