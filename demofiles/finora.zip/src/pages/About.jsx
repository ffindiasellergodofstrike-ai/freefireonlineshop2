import React, { useState } from 'react';
import { Sparkles, Users, Award, Landmark, Eye, CheckCircle2, Heart } from 'lucide-react';

export default function About() {
  const [selectedMember, setSelectedMember] = useState(0);

  const team = [
    {
      name: "Arthur Pendelton",
      role: "Lead Platform Architect",
      bio: "Arthur brings over 12 years of core financial software engineering experience, designing lightweight client-side memory database frameworks and zero-knowledge ledger sandboxes.",
      initials: "AP"
    },
    {
      name: "Sienna Vance",
      role: "Principal Visual Designer",
      bio: "Sienna spearheads Finora's spatial design rhythm, typography pairs, and user-facing layout mathematical structures, crafting beautiful interfaces that simplify budgeting.",
      initials: "SV"
    },
    {
      name: "Leland Cross",
      role: "Head of User Sovereignty",
      bio: "Leland is committed to absolute data privacy. He leads research into local-first cryptographic caching and offline data packages, protecting user financial identities.",
      initials: "LC"
    }
  ];

  const timeline = [
    { year: "2024", title: "Conceptualization", desc: "Finora was conceived as a response to aggressive corporate data brokerage, aiming to build a high-fidelity, client-bound budgeting platform." },
    { year: "2025", title: "Interactive Engine Launch", desc: "Shipped our first offline compound wealth models and high-performance Recharts visualization layers to independent planners." },
    { year: "2026", title: "Global Sandbox Adoption", desc: "Empowered thousands of modern allocators to model startup runaways and business treasury parameters without central database risks." }
  ];

  return (
    <div className="bg-slate-50 min-h-screen text-slate-800 font-sans pb-16">
      
      {/* Header */}
      <section className="bg-white border-b border-slate-100 pt-12 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-700 rounded-full text-xs font-semibold tracking-wide mb-3 border border-emerald-100">
            <Heart className="h-3.5 w-3.5" />
            <span>Mission & Vision</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight">
            Our story & values.
          </h1>
          <p className="text-slate-600 text-sm sm:text-base max-w-xl mx-auto mt-3 leading-relaxed">
            We are a group of dedicated platform designers and privacy engineers who believe your budget forecasts belong strictly to you.
          </p>
        </div>
      </section>

      {/* Narrative & Mission */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          <div className="lg:col-span-7 space-y-5">
            <span className="text-xs font-bold uppercase tracking-widest text-emerald-600 block mb-1">
              Platform Origins
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight leading-tight">
              A commitment to absolute user data sovereignty
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Traditional financial trackers force users to link sensitive, real-world credentials to insecure global cloud servers, leaving personal spending habits vulnerable to server intrusions and corporate data brokerage. 
            </p>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Finora redefines personal budget management. By modeling elite corporate security and client-bound database structures, we deliver powerful, high-fidelity projections and dynamic Recharts visualizers without storing a single byte of your data on central servers.
            </p>

            <div className="grid grid-cols-2 gap-4 pt-4">
              <div className="flex gap-2.5 items-start">
                <CheckCircle2 className="h-5 w-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="text-xs font-bold text-slate-900">100% Client-Bound Caching</h4>
                  <p className="text-[11px] text-slate-500">Every credential and calculation remains on your machine.</p>
                </div>
              </div>
              <div className="flex gap-2.5 items-start">
                <CheckCircle2 className="h-5 w-5 text-emerald-600 mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="text-xs font-bold text-slate-900">Sovereign Data Portability</h4>
                  <p className="text-[11px] text-slate-500">Export entire virtual ledgers instantly as encrypted CSV/JSON.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 bg-white p-6 rounded-2xl shadow-xl border border-slate-100 text-center space-y-4">
            <span className="text-xs font-bold text-emerald-600 uppercase block">Our Philosophy</span>
            <blockquote className="text-sm font-medium text-slate-700 italic leading-relaxed">
              "Financial forecasting shouldn't compromise your privacy. Craft is the union of sophisticated mathematical projection and absolute cryptographic user safety."
            </blockquote>
            <p className="text-[11px] font-bold text-slate-400">— Arthur Pendelton, Platform Lead</p>
          </div>

        </div>
      </section>

      {/* Interactive Feature: Dynamic Timeline */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-20">
        <div className="text-center mb-12">
          <h2 className="text-xs font-bold uppercase tracking-widest text-emerald-600 block mb-2">Our History</h2>
          <p className="text-2xl font-extrabold text-slate-900">How we engineered Finora</p>
        </div>

        <div className="space-y-6 relative border-l-2 border-slate-200 pl-6 ml-4">
          {timeline.map((item, i) => (
            <div key={i} className="relative space-y-1">
              {/* Dot marker */}
              <span className="absolute left-[-32px] top-1 h-4 w-4 bg-emerald-600 rounded-full border-4 border-white shadow-sm"></span>
              <span className="text-xs font-extrabold text-emerald-600 block">{item.year} — {item.title}</span>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Interactive Feature: Dynamic Team Bio Switcher */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 pt-20">
        <div className="text-center mb-10">
          <span className="text-xs font-bold uppercase tracking-widest text-emerald-600 block mb-2">The Founders</span>
          <h2 className="text-2xl font-extrabold text-slate-900">Meet our engineering leads</h2>
          <p className="text-xs text-slate-500 mt-1">Select a profile card below to expand details on their specialized expertise.</p>
        </div>

        {/* Member cards row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {team.map((member, i) => (
            <button
              key={i}
              onClick={() => setSelectedMember(i)}
              className={`p-5 rounded-2xl text-left border-2 transition-all ${
                selectedMember === i
                  ? 'bg-white border-emerald-500 shadow-md translate-y-[-1px]'
                  : 'bg-white/50 border-slate-200/60 hover:bg-white hover:border-slate-300'
              }`}
            >
              <div className="flex gap-3.5 items-center">
                <div className={`h-10 w-10 rounded-xl font-bold flex items-center justify-center text-xs ${
                  selectedMember === i ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-500'
                }`}>
                  {member.initials}
                </div>
                <div>
                  <h4 className="text-xs font-bold text-slate-900">{member.name}</h4>
                  <span className="block text-[10px] text-slate-400">{member.role}</span>
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Expanded Bio Container */}
        <div className="bg-white p-6 rounded-2xl border border-slate-150 shadow-sm animate-in fade-in slide-in-from-bottom-2 duration-300">
          <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-600 block mb-1">
            Core Bio — {team[selectedMember].name}
          </span>
          <span className="text-xs font-semibold text-slate-500 block mb-3">{team[selectedMember].role}</span>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
            {team[selectedMember].bio} Continuous validation frameworks ensure their code modules meet Finora's strict offline-first quality bounds.
          </p>
        </div>

      </section>

    </div>
  );
}
