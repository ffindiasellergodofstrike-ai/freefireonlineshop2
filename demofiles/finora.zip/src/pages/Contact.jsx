import React, { useState } from 'react';
import { Sparkles, MessageSquare, ShieldAlert, FileText, Send, CheckCircle2, RefreshCw } from 'lucide-react';

export default function Contact() {
  const [inquiryType, setInquiryType] = useState('general'); // 'general', 'security', 'partnership'
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '', physicalKey: '' });
  const [errors, setErrors] = useState({});
  const [isSending, setIsSending] = useState(false);
  const [sendSuccess, setSendSuccess] = useState(false);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    const newErrors = {};

    if (!formData.name.trim()) newErrors.name = "Please enter your name.";
    
    if (!formData.email.trim()) {
      newErrors.email = "Please enter your email.";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Please enter a valid email address.";
    }

    if (!formData.message.trim()) {
      newErrors.message = "Please enter your message.";
    }

    if (inquiryType === 'security' && !formData.physicalKey.trim()) {
      newErrors.physicalKey = "Security disclosures require a test physical seed key to verify local simulation environment.";
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    // Begin mock sending animation
    setIsSending(true);
    setTimeout(() => {
      setIsSending(false);
      setSendSuccess(true);
      setFormData({ name: '', email: '', subject: '', message: '', physicalKey: '' });
    }, 2000);
  };

  return (
    <div className="bg-slate-50 min-h-screen text-slate-800 font-sans pb-16">
      
      {/* Header */}
      <section className="bg-white border-b border-slate-100 pt-12 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-700 rounded-full text-xs font-semibold tracking-wide mb-3 border border-emerald-100">
            <MessageSquare className="h-3.5 w-3.5" />
            <span>Secure Help Desk</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight">
            Connect with Finora.
          </h1>
          <p className="text-slate-600 text-sm sm:text-base max-w-xl mx-auto mt-3 leading-relaxed">
            Have a question about our client-side models, compound calculators, or privacy framework? Choose your wizard mode to contact us.
          </p>
        </div>
      </section>

      {/* Inquiry Wizard and Contact form */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-12">
        <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-xl border border-slate-100">
          
          {/* Inquiry Selector */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-100 pb-5 mb-8 gap-4">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Contact Inquiry Wizard</span>
              <p className="text-xs text-slate-500">Select inquiry type to dynamically configure secure message forms.</p>
            </div>
            
            {/* Custom Interactive Toggle Tabs */}
            <div className="inline-flex p-1 bg-slate-100 rounded-lg">
              <button
                type="button"
                onClick={() => { setInquiryType('general'); setErrors({}); }}
                className={`px-3 py-1.5 rounded-md text-[11px] font-bold transition-all ${
                  inquiryType === 'general' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                General Help
              </button>
              <button
                type="button"
                onClick={() => { setInquiryType('security'); setErrors({}); }}
                className={`px-3 py-1.5 rounded-md text-[11px] font-bold transition-all ${
                  inquiryType === 'security' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                Security Report
              </button>
              <button
                type="button"
                onClick={() => { setInquiryType('partnership'); setErrors({}); }}
                className={`px-3 py-1.5 rounded-md text-[11px] font-bold transition-all ${
                  inquiryType === 'partnership' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                Partnership
              </button>
            </div>
          </div>

          {/* Contact form body */}
          {sendSuccess ? (
            <div className="text-center py-12 space-y-4 animate-in fade-in zoom-in-95 duration-300">
              <div className="p-4 bg-emerald-50 text-emerald-700 rounded-full inline-block border border-emerald-100">
                <CheckCircle2 className="h-8 w-8" />
              </div>
              <h3 className="text-base sm:text-lg font-bold text-slate-900">Message Dispatched Successfully</h3>
              <p className="text-xs text-slate-600 max-w-sm mx-auto leading-relaxed">
                Thank you! Your simulated message has been validated and compiled with client cryptographic parameters. We will review it shortly.
              </p>
              <button
                type="button"
                onClick={() => setSendSuccess(false)}
                className="text-xs font-bold text-emerald-600 hover:text-emerald-700 bg-emerald-50 px-4 py-2 rounded-lg border border-emerald-100 transition-colors"
              >
                Send Another Message
              </button>
            </div>
          ) : (
            <form onSubmit={handleFormSubmit} className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                
                {/* Field 1 */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700 block">Your Name</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    placeholder="E.g. Arthur Sinclair"
                    className={`w-full text-xs px-3.5 py-2.5 rounded-lg border focus:outline-none transition-colors ${
                      errors.name ? 'border-rose-400 focus:border-rose-500' : 'border-slate-200 focus:border-emerald-500'
                    }`}
                  />
                  {errors.name && <p className="text-[10px] text-rose-500">{errors.name}</p>}
                </div>

                {/* Field 2 */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700 block">Your Email Address</label>
                  <input
                    type="text"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="name@example.com"
                    className={`w-full text-xs px-3.5 py-2.5 rounded-lg border focus:outline-none transition-colors ${
                      errors.email ? 'border-rose-400 focus:border-rose-500' : 'border-slate-200 focus:border-emerald-500'
                    }`}
                  />
                  {errors.email && <p className="text-[10px] text-rose-500">{errors.email}</p>}
                </div>

              </div>

              {/* Dynamic Field if security disclosure */}
              {inquiryType === 'security' && (
                <div className="space-y-1 animate-in fade-in slide-in-from-top-2 duration-200">
                  <div className="flex justify-between items-center text-xs">
                    <label className="font-semibold text-slate-700">Physical Seed Key</label>
                    <span className="text-[10px] text-slate-400">(Verify local sandbox environment)</span>
                  </div>
                  <input
                    type="text"
                    name="physicalKey"
                    value={formData.physicalKey}
                    onChange={handleInputChange}
                    placeholder="Enter locally generated 24-char physical key"
                    className={`w-full text-xs px-3.5 py-2.5 font-mono rounded-lg border focus:outline-none transition-colors ${
                      errors.physicalKey ? 'border-rose-400 focus:border-rose-500' : 'border-slate-200 focus:border-emerald-500'
                    }`}
                  />
                  {errors.physicalKey && <p className="text-[10px] text-rose-500">{errors.physicalKey}</p>}
                </div>
              )}

              {/* Subject Field */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 block">Subject</label>
                <input
                  type="text"
                  name="subject"
                  value={formData.subject}
                  onChange={handleInputChange}
                  placeholder={
                    inquiryType === 'security'
                      ? "Vulnerability or system integrity disclosure"
                      : inquiryType === 'partnership'
                      ? "Co-founder / Startup venture proposal"
                      : "General inquiries & feedback"
                  }
                  className="w-full text-xs px-3.5 py-2.5 rounded-lg border border-slate-200 focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* Message Field */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-700 block">Message Details</label>
                <textarea
                  name="message"
                  rows="4"
                  value={formData.message}
                  onChange={handleInputChange}
                  placeholder="Explain your inquiry in detail..."
                  className={`w-full text-xs px-3.5 py-2.5 rounded-lg border focus:outline-none transition-colors ${
                    errors.message ? 'border-rose-400 focus:border-rose-500' : 'border-slate-200 focus:border-emerald-500'
                  }`}
                ></textarea>
                {errors.message && <p className="text-[10px] text-rose-500">{errors.message}</p>}
              </div>

              {/* Submit Buttons */}
              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  disabled={isSending}
                  className="inline-flex items-center gap-1.5 px-6 py-3 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl transition-all shadow-md shadow-emerald-500/10 hover:translate-y-[-1px] disabled:opacity-75 disabled:pointer-events-none"
                >
                  {isSending ? (
                    <>
                      <RefreshCw className="h-4 w-4 animate-spin" />
                      Dispatching Message...
                    </>
                  ) : (
                    <>
                      <Send className="h-4 w-4" />
                      Dispatch Message Packet
                    </>
                  )}
                </button>
              </div>

            </form>
          )}

        </div>
      </section>

      {/* Corporate support details */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-5 bg-white rounded-xl border border-slate-200 shadow-sm flex gap-4 items-start">
          <div className="p-3 bg-emerald-50 text-emerald-700 rounded-xl mt-0.5">
            <ShieldAlert className="h-5 w-5" />
          </div>
          <div className="space-y-1">
            <h4 className="text-xs font-bold text-slate-900">Secure Disclosure Policy</h4>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              We highly value integrity. Security disclosures compile client cryptographic variables and sandbox key tokens to verify vulnerability scopes, processed locally with zero central network storage.
            </p>
          </div>
        </div>
        
        <div className="p-5 bg-white rounded-xl border border-slate-200 shadow-sm flex gap-4 items-start">
          <div className="p-3 bg-slate-100 text-slate-700 rounded-xl mt-0.5">
            <FileText className="h-5 w-5" />
          </div>
          <div className="space-y-1">
            <h4 className="text-xs font-bold text-slate-900">Enterprise Solutions Desk</h4>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              For commercial enterprise integration agreements, seed valuation projection grids, or tailored multi-entity organizations, contact our partnership officers directly at partnerships@finora.co (fictional address).
            </p>
          </div>
        </div>
      </section>

    </div>
  );
}
