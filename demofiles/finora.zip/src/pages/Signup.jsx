import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Wallet, Key, Mail, User, ArrowRight, RefreshCw, CheckCircle2 } from 'lucide-react';

export default function Signup() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleSignup = (e) => {
    e.preventDefault();
    const newErrors = {};

    if (!name.trim()) {
      newErrors.name = "Please enter your full name.";
    }

    if (!email.trim()) {
      newErrors.email = "Please enter your email.";
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = "Please enter a valid email address.";
    }

    if (!password) {
      newErrors.password = "Please enter your password.";
    } else if (password.length < 6) {
      newErrors.password = "Password must be at least 6 characters.";
    }

    if (!agreeTerms) {
      newErrors.agreeTerms = "You must agree to the data sovereignty privacy guidelines.";
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setIsLoading(true);
    
    // Simulate API request
    setTimeout(() => {
      setIsLoading(false);
      localStorage.setItem('finora_logged_in', 'true');
      localStorage.setItem('finora_user_email', email);
      navigate('/dashboard');
      window.location.reload(); // Reload to refresh navbar state
    }, 1500);
  };

  return (
    <div className="bg-slate-50 min-h-[calc(100vh-4rem)] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full bg-white p-6 sm:p-10 rounded-2xl shadow-xl border border-slate-100 space-y-8 animate-in fade-in zoom-in-95 duration-300">
        
        {/* Header logo & brand */}
        <div className="text-center space-y-2">
          <Link to="/" className="inline-flex items-center gap-2 text-slate-900 justify-center">
            <div className="p-2 bg-emerald-600 rounded-lg text-white">
              <Wallet className="h-5 w-5" />
            </div>
            <span className="text-xl font-bold tracking-tight">
              Finora<span className="text-emerald-600">.</span>
            </span>
          </Link>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Create sandbox account
          </h2>
          <p className="text-xs text-slate-500">
            Configure your zero-knowledge offline budget simulation now.
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSignup} className="space-y-4">
          
          {/* Name field */}
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-700 block">Full Name</label>
            <div className="relative">
              <input
                type="text"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  if (errors.name) setErrors(prev => ({ ...prev, name: '' }));
                }}
                placeholder="E.g. Arthur Sinclair"
                className={`w-full text-xs px-3.5 py-2.5 pl-9 rounded-lg border focus:outline-none transition-colors ${
                  errors.name ? 'border-rose-400 focus:border-rose-500' : 'border-slate-200 focus:border-emerald-500'
                }`}
              />
              <User className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
            </div>
            {errors.name && <p className="text-[10px] text-rose-500">{errors.name}</p>}
          </div>

          {/* Email field */}
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-700 block">Email Address</label>
            <div className="relative">
              <input
                type="text"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (errors.email) setErrors(prev => ({ ...prev, email: '' }));
                }}
                placeholder="name@example.com"
                className={`w-full text-xs px-3.5 py-2.5 pl-9 rounded-lg border focus:outline-none transition-colors ${
                  errors.email ? 'border-rose-400 focus:border-rose-500' : 'border-slate-200 focus:border-emerald-500'
                }`}
              />
              <Mail className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
            </div>
            {errors.email && <p className="text-[10px] text-rose-500">{errors.email}</p>}
          </div>

          {/* Password field */}
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-700 block">Password</label>
            <div className="relative">
              <input
                type="password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (errors.password) setErrors(prev => ({ ...prev, password: '' }));
                }}
                placeholder="••••••••"
                className={`w-full text-xs px-3.5 py-2.5 pl-9 rounded-lg border focus:outline-none transition-colors ${
                  errors.password ? 'border-rose-400 focus:border-rose-500' : 'border-slate-200 focus:border-emerald-500'
                }`}
              />
              <Key className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
            </div>
            {errors.password && <p className="text-[10px] text-rose-500">{errors.password}</p>}
          </div>

          {/* Consent Checkbox */}
          <div className="space-y-1">
            <label className="flex items-start gap-2 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={agreeTerms}
                onChange={(e) => {
                  setAgreeTerms(e.target.checked);
                  if (errors.agreeTerms) setErrors(prev => ({ ...prev, agreeTerms: '' }));
                }}
                className="mt-0.5 accent-emerald-600 rounded"
              />
              <span className="text-[11px] text-slate-500 leading-normal">
                I understand and agree that my budget credentials and calculations compile strictly within my client-side browser tab for absolute privacy.
              </span>
            </label>
            {errors.agreeTerms && <p className="text-[10px] text-rose-500">{errors.agreeTerms}</p>}
          </div>

          {/* Submit button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 py-3 rounded-lg shadow-md shadow-emerald-500/10 transition-all hover:translate-y-[-1px] flex items-center justify-center gap-1.5 disabled:opacity-75 disabled:pointer-events-none"
          >
            {isLoading ? (
              <>
                <RefreshCw className="h-4 w-4 animate-spin" />
                Creating Workspace...
              </>
            ) : (
              <>
                Create Free Workspace
                <ArrowRight className="h-4 w-4" />
              </>
            )}
          </button>

        </form>

        {/* Footer links */}
        <div className="text-center pt-2 border-t border-slate-100 text-xs text-slate-500">
          <span>Already have a secure workspace? </span>
          <Link to="/login" className="text-emerald-600 font-bold hover:text-emerald-700">
            Sign In Here
          </Link>
        </div>

      </div>
    </div>
  );
}
