import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Wallet, Key, Mail, ArrowRight, RefreshCw, AlertCircle, CheckCircle2 } from 'lucide-react';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    const newErrors = {};

    if (!email.trim()) {
      newErrors.email = "Please enter your email.";
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = "Please enter a valid email address.";
    }

    if (!password) {
      newErrors.password = "Please enter your password.";
    } else if (password.length < 6) {
      newErrors.password = "Passwords must be at least 6 characters.";
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setIsLoading(true);
    
    // Simulate API request
    setTimeout(() => {
      setIsLoading(false);
      localStorage.setItem('finora_logged_in', 'true');
      localStorage.setItem('finora_user_email', email);
      // Force page state update or redirect
      navigate('/dashboard');
      window.location.reload(); // Reload to refresh navbar login state
    }, 1500);
  };

  return (
    <div className="bg-slate-50 min-h-[calc(100vh-4rem)] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full bg-white p-6 sm:p-10 rounded-2xl shadow-xl border border-slate-100 space-y-8 animate-in fade-in zoom-in-95 duration-300">
        
        {/* Header logo & brand */}
        <div className="text-center space-y-2">
          <Link to="/" className="inline-flex items-center gap-2 text-slate-900 justify-center">
            <div className="p-2 bg-emerald-600 rounded-lg text-white">
              <Wallet className="h-5 w-5" />
            </div>
            <span className="text-xl font-bold tracking-tight">
              Finora<span className="text-emerald-600">.</span>
            </span>
          </Link>
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            Sign in to your sandbox
          </h2>
          <p className="text-xs text-slate-500">
            Enter any demo credentials or create an account to start sandboxing.
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleLogin} className="space-y-4">
          
          {/* Email field */}
          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-700 block">Email Address</label>
            <div className="relative">
              <input
                type="text"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (errors.email) setErrors(prev => ({ ...prev, email: '' }));
                }}
                placeholder="name@example.com"
                className={`w-full text-xs px-3.5 py-2.5 pl-9 rounded-lg border focus:outline-none transition-colors ${
                  errors.email ? 'border-rose-400 focus:border-rose-500' : 'border-slate-200 focus:border-emerald-500'
                }`}
              />
              <Mail className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
            </div>
            {errors.email && <p className="text-[10px] text-rose-500">{errors.email}</p>}
          </div>

          {/* Password field */}
          <div className="space-y-1">
            <div className="flex justify-between items-center text-xs">
              <label className="font-semibold text-slate-700">Password</label>
              <button
                type="button"
                onClick={() => alert("Simulated recovery: Demo accounts require no password verification.")}
                className="text-[10px] text-emerald-600 hover:text-emerald-700 font-bold"
              >
                Forgot Password?
              </button>
            </div>
            <div className="relative">
              <input
                type="password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (errors.password) setErrors(prev => ({ ...prev, password: '' }));
                }}
                placeholder="••••••••"
                className={`w-full text-xs px-3.5 py-2.5 pl-9 rounded-lg border focus:outline-none transition-colors ${
                  errors.password ? 'border-rose-400 focus:border-rose-500' : 'border-slate-200 focus:border-emerald-500'
                }`}
              />
              <Key className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
            </div>
            {errors.password && <p className="text-[10px] text-rose-500">{errors.password}</p>}
          </div>

          {/* Submit button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 py-3 rounded-lg shadow-md shadow-emerald-500/10 transition-all hover:translate-y-[-1px] flex items-center justify-center gap-1.5 disabled:opacity-75 disabled:pointer-events-none"
          >
            {isLoading ? (
              <>
                <RefreshCw className="h-4 w-4 animate-spin" />
                Authorizing Access...
              </>
            ) : (
              <>
                Authorize Sandbox Session
                <ArrowRight className="h-4 w-4" />
              </>
            )}
          </button>

        </form>

        {/* Footer links */}
        <div className="text-center pt-2 border-t border-slate-100 text-xs text-slate-500">
          <span>Don't have a secure sandbox account? </span>
          <Link to="/signup" className="text-emerald-600 font-bold hover:text-emerald-700">
            Create Account Free
          </Link>
        </div>

      </div>
    </div>
  );
}
