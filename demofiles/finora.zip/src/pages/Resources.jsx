import React, { useState } from 'react';
import { 
  Sparkles, BookOpen, ChevronRight, Search, 
  Award, HeartPulse, RefreshCw, AlertCircle, CheckCircle, ArrowRight
} from 'lucide-react';

export default function Resources() {
  const [searchTerm, setSearchTerm] = useState('');
  
  // Quiz states
  const [quizStarted, setQuizStarted] = useState(false);
  const [answers, setAnswers] = useState({ q1: '', q2: '', q3: '' });
  const [quizScore, setQuizScore] = useState(null);

  // Fictional educational posts
  const articles = [
    {
      title: "Understanding Local Caching & Data Sovereignty",
      category: "Platform Security",
      readTime: "4 min read",
      summary: "Explore why offline-first, client-side databases prevent global network breaches and keep your sensitive budgets completely safe."
    },
    {
      title: "How to Build a Compound Interest savings curve",
      category: "Personal Wealth",
      readTime: "6 min read",
      summary: "Understand the mathematical variables behind compound growth and how micro-adjustments to overhead accelerate long-term wealth."
    },
    {
      title: "Startup burn rates: Modeling safe runway thresholds",
      category: "Venture Treasury",
      readTime: "5 min read",
      summary: "An in-depth review on calculating venture runaways, founder dilution parameters, and seed-funding tax brackets."
    }
  ];

  // Fictional glossary terms
  const glossary = [
    { term: "Compound Interest", definition: "Interest calculated on the initial principal, which also includes all of the accumulated interest from previous periods on a deposit or loan." },
    { term: "Client-side Encryption", definition: "A cryptographic technique where data is encrypted on the sender's local machine or browser before being saved or transferred." },
    { term: "Zero-Knowledge Ledger", definition: "A conceptual framework where the host platform facilitates financial projections and ledger logs without storing or possessing the decryption keys." },
    { term: "Venture Burn Rate", definition: "The rate at which a newly created startup or business spends its venture capital to finance overhead before generating positive cash flow." }
  ];

  const filteredGlossary = glossary.filter(
    item => item.term.toLowerCase().includes(searchTerm.toLowerCase()) || 
            item.definition.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const startQuiz = () => {
    setQuizStarted(true);
    setAnswers({ q1: '', q2: '', q3: '' });
    setQuizScore(null);
  };

  const handleSelectAnswer = (q, val) => {
    setAnswers(prev => ({ ...prev, [q]: val }));
  };

  const calculateScore = (e) => {
    e.preventDefault();
    if (!answers.q1 || !answers.q2 || !answers.q3) {
      alert("Please answer all questions to complete the scan.");
      return;
    }
    
    let score = 0;
    if (answers.q1 === 'always') score += 35;
    else if (answers.q1 === 'sometimes') score += 20;
    
    if (answers.q2 === 'over_20') score += 35;
    else if (answers.q2 === '10_20') score += 20;
    
    if (answers.q3 === 'yes_3_6') score += 30;
    else if (answers.q3 === 'yes_1_2') score += 15;

    let rating = "Fair Financial Health";
    let color = "text-amber-700 bg-amber-50 border-amber-100";
    let tips = "Consider expanding your emergency reserves and committing to a rigorous monthly budgeting routine inside our Finora dashboard.";
    
    if (score >= 80) {
      rating = "Excellent Sovereign Wealth Health";
      color = "text-emerald-700 bg-emerald-50 border-emerald-100";
      tips = "Outstanding habits! Continue leveraging Finora's compound projections and multi-entity vault sandboxing to fine-tune your parameters.";
    } else if (score < 40) {
      rating = "Vulnerable Financial Position";
      color = "text-rose-700 bg-rose-50 border-rose-100";
      tips = "Prioritize forming a solid 3-month savings reserve. Use our compound interest sliders in Features to plan small, consistent deposits.";
    }

    setQuizScore({ score, rating, tips, color });
  };

  return (
    <div className="bg-slate-50 min-h-screen text-slate-800 font-sans pb-16">
      
      {/* Header */}
      <section className="bg-white border-b border-slate-100 pt-12 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-700 rounded-full text-xs font-semibold tracking-wide mb-3 border border-emerald-100">
            <BookOpen className="h-3.5 w-3.5" />
            <span>Educational Knowledge Base</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight">
            Financial Resources & Guides.
          </h1>
          <p className="text-slate-600 text-sm sm:text-base max-w-xl mx-auto mt-3 leading-relaxed">
            Gain mastery over budgeting calculations, security mechanics, and ledger operations. Fully offline-safe resources.
          </p>
        </div>
      </section>

      {/* Interactive Tool: Financial Health Scanner */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-12">
        <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-xl border border-slate-100">
          <div className="flex justify-between items-center border-b border-slate-100 pb-5 mb-6">
            <div className="flex items-center gap-2">
              <HeartPulse className="h-5 w-5 text-emerald-600 animate-pulse" />
              <div>
                <h3 className="text-base sm:text-lg font-extrabold text-slate-900">Financial Health Scanner</h3>
                <p className="text-xs text-slate-500">Scan your micro-budgeting metrics locally to find targeted growth tips.</p>
              </div>
            </div>
            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded border border-emerald-100">
              Interactive Scanner Mode
            </span>
          </div>

          {!quizStarted ? (
            <div className="text-center py-6 space-y-4">
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed max-w-lg mx-auto">
                Evaluate your strategic budgeting frequency, monthly savings rates, and emergency fund buffer reserves in a secure browser sandboxed scanner.
              </p>
              <button
                onClick={startQuiz}
                className="inline-flex items-center gap-1.5 px-5 py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl shadow-md transition-all"
              >
                Start Free Diagnostic
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <form onSubmit={calculateScore} className="space-y-6">
              
              {/* Question 1 */}
              <div className="space-y-2">
                <label className="text-xs sm:text-sm font-bold text-slate-700 block">1. How frequently do you log or evaluate your expenditures?</label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  {[
                    { label: 'Weekly or Always', val: 'always' },
                    { label: 'Occasionally / Monthly', val: 'sometimes' },
                    { label: 'Rarely or Never', val: 'rarely' }
                  ].map((opt) => (
                    <button
                      key={opt.val}
                      type="button"
                      onClick={() => handleSelectAnswer('q1', opt.val)}
                      className={`px-4 py-2.5 rounded-lg border text-xs font-semibold text-center transition-all ${
                        answers.q1 === opt.val
                          ? 'border-emerald-500 bg-emerald-50/50 text-emerald-700 font-bold'
                          : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Question 2 */}
              <div className="space-y-2">
                <label className="text-xs sm:text-sm font-bold text-slate-700 block">2. What percentage of your monthly income is committed to savings?</label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  {[
                    { label: 'More than 20%', val: 'over_20' },
                    { label: 'Between 10% and 20%', val: '10_20' },
                    { label: 'Less than 10%', val: 'under_10' }
                  ].map((opt) => (
                    <button
                      key={opt.val}
                      type="button"
                      onClick={() => handleSelectAnswer('q2', opt.val)}
                      className={`px-4 py-2.5 rounded-lg border text-xs font-semibold text-center transition-all ${
                        answers.q2 === opt.val
                          ? 'border-emerald-500 bg-emerald-50/50 text-emerald-700 font-bold'
                          : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Question 3 */}
              <div className="space-y-2">
                <label className="text-xs sm:text-sm font-bold text-slate-700 block">3. Do you maintain a liquid cash safety reserve?</label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                  {[
                    { label: 'Yes, 3–6 months overhead', val: 'yes_3_6' },
                    { label: 'Yes, 1–2 months overhead', val: 'yes_1_2' },
                    { label: 'No liquid reserves yet', val: 'no' }
                  ].map((opt) => (
                    <button
                      key={opt.val}
                      type="button"
                      onClick={() => handleSelectAnswer('q3', opt.val)}
                      className={`px-4 py-2.5 rounded-lg border text-xs font-semibold text-center transition-all ${
                        answers.q3 === opt.val
                          ? 'border-emerald-500 bg-emerald-50/50 text-emerald-700 font-bold'
                          : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex gap-3 justify-end pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={startQuiz}
                  className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-950 transition-colors"
                >
                  Reset Answers
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-all"
                >
                  Compile Diagnostic Result
                </button>
              </div>

            </form>
          )}

          {quizScore && (
            <div className={`mt-6 p-5 rounded-xl border text-xs leading-relaxed space-y-2.5 ${quizScore.color}`}>
              <div className="flex justify-between items-center">
                <span className="font-extrabold text-sm sm:text-base">Result: {quizScore.rating}</span>
                <span className="font-mono font-black text-sm px-2.5 py-0.5 bg-white/60 rounded">
                  Score: {quizScore.score}/100
                </span>
              </div>
              <p className="font-medium text-slate-700">{quizScore.tips}</p>
              <button
                type="button"
                onClick={startQuiz}
                className="text-[10px] font-bold text-slate-900 bg-white/80 hover:bg-white px-2.5 py-1 rounded border border-black/10 transition-colors flex items-center gap-1.5"
              >
                <RefreshCw className="h-3 w-3" /> Re-scan Metrics
              </button>
            </div>
          )}

        </div>
      </section>

      {/* Articles / Blog Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-20">
        <div className="flex justify-between items-end border-b border-slate-200 pb-4 mb-8">
          <div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">Educational Deep Dives</h2>
            <p className="text-xs text-slate-500 mt-1">Read guides prepared by our leading fintech visual designers.</p>
          </div>
          <span className="text-xs font-semibold text-emerald-600 hover:underline cursor-pointer hidden sm:inline-block">
            View all articles
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {articles.map((art, i) => (
            <div key={i} className="bg-white p-5 rounded-2xl border border-slate-150 shadow-sm flex flex-col justify-between hover:shadow-md transition-shadow">
              <div className="space-y-3">
                <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-wider">
                  <span className="text-emerald-600">{art.category}</span>
                  <span className="text-slate-400">{art.readTime}</span>
                </div>
                <h3 className="font-bold text-slate-900 text-sm sm:text-base">{art.title}</h3>
                <p className="text-xs text-slate-500 leading-relaxed">{art.summary}</p>
              </div>
              
              <button 
                onClick={() => alert(`Fictional Blog: You selected "${art.title}". This demo article is complete.`)}
                className="text-xs font-bold text-emerald-600 hover:text-emerald-700 inline-flex items-center gap-1.5 mt-5 group text-left"
              >
                Read Article
                <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Glossary with Instant Search */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mt-20">
        <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-xl border border-slate-100">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-100 pb-5 mb-6 gap-4">
            <div>
              <h3 className="text-base sm:text-lg font-extrabold text-slate-900">Financial Glossary</h3>
              <p className="text-xs text-slate-500">Search technical definitions for premium ledger variables instantly.</p>
            </div>
            
            {/* Search Input */}
            <div className="relative w-full sm:w-60">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search terms (e.g. Compound)"
                className="w-full text-xs px-3 py-2.5 pl-8 rounded-lg border border-slate-200 focus:outline-none focus:border-emerald-500"
              />
              <Search className="absolute left-2.5 top-3 h-4 w-4 text-slate-400" />
            </div>
          </div>

          <div className="space-y-4">
            {filteredGlossary.length > 0 ? (
              filteredGlossary.map((item, i) => (
                <div key={i} className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-1">
                  <h4 className="text-xs font-bold text-slate-900">{item.term}</h4>
                  <p className="text-xs text-slate-600 leading-relaxed">{item.definition}</p>
                </div>
              ))
            ) : (
              <p className="text-center text-xs text-slate-500 py-4">No matching technical terms found.</p>
            )}
          </div>
        </div>
      </section>

    </div>
  );
}
