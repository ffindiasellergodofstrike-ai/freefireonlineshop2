import React, { useState } from 'react';
import { Shield, Key, Eye, Lock, RefreshCw, CheckCircle, HelpCircle, Sparkles, AlertTriangle } from 'lucide-react';

export default function Security() {
  const [entropyInput, setEntropyInput] = useState('');
  const [strengthResult, setStrengthResult] = useState(null);
  const [generatedKey, setGeneratedKey] = useState('');

  const checkStrength = (e) => {
    e.preventDefault();
    if (!entropyInput) return;
    
    // Evaluate simple local offline password entropy
    const len = entropyInput.length;
    let hasUpper = /[A-Z]/.test(entropyInput);
    let hasLower = /[a-z]/.test(entropyInput);
    let hasDigit = /[0-9]/.test(entropyInput);
    let hasSpecial = /[^A-Za-z0-9]/.test(entropyInput);
    
    let score = len * 4;
    if (hasUpper) score += 10;
    if (hasLower) score += 10;
    if (hasDigit) score += 10;
    if (hasSpecial) score += 15;

    let grade = "Weak";
    let color = "text-rose-500 bg-rose-50 border-rose-100";
    if (score > 70) {
      grade = "Very Strong (Excellent)";
      color = "text-emerald-700 bg-emerald-50 border-emerald-100";
    } else if (score > 45) {
      grade = "Strong (Good)";
      color = "text-amber-700 bg-amber-50 border-amber-100";
    }

    setStrengthResult({ score, grade, color });
  };

  const generateLocalKey = () => {
    // Fictional local client-side key block
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()';
    let key = '';
    for (let i = 0; i < 24; i++) {
      key += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setGeneratedKey(key);
  };

  return (
    <div className="bg-slate-50 min-h-screen text-slate-800 font-sans pb-16">
      
      {/* Header */}
      <section className="bg-white border-b border-slate-100 pt-12 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-700 rounded-full text-xs font-semibold tracking-wide mb-3 border border-emerald-100">
            <Shield className="h-3.5 w-3.5" />
            <span>Sovereign Client-Side Security</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight">
            Security centered on you.
          </h1>
          <p className="text-slate-600 text-sm sm:text-base max-w-xl mx-auto mt-3 leading-relaxed">
            Finora employs robust client-side architecture to model premium data security protocols, ensuring absolute budget sovereignty without central caching risks.
          </p>
        </div>
      </section>

      {/* Security core pillars layout */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          
          <div className="bg-white p-6 rounded-2xl border border-slate-150 shadow-sm space-y-4">
            <div className="p-3 bg-emerald-50 text-emerald-700 rounded-xl inline-block">
              <Lock className="h-5 w-5" />
            </div>
            <h3 className="text-base sm:text-lg font-bold text-slate-900">Browser-Bound Caching</h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              We leverage safe client-side databases. Your credentials, simulated balance ledgers, and transaction metrics compile locally within your browser tab, ensuring no global network breach can compromise your records.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-150 shadow-sm space-y-4">
            <div className="p-3 bg-emerald-50 text-emerald-700 rounded-xl inline-block">
              <Key className="h-5 w-5" />
            </div>
            <h3 className="text-base sm:text-lg font-bold text-slate-900">Custom Physical Seed Keys</h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              Secure your data backups using locally generated, high-entropy seed phrases. You hold the unique key to compile and decrypt your local transaction packages, giving you complete tactile sovereignty.
            </p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-150 shadow-sm space-y-4">
            <div className="p-3 bg-emerald-50 text-emerald-700 rounded-xl inline-block">
              <RefreshCw className="h-5 w-5" />
            </div>
            <h3 className="text-base sm:text-lg font-bold text-slate-900">Zero Central Storage</h3>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              We never collect, store, or sell your financial dossier or private allocations. Finora acts purely as a local visualization engine, ensuring your strategic budget ratios remain completely confidential.
            </p>
          </div>

        </div>
      </section>

      {/* Interactive Tool: Client-Side Security Key Lab */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-16">
        <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-xl border border-slate-100">
          <div className="flex justify-between items-center border-b border-slate-100 pb-5 mb-6">
            <div>
              <div className="flex items-center gap-1.5 mb-1 text-slate-900">
                <Sparkles className="h-5 w-5 text-emerald-600" />
                <h3 className="text-lg font-extrabold">Client-Side Key Laboratory</h3>
              </div>
              <p className="text-xs text-slate-500">Test physical file passphrase entropy or generate physical keys locally.</p>
            </div>
            <span className="text-[10px] uppercase font-bold text-emerald-700 bg-emerald-50 px-2 py-1 rounded border border-emerald-100">
              Offline-Safe Tool
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            
            {/* Column 1: Test Entropy */}
            <div className="space-y-4">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">Passphrase Entropy Tester</span>
              
              <form onSubmit={checkStrength} className="space-y-3">
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-slate-700">Enter Backup Password</label>
                  <input
                    type="text"
                    value={entropyInput}
                    onChange={(e) => setEntropyInput(e.target.value)}
                    placeholder="Enter a test passphrase"
                    className="w-full text-xs px-3.5 py-2.5 rounded-lg border border-slate-200 focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 py-2 rounded-lg transition-all"
                >
                  Analyze Passphrase Strength
                </button>
              </form>

              {strengthResult && (
                <div className={`p-4 rounded-xl border text-xs leading-relaxed space-y-1.5 ${strengthResult.color}`}>
                  <p className="font-bold">Result: {strengthResult.grade}</p>
                  <p className="text-slate-600 font-mono text-[10px]">Calculated Local Bit Score: {strengthResult.score}</p>
                </div>
              )}
            </div>

            {/* Column 2: Generator */}
            <div className="space-y-4 flex flex-col justify-between">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block mb-2">Physical Key Generator</span>
                <p className="text-xs text-slate-600 leading-relaxed mb-4">
                  Need a secure offline seed phrase to backup your local ledger export? Generate a premium client-side randomized key packet instantly.
                </p>
                
                <button
                  onClick={generateLocalKey}
                  className="w-full text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 py-2 rounded-lg border border-emerald-100 transition-all flex items-center justify-center gap-1.5"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                  Generate Physical Key
                </button>
              </div>

              {generatedKey && (
                <div className="p-3 bg-slate-50 border border-slate-100 rounded-xl text-center">
                  <span className="block text-[10px] uppercase font-bold text-slate-400 mb-1">Generated Secret Key</span>
                  <code className="text-[11px] font-mono select-all bg-white px-2 py-1 rounded border border-slate-100 font-bold break-all block">
                    {generatedKey}
                  </code>
                </div>
              )}
            </div>

          </div>
        </div>
      </section>

      {/* Disclaimer on certifications */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        <div className="p-5 rounded-2xl bg-amber-50 border border-amber-100 flex items-start gap-3 text-xs text-amber-800 leading-relaxed">
          <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5 flex-shrink-0" />
          <div className="space-y-1">
            <span className="font-bold uppercase tracking-wider text-[10px] text-amber-900 block">Fictional Product Sandbox Disclaimer</span>
            <p>
              Finora is a premium high-fidelity fintech design template. This security hub explains conceptual security frameworks (including local cryptographic caching and offline sovereignty keys) for template demonstration purposes. This template does not hold PCI-DSS, SOC2, or ISO audits, nor does it maintain central partner bank clearances or regulatory filings. All mock configurations demonstrate frontend craftsmanship and sandbox visual data models.
            </p>
          </div>
        </div>
      </section>

    </div>
  );
}
