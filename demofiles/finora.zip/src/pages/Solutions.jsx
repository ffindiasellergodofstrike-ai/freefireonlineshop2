import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  User, Building2, Rocket, Shield, ArrowRight, Check, 
  Sparkles, Wallet, BarChart3, Landmark, RefreshCw
} from 'lucide-react';

export default function Solutions() {
  const [activeSolution, setActiveSolution] = useState('personal');

  const solutionsData = {
    personal: {
      title: "Finora Personal Wealth",
      subtitle: "Map your journey to financial independence with pristine clarity.",
      icon: User,
      color: "emerald",
      badge: "Sovereign Planners",
      tagline: "Unify your budgets, optimize savings curves, and master your cash flows.",
      metrics: [
        { label: "Optimal Savings Rate Target", value: "35% MoM" },
        { label: "Compound Wealth Velocity", value: "+12.4% Avg" },
        { label: "Zero Personal Data Sale", value: "Guaranteed" }
      ],
      features: [
        "Uncapped local storage for transaction logs",
        "Compound curves with interactive interest sliders",
        "Multiple offline-friendly virtual vault targets",
        "Encrypted backup data files downloadable instantly",
        "Daily micro-spending leakage alert models"
      ]
    },
    business: {
      title: "Finora Business Treasury",
      subtitle: "Optimize corporate liquidity & model commercial treasury partitions.",
      icon: Building2,
      color: "slate",
      badge: "Commercial Entities",
      tagline: "Consolidate multi-account simulations and review precise overhead caps.",
      metrics: [
        { label: "Calculated Overhead Capping", value: "45% Max" },
        { label: "Virtual Ledger Entities Supported", value: "Up to 10" },
        { label: "Encrypted Backup Systems", value: "Integrated" }
      ],
      features: [
        "Multi-entity simulated corporate structures",
        "Custom tax bracket and retention rate projection modules",
        "Aggregate Recharts metrics for overhead monitoring",
        "Corporate payroll simulation boxes",
        "Dynamic export systems compatible with standard accounting sheets"
      ]
    },
    startup: {
      title: "Finora Startup Growth",
      subtitle: "Model runway scenarios, founder equity dilutions, & seed valuations.",
      icon: Rocket,
      color: "teal",
      badge: "Venture Builders",
      tagline: "Track team burn rates and preview compound capital pools.",
      metrics: [
        { label: "Runway Safety Buffers", value: "18 Months" },
        { label: "Dilution Projection Curves", value: "Interactive" },
        { label: "Venture Liquidation Models", value: "Continuous" }
      ],
      features: [
        "Interactive startup burn rate runway calculator",
        "Dynamic cap table simulation sheets",
        "Venture validation scenarios for Series seed-to-A",
        "Founder equity division sandbox models",
        "Direct simulated investor reporting templates"
      ]
    }
  };

  const current = solutionsData[activeSolution];
  const IconComponent = current.icon;

  return (
    <div className="bg-slate-50 min-h-screen text-slate-800 font-sans pb-16">
      
      {/* Header */}
      <section className="bg-white border-b border-slate-100 pt-12 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-700 rounded-full text-xs font-semibold tracking-wide mb-3 border border-emerald-100">
            <Sparkles className="h-3.5 w-3.5" />
            <span>Targeted Financial Architectures</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight">
            Tailored solutions for every scale.
          </h1>
          <p className="text-slate-600 text-sm sm:text-base max-w-xl mx-auto mt-3 leading-relaxed">
            Choose a custom-targeted profile sandbox to review custom-designed tools for personal budgeting, business treasury, or startup runaway simulation.
          </p>
        </div>
      </section>

      {/* Solutions Interactive Selector Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12">
        
        {/* Solution Toggle Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12 max-w-4xl mx-auto">
          
          <button
            onClick={() => setActiveSolution('personal')}
            className={`flex items-center gap-3 p-4 rounded-xl text-left border-2 transition-all ${
              activeSolution === 'personal'
                ? 'bg-white border-emerald-500 shadow-md translate-y-[-1px]'
                : 'bg-white/50 border-slate-200/60 hover:bg-white hover:border-slate-300'
            }`}
          >
            <div className={`p-2.5 rounded-lg ${activeSolution === 'personal' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
              <User className="h-5 w-5" />
            </div>
            <div>
              <span className="block text-xs font-extrabold text-slate-900">Personal Wealth</span>
              <span className="block text-[10px] text-slate-500">Wealth planners & savers</span>
            </div>
          </button>

          <button
            onClick={() => setActiveSolution('business')}
            className={`flex items-center gap-3 p-4 rounded-xl text-left border-2 transition-all ${
              activeSolution === 'business'
                ? 'bg-white border-slate-900 shadow-md translate-y-[-1px]'
                : 'bg-white/50 border-slate-200/60 hover:bg-white hover:border-slate-300'
            }`}
          >
            <div className={`p-2.5 rounded-lg ${activeSolution === 'business' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-500'}`}>
              <Building2 className="h-5 w-5" />
            </div>
            <div>
              <span className="block text-xs font-extrabold text-slate-900">Business Treasury</span>
              <span className="block text-[10px] text-slate-500">Corporate & SMB treasury</span>
            </div>
          </button>

          <button
            onClick={() => setActiveSolution('startup')}
            className={`flex items-center gap-3 p-4 rounded-xl text-left border-2 transition-all ${
              activeSolution === 'startup'
                ? 'bg-white border-teal-500 shadow-md translate-y-[-1px]'
                : 'bg-white/50 border-slate-200/60 hover:bg-white hover:border-slate-300'
            }`}
          >
            <div className={`p-2.5 rounded-lg ${activeSolution === 'startup' ? 'bg-teal-100 text-teal-700' : 'bg-slate-100 text-slate-500'}`}>
              <Rocket className="h-5 w-5" />
            </div>
            <div>
              <span className="block text-xs font-extrabold text-slate-900">Startup Growth</span>
              <span className="block text-[10px] text-slate-500">Venture founders & builders</span>
            </div>
          </button>

        </div>

        {/* Dynamic Solution Display Container */}
        <div className="bg-white p-6 sm:p-10 rounded-2xl shadow-xl border border-slate-100 max-w-5xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            
            {/* Display Text Left */}
            <div className="lg:col-span-7 space-y-5">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-slate-100 text-slate-800 rounded-lg text-xs font-bold uppercase tracking-wider">
                <IconComponent className="h-3.5 w-3.5" />
                <span>{current.badge}</span>
              </div>
              
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight leading-tight">
                {current.title}
              </h2>
              <p className="text-sm font-bold text-slate-700">
                {current.tagline}
              </p>
              <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
                {current.subtitle} Review customized visualization features and sandbox configurations targeted exactly for this profile. Log transactions, evaluate compound models, and check runway formulas.
              </p>

              {/* Dynamic Metrics Row */}
              <div className="grid grid-cols-3 gap-2 py-4 border-y border-slate-100">
                {current.metrics.map((metric, i) => (
                  <div key={i} className="text-center bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                    <span className="block text-[9px] uppercase font-bold text-slate-400 mb-0.5">{metric.label}</span>
                    <span className="text-xs sm:text-sm font-extrabold text-slate-800">{metric.value}</span>
                  </div>
                ))}
              </div>

              <div className="flex gap-3 pt-2">
                <Link
                  to="/signup"
                  className="px-5 py-3 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl transition-all shadow-md shadow-emerald-500/10"
                >
                  Create Custom Ledger
                </Link>
                <Link
                  to="/dashboard"
                  className="px-5 py-3 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all"
                >
                  Interactive Preview
                </Link>
              </div>
            </div>

            {/* Display list/visualizer Right */}
            <div className="lg:col-span-5 bg-slate-50 p-5 rounded-2xl border border-slate-100 space-y-4">
              <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400 block mb-2">
                Platform Capabilities
              </span>
              
              <ul className="space-y-3">
                {current.features.map((feature, i) => (
                  <li key={i} className="flex gap-2.5 items-start text-xs text-slate-600 leading-relaxed">
                    <div className="p-1 bg-emerald-100 text-emerald-700 rounded-md mt-0.5 flex-shrink-0">
                      <Check className="h-3 w-3" />
                    </div>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              
              <div className="p-4 bg-white rounded-xl border border-slate-100 text-center mt-4">
                <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Fictional Compliance</span>
                <p className="text-[10px] text-slate-500 leading-normal">
                  All models are engineered strictly as interactive client-side assets to keep personal budgets completely safe.
                </p>
              </div>
            </div>

          </div>
        </div>

      </section>

      {/* Solutions Bottom Row */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mt-16 text-center bg-slate-900 text-white rounded-2xl p-8 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[linear-gradient(to_right,#808080_1px,transparent_1px),linear-gradient(to_bottom,#808080_1px,transparent_1px)] bg-[size:24px_24px]"></div>
        <div className="relative space-y-4">
          <h3 className="text-xl font-bold tracking-tight">Need a custom enterprise sandbox modeling architecture?</h3>
          <p className="text-xs text-slate-300 max-w-lg mx-auto leading-relaxed">
            Configure isolated virtual teams, secure reporting formats, and high-fidelity project models with our bespoke Enterprise support solutions.
          </p>
          <Link to="/contact" className="inline-flex items-center gap-1 px-4 py-2 text-xs font-bold text-emerald-400 bg-emerald-950 hover:bg-emerald-900 rounded-lg border border-emerald-900 transition-colors">
            Contact Enterprise Solutions <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

    </div>
  );
}
