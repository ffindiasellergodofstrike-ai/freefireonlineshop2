import React, { useState, useMemo } from 'react';
import { 
  TrendingUp, BarChart3, LineChart, FileText, CheckCircle2, 
  Settings, Sparkles, HelpCircle, ArrowRight, Download, Calculator
} from 'lucide-react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, Legend 
} from 'recharts';

export default function Features() {
  // Calculator States
  const [initialDeposit, setInitialDeposit] = useState(5000);
  const [monthlyContribution, setMonthlyContribution] = useState(300);
  const [interestRate, setInterestRate] = useState(7);
  const [years, setYears] = useState(15);

  // Math simulation for compound growth
  const compoundData = useMemo(() => {
    let currentTotal = initialDeposit;
    let totalContributed = initialDeposit;
    const ratePerMonth = (interestRate / 100) / 12;
    const data = [];

    // Add year 0
    data.push({
      year: 'Year 0',
      'Total Wealth': Math.round(currentTotal),
      'Total Contributions': Math.round(totalContributed),
      'Interest Earned': 0
    });

    for (let y = 1; y <= years; y++) {
      for (let m = 0; m < 12; m++) {
        currentTotal = (currentTotal + monthlyContribution) * (1 + ratePerMonth);
        totalContributed += monthlyContribution;
      }
      data.push({
        year: `Yr ${y}`,
        'Total Wealth': Math.round(currentTotal),
        'Total Contributions': Math.round(totalContributed),
        'Interest Earned': Math.max(0, Math.round(currentTotal - totalContributed))
      });
    }
    return data;
  }, [initialDeposit, monthlyContribution, interestRate, years]);

  const finalWealth = compoundData[compoundData.length - 1]['Total Wealth'];
  const finalContributions = compoundData[compoundData.length - 1]['Total Contributions'];
  const finalInterest = compoundData[compoundData.length - 1]['Interest Earned'];

  const formatter = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0
  });

  return (
    <div className="bg-slate-50 min-h-screen text-slate-800 font-sans pb-16">
      
      {/* Page Header */}
      <section className="bg-white border-b border-slate-100 pt-12 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-700 rounded-full text-xs font-semibold tracking-wide mb-3 border border-emerald-100">
            <Sparkles className="h-3.5 w-3.5" />
            <span>Interactive Platform Tools</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight">
            Powerful features built for clarity.
          </h1>
          <p className="text-slate-600 text-sm sm:text-base max-w-xl mx-auto mt-3 leading-relaxed">
            Finora is equipped with sophisticated ledger models, calculators, and visualizations to help you map your future wealth with zero complexity.
          </p>
        </div>
      </section>

      {/* Interactive Tool: Compound Wealth Simulator */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12">
        <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-xl border border-slate-100">
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center border-b border-slate-100 pb-6 mb-8 gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Calculator className="h-5 w-5 text-emerald-600" />
                <h2 className="text-lg font-extrabold text-slate-900">Compound Growth Simulator</h2>
              </div>
              <p className="text-xs text-slate-500 leading-relaxed">
                Adjust variables and observe how compounding interest grows your savings curve over time.
              </p>
            </div>
            <div className="inline-flex bg-emerald-50 text-emerald-700 border border-emerald-100 rounded-xl px-3.5 py-1.5 text-xs font-bold items-center gap-1">
              <span>Interactive Calculator Mode</span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
            {/* Left Column: Sliders */}
            <div className="lg:col-span-4 space-y-6 bg-slate-50/50 p-5 rounded-xl border border-slate-100">
              
              {/* Slider 1 */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <label className="font-bold text-slate-700">Initial Deposit</label>
                  <span className="font-mono text-emerald-600 font-bold bg-white px-2 py-0.5 rounded border border-slate-100">
                    {formatter.format(initialDeposit)}
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100000"
                  step="1000"
                  value={initialDeposit}
                  onChange={(e) => setInitialDeposit(Number(e.target.value))}
                  className="w-full accent-emerald-600"
                />
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>$0</span>
                  <span>$100K</span>
                </div>
              </div>

              {/* Slider 2 */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <label className="font-bold text-slate-700">Monthly Contribution</label>
                  <span className="font-mono text-emerald-600 font-bold bg-white px-2 py-0.5 rounded border border-slate-100">
                    {formatter.format(monthlyContribution)}
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="5000"
                  step="50"
                  value={monthlyContribution}
                  onChange={(e) => setMonthlyContribution(Number(e.target.value))}
                  className="w-full accent-emerald-600"
                />
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>$0</span>
                  <span>$5,000</span>
                </div>
              </div>

              {/* Slider 3 */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <label className="font-bold text-slate-700">Annual Growth Rate</label>
                  <span className="font-mono text-emerald-600 font-bold bg-white px-2 py-0.5 rounded border border-slate-100">
                    {interestRate}%
                  </span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="15"
                  step="0.5"
                  value={interestRate}
                  onChange={(e) => setInterestRate(Number(e.target.value))}
                  className="w-full accent-emerald-600"
                />
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>1%</span>
                  <span>15%</span>
                </div>
              </div>

              {/* Slider 4 */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <label className="font-bold text-slate-700">Years to Grow</label>
                  <span className="font-mono text-emerald-600 font-bold bg-white px-2 py-0.5 rounded border border-slate-100">
                    {years} Years
                  </span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="40"
                  step="1"
                  value={years}
                  onChange={(e) => setYears(Number(e.target.value))}
                  className="w-full accent-emerald-600"
                />
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>1 Year</span>
                  <span>40 Years</span>
                </div>
              </div>

            </div>

            {/* Right Column: Dynamic Output Visualization */}
            <div className="lg:col-span-8 flex flex-col justify-between space-y-6">
              
              {/* Key Results */}
              <div className="grid grid-cols-3 gap-2.5 bg-slate-50 p-4 rounded-xl text-center border border-slate-100">
                <div>
                  <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-0.5">Total Contributions</span>
                  <span className="text-sm sm:text-lg font-extrabold text-slate-700">{formatter.format(finalContributions)}</span>
                </div>
                <div>
                  <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-0.5">Interest Earned</span>
                  <span className="text-sm sm:text-lg font-extrabold text-emerald-600">+{formatter.format(finalInterest)}</span>
                </div>
                <div>
                  <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-0.5">Estimated Wealth</span>
                  <span className="text-sm sm:text-lg font-extrabold text-slate-900">{formatter.format(finalWealth)}</span>
                </div>
              </div>

              {/* Chart container */}
              <div className="h-64 sm:h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={compoundData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                    <defs>
                      <linearGradient id="wealthGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.25}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="contribGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#94a3b8" stopOpacity={0.15}/>
                        <stop offset="95%" stopColor="#94a3b8" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="year" stroke="#94a3b8" fontSize={10} tickLine={false} />
                    <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} />
                    <Tooltip formatter={(val) => formatter.format(val)} contentStyle={{ fontSize: '11px', borderRadius: '8px' }} />
                    <Legend verticalAlign="top" height={32} iconType="circle" wrapperStyle={{ fontSize: '11px' }} />
                    <Area type="monotone" dataKey="Total Contributions" stroke="#94a3b8" strokeWidth={2} fillOpacity={1} fill="url(#contribGrad)" />
                    <Area type="monotone" dataKey="Total Wealth" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#wealthGrad)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              {/* Export simulation feedback */}
              <div className="flex justify-between items-center text-xs text-slate-500 pt-2 border-t border-slate-100">
                <span>Calculations are generated based on mathematical monthly compounding formulas.</span>
                <button
                  onClick={() => alert(`Fictional simulation export: You exported a compound sheet detailing final wealth of ${formatter.format(finalWealth)} over ${years} years.`)}
                  className="inline-flex items-center gap-1 text-emerald-600 font-bold hover:text-emerald-700 transition-colors bg-emerald-50 px-2.5 py-1.5 rounded-lg border border-emerald-100"
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>Export Sheet</span>
                </button>
              </div>

            </div>
          </div>
        </div>
      </section>

      {/* Feature Deep-Dive Layout */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-20">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-xs font-bold uppercase tracking-widest text-emerald-600 block mb-2">Designed for Mastery</h2>
          <p className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">Refined controls over your private money ledger</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          
          {/* Card left side */}
          <div className="space-y-6">
            <div className="flex gap-4 items-start">
              <div className="p-3 bg-emerald-100 text-emerald-700 rounded-xl mt-1">
                <TrendingUp className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-bold text-slate-900">Custom Projection Engine</h3>
                <p className="text-sm text-slate-600 leading-relaxed mt-1">
                  Adjust variables like savings rates, contribution frequencies, and compounding intervals. Instantly see how small shifts in overhead alter your decades-long velocity.
                </p>
              </div>
            </div>

            <div className="flex gap-4 items-start">
              <div className="p-3 bg-emerald-100 text-emerald-700 rounded-xl mt-1">
                <FileText className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-bold text-slate-900">Encrypted CSV/JSON Data Packets</h3>
                <p className="text-sm text-slate-600 leading-relaxed mt-1">
                  We champion complete offline sovereignty. Export entire virtual ledgers, transaction tables, and calculator configurations as encrypted file bundles to run in local spreadsheet programs.
                </p>
              </div>
            </div>

            <div className="flex gap-4 items-start">
              <div className="p-3 bg-emerald-100 text-emerald-700 rounded-xl mt-1">
                <CheckCircle2 className="h-5 w-5" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-bold text-slate-900">Simulated Smart Budget Allocation</h3>
                <p className="text-sm text-slate-600 leading-relaxed mt-1">
                  Structure up to 10 separate cash boxes. Easily model complex allocations, family safety deposits, or startup overhead partitions dynamically with zero risk.
                </p>
              </div>
            </div>
          </div>

          {/* Graphical Representation of Finora Interface */}
          <div className="p-6 bg-slate-900 text-white rounded-2xl shadow-xl border border-slate-800 space-y-6">
            <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-400 block">Console Feed Simulator</span>
            
            <div className="space-y-3 font-mono text-xs text-slate-300">
              <div className="flex gap-2 text-slate-500">
                <span>[system_log]</span>
                <span>Initializing client-side sandbox container...</span>
              </div>
              <div className="flex gap-2 text-slate-500">
                <span>[system_log]</span>
                <span>Generating zero-knowledge cryptographic signature...</span>
              </div>
              <div className="flex gap-2 text-emerald-400">
                <span>[success]</span>
                <span>Virtual ledger loaded. No network cached credentials detected.</span>
              </div>
              <div className="flex gap-2">
                <span className="text-emerald-500">&gt;</span>
                <span className="text-white">Active Simulated Entity Balance: $84,392.50</span>
              </div>
            </div>

            {/* Simulated UI list */}
            <div className="space-y-2.5 pt-2 border-t border-slate-800">
              <div className="flex justify-between items-center text-xs p-2 bg-slate-800/60 rounded">
                <span className="text-slate-300">Target Reserves</span>
                <span className="text-emerald-400 font-bold">112% Met</span>
              </div>
              <div className="flex justify-between items-center text-xs p-2 bg-slate-800/60 rounded">
                <span className="text-slate-300">Overhead Threshold</span>
                <span className="text-yellow-400 font-bold">24.5% Cap</span>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* Benefits CTA */}
      <section className="bg-emerald-600 text-white max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 rounded-2xl p-8 sm:p-12 text-center mt-20 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[linear-gradient(to_right,#808080_1px,transparent_1px),linear-gradient(to_bottom,#808080_1px,transparent_1px)] bg-[size:24px_24px]"></div>
        <div className="relative space-y-5">
          <h2 className="text-2xl sm:text-3xl font-extrabold">Ready to put these features to work?</h2>
          <p className="text-sm text-emerald-100 max-w-xl mx-auto leading-relaxed">
            Configure your own private ledger now. Toggle models, log simulated cash transactions, and build compound projection sheets inside our premium dashboard preview.
          </p>
          <div className="flex gap-3 justify-center">
            <Link to="/signup" className="px-5 py-2.5 text-xs sm:text-sm font-bold text-emerald-700 bg-white hover:bg-emerald-50 rounded-xl transition-all hover:translate-y-[-1px]">
              Create Sandbox Account
            </Link>
            <Link to="/dashboard" className="px-5 py-2.5 text-xs sm:text-sm font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-xl border border-emerald-500 transition-all hover:translate-y-[-1px]">
              Explore Demo Now
            </Link>
          </div>
        </div>
      </section>

    </div>
  );
}
