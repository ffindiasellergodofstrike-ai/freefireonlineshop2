import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Check, Sparkles, HelpCircle, ArrowRight, ShieldCheck, Calculator } from 'lucide-react';

export default function Pricing() {
  const [billingCycle, setBillingCycle] = useState('monthly'); // 'monthly' or 'annual'
  const [seatCount, setSeatCount] = useState(3);

  // Math for dynamic pricing calculator
  const proRate = billingCycle === 'monthly' ? 12 : 10; // Annual gives discount
  const savingsAmount = billingCycle === 'monthly' ? 0 : (12 - 10) * seatCount * 12;

  const faqs = [
    {
      q: "Can I cancel my subscription at any time?",
      a: "Yes. Our subscriptions are fully self-managed with zero cancellation penalties. Simply downgrade to the Free Plan inside your user settings, and your account will transition at the end of the current billing cycle."
    },
    {
      q: "Do you offer discounts for educational use or non-profits?",
      a: "Absolutely! We support academics and non-profit treasurers. Contact our solutions desk and we will configure a custom 50% discount code for your sandbox workspace."
    },
    {
      q: "How does the annual billing discount work?",
      a: "By selecting annual billing, you receive a flat discount of 16.5% on your Professional subscription, which effectively grants you two months completely free."
    }
  ];

  return (
    <div className="bg-slate-50 min-h-screen text-slate-800 font-sans pb-16">
      
      {/* Header */}
      <section className="bg-white border-b border-slate-100 pt-12 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-700 rounded-full text-xs font-semibold tracking-wide mb-3 border border-emerald-100">
            <Sparkles className="h-3.5 w-3.5" />
            <span>Transparent Subscription Tiers</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight">
            Plans built for every scope.
          </h1>
          <p className="text-slate-600 text-sm sm:text-base max-w-xl mx-auto mt-3 leading-relaxed">
            Choose a tier to match your tracking ambitions. Enjoy total data privacy, offline backup systems, and beautiful dynamic reports.
          </p>
        </div>
      </section>

      {/* Pricing Toggle Row */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12">
        <div className="flex justify-center mb-10">
          <div className="inline-flex items-center p-1 bg-slate-200/80 rounded-xl">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                billingCycle === 'monthly' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Monthly Billing
            </button>
            <button
              onClick={() => setBillingCycle('annual')}
              className={`px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                billingCycle === 'annual' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>Annual Billing</span>
              <span className="bg-emerald-100 text-emerald-700 text-[10px] px-1.5 py-0.5 rounded-full font-extrabold uppercase">
                Save 16%
              </span>
            </button>
          </div>
        </div>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          
          {/* Plan 1 */}
          <div className="p-6 sm:p-8 rounded-2xl bg-white border border-slate-200 flex flex-col justify-between shadow-sm">
            <div>
              <span className="text-xs font-bold text-slate-400 block uppercase tracking-wider mb-1">Standard Scale</span>
              <h3 className="text-xl font-bold text-slate-900">Personal Free</h3>
              <p className="text-xs text-slate-500 mt-2 min-h-[40px]">Perfect for single-person sandboxing and basic personal tracking.</p>
              
              <div className="my-6">
                <span className="text-4xl font-black text-slate-900">$0</span>
                <span className="text-xs text-slate-500"> / perpetual</span>
              </div>

              <ul className="space-y-3.5 text-xs text-slate-600 border-t border-slate-100 pt-5">
                <li className="flex items-center gap-2.5">
                  <Check className="h-4 w-4 text-emerald-600 flex-shrink-0" />
                  <span>3 Virtual Ledger Entities</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <Check className="h-4 w-4 text-emerald-600 flex-shrink-0" />
                  <span>Standard Compound Calculator</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <Check className="h-4 w-4 text-emerald-600 flex-shrink-0" />
                  <span>Encrypted Client Local Cache</span>
                </li>
              </ul>
            </div>
            
            <Link to="/signup" className="mt-8 w-full text-center py-3 text-xs font-bold text-slate-700 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 transition-colors">
              Get Started Free
            </Link>
          </div>

          {/* Plan 2 */}
          <div className="p-6 sm:p-8 rounded-2xl bg-white border-2 border-emerald-500 flex flex-col justify-between shadow-lg relative">
            <span className="absolute top-0 right-6 translate-y-[-50%] bg-emerald-500 text-white text-[10px] font-extrabold uppercase tracking-widest px-3 py-1 rounded-full shadow-md">
              Most Popular
            </span>
            <div>
              <span className="text-xs font-bold text-emerald-600 block uppercase tracking-wider mb-1">Advanced Scale</span>
              <h3 className="text-xl font-bold text-slate-900">Finora Professional</h3>
              <p className="text-xs text-slate-500 mt-2 min-h-[40px]">Engineered for active wealth builders, co-founders, and business allocators.</p>
              
              <div className="my-6">
                <span className="text-4xl font-black text-slate-900">
                  ${billingCycle === 'monthly' ? '12' : '10'}
                </span>
                <span className="text-xs text-slate-500"> / user / month</span>
              </div>

              <ul className="space-y-3.5 text-xs text-slate-600 border-t border-slate-100 pt-5">
                <li className="flex items-center gap-2.5">
                  <Check className="h-4 w-4 text-emerald-600 flex-shrink-0" />
                  <span className="font-semibold text-slate-900">Unlimited Virtual Ledgers</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <Check className="h-4 w-4 text-emerald-600 flex-shrink-0" />
                  <span>All High-fidelity Recharts Layouts</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <Check className="h-4 w-4 text-emerald-600 flex-shrink-0" />
                  <span>Interactive Dynamic Projection Math</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <Check className="h-4 w-4 text-emerald-600 flex-shrink-0" />
                  <span>Encrypted CSV/JSON Backup Exports</span>
                </li>
              </ul>
            </div>
            
            <Link to="/signup" className="mt-8 w-full text-center py-3 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl shadow-md shadow-emerald-500/20 transition-all hover:translate-y-[-1px]">
              Start Professional Plan
            </Link>
          </div>

          {/* Plan 3 */}
          <div className="p-6 sm:p-8 rounded-2xl bg-white border border-slate-200 flex flex-col justify-between shadow-sm">
            <div>
              <span className="text-xs font-bold text-slate-400 block uppercase tracking-wider mb-1">Enterprise Scale</span>
              <h3 className="text-xl font-bold text-slate-900">Corporate</h3>
              <p className="text-xs text-slate-500 mt-2 min-h-[40px]">Bespoke virtual modeling grids with custom permission rules.</p>
              
              <div className="my-6">
                <span className="text-4xl font-black text-slate-900">
                  ${billingCycle === 'monthly' ? '39' : '32'}
                </span>
                <span className="text-xs text-slate-500"> / organization / mo</span>
              </div>

              <ul className="space-y-3.5 text-xs text-slate-600 border-t border-slate-100 pt-5">
                <li className="flex items-center gap-2.5">
                  <Check className="h-4 w-4 text-emerald-600 flex-shrink-0" />
                  <span>All Professional Plan Capabilities</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <Check className="h-4 w-4 text-emerald-600 flex-shrink-0" />
                  <span>Custom Sandbox Modeling Frameworks</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <Check className="h-4 w-4 text-emerald-600 flex-shrink-0" />
                  <span>Priority Support Engineering Tickets</span>
                </li>
              </ul>
            </div>
            
            <Link to="/contact" className="mt-8 w-full text-center py-3 text-xs font-bold text-slate-700 bg-slate-50 hover:bg-slate-100 rounded-xl border border-slate-200 transition-colors">
              Contact Enterprise Desk
            </Link>
          </div>

        </div>
      </section>

      {/* Interactive Tool: Dynamic Billing & Savings Estimator */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-16">
        <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-xl border border-slate-100">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-100 pb-5 mb-6 gap-3">
            <div>
              <div className="flex items-center gap-1.5 mb-1 text-slate-900">
                <Calculator className="h-5 w-5 text-emerald-600" />
                <h3 className="text-base sm:text-lg font-extrabold">Billing & Savings Estimator</h3>
              </div>
              <p className="text-xs text-slate-500">Estimate monthly expenditures and annual discounts based on selected seats.</p>
            </div>
            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded border border-emerald-100">
              Interactive Tool Mode
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            
            {/* Input Slider left */}
            <div className="space-y-4">
              <div className="space-y-1">
                <div className="flex justify-between items-center text-xs">
                  <label className="font-bold text-slate-700">Team Seats</label>
                  <span className="font-mono text-emerald-600 font-bold bg-slate-50 px-2 py-0.5 rounded border border-slate-150">
                    {seatCount} Seats
                  </span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="50"
                  step="1"
                  value={seatCount}
                  onChange={(e) => setSeatCount(Number(e.target.value))}
                  className="w-full accent-emerald-600"
                />
                <div className="flex justify-between text-[10px] text-slate-400">
                  <span>1 Seat</span>
                  <span>50 Seats</span>
                </div>
              </div>

              <div className="p-3.5 bg-emerald-50 text-emerald-800 rounded-xl border border-emerald-100 text-xs flex gap-2">
                <ShieldCheck className="h-4 w-4 mt-0.5 text-emerald-600 flex-shrink-0" />
                <span>Annual billing discounts apply flatly. Drag the seat count slider to view direct compounding discounts.</span>
              </div>
            </div>

            {/* Calculations outputs right */}
            <div className="bg-slate-50 p-5 rounded-xl border border-slate-150 text-center space-y-4">
              <div>
                <span className="block text-[10px] font-bold uppercase tracking-wider text-slate-400">Calculated Monthly Rate</span>
                <span className="text-2xl font-black text-slate-900">${seatCount * proRate}</span>
              </div>

              {billingCycle === 'annual' ? (
                <div className="pt-2.5 border-t border-slate-200 text-xs">
                  <span className="block text-[10px] font-bold uppercase tracking-wider text-emerald-600">Your Annual Savings</span>
                  <span className="text-base font-bold text-emerald-700">+${savingsAmount} / Year</span>
                </div>
              ) : (
                <div className="pt-2.5 border-t border-slate-200 text-xs">
                  <span className="text-slate-500">Toggle to <button onClick={() => setBillingCycle('annual')} className="text-emerald-600 font-bold underline hover:text-emerald-700">Annual Billing</button> to unlock savings!</span>
                </div>
              )}
            </div>

          </div>
        </div>
      </section>

      {/* Pricing FAQs */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-16">
        <div className="text-center max-w-xl mx-auto mb-10">
          <h3 className="text-xl font-bold tracking-tight text-slate-900">Pricing FAQs</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs sm:text-sm">
          {faqs.map((faq, i) => (
            <div key={i} className="p-5 bg-white rounded-xl border border-slate-200 shadow-sm space-y-2">
              <h4 className="font-bold text-slate-900">{faq.q}</h4>
              <p className="text-slate-600 leading-relaxed text-xs">{faq.a}</p>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
}
