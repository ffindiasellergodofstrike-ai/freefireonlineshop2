import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  TrendingUp, Shield, BarChart3, Users, ChevronRight, 
  ArrowRight, Landmark, Lock, RefreshCw, Layers, Check, 
  HelpCircle, ChevronDown, Award, Sparkles, MessageSquare
} from 'lucide-react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, BarChart, Bar 
} from 'recharts';

// Fictional data for visualization chart
const chartData = {
  monthly: [
    { name: 'Jan', Income: 4200, Expenses: 2100, Savings: 2100 },
    { name: 'Feb', Income: 4500, Expenses: 2300, Savings: 2200 },
    { name: 'Mar', Income: 5100, Expenses: 2400, Savings: 2700 },
    { name: 'Apr', Income: 4800, Expenses: 2200, Savings: 2600 },
    { name: 'May', Income: 5800, Expenses: 2800, Savings: 3000 },
    { name: 'Jun', Income: 6200, Expenses: 2900, Savings: 3300 },
    { name: 'Jul', Income: 6500, Expenses: 3100, Savings: 3400 },
  ],
  quarterly: [
    { name: 'Q1', Income: 13800, Expenses: 6800, Savings: 7000 },
    { name: 'Q2', Income: 16800, Expenses: 7900, Savings: 8900 },
    { name: 'Q3', Income: 19500, Expenses: 9000, Savings: 10500 },
  ]
};

export default function Home() {
  const [activeTab, setActiveTab] = useState('monthly');
  const [openFaq, setOpenFaq] = useState(null);

  const toggleFaq = (index) => {
    setOpenFaq(openFaq === index ? null : index);
  };

  const faqs = [
    {
      q: "How does Finora secure my financial data?",
      a: "Finora employs robust client-side encryption techniques. Your private access keys and transaction parameters are compiled and processed locally in your browser. We never store, sell, or broker your personal financial details, ensuring absolute data sovereign protection."
    },
    {
      q: "Is there any real-world banking integration available in this template?",
      a: "Finora is a premium high-fidelity fintech design template. This version demonstrates premium interface engineering, fully functional charts, simulated ledger state engines, and client-side calculators. Actual bank feeds are represented by high-fidelity fictional datasets and simulation engines."
    },
    {
      q: "Can I use Finora for multiple business accounts?",
      a: "Yes! Our Pro and Enterprise configurations support multi-entity account management. You can configure up to 10 separate virtual organization structures inside our dashboard simulation to model complex treasury flows."
    },
    {
      q: "Are there any hidden transaction fees?",
      a: "No hidden charges whatsoever. Finora features flat-rate subscription models with complete, transparent cost breakdowns. Simulated ledger transfers run on virtual credits for zero-cost exploration."
    }
  ];

  return (
    <div className="bg-slate-50 min-h-screen text-slate-800 font-sans">
      
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden pt-12 pb-20 lg:pt-20 lg:pb-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Hero Text */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-50 text-emerald-700 rounded-full text-xs font-semibold tracking-wide border border-emerald-100">
                <Sparkles className="h-3.5 w-3.5" />
                <span>Next-Gen Financial Intelligence</span>
              </div>
              
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight leading-[1.1] text-balance">
                Simple tools for a <span className="text-emerald-600 relative">clearer</span> financial future.
              </h1>
              
              <p className="text-lg text-slate-600 max-w-xl mx-auto lg:mx-0 leading-relaxed">
                Take command of your wealth. Finora simplifies budgeting, aggregates multi-account simulations, and visualizes cash flow with pristine precision.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-3 justify-center lg:justify-start pt-2">
                <Link
                  to="/signup"
                  className="inline-flex items-center justify-center px-6 py-3.5 border border-transparent text-base font-bold rounded-xl text-white bg-emerald-600 hover:bg-emerald-500 shadow-lg shadow-emerald-600/10 hover:shadow-emerald-600/20 transition-all hover:translate-y-[-1px] gap-2"
                >
                  Create Free Account
                  <ArrowRight className="h-5 w-5" />
                </Link>
                <Link
                  to="/dashboard"
                  className="inline-flex items-center justify-center px-6 py-3.5 border border-slate-200 text-base font-bold rounded-xl text-slate-700 bg-white hover:bg-slate-50 shadow-sm hover:border-slate-300 transition-all hover:translate-y-[-1px]"
                >
                  Explore Live Demo
                </Link>
              </div>

              {/* Trust Indicators */}
              <div className="pt-6 border-t border-slate-100 flex flex-wrap gap-x-8 gap-y-4 justify-center lg:justify-start text-xs text-slate-500">
                <div className="flex items-center gap-1.5">
                  <Shield className="h-4 w-4 text-emerald-600" />
                  <span>Client-Side Sandbox Encryption</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <TrendingUp className="h-4 w-4 text-emerald-600" />
                  <span>Interactive Real-time Visualizers</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Award className="h-4 w-4 text-emerald-600" />
                  <span>Premium Design Excellence</span>
                </div>
              </div>
            </div>

            {/* Hero Interactive Mini Dashboard Image / Graphic */}
            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto max-w-md lg:max-w-none bg-white p-6 rounded-2xl shadow-2xl border border-slate-100/80 animate-in fade-in zoom-in-95 duration-500">
                
                {/* Header Row */}
                <div className="flex justify-between items-center mb-6 border-b border-slate-50 pb-4">
                  <div>
                    <span className="text-xs font-semibold text-slate-400 block uppercase tracking-wider">Estimated Balance</span>
                    <span className="text-2xl font-bold text-slate-900 tracking-tight">$84,392.50</span>
                  </div>
                  <span className="bg-emerald-50 text-emerald-700 text-xs font-bold px-2.5 py-1 rounded-lg border border-emerald-100">
                    +14.2% MoM
                  </span>
                </div>

                {/* Simulated Sparkline / Chart */}
                <div className="h-40 w-full mb-6">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={chartData.monthly} margin={{ top: 5, right: 5, left: -25, bottom: 5 }}>
                      <defs>
                        <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#10b981" stopOpacity={0.2}/>
                          <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} tickLine={false} />
                      <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} />
                      <Tooltip />
                      <Area type="monotone" dataKey="Income" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorIncome)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>

                {/* Mock Transactions */}
                <div className="space-y-3">
                  <div className="flex justify-between items-center p-2.5 hover:bg-slate-50 rounded-lg transition-colors border border-dashed border-slate-100">
                    <div className="flex items-center gap-3">
                      <div className="h-8 w-8 rounded-full bg-slate-100 flex items-center justify-center text-xs font-bold text-slate-700">
                        S
                      </div>
                      <div>
                        <span className="text-xs font-bold text-slate-800 block">SaaS Subscription</span>
                        <span className="text-[10px] text-slate-400">Marketing Tool • 10:24 AM</span>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-slate-900">-$49.00</span>
                  </div>
                  <div className="flex justify-between items-center p-2.5 hover:bg-slate-50 rounded-lg transition-colors border border-dashed border-slate-100">
                    <div className="flex items-center gap-3">
                      <div className="h-8 w-8 rounded-full bg-emerald-50 text-emerald-700 flex items-center justify-center text-xs font-bold">
                        P
                      </div>
                      <div>
                        <span className="text-xs font-bold text-slate-800 block">Payout Received</span>
                        <span className="text-[10px] text-slate-400">Acme Corp Ltd • Yesterday</span>
                      </div>
                    </div>
                    <span className="text-xs font-bold text-emerald-600">+$2,450.00</span>
                  </div>
                </div>

                {/* Dashboard Shortcut link */}
                <div className="mt-5 text-center">
                  <Link 
                    to="/dashboard" 
                    className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 inline-flex items-center gap-1 group"
                  >
                    Interact with real sandbox metrics
                    <ChevronRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
                  </Link>
                </div>

              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 2. SECURITY & TRUST SECTION */}
      <section className="py-10 bg-slate-900 text-slate-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-xl mx-auto mb-8">
            <span className="text-xs font-bold uppercase tracking-widest text-emerald-400 block mb-1">
              Zero Trust Architecture
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Premium client-side security you can count on
            </h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
            <div className="p-5 rounded-xl bg-slate-800/50 border border-slate-800 hover:border-slate-700 transition-colors">
              <div className="inline-flex p-3 bg-emerald-950 text-emerald-400 rounded-lg mb-3">
                <Lock className="h-6 w-6" />
              </div>
              <h3 className="font-bold text-white text-base mb-1.5">No Credential Caching</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                We design with offline-first capabilities. Credentials stay on your machine, preventing global network breaches.
              </p>
            </div>
            <div className="p-5 rounded-xl bg-slate-800/50 border border-slate-800 hover:border-slate-700 transition-colors">
              <div className="inline-flex p-3 bg-emerald-950 text-emerald-400 rounded-lg mb-3">
                <RefreshCw className="h-6 w-6" />
              </div>
              <h3 className="font-bold text-white text-base mb-1.5">Zero-Knowledge Ledger</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Your data schemas reside purely in system memory during active sessions and sync selectively. 
              </p>
            </div>
            <div className="p-5 rounded-xl bg-slate-800/50 border border-slate-800 hover:border-slate-700 transition-colors">
              <div className="inline-flex p-3 bg-emerald-950 text-emerald-400 rounded-lg mb-3">
                <Layers className="h-6 w-6" />
              </div>
              <h3 className="font-bold text-white text-base mb-1.5">Fictional Compliance Sandbox</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                All security modules model standard protocols, demonstrating top-tier engineering without making unsupported claims.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 3. CORE FEATURES GRID */}
      <section className="py-16 sm:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Section Header */}
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-xs font-bold uppercase tracking-widest text-emerald-600 block mb-2">
              Everything You Need
            </h2>
            <p className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              Equipped with elite features to supercharge your tracking
            </p>
            <p className="text-base text-slate-600 mt-4 leading-relaxed">
              We design and construct digital assets with strict spatial rhythm. Discover features optimized for ultimate financial clarity.
            </p>
          </div>

          {/* Features Layout */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            
            {/* Feature Card 1 */}
            <div className="group p-6 rounded-2xl bg-slate-50 border border-slate-100 hover:border-emerald-500/20 hover:bg-white hover:shadow-xl transition-all duration-300">
              <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl inline-block mb-4 transition-transform group-hover:scale-110">
                <BarChart3 className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">Dynamic Projections</h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Input your savings goals and visualize compound curves over 5, 10, or 25 years. Plan your early retirement seamlessly.
              </p>
              <Link to="/features" className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 inline-flex items-center gap-1 mt-4">
                Explore Projections <ChevronRight className="h-3.5 w-3.5" />
              </Link>
            </div>

            {/* Feature Card 2 */}
            <div className="group p-6 rounded-2xl bg-slate-50 border border-slate-100 hover:border-emerald-500/20 hover:bg-white hover:shadow-xl transition-all duration-300">
              <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl inline-block mb-4 transition-transform group-hover:scale-110">
                <Landmark className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">Multi-Entity Ledger</h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Seamlessly model individual cash repositories, startup investment terms, and business tax calculations in one workspace.
              </p>
              <Link to="/solutions" className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 inline-flex items-center gap-1 mt-4">
                Explore Multi-Entity <ChevronRight className="h-3.5 w-3.5" />
              </Link>
            </div>

            {/* Feature Card 3 */}
            <div className="group p-6 rounded-2xl bg-slate-50 border border-slate-100 hover:border-emerald-500/20 hover:bg-white hover:shadow-xl transition-all duration-300">
              <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl inline-block mb-4 transition-transform group-hover:scale-110">
                <Shield className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">Bulletproof Encryption</h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                We model high-tier corporate security patterns locally. Generate physical-key seeds to safeguard data export packets.
              </p>
              <Link to="/security" className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 inline-flex items-center gap-1 mt-4">
                View Security Hub <ChevronRight className="h-3.5 w-3.5" />
              </Link>
            </div>

            {/* Feature Card 4 */}
            <div className="group p-6 rounded-2xl bg-slate-50 border border-slate-100 hover:border-emerald-500/20 hover:bg-white hover:shadow-xl transition-all duration-300">
              <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl inline-block mb-4 transition-transform group-hover:scale-110">
                <TrendingUp className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">Trend Analysis</h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Discover patterns in your daily transactions. Finora groups expenditures dynamically, notifying you of regular leakages.
              </p>
              <Link to="/dashboard" className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 inline-flex items-center gap-1 mt-4">
                Open Trend Sandbox <ChevronRight className="h-3.5 w-3.5" />
              </Link>
            </div>

            {/* Feature Card 5 */}
            <div className="group p-6 rounded-2xl bg-slate-50 border border-slate-100 hover:border-emerald-500/20 hover:bg-white hover:shadow-xl transition-all duration-300">
              <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl inline-block mb-4 transition-transform group-hover:scale-110">
                <Users className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">Collaborative Budgets</h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Share isolated simulation URLs with family or startup co-founders to align dynamic asset management without security risks.
              </p>
              <Link to="/solutions" className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 inline-flex items-center gap-1 mt-4">
                Explore Shared Boards <ChevronRight className="h-3.5 w-3.5" />
              </Link>
            </div>

            {/* Feature Card 6 */}
            <div className="group p-6 rounded-2xl bg-slate-50 border border-slate-100 hover:border-emerald-500/20 hover:bg-white hover:shadow-xl transition-all duration-300">
              <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl inline-block mb-4 transition-transform group-hover:scale-110">
                <RefreshCw className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">Offline Sovereignty</h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Export all datasets as encrypted CSV or JSON bundles instantly. Keep complete tactile mastery over your historical files.
              </p>
              <Link to="/resources" className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 inline-flex items-center gap-1 mt-4">
                Access Documentation <ChevronRight className="h-3.5 w-3.5" />
              </Link>
            </div>

          </div>
        </div>
      </section>

      {/* 4. FINANCIAL INSIGHTS & DYNAMIC TRANSACTION VISUALIZATION */}
      <section className="py-16 sm:py-20 bg-slate-50 border-y border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Content Column */}
            <div className="lg:col-span-5 space-y-6">
              <span className="text-xs font-bold uppercase tracking-widest text-emerald-600 block mb-1">
                Visualizing Liquid Flow
              </span>
              <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight leading-tight">
                Clear insights to unlock smarter cash flow allocations
              </h2>
              <p className="text-slate-600 text-sm leading-relaxed">
                Raw ledger logs are complex. Finora refines static transactional reports into simple, highly legible visual layouts. Use our projection switch to model long-term curves instantly.
              </p>

              {/* Toggle controls */}
              <div className="inline-flex p-1 bg-slate-200/80 rounded-lg">
                <button
                  onClick={() => setActiveTab('monthly')}
                  className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all ${
                    activeTab === 'monthly' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Monthly Scope
                </button>
                <button
                  onClick={() => setActiveTab('quarterly')}
                  className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all ${
                    activeTab === 'quarterly' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Quarterly Scope
                </button>
              </div>

              {/* Key insight highlights */}
              <div className="space-y-3.5 pt-2">
                <div className="flex gap-3 items-start">
                  <div className="p-1 bg-emerald-100 rounded-md text-emerald-700 mt-0.5">
                    <Check className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">Calculated Compound Buffer</h4>
                    <p className="text-xs text-slate-500">Savings rates are simulated based on standard compounding cycles, optimizing reserves.</p>
                  </div>
                </div>
                <div className="flex gap-3 items-start">
                  <div className="p-1 bg-emerald-100 rounded-md text-emerald-700 mt-0.5">
                    <Check className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">Segmented Overhead Warning</h4>
                    <p className="text-xs text-slate-500">Automatically alerts when total fixed expenses cross 45% of total recurring simulated revenue.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Interactive Chart Column */}
            <div className="lg:col-span-7 bg-white p-6 rounded-2xl shadow-xl border border-slate-100/80">
              <div className="flex justify-between items-center mb-6">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">Aggregated Sandbox Ledger</h3>
                  <p className="text-[11px] text-slate-400">Continuous model representation of income vs outflow</p>
                </div>
                <span className="text-[11px] font-semibold text-slate-500 px-2 py-1 bg-slate-100 rounded-md">
                  Recharts-Powered Engine
                </span>
              </div>

              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData[activeTab]} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorInc" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.15}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorExp" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.15}/>
                        <stop offset="95%" stopColor="#f43f5e" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} tickLine={false} />
                    <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
                    <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid #f1f5f9', fontSize: '12px' }} />
                    <Area type="monotone" dataKey="Income" stroke="#10b981" strokeWidth={2.5} fillOpacity={1} fill="url(#colorInc)" />
                    <Area type="monotone" dataKey="Expenses" stroke="#f43f5e" strokeWidth={2.5} fillOpacity={1} fill="url(#colorExp)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              <div className="mt-4 pt-4 border-t border-slate-100 grid grid-cols-3 gap-2 text-center">
                <div>
                  <span className="block text-[10px] uppercase font-bold text-slate-400">Total Simulated Income</span>
                  <span className="text-base font-bold text-emerald-600">
                    {activeTab === 'monthly' ? '$37,600.00' : '$50,100.00'}
                  </span>
                </div>
                <div>
                  <span className="block text-[10px] uppercase font-bold text-slate-400">Simulated Expenses</span>
                  <span className="text-base font-bold text-rose-500">
                    {activeTab === 'monthly' ? '$17,300.00' : '$23,700.00'}
                  </span>
                </div>
                <div>
                  <span className="block text-[10px] uppercase font-bold text-slate-400">Net Saved Capital</span>
                  <span className="text-base font-bold text-slate-800">
                    {activeTab === 'monthly' ? '$20,300.00' : '$26,400.00'}
                  </span>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 5. BENEFITS SECTION (Comparison table) */}
      <section className="py-16 sm:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-xs font-bold uppercase tracking-widest text-emerald-600 block mb-2">Platform Advantage</h2>
            <p className="text-3xl font-extrabold text-slate-900 tracking-tight">How does Finora stack up?</p>
            <p className="text-slate-500 text-sm mt-3">See why modern planners leave traditional worksheets behind for Finora.</p>
          </div>

          <div className="overflow-x-auto max-w-4xl mx-auto rounded-xl border border-slate-150 shadow-sm bg-white">
            <table className="w-full text-left border-collapse min-w-[500px]">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100 text-xs font-bold uppercase tracking-wider text-slate-500">
                  <th className="p-4 sm:p-5">Strategic Feature</th>
                  <th className="p-4 sm:p-5 text-emerald-700 bg-emerald-50/50">Finora Platform</th>
                  <th className="p-4 sm:p-5">Traditional Banks</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm text-slate-700">
                <tr>
                  <td className="p-4 sm:p-5 font-semibold text-slate-900">Ledger Customization</td>
                  <td className="p-4 sm:p-5 text-emerald-600 font-bold bg-emerald-50/20">Unlimited virtual accounts</td>
                  <td className="p-4 sm:p-5">Locked into rigid accounts</td>
                </tr>
                <tr>
                  <td className="p-4 sm:p-5 font-semibold text-slate-900">Data Privacy Sovereignty</td>
                  <td className="p-4 sm:p-5 text-emerald-600 font-bold bg-emerald-50/20">No external brokerage / sales</td>
                  <td className="p-4 sm:p-5">Shares financial dossiers</td>
                </tr>
                <tr>
                  <td className="p-4 sm:p-5 font-semibold text-slate-900">Compound Projections</td>
                  <td className="p-4 sm:p-5 text-emerald-600 font-bold bg-emerald-50/20">Interactive multi-variable math</td>
                  <td className="p-4 sm:p-5">Static spreadsheets only</td>
                </tr>
                <tr>
                  <td className="p-4 sm:p-5 font-semibold text-slate-900">Multi-Entity Workspace</td>
                  <td className="p-4 sm:p-5 text-emerald-600 font-bold bg-emerald-50/20">Included by default</td>
                  <td className="p-4 sm:p-5">Expensive commercial add-on</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* 6. TESTIMONIALS SECTION */}
      <section className="py-16 sm:py-20 bg-slate-900 text-white relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-2xl mx-auto mb-14">
            <span className="text-xs font-bold uppercase tracking-widest text-emerald-400 block mb-2">Customer Proof</span>
            <h2 className="text-3xl font-extrabold tracking-tight">Endorsed by premium creators</h2>
            <p className="text-slate-400 text-sm mt-3">Read how users globally leverage our sandbox interface to find true clarity.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            {/* Testimonial 1 */}
            <div className="p-6 rounded-xl bg-slate-800/80 border border-slate-800 flex flex-col justify-between space-y-6">
              <p className="text-slate-300 text-xs italic leading-relaxed">
                "Finora completely transformed our startup budgeting. Modeling dynamic tax rates and founder payouts client-side before committing funds saved us thousands in mistakes."
              </p>
              <div className="flex items-center gap-3 border-t border-slate-700/50 pt-4">
                <div className="h-9 w-9 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-xs">
                  HS
                </div>
                <div>
                  <span className="block text-xs font-bold text-white">Harriot Sinclair</span>
                  <span className="block text-[10px] text-slate-400">Co-founder, HexaPulse Tech</span>
                </div>
              </div>
            </div>

            {/* Testimonial 2 */}
            <div className="p-6 rounded-xl bg-slate-800/80 border border-slate-800 flex flex-col justify-between space-y-6">
              <p className="text-slate-300 text-xs italic leading-relaxed">
                "I was looking for a beautiful, offline-friendly tool to visualize my personal real estate compound savings curves. Finora handles Recharts-level visualization elegantly."
              </p>
              <div className="flex items-center gap-3 border-t border-slate-700/50 pt-4">
                <div className="h-9 w-9 rounded-full bg-slate-700 text-white font-bold flex items-center justify-center text-xs">
                  MA
                </div>
                <div>
                  <span className="block text-xs font-bold text-white">Marcelle Aubert</span>
                  <span className="block text-[10px] text-slate-400">Real Estate Allocator</span>
                </div>
              </div>
            </div>

            {/* Testimonial 3 */}
            <div className="p-6 rounded-xl bg-slate-800/80 border border-slate-800 flex flex-col justify-between space-y-6">
              <p className="text-slate-300 text-xs italic leading-relaxed">
                "Simple, pristine, and secure. Having complete control over data export variables without forced APIs gives me total sovereign peace of mind."
              </p>
              <div className="flex items-center gap-3 border-t border-slate-700/50 pt-4">
                <div className="h-9 w-9 rounded-full bg-emerald-700 text-white font-bold flex items-center justify-center text-xs">
                  JL
                </div>
                <div>
                  <span className="block text-xs font-bold text-white">Jonathan Low</span>
                  <span className="block text-[10px] text-slate-400">Independent Consultant</span>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 7. PRICING TASTING ROW */}
      <section className="py-16 sm:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-xs font-bold uppercase tracking-widest text-emerald-600 block mb-2">Transparent Plans</span>
            <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Flexible tiers for every scenario</h2>
            <p className="text-slate-500 text-sm mt-3">Choose a package tailored to your scope. Fully offline or aggregate synced ledger options.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            
            {/* Tier 1 */}
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-100 flex flex-col justify-between">
              <div>
                <span className="text-xs font-bold text-slate-400 block uppercase mb-1">Standard Scope</span>
                <h3 className="text-xl font-bold text-slate-900">Personal Free</h3>
                <p className="text-xs text-slate-500 mt-2 min-h-[36px]">Perfect for single-person sandboxing and clean basic budget tracking.</p>
                <div className="my-5">
                  <span className="text-3xl font-black text-slate-900">$0</span>
                  <span className="text-xs text-slate-500"> / perpetual</span>
                </div>
                <ul className="space-y-2.5 text-xs text-slate-600 border-t border-slate-200/50 pt-4">
                  <li className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-600" /> <span>3 Virtual Ledger Entities</span></li>
                  <li className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-600" /> <span>Standard Compound Calculator</span></li>
                  <li className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-600" /> <span>Encrypted Local Storage Packets</span></li>
                </ul>
              </div>
              <Link to="/signup" className="mt-6 w-full text-center py-2.5 px-4 text-xs font-bold text-slate-700 bg-white hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors">
                Get Started Free
              </Link>
            </div>

            {/* Tier 2 */}
            <div className="p-6 rounded-2xl bg-white border-2 border-emerald-500 flex flex-col justify-between relative shadow-lg">
              <span className="absolute top-0 right-6 translate-y-[-50%] bg-emerald-500 text-white text-[10px] font-bold uppercase tracking-widest px-2.5 py-0.5 rounded-full">
                Most Popular
              </span>
              <div>
                <span className="text-xs font-bold text-emerald-600 block uppercase mb-1">Advanced Scope</span>
                <h3 className="text-xl font-bold text-slate-900">Finora Professional</h3>
                <p className="text-xs text-slate-500 mt-2 min-h-[36px]">Engineered for business allocators, startups, and active wealth managers.</p>
                <div className="my-5">
                  <span className="text-3xl font-black text-slate-900">$12</span>
                  <span className="text-xs text-slate-500"> / month</span>
                </div>
                <ul className="space-y-2.5 text-xs text-slate-600 border-t border-slate-200/50 pt-4">
                  <li className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-600" /> <span className="font-semibold text-slate-900">Unlimited Virtual Ledgers</span></li>
                  <li className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-600" /> <span>All High-fidelity Recharts Layouts</span></li>
                  <li className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-600" /> <span>Dynamic Interactive Projection Math</span></li>
                  <li className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-600" /> <span>Encrypted CSV/JSON Data Packets</span></li>
                </ul>
              </div>
              <Link to="/signup" className="mt-6 w-full text-center py-2.5 px-4 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors shadow-md shadow-emerald-500/15">
                Start Pro Account
              </Link>
            </div>

            {/* Tier 3 */}
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-100 flex flex-col justify-between">
              <div>
                <span className="text-xs font-bold text-slate-400 block uppercase mb-1">Corporate Scope</span>
                <h3 className="text-xl font-bold text-slate-900">Enterprise</h3>
                <p className="text-xs text-slate-500 mt-2 min-h-[36px]">Bespoke virtual modeling grids with custom permission rules.</p>
                <div className="my-5">
                  <span className="text-3xl font-black text-slate-900">$39</span>
                  <span className="text-xs text-slate-500"> / month</span>
                </div>
                <ul className="space-y-2.5 text-xs text-slate-600 border-t border-slate-200/50 pt-4">
                  <li className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-600" /> <span>All Professional Plan Capabilities</span></li>
                  <li className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-600" /> <span>Custom Sandbox Modeling Frameworks</span></li>
                  <li className="flex items-center gap-2"><Check className="h-4 w-4 text-emerald-600" /> <span>Priority Support Engineering Tickets</span></li>
                </ul>
              </div>
              <Link to="/contact" className="mt-6 w-full text-center py-2.5 px-4 text-xs font-bold text-slate-700 bg-white hover:bg-slate-100 rounded-lg border border-slate-200 transition-colors">
                Contact Enterprise
              </Link>
            </div>

          </div>
        </div>
      </section>

      {/* 8. FAQ ACCORDION */}
      <section className="py-16 sm:py-24 bg-slate-50 border-t border-slate-100">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-xs font-bold uppercase tracking-widest text-emerald-600 block mb-2">FAQ</h2>
            <p className="text-3xl font-extrabold text-slate-900 tracking-tight">Got Questions? We’ve got answers.</p>
            <p className="text-slate-500 text-sm mt-3">Learn more about how our platform preserves privacy while offering visual power.</p>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div 
                key={index} 
                className="bg-white rounded-xl border border-slate-150 overflow-hidden shadow-sm transition-all"
              >
                <button
                  onClick={() => toggleFaq(index)}
                  className="w-full flex justify-between items-center p-5 text-left font-bold text-slate-800 hover:text-slate-900 text-sm sm:text-base focus:outline-none"
                >
                  <span>{faq.q}</span>
                  <ChevronDown className={`h-5 w-5 text-slate-400 transition-transform ${openFaq === index ? 'rotate-180' : ''}`} />
                </button>
                
                {openFaq === index && (
                  <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-50">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* 9. CALL TO ACTION (CTA) */}
      <section className="bg-emerald-600 text-white py-16 sm:py-20 relative overflow-hidden">
        {/* Subtle decorative grid effect using CSS */}
        <div className="absolute inset-0 opacity-10 bg-[linear-gradient(to_right,#808080_1px,transparent_1px),linear-gradient(to_bottom,#808080_1px,transparent_1px)] bg-[size:24px_24px]"></div>
        
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative text-center space-y-6">
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
            Ready to experience absolute financial clarity?
          </h2>
          <p className="text-base text-emerald-100 max-w-xl mx-auto leading-relaxed">
            Join thousands of modern wealth allocators already sandboxing their financial targets with Finora. Start free today.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center pt-2">
            <Link
              to="/signup"
              className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-sm font-bold rounded-xl text-emerald-700 bg-white hover:bg-emerald-50 shadow-md transition-all hover:translate-y-[-1px]"
            >
              Get Started Free
            </Link>
            <Link
              to="/dashboard"
              className="inline-flex items-center justify-center px-6 py-3 border border-emerald-500 text-sm font-bold rounded-xl text-white bg-emerald-700 hover:bg-emerald-800 transition-all hover:translate-y-[-1px]"
            >
              Interactive Sandbox Preview
            </Link>
          </div>
        </div>
      </section>

    </div>
  );
}
