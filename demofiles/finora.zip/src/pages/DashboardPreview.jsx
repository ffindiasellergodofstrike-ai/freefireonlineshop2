import React, { useState, useMemo } from 'react';
import { 
  Wallet, TrendingUp, TrendingDown, Bell, Landmark, CreditCard, 
  Plus, Trash2, Check, RefreshCw, ChevronRight, Sparkles, Download, Calendar
} from 'lucide-react';
import { 
  ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, 
  Tooltip, BarChart, Bar, Cell, PieChart, Pie 
} from 'recharts';

export default function DashboardPreview() {
  const [activeAccount, setActiveAccount] = useState('personal'); // 'personal', 'cash', 'venture'
  
  // Simulated initial transactions by account
  const [transactions, setTransactions] = useState({
    personal: [
      { id: 1, desc: 'SaaS Platform Payout', category: 'Income', amount: 3450.00, type: 'income', date: '2026-09-21' },
      { id: 2, desc: 'Premium Host Provider', category: 'Infrastructure', amount: -120.00, type: 'expense', date: '2026-09-20' },
      { id: 3, desc: 'Visual Typography Assets', category: 'Design', amount: -45.00, type: 'expense', date: '2026-09-18' },
      { id: 4, desc: 'Independent Design Project', category: 'Income', amount: 800.00, type: 'income', date: '2026-09-15' }
    ],
    cash: [
      { id: 1, desc: 'Local Coffee Shop', category: 'Dining', amount: -8.50, type: 'expense', date: '2026-09-21' },
      { id: 2, desc: 'Atm Withdrawal', category: 'Cash Transfer', amount: 200.00, type: 'income', date: '2026-09-19' },
      { id: 3, desc: 'Transit Fare Ticket', category: 'Transit', amount: -15.00, type: 'expense', date: '2026-09-18' }
    ],
    venture: [
      { id: 1, desc: 'Seed Series Investment', category: 'Investment', amount: 75000.00, type: 'income', date: '2026-09-20' },
      { id: 2, desc: 'Initial Payroll Block', category: 'Salary', amount: -12000.00, type: 'expense', date: '2026-09-15' },
      { id: 3, desc: 'Legal Entity Registry', category: 'Legal', amount: -1500.00, type: 'expense', date: '2026-09-14' }
    ]
  });

  // Notifications state
  const [notifications, setNotifications] = useState([
    { id: 1, msg: "Sovereign backup export generated successfully.", read: false },
    { id: 2, msg: "Simulated compound buffer targets updated for Q3.", read: false }
  ]);

  // Form states to add custom transaction
  const [newDesc, setNewDesc] = useState('');
  const [newCategory, setNewCategory] = useState('General');
  const [newAmount, setNewAmount] = useState('');
  const [newType, setNewType] = useState('expense'); // 'income' or 'expense'

  // Calculations based on active account
  const activeTxList = transactions[activeAccount] || [];

  const totals = useMemo(() => {
    let income = 0;
    let expenses = 0;
    activeTxList.forEach(tx => {
      if (tx.amount > 0) {
        income += tx.amount;
      } else {
        expenses += Math.abs(tx.amount);
      }
    });

    const startingBalance = activeAccount === 'personal' ? 80207.50 : activeAccount === 'cash' ? 120.00 : 250000.00;
    const balance = startingBalance + income - expenses;

    return {
      balance,
      income,
      expenses
    };
  }, [activeTxList, activeAccount]);

  // spending category breakdown for Recharts Pie
  const spendingBreakdown = useMemo(() => {
    const categories = {};
    activeTxList.forEach(tx => {
      if (tx.amount < 0) {
        const cat = tx.category;
        categories[cat] = (categories[cat] || 0) + Math.abs(tx.amount);
      }
    });

    return Object.keys(categories).map(cat => ({
      name: cat,
      value: Math.round(categories[cat])
    }));
  }, [activeTxList]);

  // Monthly report simulated chart data
  const reportChartData = useMemo(() => {
    // Basic standard layout
    return [
      { name: 'Jul', Income: totals.income * 0.8, Expenses: totals.expenses * 0.9 },
      { name: 'Aug', Income: totals.income * 0.95, Expenses: totals.expenses * 0.85 },
      { name: 'Current', Income: totals.income, Expenses: totals.expenses }
    ];
  }, [totals]);

  const COLORS = ['#10b981', '#f43f5e', '#3b82f6', '#f59e0b', '#8b5cf6'];

  const handleAddTransaction = (e) => {
    e.preventDefault();
    if (!newDesc.trim()) {
      alert("Please enter transaction description.");
      return;
    }
    const parsedAmount = parseFloat(newAmount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      alert("Please enter a valid positive number for amount.");
      return;
    }

    const finalAmount = newType === 'expense' ? -parsedAmount : parsedAmount;
    const newTx = {
      id: Date.now(),
      desc: newDesc,
      category: newCategory,
      amount: finalAmount,
      type: newType,
      date: new Date().toISOString().split('T')[0]
    };

    // Update transactions list
    setTransactions(prev => ({
      ...prev,
      [activeAccount]: [newTx, ...prev[activeAccount]]
    }));

    // Trigger custom alert notification
    const alertMsg = `Added transaction: "${newDesc}" of $${parsedAmount.toFixed(2)}`;
    setNotifications(prev => [
      { id: Date.now(), msg: alertMsg, read: false },
      ...prev
    ]);

    // Reset fields
    setNewDesc('');
    setNewAmount('');
  };

  const handleDeleteTransaction = (id) => {
    setTransactions(prev => ({
      ...prev,
      [activeAccount]: prev[activeAccount].filter(tx => tx.id !== id)
    }));
  };

  const handleClearNotification = (id) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const formatter = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
  });

  return (
    <div className="bg-slate-50 min-h-screen text-slate-800 font-sans pb-16">
      
      {/* Top Banner Row */}
      <section className="bg-white border-b border-slate-100 pt-6 pb-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <div className="flex items-center gap-1.5 text-emerald-700">
              <Sparkles className="h-4 w-4" />
              <span className="text-xs font-bold uppercase tracking-widest">Active Simulation Console</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">Finora Sandbox Ledger</h1>
          </div>
          
          {/* Quick Stats Banner */}
          <div className="flex flex-wrap gap-4 text-xs">
            <div className="bg-slate-100 px-3.5 py-1.5 rounded-lg border border-slate-150">
              <span className="text-slate-400 font-bold uppercase text-[9px] block">Database Scope</span>
              <span className="font-extrabold text-slate-700">Local Sandbox</span>
            </div>
            <div className="bg-emerald-50 text-emerald-700 px-3.5 py-1.5 rounded-lg border border-emerald-100">
              <span className="text-emerald-600 font-bold uppercase text-[9px] block">Security Protocol</span>
              <span className="font-extrabold">Browser Sandbox Caching</span>
            </div>
          </div>
        </div>
      </section>

      {/* Main Grid Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* LEFT COLUMN: VIRTUAL ACCOUNTS & NOTIFICATIONS (Col Span 4) */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* Account Selector Cards */}
            <div className="space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 block">Virtual Repositories</span>
              
              {/* Card 1 */}
              <button
                onClick={() => setActiveAccount('personal')}
                className={`w-full p-4 rounded-xl text-left border-2 transition-all flex justify-between items-center ${
                  activeAccount === 'personal'
                    ? 'bg-white border-emerald-600 shadow-md translate-y-[-1px]'
                    : 'bg-white/50 border-slate-200/60 hover:bg-white hover:border-slate-300'
                }`}
              >
                <div className="flex gap-3 items-center">
                  <div className={`p-2.5 rounded-lg ${activeAccount === 'personal' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                    <CreditCard className="h-4 w-4" />
                  </div>
                  <div>
                    <span className="block text-xs font-bold text-slate-900">Personal Cash Reserves</span>
                    <span className="block text-[10px] text-slate-400">Main banking simulator</span>
                  </div>
                </div>
                <ChevronRight className="h-4 w-4 text-slate-400" />
              </button>

              {/* Card 2 */}
              <button
                onClick={() => setActiveAccount('cash')}
                className={`w-full p-4 rounded-xl text-left border-2 transition-all flex justify-between items-center ${
                  activeAccount === 'cash'
                    ? 'bg-white border-emerald-600 shadow-md translate-y-[-1px]'
                    : 'bg-white/50 border-slate-200/60 hover:bg-white hover:border-slate-300'
                }`}
              >
                <div className="flex gap-3 items-center">
                  <div className={`p-2.5 rounded-lg ${activeAccount === 'cash' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                    <Wallet className="h-4 w-4" />
                  </div>
                  <div>
                    <span className="block text-xs font-bold text-slate-900">Physical Pocket Cash</span>
                    <span className="block text-[10px] text-slate-400">Micro-transactions ledger</span>
                  </div>
                </div>
                <ChevronRight className="h-4 w-4 text-slate-400" />
              </button>

              {/* Card 3 */}
              <button
                onClick={() => setActiveAccount('venture')}
                className={`w-full p-4 rounded-xl text-left border-2 transition-all flex justify-between items-center ${
                  activeAccount === 'venture'
                    ? 'bg-white border-emerald-600 shadow-md translate-y-[-1px]'
                    : 'bg-white/50 border-slate-200/60 hover:bg-white hover:border-slate-300'
                }`}
              >
                <div className="flex gap-3 items-center">
                  <div className={`p-2.5 rounded-lg ${activeAccount === 'venture' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-500'}`}>
                    <Landmark className="h-4 w-4" />
                  </div>
                  <div>
                    <span className="block text-xs font-bold text-slate-900">Venture Seed Treasury</span>
                    <span className="block text-[10px] text-slate-400">Startup capital buffer</span>
                  </div>
                </div>
                <ChevronRight className="h-4 w-4 text-slate-400" />
              </button>

            </div>

            {/* Notifications Console */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
              <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                <div className="flex items-center gap-1.5 text-slate-950 font-bold text-xs">
                  <Bell className="h-4 w-4 text-slate-500" />
                  <span>Platform Alerts</span>
                </div>
                {notifications.length > 0 && (
                  <button 
                    onClick={() => setNotifications([])}
                    className="text-[10px] text-rose-500 font-bold hover:underline"
                  >
                    Clear All
                  </button>
                )}
              </div>

              {notifications.length > 0 ? (
                <div className="space-y-2.5">
                  {notifications.map((n) => (
                    <div key={n.id} className="flex justify-between items-start gap-2 p-2.5 bg-slate-50 rounded-lg border border-slate-100 text-[11px] leading-snug">
                      <p className="text-slate-600">{n.msg}</p>
                      <button 
                        onClick={() => handleClearNotification(n.id)}
                        className="text-slate-400 hover:text-slate-900 font-bold flex-shrink-0"
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center text-[10px] text-slate-400 py-2">No new notifications in this session.</p>
              )}
            </div>

          </div>

          {/* RIGHT COLUMN: CORE DASHBOARD VISUALIZATIONS & LOGGING (Col Span 8) */}
          <div className="lg:col-span-8 space-y-6">
            
            {/* Core Metrics: Balance, Income, Expenses Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              
              {/* Balance Card */}
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-2">
                <span className="text-[10px] uppercase tracking-wider font-bold text-slate-400 block">Simulated Balance</span>
                <span className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight block">
                  {formatter.format(totals.balance)}
                </span>
                <span className="inline-block bg-emerald-50 text-emerald-700 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-100">
                  +11.2% this Month
                </span>
              </div>

              {/* Income Card */}
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-2">
                <span className="text-[10px] uppercase tracking-wider font-bold text-slate-400 block">Total Sandbox Income</span>
                <span className="text-xl sm:text-2xl font-black text-emerald-600 tracking-tight block">
                  {formatter.format(totals.income)}
                </span>
                <span className="text-[10px] text-slate-400 block flex items-center gap-1">
                  <TrendingUp className="h-3.5 w-3.5 text-emerald-600" />
                  Active ledger inflows
                </span>
              </div>

              {/* Expenses Card */}
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm space-y-2">
                <span className="text-[10px] uppercase tracking-wider font-bold text-slate-400 block">Active Expenses</span>
                <span className="text-xl sm:text-2xl font-black text-rose-500 tracking-tight block">
                  {formatter.format(totals.expenses)}
                </span>
                <span className="text-[10px] text-slate-400 block flex items-center gap-1">
                  <TrendingDown className="h-3.5 w-3.5 text-rose-500" />
                  Total simulated leakages
                </span>
              </div>

            </div>

            {/* Interactive Section: Add Fictional Transaction */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
              <div className="flex justify-between items-center border-b border-slate-100 pb-3.5 mb-4">
                <span className="text-xs font-bold text-slate-950 uppercase tracking-wider">Log Custom Simulated Transaction</span>
                <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded border border-emerald-100">
                  Zero Network Costs
                </span>
              </div>

              <form onSubmit={handleAddTransaction} className="grid grid-cols-1 sm:grid-cols-12 gap-3.5 items-end">
                {/* Description */}
                <div className="sm:col-span-4 space-y-1">
                  <label className="text-[10px] font-bold text-slate-600">Description</label>
                  <input
                    type="text"
                    value={newDesc}
                    onChange={(e) => setNewDesc(e.target.value)}
                    placeholder="E.g. SaaS Design Assets"
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                {/* Category */}
                <div className="sm:col-span-2 space-y-1">
                  <label className="text-[10px] font-bold text-slate-600">Category</label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    className="w-full text-xs px-2 py-2 rounded-lg border border-slate-200 focus:outline-none focus:border-emerald-500 bg-white"
                  >
                    <option value="General">General</option>
                    <option value="Infrastructure">Infrastructure</option>
                    <option value="Design">Design</option>
                    <option value="Investment">Investment</option>
                    <option value="Dining">Dining</option>
                    <option value="Transit">Transit</option>
                    <option value="Salary">Salary</option>
                  </select>
                </div>

                {/* Type Selection */}
                <div className="sm:col-span-2 space-y-1">
                  <label className="text-[10px] font-bold text-slate-600">Type</label>
                  <select
                    value={newType}
                    onChange={(e) => setNewType(e.target.value)}
                    className="w-full text-xs px-2 py-2 rounded-lg border border-slate-200 focus:outline-none focus:border-emerald-500 bg-white font-bold"
                  >
                    <option value="expense" className="text-rose-500">Outflow (-)</option>
                    <option value="income" className="text-emerald-600">Inflow (+)</option>
                  </select>
                </div>

                {/* Amount */}
                <div className="sm:col-span-2 space-y-1">
                  <label className="text-[10px] font-bold text-slate-600">Amount ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={newAmount}
                    onChange={(e) => setNewAmount(e.target.value)}
                    placeholder="45.00"
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                {/* Button */}
                <div className="sm:col-span-2">
                  <button
                    type="submit"
                    className="w-full text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 py-2 rounded-lg transition-all flex items-center justify-center gap-1"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    Add Log
                  </button>
                </div>
              </form>
            </div>

            {/* Charts Section: Spending Breakdown & Monthly Report */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-6">
              
              {/* Pie spending Chart (Col Span 5) */}
              <div className="sm:col-span-5 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between min-h-[300px]">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Outflow Categories</span>
                  <h3 className="text-xs font-bold text-slate-900 mt-1">Simulated Category Allocations</h3>
                </div>

                {spendingBreakdown.length > 0 ? (
                  <div className="h-44 w-full relative">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={spendingBreakdown}
                          cx="50%"
                          cy="50%"
                          innerRadius={45}
                          outerRadius={65}
                          paddingAngle={3}
                          dataKey="value"
                        >
                          {spendingBreakdown.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => formatter.format(value)} />
                      </PieChart>
                    </ResponsiveContainer>
                    
                    {/* Centered label */}
                    <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                      <span className="text-[9px] uppercase font-bold text-slate-400">Total Outflow</span>
                      <span className="text-xs font-black text-slate-800">{formatter.format(totals.expenses)}</span>
                    </div>
                  </div>
                ) : (
                  <p className="text-center text-xs text-slate-400 py-12">No simulated expense records to categorize.</p>
                )}

                {/* Small labels row */}
                <div className="flex flex-wrap gap-2.5 justify-center text-[9px] font-bold text-slate-500">
                  {spendingBreakdown.map((item, idx) => (
                    <span key={idx} className="flex items-center gap-1">
                      <span className="h-2 w-2 rounded-full inline-block" style={{ backgroundColor: COLORS[idx % COLORS.length] }}></span>
                      {item.name}
                    </span>
                  ))}
                </div>
              </div>

              {/* Monthly report Bar chart (Col Span 7) */}
              <div className="sm:col-span-7 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between min-h-[300px]">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block">Historical Runways</span>
                  <h3 className="text-xs font-bold text-slate-900 mt-1">Income vs Expense Monthly Report</h3>
                </div>

                <div className="h-48 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={reportChartData} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} tickLine={false} />
                      <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} />
                      <Tooltip formatter={(value) => formatter.format(value)} />
                      <Bar dataKey="Income" fill="#10b981" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="Expenses" fill="#f43f5e" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                <div className="text-[10px] text-slate-400 leading-normal border-t border-slate-50 pt-2 flex justify-between items-center">
                  <span>Simulating real-time compound savings buffer parameters</span>
                  <button
                    onClick={() => alert("Simulation report package exported as an encrypted offline spreadsheet packet.")}
                    className="text-emerald-600 font-bold hover:underline flex items-center gap-0.5"
                  >
                    <Download className="h-3 w-3" /> Export Sheet
                  </button>
                </div>
              </div>

            </div>

            {/* Transactions List */}
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
              <div className="flex justify-between items-center border-b border-slate-100 pb-3 mb-4">
                <span className="text-xs font-bold text-slate-900 uppercase tracking-wider">Simulated Ledger Entries</span>
                <span className="text-[10px] text-slate-400">Showing {activeTxList.length} total entries</span>
              </div>

              {activeTxList.length > 0 ? (
                <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
                  {activeTxList.map((tx) => (
                    <div key={tx.id} className="flex justify-between items-center py-3 hover:bg-slate-50/50 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg text-xs font-bold ${
                          tx.amount > 0 ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                        }`}>
                          {tx.amount > 0 ? 'IN' : 'OUT'}
                        </div>
                        <div>
                          <span className="text-xs font-extrabold text-slate-900 block">{tx.desc}</span>
                          <span className="text-[10px] text-slate-400 flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {tx.date} • {tx.category}
                          </span>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-3">
                        <span className={`text-xs font-black ${
                          tx.amount > 0 ? 'text-emerald-600' : 'text-slate-800'
                        }`}>
                          {tx.amount > 0 ? '+' : ''}{formatter.format(tx.amount)}
                        </span>
                        
                        <button
                          onClick={() => handleDeleteTransaction(tx.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-500 rounded hover:bg-rose-50 transition-colors"
                          title="Delete entry"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-center text-xs text-slate-400 py-12">No transactions recorded inside this virtual account ledger.</p>
              )}
            </div>

          </div>

        </div>
      </div>

    </div>
  );
}
