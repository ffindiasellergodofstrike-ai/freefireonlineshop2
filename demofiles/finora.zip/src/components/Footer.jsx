import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Wallet, Check, Send, ShieldAlert, ArrowUpRight } from 'lucide-react';

export default function Footer() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [error, setError] = useState('');

  const handleSubscribe = (e) => {
    e.preventDefault();
    if (!email) {
      setError('Please enter your email.');
      return;
    }
    if (!/\S+@\S+\.\S+/.test(email)) {
      setError('Please enter a valid email address.');
      return;
    }
    setError('');
    setSubscribed(true);
    setEmail('');
    setTimeout(() => setSubscribed(false), 5000); // Reset success state
  };

  return (
    <footer className="bg-slate-900 text-slate-400 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-12">
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <Link to="/" className="flex items-center gap-2 text-white">
              <div className="p-2 bg-emerald-600 rounded-lg">
                <Wallet className="h-5 w-5" />
              </div>
              <span className="text-xl font-bold tracking-tight text-white">
                Finora<span className="text-emerald-500">.</span>
              </span>
            </Link>
            <p className="text-sm max-w-sm leading-relaxed text-slate-400">
              Simple tools for a clearer financial future. Plan, save, and visualize your wealth in a beautifully simple, secure environment.
            </p>
            {/* Newsletter */}
            <div className="pt-2">
              <span className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">
                Stay updated with financial insights
              </span>
              <form onSubmit={handleSubscribe} className="relative flex max-w-sm">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (error) setError('');
                  }}
                  placeholder="name@example.com"
                  className="w-full bg-slate-800/80 text-white placeholder-slate-500 text-sm px-4 py-2.5 rounded-lg border border-slate-700 focus:outline-none focus:border-emerald-500 transition-colors"
                />
                <button
                  type="submit"
                  className="absolute right-1 top-1 bottom-1 px-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-md transition-colors flex items-center justify-center"
                >
                  {subscribed ? <Check className="h-4 w-4" /> : <Send className="h-4 w-4" />}
                </button>
              </form>
              {error && <p className="text-rose-400 text-xs mt-1">{error}</p>}
              {subscribed && (
                <p className="text-emerald-400 text-xs mt-1 flex items-center gap-1">
                  <Check className="h-3 w-3" /> Subscribed successfully! Thank you.
                </p>
              )}
            </div>
          </div>

          {/* Column 2: Platform */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-300 mb-4">
              Platform
            </h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/features" className="hover:text-white transition-colors">
                  Features
                </Link>
              </li>
              <li>
                <Link to="/solutions" className="hover:text-white transition-colors">
                  Solutions
                </Link>
              </li>
              <li>
                <Link to="/pricing" className="hover:text-white transition-colors">
                  Pricing Plans
                </Link>
              </li>
              <li>
                <Link to="/dashboard" className="hover:text-white transition-colors flex items-center gap-1">
                  Live Preview <span className="inline-block bg-emerald-500/10 text-emerald-400 text-[10px] font-bold px-1.5 py-0.5 rounded">Demo</span>
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 3: Trust & Safety */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-300 mb-4">
              Trust & Safety
            </h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/security" className="hover:text-white transition-colors">
                  Security Hub
                </Link>
              </li>
              <li>
                <span className="text-slate-500 block">End-to-End Encryption</span>
              </li>
              <li>
                <span className="text-slate-500 block">No Data Brokerage</span>
              </li>
              <li>
                <Link to="/contact" className="hover:text-white transition-colors">
                  Report a Vulnerability
                </Link>
              </li>
            </ul>
          </div>

          {/* Column 4: Company */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-300 mb-4">
              Company
            </h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link to="/about" className="hover:text-white transition-colors">
                  About Finora
                </Link>
              </li>
              <li>
                <Link to="/resources" className="hover:text-white transition-colors">
                  Resources & Blog
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-white transition-colors">
                  Contact Support
                </Link>
              </li>
              <li>
                <span className="text-slate-500 block">Careers — We're hiring!</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 mt-12 border-t border-slate-800 text-xs flex flex-col sm:flex-row justify-between items-center gap-4 text-slate-500">
          <div className="flex flex-col gap-1 sm:max-w-md">
            <span>© {new Date().getFullYear()} Finora Inc. All rights reserved.</span>
            <span className="text-[11px] leading-relaxed">
              Disclaimer: Finora is a fictional commercial template demonstrating high-fidelity fintech design concepts. We do not provide banking, asset custody, or brokerage services. Fictional data and visualizations are for illustrative purposes only.
            </span>
          </div>
          <div className="flex gap-4">
            <Link to="/security" className="hover:text-slate-400 transition-colors">
              Privacy Policy
            </Link>
            <Link to="/security" className="hover:text-slate-400 transition-colors">
              Terms of Use
            </Link>
            <Link to="/security" className="hover:text-slate-400 transition-colors">
              Fictional Disclosures
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
