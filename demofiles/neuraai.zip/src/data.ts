import { MessageSquare, Sparkles, BookOpen, Zap, Cpu, Layers, ShieldCheck, Database, HardDrive, LineChart, Code2, Users, CheckCircle2, Terminal } from 'lucide-react';

export const FAQ_DATA = [
  {
    id: 'faq-1',
    question: 'How does NeuraAI connect with our legacy data sources?',
    answer: 'NeuraAI supports native cloud connections, standard SQL databases, flat file streams, and REST/GraphQL APIs. With over 150+ pre-built integrations, your engineering team can hook up NeuraAI into your active data pipeline within 5 minutes without writing custom wrapper scripts.'
  },
  {
    id: 'faq-2',
    question: 'Is my company data used to train public NeuraAI models?',
    answer: 'Absolutely not. NeuraAI enforces a strict privacy boundary. Your models are running in isolated sandboxes. Your data, prompts, context files, and operational history are strictly yours and are never shared, anonymized, or used for any collective AI model training.'
  },
  {
    id: 'faq-3',
    question: 'What is the latency rate for the Enterprise API tier?',
    answer: 'Our global edge routing network delivers sub-150ms response latency for content generation and under 80ms for analytical summaries. Our systems utilize custom matrix processing hardware and persistent context caching to guarantee millisecond responses.'
  },
  {
    id: 'faq-4',
    question: 'Can we switch plans, and how are usage credits billed?',
    answer: 'You can upgrade or downgrade between Free, Pro, and Business tiers instantly. Usage credits are computed transparently based on model tokens and CPU/GPU compute seconds utilized. Pro and Business accounts include high baseline monthly credits, with automatic scaling pools available if you exceed them.'
  },
  {
    id: 'faq-5',
    question: 'Does NeuraAI support custom fine-tuning with custom parameters?',
    answer: 'Yes! The Business and Enterprise tiers grant full access to custom hyperparameter tuning and model training modules. You can upload proprietary datasets, configure training weights, and deploy custom fine-tuned versions within our visual dashboard or via standard terminal SDKs.'
  }
];

export const TESTIMONIALS = [
  {
    id: 't-1',
    name: 'Sarah Jenkins',
    role: 'VP of Product Innovation',
    company: 'Synergy Corp',
    quote: 'Implementing NeuraAI fundamentally transformed our product development cycles. We hooked up the document intelligence module to our technical backlogs and automated over 40% of our specifications drafting in less than a month. Latitude and performance are unparalleled.',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=120&h=120'
  },
  {
    id: 't-2',
    name: 'Marcus Vance',
    role: 'Director of Growth & Demand Gen',
    company: 'Veloce Retail',
    quote: 'The Content Suite is an absolute game changer. We configured the AI to generate hyper-personalized ad copy matching our specific visual guidelines, and our conversion rate jumped by 32% on Instagram and LinkedIn. NeuraAI is the only model that actually gets our tone right.',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=120&h=120'
  },
  {
    id: 't-3',
    name: 'Elena Rostova',
    role: 'Head of Information Security',
    company: 'AeroGroup Systems',
    quote: 'As an aerospace entity, data isolation and strict privacy are non-negotiable. NeuraAI delivered complete end-to-end encryption and a dedicated single-tenant workspace. The compliance audits were spotless. Performance is incredible without compromise.',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=120&h=120'
  }
];

export const INTEGRATIONS = [
  { id: 'slack', name: 'Slack', category: 'Communication', desc: 'Deliver actionable AI summaries directly into public channels and private team briefs.', status: 'Native' },
  { id: 'notion', name: 'Notion', category: 'Documentation', desc: 'Sync generated marketing content, product specs, and technical documentation automatically.', status: 'Native' },
  { id: 'github', name: 'GitHub', category: 'Engineering', desc: 'Trigger workflow automation actions directly from commit logs and pull request updates.', status: 'Advanced' },
  { id: 'salesforce', name: 'Salesforce', category: 'CRM', desc: 'Analyze historical sales transcripts to update contacts and forecast account growth.', status: 'Enterprise' },
  { id: 'hubspot', name: 'HubSpot', category: 'Marketing', desc: 'Draft, personalize, and publish automated blog and email campaigns based on buyer profiles.', status: 'Native' },
  { id: 'figma', name: 'Figma', category: 'Design', desc: 'Feed design system parameters into the content suite for visual contextual generation.', status: 'Advanced' },
  { id: 'postgres', name: 'PostgreSQL', category: 'Data & Databases', desc: 'Directly query, structure, and synthesize complex relational databases securely with natural text.', status: 'Enterprise' },
  { id: 'gdrive', name: 'Google Workspace', category: 'Documentation', desc: 'Extract data, summarize spreadsheets, and draft slide briefs in real time.', status: 'Native' },
  { id: 'jira', name: 'Jira Software', category: 'Product Management', desc: 'Auto-create epic tasks, backlog tickets, and technical descriptions from unstructured transcripts.', status: 'Advanced' }
];

export const PRICING_PLANS = [
  {
    name: 'Free',
    priceMonthly: 0,
    priceYearly: 0,
    desc: 'For builders, researchers, and individuals exploring general generative workflows.',
    features: [
      '10,000 baseline tokens/mo',
      'Standard AI Chat Access',
      '3 active custom templates',
      'Web-only access (no API keys)',
      'Community assistance'
    ],
    cta: 'Get Started Free',
    popular: false,
    path: '/signup'
  },
  {
    name: 'Pro',
    priceMonthly: 39,
    priceYearly: 29,
    desc: 'For professional marketers, writers, and product managers requiring high volumes.',
    features: [
      '500,000 premium tokens/mo',
      'Full Content Suite with templates',
      'Document Intelligence (up to 100MB)',
      'API Access (Standard Latency)',
      'Integrations with Notion & Slack',
      'Standard email support'
    ],
    cta: 'Upgrade to Pro',
    popular: true,
    path: '/signup'
  },
  {
    name: 'Business',
    priceMonthly: 129,
    priceYearly: 99,
    desc: 'For growing scale-ups, media agencies, and high-velocity engineering departments.',
    features: [
      '4,000,000 elite tokens/mo',
      'High-speed dedicated visual builders',
      'All 150+ native integrations unlocked',
      'Sub-150ms Edge API Latency',
      'Custom fine-tuning & tuning modules',
      '24/7 Priority engineering SLA'
    ],
    cta: 'Secure Business Plan',
    popular: false,
    path: '/signup'
  },
  {
    name: 'Enterprise',
    priceMonthly: 'Custom',
    priceYearly: 'Custom',
    desc: 'For high-governance banks, global enterprises, and security-focused platforms.',
    features: [
      'Unlimited scalable compute models',
      'Single-tenant isolated cluster options',
      'Custom compliance audits (SOC2/GDPR)',
      'Dedicated LLM architect assistance',
      'Custom model deployment & training',
      'White-glove concierge onboarding'
    ],
    cta: 'Contact Enterprise Sales',
    popular: false,
    path: '/contact'
  }
];

export const BLOG_POSTS = [
  {
    id: 'post-1',
    title: 'The Future of AI Orchestration: Moving from Chatbots to Autonomous Agents',
    excerpt: 'Explore how generative artificial intelligence is shifting from single-turn chat boxes to active, context-aware autonomous agents executing structured business workflows.',
    category: 'Engineering',
    readTime: '8 min read',
    date: 'Sep 18, 2026',
    author: 'Dr. Evelyn Vance, Head of LLM Systems',
    image: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&q=80&w=600&h=400',
    content: `Generative AI has evolved rapidly. In the early stages, users interacted with language models through simple, conversational chat interfaces. While helpful, these systems were static—entirely dependent on a human operator to prompt, evaluate, and transfer the output to secondary applications.

Today, we are witnessing a paradigm shift. We are moving from simple chatbots to autonomous AI agents that can trigger actions, monitor environments, handle multi-layered tasks, and self-correct during failure modes.

### What is an Autonomous Agent?
Unlike chat engines, an autonomous agent possesses three fundamental dimensions:
1. **Memory**: Persistence of historical prompts, actions, and files.
2. **Planning**: The ability to break down a long-form task into a structured checklist of actions before execution.
3. **Tool Access**: The ability to execute code, call external APIs, write to databases, and send emails.

At NeuraAI, we are packaging this capability into our code-free visual workflow automation tool. By defining triggers, you allow agents to act on your behalf safely.`
  },
  {
    id: 'post-2',
    title: 'Security Guidelines: Safeguarding Proprietary IP in LLM Workspaces',
    excerpt: 'How compliance officers and information security heads can design secure AI pipelines without risking data leakages, prompt injection attacks, or regulatory breaches.',
    category: 'Security & Compliance',
    readTime: '6 min read',
    date: 'Sep 14, 2026',
    author: 'Daniel Cross, Director of Security',
    image: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&q=80&w=600&h=400',
    content: `Integrating enterprise SaaS AI features is a strategic priority, but it must not override data security protocols. Traditional public AI interfaces pose a major risk: user queries might be utilized as training points for collective future models, thereby leaking proprietary patents, trade secrets, and customers private profiles.

Here is a practical security checklist for deploying AI platforms in high-governance industries:

### 1. Enforce Absolute Isolation
Make sure your vendor utilizes separate database clusters and isolated model runtimes. At NeuraAI, we offer single-tenant cloud configurations to ensure your files and prompts never cross paths with other clients.

### 2. Guard Against Injection
Prompt injections are a real hazard. Ensure inputs are cleaned and filtered by secondary classification models before being dispatched to your main LLM.

### 3. Compliance Frameworks
Verify SOC2 Type II, GDPR, and HIPAA compliance credentials before establishing connection pipelines.`
  },
  {
    id: 'post-3',
    title: 'Optimizing Ad Creative Pipelines with Generative Intelligence',
    excerpt: 'A comprehensive study of how modern marketing agencies are scaling high-converting asset variations while adhering to rigid corporate styling guides.',
    category: 'SaaS Marketing',
    readTime: '5 min read',
    date: 'Sep 10, 2026',
    author: 'Clara Zhao, Principal Growth strategist',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=600&h=400',
    content: `Marketing teams face a persistent bottleneck: personalization. Running multiple demographic variations across search, social, and programmatic display requires hundreds of copy and graphic versions.

Traditional drafting takes days of graphic designers and copywriters effort. Generative Content Suites have solved this.

### Personalized Copy on Autopilot
By utilizing NeuraAI's template engine, growth managers can supply a core pitch and generate fifty unique, highly tailored copy variations in under three seconds. This content is automatically aligned to match brand tone, character limitations, and visual style.

The results speak for themselves: early adopters have recorded an average 30%+ drop in cost-per-acquisition across digital channels.`
  }
];

export const STATISTICS = [
  { id: 'stat-1', value: '99.98%', label: 'API Uptime SLA' },
  { id: 'stat-2', value: '450M+', label: 'Tokens Processed' },
  { id: 'stat-3', value: '< 150ms', label: 'Average Edge Latency' },
  { id: 'stat-4', value: '150+', label: 'Native Integrations' }
];

export const WORKFLOW_STEPS = [
  {
    id: 'step-1',
    num: '01',
    title: 'Connect Secure Pipelines',
    desc: 'Hook up your Slack workspace, Notion repositories, or PostgreSQL database directly. All connections are secured with AES-256 grade credentials.'
  },
  {
    id: 'step-2',
    num: '02',
    title: 'Configure Your Agent Rules',
    desc: 'Instruct your custom AI workspace in pure English: define how reports should be analyzed, set threshold alerts, or provide target design parameters.'
  },
  {
    id: 'step-3',
    num: '03',
    title: 'Deploy and Auto-Scale',
    desc: 'Deploy your workflow securely. NeuraAI listens to event triggers, synthesizes actions, and delivers structured reports, copies, or data updates on autopilot.'
  }
];
