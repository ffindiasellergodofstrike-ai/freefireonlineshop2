import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { PRICING_PLANS } from '../data';
import { CheckCircle2, ChevronDown, ChevronUp, Star, ShieldCheck, HelpCircle } from 'lucide-react';

export default function Pricing() {
  const [billingCycle, setBillingCycle] = useState('monthly'); // 'monthly' | 'yearly'
  const [faqOpen, setFaqOpen] = useState<string | null>(null);

  const toggleFaq = (id: string) => {
    setFaqOpen(faqOpen === id ? null : id);
  };

  const pricingFaq = [
    { id: 'p-faq-1', q: 'How are extra usage credits computed beyond our standard limit?', a: 'If your team exceeds your monthly token allotment on Pro or Business tiers, NeuraAI automatically utilizes standard scaling pricing: $0.02 per 10,000 premium tokens. You can set strict billing limits in your analytics dashboard to prevent unexpected overages.' },
    { id: 'p-faq-2', q: 'Can we switch plans mid-billing cycle?', a: 'Yes! You can upgrade or downgrade at any time. When upgrading, your credits are immediately prorated and updated. When downgrading, the new tier parameters and credit limits apply starting from your subsequent billing date.' },
    { id: 'p-faq-3', q: 'Do you offer custom models or discounts for research entities?', a: 'Absolutely. We support dedicated fine-tuning discounts for universities, researchers, and non-profits. Please get in touch with our solutions architects team on our Contact page.' }
  ];

  const comparisonRows = [
    { feature: 'Monthly Tokens', free: '10,000 tokens', pro: '500,000 tokens', business: '4,000,000 tokens', enterprise: 'Unlimited' },
    { feature: 'Edge Latency', free: 'Standard', pro: 'Sub-300ms', business: 'Sub-150ms Edge Cached', enterprise: 'Sub-80ms Single Tenant' },
    { feature: 'Document Parsing Limit', free: 'Not available', pro: '100MB documents', business: 'Unrestricted', enterprise: 'Isolated Clusters' },
    { feature: 'Integrations', free: 'Web-only UI', pro: 'Notion & Slack', business: 'All 150+ native synced', enterprise: 'Custom sync pipelines' },
    { feature: 'Hyperparameter Tuning', free: 'No', pro: 'Basic template tuning', business: 'Full custom fine-tuning', enterprise: 'Proprietary model training' },
    { feature: 'Security Compliance', free: 'Multi-tenant public', pro: 'Symmetric TLS Encryption', business: 'SOC2 Type II boundaries', enterprise: 'Isolated Tenant cluster options' },
    { feature: 'Support SLA', free: 'Community boards', pro: 'Email (24 hr responses)', business: 'Priority Slack (sub-1 hr)', enterprise: 'Dedicated account engineer' }
  ];

  return (
    <div id="pricing-page" className="pt-24 space-y-32">
      
      {/* Header */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 text-center space-y-6 relative">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
        <span className="text-xs font-bold text-blue-500 tracking-wider uppercase">Monetization Plans</span>
        <h1 className="text-4xl md:text-5xl font-black text-white tracking-tight leading-tight">
          Flexible Pricing Built to Scale.
        </h1>
        <p className="text-sm text-gray-400 max-w-2xl mx-auto leading-relaxed">
          Select a standard plan or customize cloud computing cluster units matching your governance frameworks.
        </p>

        {/* Billing Cycle Toggle */}
        <div className="inline-flex items-center bg-gray-950/80 border border-gray-900 rounded-xl p-1.5 mt-4">
          <button
            onClick={() => setBillingCycle('monthly')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all ${
              billingCycle === 'monthly' ? 'bg-blue-600 text-white shadow-md' : 'text-gray-400 hover:text-white'
            }`}
          >
            Monthly billing
          </button>
          <button
            onClick={() => setBillingCycle('yearly')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-1 ${
              billingCycle === 'yearly' ? 'bg-blue-600 text-white shadow-md' : 'text-gray-400 hover:text-white'
            }`}
          >
            <span>Yearly billing</span>
            <span className="text-[9px] bg-emerald-500/15 text-emerald-400 border border-emerald-500/20 px-1 rounded-full uppercase font-bold tracking-tight">Save 25%</span>
          </button>
        </div>
      </section>

      {/* Pricing Cards Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {PRICING_PLANS.map((plan) => {
            const isYearly = billingCycle === 'yearly';
            const price = isYearly ? plan.priceYearly : plan.priceMonthly;
            const isEnterprise = plan.name === 'Enterprise';

            return (
              <div 
                key={plan.name} 
                className={`bg-[#070b14] border rounded-3xl p-6 space-y-6 flex flex-col justify-between relative ${
                  plan.popular ? 'border-blue-500/50 shadow-xl shadow-blue-500/5' : 'border-gray-900'
                }`}
              >
                {plan.popular && (
                  <span className="absolute top-4 right-4 bg-blue-600 text-[10px] font-bold text-white px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                    Most Popular
                  </span>
                )}
                
                <div className="space-y-4">
                  <h3 className="text-lg font-black text-white">{plan.name} Plan</h3>
                  <p className="text-[11px] text-gray-400 leading-relaxed min-h-[44px]">{plan.desc}</p>
                  
                  {/* Price display */}
                  <div className="flex items-baseline gap-1 pt-2">
                    {isEnterprise ? (
                      <span className="text-3xl font-extrabold text-white">Custom Scales</span>
                    ) : (
                      <>
                        <span className="text-4xl font-extrabold text-white font-mono">${price}</span>
                        <span className="text-[10px] text-gray-500 font-semibold uppercase">/ user / mo</span>
                      </>
                    )}
                  </div>
                </div>

                <ul className="space-y-3.5 border-t border-gray-900 pt-6">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2.5 text-xs text-gray-300">
                      <CheckCircle2 className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                      <span className="leading-tight">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Link
                  to={plan.path}
                  className={`w-full py-3 rounded-xl text-center text-xs font-bold transition-all ${
                    plan.popular 
                      ? 'bg-blue-600 text-white hover:bg-blue-500 shadow-md shadow-blue-500/10' 
                      : 'bg-gray-900 hover:bg-gray-850 border border-gray-800 text-gray-300 hover:text-white'
                  }`}
                >
                  {plan.cta}
                </Link>
              </div>
            );
          })}
        </div>
      </section>

      {/* Plans Comparison Table */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        <h2 className="text-xl md:text-2xl font-extrabold text-center text-white tracking-tight">Plan Features Comparison</h2>
        
        <div className="overflow-x-auto bg-[#070b14] border border-gray-900 rounded-3xl p-4">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-gray-900 text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                <th className="py-4 px-4 min-w-[180px]">Operational Metrics</th>
                <th className="py-4 px-4">Free Plan</th>
                <th className="py-4 px-4">Pro Plan</th>
                <th className="py-4 px-4">Business Plan</th>
                <th className="py-4 px-4">Enterprise Plan</th>
              </tr>
            </thead>
            <tbody className="text-gray-300">
              {comparisonRows.map((row, idx) => (
                <tr key={idx} className="border-b border-gray-900/50 hover:bg-gray-900/10 transition-colors">
                  <td className="py-4 px-4 font-semibold text-gray-200">{row.feature}</td>
                  <td className="py-4 px-4 text-gray-400">{row.free}</td>
                  <td className="py-4 px-4 text-gray-300">{row.pro}</td>
                  <td className="py-4 px-4 font-medium text-white">{row.business}</td>
                  <td className="py-4 px-4 text-blue-400 font-semibold">{row.enterprise}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Pricing FAQs */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10 pb-16">
        <h2 className="text-xl md:text-2xl font-extrabold text-center text-white tracking-tight">Billing Inquiries</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {pricingFaq.map((faq) => (
            <div key={faq.id} className="bg-gray-950/20 border border-gray-900 p-6 rounded-2xl space-y-3">
              <h4 className="text-xs font-bold text-white flex items-center gap-1.5">
                <HelpCircle className="w-4 h-4 text-blue-500" />
                {faq.q}
              </h4>
              <p className="text-xs text-gray-400 leading-relaxed pl-5">{faq.a}</p>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
}
