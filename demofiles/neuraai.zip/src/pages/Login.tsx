import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Cpu, Mail, Lock, ArrowRight, AlertCircle, RefreshCw } from 'lucide-react';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email || !password) {
      setError('Please provide both email address and password.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError('Please enter a valid email address.');
      return;
    }

    if (password.length < 6) {
      setError('Password must contain at least 6 characters.');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      // Redirect to dashboard preview
      navigate('/dashboard');
    }, 1200);
  };

  return (
    <div id="login-page" className="pt-24 min-h-screen bg-[#030712] flex items-center justify-center p-4">
      <div className="bg-[#070b14] border border-gray-900 rounded-3xl p-6 lg:p-8 max-w-md w-full space-y-6 shadow-2xl shadow-black/80 relative">
        
        {/* Brand */}
        <div className="text-center space-y-2">
          <Link to="/" className="inline-flex items-center gap-2 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center shadow-md shadow-blue-500/15">
              <Cpu className="w-5.5 h-5.5 text-white" />
            </div>
            <span className="text-xl font-bold tracking-tight text-white">
              Neura<span className="text-blue-500">AI</span>
            </span>
          </Link>
          <h2 className="text-lg font-extrabold text-white">Access Your Sandbox Core</h2>
          <p className="text-xs text-gray-500 leading-relaxed">Enter your credentials to manage clusters and workflows.</p>
        </div>

        {/* Form */}
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1.5">Email address</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="email"
                placeholder="sarah@synergy.corp"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-[#030712] border border-gray-800 focus:border-blue-500 rounded-xl pl-10 pr-4 py-3 text-xs text-gray-200 placeholder-gray-500 focus:outline-none transition-colors"
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">Account Password</label>
              <a href="#" className="text-[10px] text-blue-500 hover:underline">Forgot?</a>
            </div>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-[#030712] border border-gray-800 focus:border-blue-500 rounded-xl pl-10 pr-4 py-3 text-xs text-gray-200 placeholder-gray-500 focus:outline-none transition-colors"
              />
            </div>
          </div>

          {error && (
            <div className="p-3 bg-red-950/20 border border-red-900/30 text-[11px] text-red-400 rounded-xl font-medium flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-xs font-bold text-white transition-all flex items-center justify-center gap-2 shadow-md"
          >
            {isSubmitting ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Authenticating tunnel...</span>
              </>
            ) : (
              <>
                <span>Secure Sign In</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Footer */}
        <div className="text-center pt-2 border-t border-gray-900">
          <p className="text-xs text-gray-500">
            Don't have a secure workspace sandbox yet? <Link to="/signup" className="text-blue-500 hover:underline">Create Sandbox</Link>
          </p>
        </div>

      </div>
    </div>
  );
}
