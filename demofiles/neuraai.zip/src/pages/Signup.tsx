import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Cpu, Mail, Lock, User, Briefcase, ArrowRight, AlertCircle, RefreshCw } from 'lucide-react';

export default function Signup() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    password: '',
    terms: false
  });
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Validations
    if (!formData.name || !formData.email || !formData.password) {
      setError('Please provide all required credentials (Name, Email, Password).');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      setError('Please enter a valid email address.');
      return;
    }

    if (formData.password.length < 6) {
      setError('Password must contain at least 6 characters.');
      return;
    }

    if (!formData.terms) {
      setError('You must accept the isolated single-tenant workspace guidelines.');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      // Redirect to dashboard sandbox preview
      navigate('/dashboard');
    }, 1500);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
    setFormData({
      ...formData,
      [e.target.name]: val
    });
  };

  return (
    <div id="signup-page" className="pt-24 min-h-screen bg-[#030712] flex items-center justify-center p-4">
      <div className="bg-[#070b14] border border-gray-900 rounded-3xl p-6 lg:p-8 max-w-md w-full space-y-6 shadow-2xl shadow-black/80 relative">
        
        {/* Brand */}
        <div className="text-center space-y-2">
          <Link to="/" className="inline-flex items-center gap-2 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center shadow-md shadow-blue-500/15">
              <Cpu className="w-5.5 h-5.5 text-white" />
            </div>
            <span className="text-xl font-bold tracking-tight text-white">
              NeuraAI
            </span>
          </Link>
          <h2 className="text-lg font-extrabold text-white">Initialize Sandbox Space</h2>
          <p className="text-xs text-gray-500 leading-relaxed">Start testing 10,000 baseline credits in our secure sandbox today.</p>
        </div>

        {/* Form */}
        <form onSubmit={handleSignup} className="space-y-4">
          <div>
            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1.5">Your Name *</label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="text"
                name="name"
                required
                placeholder="e.g. Sarah Jenkins"
                value={formData.name}
                onChange={handleInputChange}
                className="w-full bg-[#030712] border border-gray-800 focus:border-blue-500 rounded-xl pl-10 pr-4 py-3 text-xs text-gray-200 placeholder-gray-500 focus:outline-none transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1.5">Email address *</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="email"
                name="email"
                required
                placeholder="sarah@synergy.corp"
                value={formData.email}
                onChange={handleInputChange}
                className="w-full bg-[#030712] border border-gray-800 focus:border-blue-500 rounded-xl pl-10 pr-4 py-3 text-xs text-gray-200 placeholder-gray-500 focus:outline-none transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1.5">Company Name</label>
            <div className="relative">
              <Briefcase className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="text"
                name="company"
                placeholder="Synergy Corp"
                value={formData.company}
                onChange={handleInputChange}
                className="w-full bg-[#030712] border border-gray-800 focus:border-blue-500 rounded-xl pl-10 pr-4 py-3 text-xs text-gray-200 placeholder-gray-500 focus:outline-none transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1.5">Create Password *</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <input
                type="password"
                name="password"
                required
                placeholder="••••••••"
                value={formData.password}
                onChange={handleInputChange}
                className="w-full bg-[#030712] border border-gray-800 focus:border-blue-500 rounded-xl pl-10 pr-4 py-3 text-xs text-gray-200 placeholder-gray-500 focus:outline-none transition-colors"
              />
            </div>
          </div>

          {/* Guidelines */}
          <div className="pt-2">
            <label className="flex items-start gap-2.5 text-[11px] text-gray-400 leading-relaxed cursor-pointer select-none">
              <input
                type="checkbox"
                name="terms"
                checked={formData.terms}
                onChange={handleInputChange}
                className="accent-blue-600 rounded shrink-0 mt-0.5"
              />
              <span>
                I agree to the secure, isolated single-tenant workspace <a href="#" className="text-blue-500 hover:underline">Guidelines & Compliance Policy</a>.
              </span>
            </label>
          </div>

          {error && (
            <div className="p-3 bg-red-950/20 border border-red-900/30 text-[11px] text-red-400 rounded-xl font-medium flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-xs font-bold text-white transition-all flex items-center justify-center gap-2 shadow-md"
          >
            {isSubmitting ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Initializing sandbox environment...</span>
              </>
            ) : (
              <>
                <span>Launch Free Sandbox</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Footer */}
        <div className="text-center pt-2 border-t border-gray-900">
          <p className="text-xs text-gray-500">
            Already have a workspace sandbox space? <Link to="/login" className="text-blue-500 hover:underline">Sign In</Link>
          </p>
        </div>

      </div>
    </div>
  );
}
