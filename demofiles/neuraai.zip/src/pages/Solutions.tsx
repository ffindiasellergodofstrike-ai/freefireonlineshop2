import React from 'react';
import { Link } from 'react-router-dom';
import { Cpu, Layers, Zap, ShieldCheck, CheckCircle2, ArrowRight, Server, Terminal, Code2 } from 'lucide-react';

export default function Solutions() {
  const sectors = [
    {
      id: 'enterprise',
      title: 'Enterprise Intelligence',
      tag: 'Strict Security & Scale',
      icon: Cpu,
      desc: 'Formulate private virtual agent matrices, compile internal document backlogs, and guarantee compliance across security boundaries.',
      features: [
        'Dedicated isolated cloud tenant servers.',
        'Complete SOC2 Type II, GDPR, and HIPAA compliance structures.',
        'Custom fine-tuning modules with proprietary dataset support.',
        'SLA guaranteed 24/7 dedicated engineering support lines.'
      ],
      terminalHeader: 'enterprise_cluster_provision.yaml',
      terminalLines: [
        'cluster_type: single_tenant_isolated',
        'compliance_policy: high_governance_soc2_gdpr',
        'encryption_method: aes_256_symmetric_keys',
        'status: isolated_cluster_running_100pct'
      ]
    },
    {
      id: 'marketing',
      title: 'Marketing Pipeline Optimization',
      tag: 'Conversion & Velocity',
      icon: Layers,
      desc: 'Accelerate ad copywriting, refine email funnel personalization, and schedule optimized blogs aligned to exact tone parameters.',
      features: [
        'Fine-tuned brand voice matching algorithms.',
        'A/B test variations synthesized in under 3 seconds.',
        'Native sync with Slack, HubSpot, and Notion.',
        'Averages 30%+ reduction in digital acquisition costs.'
      ],
      terminalHeader: 'marketing_pipeline_sync.config',
      terminalLines: [
        'brand_tone: professional_persuasive_bold',
        'target_channels: hubspot_slack_notion',
        'conversion_optimization: enabled_v3_pipelines',
        'status: synchronization_pulse_stable_112ms'
      ]
    },
    {
      id: 'product',
      title: 'Product Engineering APIs',
      tag: 'Microsecond Latency',
      icon: Zap,
      desc: 'Deploy context cached API requests directly into production. Harness gRPC or HTTPS structures running at scale with sub-150ms edge routing.',
      features: [
        'Persistent edge caching reducing token cost scales.',
        'Comprehensive SDK documentation and API keys.',
        'Automatic failover routing to multiple cloud regions.',
        'Near-zero system maintenance overhead.'
      ],
      terminalHeader: 'product_api_endpoint.json',
      terminalLines: [
        'api_protocol: grpc_microservice_mesh',
        'average_latency: 112ms_edge_cached',
        'error_rate_threshold: 0.0001pct_failover_ready',
        'status: systems_operating_with_maximum_speed'
      ]
    }
  ];

  return (
    <div id="solutions-page" className="pt-24 space-y-32">
      
      {/* Page Header */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 text-center space-y-4 relative">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-80 h-80 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />
        <span className="text-xs font-bold text-blue-500 tracking-wider uppercase">SaaS Solutions</span>
        <h1 className="text-4xl md:text-5xl font-black text-white tracking-tight leading-tight">
          Tailored Workspaces for Elite Operations.
        </h1>
        <p className="text-sm text-gray-400 max-w-2xl mx-auto leading-relaxed">
          From isolated single-tenant enterprise clusters to lightning-fast product APIs, choose the infrastructure built for your velocity.
        </p>
      </section>

      {/* Solutions Sectors Details */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-24">
        {sectors.map((sector, index) => {
          const Icon = sector.icon;
          const isEven = index % 2 === 0;
          return (
            <div 
              key={sector.id}
              className={`grid grid-cols-1 lg:grid-cols-12 gap-12 items-center ${
                isEven ? '' : 'lg:flex-row-reverse'
              }`}
            >
              
              {/* Text Specs (Col span 6) */}
              <div className={`lg:col-span-6 space-y-6 ${isEven ? 'lg:order-1' : 'lg:order-2'}`}>
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0b1020] border border-blue-950/80 text-xs font-semibold text-blue-400 uppercase tracking-wider">
                  <Icon className="w-3.5 h-3.5 text-blue-500" />
                  <span>{sector.tag}</span>
                </div>
                
                <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">{sector.title}</h2>
                <p className="text-xs text-gray-400 leading-relaxed">{sector.desc}</p>
                
                <ul className="space-y-3 pt-2">
                  {sector.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2.5 text-xs text-gray-300">
                      <CheckCircle2 className="w-4 h-4 text-blue-500 mt-0.5 shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                <div className="pt-4 flex items-center gap-4">
                  <Link
                    to="/signup"
                    className="px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-xs font-bold text-white transition-colors"
                  >
                    Deploy This Solution
                  </Link>
                  <Link
                    to="/contact"
                    className="px-6 py-3 rounded-xl bg-gray-900 hover:bg-gray-850 border border-gray-800 hover:border-gray-700 text-xs font-bold text-gray-400 hover:text-white transition-colors"
                  >
                    Consult An Architect
                  </Link>
                </div>
              </div>

              {/* Terminal Mockup (Col span 6) */}
              <div className={`lg:col-span-6 bg-gray-950/60 rounded-3xl border border-gray-900 p-6 font-mono text-[11px] leading-relaxed text-gray-400 space-y-4 shadow-xl shadow-black/40 ${
                isEven ? 'lg:order-2' : 'lg:order-1'
              }`}>
                <div className="flex items-center justify-between border-b border-gray-900 pb-2.5">
                  <span className="text-gray-500 uppercase tracking-widest text-[9px] font-bold">{sector.terminalHeader}</span>
                  <div className="flex items-center gap-1.5">
                    <div className="w-2 h-2 rounded-full bg-red-500/40" />
                    <div className="w-2 h-2 rounded-full bg-amber-500/40" />
                    <div className="w-2 h-2 rounded-full bg-emerald-500/40" />
                  </div>
                </div>

                <div className="space-y-2">
                  <p className="text-gray-600"># Initializing sector module parameters...</p>
                  {sector.terminalLines.map((line, lIdx) => (
                    <p key={lIdx} className="text-gray-300">
                      <span className="text-blue-500">&gt;&gt;</span> {line}
                    </p>
                  ))}
                  <p className="text-emerald-400">✓ Security handshakes established with 100% compliant isolation protocols.</p>
                </div>
              </div>

            </div>
          );
        })}
      </section>

      {/* Case Study Callout */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-10">
        <div className="bg-[#0b0f19] border border-gray-900 rounded-3xl p-8 lg:p-12 text-center space-y-6 max-w-4xl mx-auto relative overflow-hidden">
          <span className="text-xs font-bold text-blue-500 tracking-wider uppercase">Enterprise Trust</span>
          <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight max-w-2xl mx-auto leading-tight">
            See how Synergy Corp automated 40% of specifications drafting.
          </h2>
          <p className="text-xs text-gray-400 max-w-xl mx-auto leading-relaxed">
            By connecting NeuraAI's document intelligence modules to their engineering specifications backlogs, they successfully cut drafting cycles and optimized latency structures across edge platforms.
          </p>
          <div className="pt-2">
            <Link
              to="/blog"
              className="px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-xs font-bold text-white transition-colors inline-flex items-center gap-1.5"
            >
              <span>Read Case Study</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

    </div>
  );
}
