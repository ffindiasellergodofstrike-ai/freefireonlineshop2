import React, { useState } from 'react';
import { BLOG_POSTS } from '../data';
import { BookOpen, Calendar, User, ChevronRight, X, ArrowLeft, Send, CheckCircle } from 'lucide-react';

export default function Blog() {
  const [activeCategory, setActiveCategory] = useState('All');
  const [activePost, setActivePost] = useState<any>(null); // Full article view
  const [commentEmail, setCommentEmail] = useState('');
  const [commentText, setCommentText] = useState('');
  const [commentSuccess, setCommentSuccess] = useState(false);

  const categories = ['All', 'Engineering', 'Security & Compliance', 'SaaS Marketing'];

  const filteredPosts = BLOG_POSTS.filter(post => 
    activeCategory === 'All' || post.category === activeCategory
  );

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentEmail || !commentText) return;
    
    setCommentSuccess(true);
    setCommentEmail('');
    setCommentText('');
    setTimeout(() => {
      setCommentSuccess(false);
    }, 5000);
  };

  return (
    <div id="blog-page" className="pt-24 space-y-20 min-h-screen">
      
      {/* 1. Normal list view when no post is active */}
      {!activePost ? (
        <>
          {/* Header */}
          <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 text-center space-y-4 relative">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-80 h-80 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />
            <span className="text-xs font-bold text-blue-500 tracking-wider uppercase">AI Intel Center</span>
            <h1 className="text-4xl md:text-5xl font-black text-white tracking-tight leading-tight">
              NeuraAI Blog & Research.
            </h1>
            <p className="text-sm text-gray-400 max-w-2xl mx-auto leading-relaxed">
              Explore the latest technical write-ups, engineering backlog guides, and SOC2 security frameworks written by principal AI model architects.
            </p>
          </section>

          {/* Filters */}
          <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-wrap justify-center gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all ${
                  activeCategory === cat 
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-500/10' 
                    : 'bg-gray-950/20 border border-gray-900 text-gray-400 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </section>

          {/* Posts Directory */}
          <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredPosts.map((post) => (
                <article 
                  key={post.id} 
                  className="bg-[#070b14] border border-gray-900 hover:border-gray-850 rounded-3xl overflow-hidden flex flex-col justify-between group transition-all"
                >
                  <div className="space-y-4">
                    {/* Cover image */}
                    <div className="h-48 overflow-hidden relative border-b border-gray-900">
                      <img 
                        src={post.image} 
                        alt={post.title} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
                        referrerPolicy="no-referrer"
                      />
                    </div>

                    <div className="p-6 space-y-3">
                      <div className="flex items-center gap-3 text-[10px] text-gray-500 font-semibold font-mono">
                        <span className="text-blue-400 uppercase">{post.category}</span>
                        <span>•</span>
                        <span>{post.date}</span>
                      </div>
                      
                      <h3 className="text-sm font-extrabold text-white leading-snug group-hover:text-blue-400 transition-colors">
                        {post.title}
                      </h3>
                      
                      <p className="text-xs text-gray-400 leading-relaxed line-clamp-3">
                        {post.excerpt}
                      </p>
                    </div>
                  </div>

                  {/* Trigger Read */}
                  <div className="p-6 pt-0 mt-2">
                    <button
                      onClick={() => setActivePost(post)}
                      className="w-full py-3 rounded-xl bg-[#030712] border border-gray-800 hover:border-gray-700 text-xs font-bold text-gray-300 hover:text-white flex items-center justify-center gap-1.5 transition-colors"
                    >
                      <span>Read Article</span>
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                </article>
              ))}
            </div>
          </section>
        </>
      ) : (
        /* 2. Full Article Reader View */
        <section className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-20 space-y-10">
          
          {/* Back btn */}
          <button
            onClick={() => setActivePost(null)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-gray-950 hover:bg-gray-900 border border-gray-900 hover:border-gray-800 text-xs font-bold text-gray-400 hover:text-white transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to directory</span>
          </button>

          {/* Cover image */}
          <div className="h-80 rounded-3xl overflow-hidden border border-gray-900 shadow-xl">
            <img 
              src={activePost.image} 
              alt={activePost.title} 
              className="w-full h-full object-cover" 
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Metadata */}
          <div className="space-y-4">
            <div className="flex items-center gap-3 text-xs text-gray-500 font-mono font-semibold">
              <span className="text-blue-400 uppercase">{activePost.category}</span>
              <span>•</span>
              <span>{activePost.date}</span>
              <span>•</span>
              <span>{activePost.readTime}</span>
            </div>

            <h1 className="text-3xl sm:text-4xl font-black text-white leading-tight">
              {activePost.title}
            </h1>

            <div className="flex items-center gap-2.5 text-xs text-gray-400 font-semibold">
              <User className="w-4 h-4 text-blue-500" />
              <span>By {activePost.author}</span>
            </div>
          </div>

          {/* Article Full content */}
          <div className="prose prose-invert max-w-none text-xs text-gray-300 leading-relaxed whitespace-pre-line space-y-4 border-t border-gray-900 pt-8">
            {activePost.content}
          </div>

          {/* Interactive Comments Form */}
          <div className="bg-[#070b14] border border-gray-900 rounded-3xl p-6 space-y-6 mt-16">
            <h3 className="text-sm font-extrabold text-white">Join the Discussion</h3>
            
            <form onSubmit={handleCommentSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Email address</label>
                  <input
                    type="email"
                    required
                    placeholder="Enter email address"
                    value={commentEmail}
                    onChange={(e) => setCommentEmail(e.target.value)}
                    className="w-full bg-[#030712] border border-gray-800 focus:border-blue-500 rounded-xl px-4 py-3 text-xs text-gray-200 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Your Comment</label>
                <textarea
                  rows={4}
                  required
                  placeholder="Share your perspective on AI orchestration and security thresholds..."
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  className="w-full bg-[#030712] border border-gray-800 focus:border-blue-500 rounded-xl p-4 text-xs text-gray-200 focus:outline-none resize-none"
                />
              </div>

              {commentSuccess && (
                <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium pl-1">
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <span>Comment submitted! Moderated comments appear after review.</span>
                </div>
              )}

              <button
                type="submit"
                className="px-6 py-3 bg-blue-600 hover:bg-blue-500 text-xs font-bold text-white rounded-xl transition-colors inline-flex items-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Submit Feedback</span>
              </button>
            </form>
          </div>

        </section>
      )}

    </div>
  );
}
