import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  Cpu, MessageSquare, Sparkles, FileText, Zap, Bot, BarChart3, 
  ArrowRight, ShieldCheck, CheckCircle2, ChevronDown, ChevronUp, Star, Layers, Code2
} from 'lucide-react';
import { FAQ_DATA, TESTIMONIALS, INTEGRATIONS, PRICING_PLANS, STATISTICS, WORKFLOW_STEPS } from '../data';

export default function Home() {
  const [billingCycle, setBillingCycle] = useState('monthly'); // 'monthly' | 'yearly'
  const [openFaq, setOpenFaq] = useState<string | null>(null);

  const toggleFaq = (id: string) => {
    setOpenFaq(openFaq === id ? null : id);
  };

  const activePricingPlans = PRICING_PLANS.filter(p => p.name !== 'Enterprise');

  return (
    <div id="home-page" className="pt-24 space-y-32">
      
      {/* 1. HERO SECTION */}
      <section id="hero" className="relative overflow-hidden pt-12 md:pt-20">
        {/* Sleek radial backgrounds */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-1/4 right-10 w-[400px] h-[200px] bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center space-y-6 max-w-4xl mx-auto">
            {/* Elegant display accent pill */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#0b1020] border border-blue-900/40 text-xs font-semibold tracking-wider text-blue-400 uppercase">
              <Sparkles className="w-3.5 h-3.5" />
              <span>SaaS Template Core v2.0 Released</span>
            </div>

            <h1 className="text-4xl sm:text-5xl md:text-6xl font-black tracking-tight text-white leading-tight">
              AI that turns <span className="bg-gradient-to-r from-blue-500 via-indigo-400 to-indigo-600 bg-clip-text text-transparent">ideas</span> into <span className="underline decoration-blue-500 decoration-wavy underline-offset-8">results</span>.
            </h1>

            <p className="text-base sm:text-lg md:text-xl text-gray-400 leading-relaxed max-w-2xl mx-auto">
              Deploy secure, isolated custom AI agents, code-free workflow automations, and enterprise content pipelines running at sub-150ms edge latency.
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
              <Link
                to="/signup"
                id="hero-cta-signup"
                className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-sm font-bold text-white shadow-xl shadow-blue-500/15 transition-all duration-200 hover:-translate-y-0.5"
              >
                Start Free Sandbox
              </Link>
              <Link
                to="/features"
                id="hero-cta-features"
                className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gray-900 hover:bg-gray-800 border border-gray-800 hover:border-gray-700 text-sm font-bold text-gray-300 hover:text-white transition-all duration-200 flex items-center justify-center gap-2"
              >
                <span>Explore Features</span>
                <ArrowRight className="w-4.5 h-4.5" />
              </Link>
            </div>
          </div>

          {/* Interactive UI Mockup Preview */}
          <div className="mt-16 relative rounded-3xl border border-gray-800/80 bg-gray-950/40 p-4 shadow-2xl shadow-black max-w-5xl mx-auto overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-t from-[#030712] via-transparent to-transparent z-10 pointer-events-none" />
            <div className="bg-[#030712]/80 rounded-2xl border border-gray-900 overflow-hidden relative">
              <div className="bg-[#0b0f19] border-b border-gray-900 px-6 py-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500/40" />
                  <div className="w-3 h-3 rounded-full bg-amber-500/40" />
                  <div className="w-3 h-3 rounded-full bg-emerald-500/40" />
                  <span className="text-xs text-gray-500 font-mono ml-4">neura_ai_model_orchestrator.env</span>
                </div>
                <div className="text-xs bg-blue-500/10 text-blue-400 border border-blue-500/20 px-2.5 py-0.5 rounded-full font-semibold">PREVIEW MODE</div>
              </div>
              <div className="p-8 grid grid-cols-1 md:grid-cols-3 gap-6 opacity-85 group-hover:opacity-100 transition-opacity duration-300">
                <div className="space-y-3 bg-[#0b0f19]/40 p-4 rounded-xl border border-gray-900">
                  <span className="text-[10px] font-bold text-amber-500 tracking-wider">01 TRIGGER</span>
                  <h4 className="text-sm font-bold text-white">Commit Pushed to GitHub</h4>
                  <p className="text-xs text-gray-500 leading-relaxed">System listens for repository specs amendments and routes to active sandbox.</p>
                </div>
                <div className="space-y-3 bg-[#0b0f19]/40 p-4 rounded-xl border border-gray-900">
                  <span className="text-[10px] font-bold text-blue-400 tracking-wider">02 SYNTHESIS</span>
                  <h4 className="text-sm font-bold text-white">Draft Specifications</h4>
                  <p className="text-xs text-gray-500 leading-relaxed">NeuraAI automatically synthesizes compliant structural system backlogs in 112ms.</p>
                </div>
                <div className="space-y-3 bg-[#0b0f19]/40 p-4 rounded-xl border border-gray-900">
                  <span className="text-[10px] font-bold text-emerald-400 tracking-wider">03 RELEASE</span>
                  <h4 className="text-sm font-bold text-white">Push to Slack Channels</h4>
                  <p className="text-xs text-gray-500 leading-relaxed">Direct summaries delivered to tech architects and HubSpot draft blog queues.</p>
                </div>
              </div>
            </div>
            
            {/* Interactive Hover Call-out overlay */}
            <div className="absolute inset-x-0 bottom-0 py-8 z-20 flex justify-center">
              <Link
                to="/dashboard"
                id="hero-dashboard-preview"
                className="px-6 py-3 rounded-full bg-blue-600 hover:bg-blue-500 text-xs font-extrabold tracking-wide text-white shadow-xl shadow-blue-500/30 flex items-center gap-2 group-hover:scale-105 transition-transform"
              >
                <span>Launch Interactive Product Experience</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* 2. TRUSTED BY LOGOS */}
      <section id="trusted-by" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 border-y border-gray-900 bg-[#02050c]">
        <p className="text-center text-xs font-bold text-gray-500 tracking-widest uppercase mb-6">Trusted by Elite Innovation Leaders</p>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 items-center justify-items-center gap-8 opacity-65">
          {['AeroGroup Systems', 'Synergy Corp', 'Veloce Retail', 'HyperStream Data', 'Chronos Logistics'].map((brand, idx) => (
            <div key={idx} className="flex items-center gap-2 group cursor-default">
              <Cpu className="w-5 h-5 text-gray-600 group-hover:text-blue-500 transition-colors" />
              <span className="text-sm font-bold text-gray-400 group-hover:text-white transition-colors">{brand}</span>
            </div>
          ))}
        </div>
      </section>

      {/* 3. CORE STATISTICS */}
      <section id="statistics" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {STATISTICS.map((stat) => (
            <div key={stat.id} className="bg-gray-950/20 border border-gray-900 rounded-3xl p-6 text-center space-y-2">
              <p className="text-3xl md:text-4xl font-black text-white font-mono tracking-tight bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">{stat.value}</p>
              <p className="text-xs text-gray-500 font-semibold tracking-wider uppercase">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 4. KEY CAPABILITIES FEATURE GRID */}
      <section id="features-grid" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        <div className="text-center space-y-4 max-w-2xl mx-auto">
          <span className="text-xs font-bold text-blue-500 tracking-wider uppercase">Features Directory</span>
          <h2 className="text-3xl md:text-4xl font-extrabold text-white tracking-tight">Supercharged AI Infrastructure.</h2>
          <p className="text-sm text-gray-400 leading-relaxed">
            Five core capabilities custom-built inside enterprise isolation units, ensuring compliance, maximum security, and record-breaking performance speeds.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[
            { title: 'AI Chat Core', desc: 'Secure, context-aware chatbot models designed around advanced system structures and patents.', icon: MessageSquare, path: '/features' },
            { title: 'Content Suite', desc: 'Convert structured prompts into brand-aligned blogs, spec sheets, and high-converting ad copies.', icon: Sparkles, path: '/features' },
            { title: 'Document Intelligence', desc: 'Audit complex contract PDFs, technical backlog documents, or JSON payloads instantly.', icon: FileText, path: '/features' },
            { title: 'Workflow Automation', desc: 'Connect Slack, HubSpot, and DB logs. Build trigger-action chains without a line of code.', icon: Zap, path: '/features' },
            { title: 'Autonomous Agents', desc: 'Configure virtual workspace employees executing structured compliance checklists on autopilot.', icon: Bot, path: '/features' },
            { title: 'Security Isolation', desc: 'Your prompts and files are sandboxed inside isolated databases and never used for training.', icon: ShieldCheck, path: '/solutions' }
          ].map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div 
                key={index} 
                className="bg-[#070b14] border border-gray-900 hover:border-gray-800 p-8 rounded-3xl space-y-6 transition-all duration-200 hover:-translate-y-1"
              >
                <div className="w-12 h-12 rounded-xl bg-gray-950 flex items-center justify-center border border-gray-800 text-gray-400 group-hover:text-blue-400 transition-colors">
                  <Icon className="w-5.5 h-5.5 text-blue-500" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-lg font-bold text-white">{feature.title}</h3>
                  <p className="text-xs text-gray-400 leading-relaxed">{feature.desc}</p>
                </div>
                <Link 
                  to={feature.path} 
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-500 hover:text-blue-400 transition-colors"
                >
                  <span>Learn more</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </div>
            );
          })}
        </div>
      </section>

      {/* 5. WORKFLOW CHRONOLOGY */}
      <section id="workflow" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        <div className="text-center space-y-4 max-w-2xl mx-auto">
          <span className="text-xs font-bold text-blue-500 tracking-wider uppercase">Orchestration Protocol</span>
          <h2 className="text-3xl md:text-4xl font-extrabold text-white tracking-tight">Deploy secure AI workflows in minutes.</h2>
          <p className="text-sm text-gray-400 leading-relaxed">
            Hook up your historical documentation structures, specify your processing rules, and let our agents run your pipeline operations on autopilot.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {WORKFLOW_STEPS.map((step) => (
            <div key={step.id} className="bg-gray-950/10 border border-gray-900 rounded-3xl p-8 space-y-6 relative overflow-hidden">
              <span className="absolute right-6 top-6 text-5xl font-black font-mono text-gray-900/30 select-none">{step.num}</span>
              <div className="space-y-3">
                <h3 className="text-lg font-bold text-white">{step.title}</h3>
                <p className="text-xs text-gray-400 leading-relaxed">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 6. TESTIMONIAL SUITE */}
      <section id="testimonials" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        <div className="text-center space-y-4 max-w-2xl mx-auto">
          <span className="text-xs font-bold text-blue-500 tracking-wider uppercase">Client Validation</span>
          <h2 className="text-3xl md:text-4xl font-extrabold text-white tracking-tight">Earning trust across enterprise sectors.</h2>
          <p className="text-sm text-gray-400 leading-relaxed">
            Read how global innovators, information compliance officers, and performance marketers use NeuraAI to streamline backlog drafts and ad campaigns.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((t) => (
            <div key={t.id} className="bg-[#070b14] border border-gray-900 p-8 rounded-3xl space-y-6 flex flex-col justify-between">
              <div className="space-y-4">
                <div className="flex items-center gap-1 text-amber-400">
                  {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-amber-400" />)}
                </div>
                <p className="text-xs text-gray-300 italic leading-relaxed">"{t.quote}"</p>
              </div>
              <div className="flex items-center gap-3 pt-4 border-t border-gray-900 mt-4">
                <img 
                  src={t.avatar} 
                  alt={t.name} 
                  className="w-10 h-10 rounded-full border border-gray-800 object-cover" 
                  referrerPolicy="no-referrer"
                />
                <div>
                  <h4 className="text-xs font-bold text-white">{t.name}</h4>
                  <p className="text-[10px] text-gray-500 mt-0.5">{t.role}, <span className="text-gray-400">{t.company}</span></p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 7. PRICING PREVIEW */}
      <section id="pricing-preview" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        <div className="text-center space-y-6 max-w-2xl mx-auto">
          <span className="text-xs font-bold text-blue-500 tracking-wider uppercase">Monetization Scales</span>
          <h2 className="text-3xl md:text-4xl font-extrabold text-white tracking-tight">Transparent pricing, built to scale.</h2>
          <p className="text-sm text-gray-400 leading-relaxed">
            No hidden setup fees. Choose a standard plan or customized cluster resources matching your compliance frameworks.
          </p>

          {/* Pricing Toggle */}
          <div className="inline-flex items-center bg-gray-950/80 border border-gray-900 rounded-xl p-1.5">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`px-4 py-2 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all ${
                billingCycle === 'monthly' ? 'bg-blue-600 text-white shadow-md' : 'text-gray-400 hover:text-white'
              }`}
            >
              Monthly billing
            </button>
            <button
              onClick={() => setBillingCycle('yearly')}
              className={`px-4 py-2 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all flex items-center gap-1 ${
                billingCycle === 'yearly' ? 'bg-blue-600 text-white shadow-md' : 'text-gray-400 hover:text-white'
              }`}
            >
              <span>Yearly billing</span>
              <span className="text-[9px] bg-emerald-500/15 text-emerald-400 border border-emerald-500/20 px-1 rounded-full uppercase font-bold tracking-tight">Save 25%</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {activePricingPlans.map((plan) => {
            const isYearly = billingCycle === 'yearly';
            const price = isYearly ? plan.priceYearly : plan.priceMonthly;
            return (
              <div 
                key={plan.name} 
                className={`bg-[#070b14] border rounded-3xl p-8 space-y-8 flex flex-col justify-between relative ${
                  plan.popular ? 'border-blue-500/50 shadow-xl shadow-blue-500/5' : 'border-gray-900'
                }`}
              >
                {plan.popular && (
                  <span className="absolute top-4 right-4 bg-blue-600 text-[10px] font-bold text-white px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                    Most Popular
                  </span>
                )}
                
                <div className="space-y-4">
                  <h3 className="text-lg font-black text-white">{plan.name} Plan</h3>
                  <p className="text-xs text-gray-400 leading-relaxed">{plan.desc}</p>
                  
                  {/* Price display */}
                  <div className="flex items-baseline gap-1 pt-2">
                    <span className="text-4xl font-extrabold text-white font-mono">${price}</span>
                    <span className="text-xs text-gray-500 font-semibold uppercase">/ user / mo</span>
                  </div>
                </div>

                <ul className="space-y-3.5 border-t border-gray-900 pt-6">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2.5 text-xs text-gray-300">
                      <CheckCircle2 className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>

                <Link
                  to={plan.path}
                  className={`w-full py-3.5 rounded-xl text-center text-xs font-bold transition-all ${
                    plan.popular 
                      ? 'bg-blue-600 text-white hover:bg-blue-500 shadow-md shadow-blue-500/10' 
                      : 'bg-gray-900 hover:bg-gray-850 border border-gray-800 text-gray-300 hover:text-white'
                  }`}
                >
                  {plan.cta}
                </Link>
              </div>
            );
          })}
        </div>

        {/* Enterprise Callout */}
        <div className="bg-[#0b0f19] border border-gray-900 rounded-3xl p-8 flex flex-col md:flex-row items-center justify-between gap-6 max-w-4xl mx-auto">
          <div className="space-y-2">
            <h3 className="text-lg font-extrabold text-white">Require custom models or isolated single-tenant clusters?</h3>
            <p className="text-xs text-gray-400 max-w-xl leading-relaxed">
              Our Enterprise tier satisfies SOC2/HIPAA frameworks with custom hyperparameter boundaries, white-glove onboarding, and dedicated LLM engineers.
            </p>
          </div>
          <Link
            to="/contact"
            id="pricing-cta-enterprise"
            className="w-full md:w-auto px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-xs font-bold text-white transition-colors shrink-0 text-center"
          >
            Contact Enterprise Sales
          </Link>
        </div>
      </section>

      {/* 8. FAQ ACCORDION */}
      <section id="faq" className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="text-center space-y-4">
          <span className="text-xs font-bold text-blue-500 tracking-wider uppercase">Inquiries & Solves</span>
          <h2 className="text-3xl font-extrabold text-white tracking-tight">Frequently Asked Questions</h2>
          <p className="text-sm text-gray-400 max-w-md mx-auto leading-relaxed">
            Everything you need to understand about prompt compliance, model training sandboxes, and API credits.
          </p>
        </div>

        <div className="space-y-4" id="faq-accordion-group">
          {FAQ_DATA.map((item) => {
            const isOpen = openFaq === item.id;
            return (
              <div 
                key={item.id} 
                className="bg-gray-950/10 border border-gray-900 rounded-2xl overflow-hidden transition-all duration-200"
              >
                <button
                  onClick={() => toggleFaq(item.id)}
                  id={`faq-btn-${item.id}`}
                  className="w-full px-6 py-5 text-left flex items-center justify-between font-semibold text-gray-200 hover:text-white hover:bg-gray-900/10"
                >
                  <span className="text-sm">{item.question}</span>
                  {isOpen ? <ChevronUp className="w-4 h-4 text-blue-500" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
                </button>
                <div 
                  className={`px-6 border-t border-gray-900 bg-gray-950/20 text-xs text-gray-400 leading-relaxed transition-all duration-300 overflow-hidden ${
                    isOpen ? 'max-h-80 py-4 opacity-100' : 'max-h-0 py-0 opacity-0'
                  }`}
                >
                  <p>{item.answer}</p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 9. FINAL CTA */}
      <section id="final-cta" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-10">
        <div className="bg-gradient-to-tr from-blue-900/40 to-indigo-950/40 border border-blue-900/40 rounded-3xl p-8 md:p-12 text-center space-y-6 max-w-5xl mx-auto relative overflow-hidden">
          {/* subtle decoration glow */}
          <div className="absolute -top-10 -left-10 w-40 h-40 bg-blue-500/10 rounded-full blur-2xl" />
          <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-indigo-500/10 rounded-full blur-2xl" />

          <h2 className="text-3xl md:text-4xl font-extrabold text-white tracking-tight max-w-xl mx-auto leading-tight">
            Ready to convert prompts into production results?
          </h2>
          <p className="text-sm text-gray-300 max-w-md mx-auto leading-relaxed">
            Create your offline sandbox instantly, audit historical specs files, and configure secure workflows in seconds.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4 pt-4">
            <Link
              to="/signup"
              id="final-cta-signup"
              className="px-8 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-xs font-bold text-white transition-colors"
            >
              Get Started Free
            </Link>
            <Link
              to="/contact"
              id="final-cta-sales"
              className="px-8 py-3.5 rounded-xl bg-gray-900 hover:bg-gray-800 text-xs font-bold text-gray-300 hover:text-white border border-gray-800 transition-colors"
            >
              Consult an Architect
            </Link>
          </div>
        </div>
      </section>

    </div>
  );
}
