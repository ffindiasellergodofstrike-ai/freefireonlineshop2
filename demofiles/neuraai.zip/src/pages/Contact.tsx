import React, { useState } from 'react';
import { Mail, MessageSquare, Phone, MapPin, Send, CheckCircle, AlertCircle, RefreshCw } from 'lucide-react';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    subject: 'sales',
    message: ''
  });
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    // Validations
    if (!formData.name.trim() || !formData.email.trim() || !formData.message.trim()) {
      setError('Please fill in all required fields (Name, Email, Message).');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      setError('Please enter a valid email address.');
      return;
    }

    if (formData.message.trim().length < 10) {
      setError('Message must contain at least 10 characters.');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setSuccess(true);
      setFormData({
        name: '',
        email: '',
        company: '',
        subject: 'sales',
        message: ''
      });
      setTimeout(() => setSuccess(false), 5000);
    }, 1500);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div id="contact-page" className="pt-24 space-y-20 min-h-screen">
      
      {/* Header */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 text-center space-y-4 relative">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
        <span className="text-xs font-bold text-blue-500 tracking-wider uppercase">Contact Channels</span>
        <h1 className="text-4xl md:text-5xl font-black text-white tracking-tight leading-tight">
          Connect With Our Architects.
        </h1>
        <p className="text-sm text-gray-400 max-w-2xl mx-auto leading-relaxed">
          Submit custom security requirement briefs, request a single-tenant workspace cluster demonstration, or coordinate developer API support.
        </p>
      </section>

      {/* Grid: Contact Details and Form */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12 pb-20">
        
        {/* Left Side: Detail channels (Col span 5) */}
        <div className="lg:col-span-5 space-y-8">
          <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest pl-1">Communication Briefs</h3>
          
          <div className="grid gap-4">
            {[
              { title: 'Enterprise Sales', detail: 'sales@neura-ai.dev', desc: 'SLA parameters, single-tenant configurations, compliance auditing.', icon: Mail },
              { title: 'Developer Support', detail: 'support@neura-ai.dev', desc: 'SDK issues, gRPC routing queries, token limits and rates.', icon: MessageSquare },
              { title: 'Principal Operations Office', detail: 'San Francisco, CA', desc: '820 Mission St, San Francisco, CA 94103', icon: MapPin }
            ].map((channel, idx) => {
              const Icon = channel.icon;
              return (
                <div key={idx} className="bg-[#070b14] border border-gray-900 p-6 rounded-2xl flex items-start gap-4 hover:border-gray-800 transition-colors">
                  <div className="w-10 h-10 rounded-xl bg-gray-950 flex items-center justify-center border border-gray-800 text-blue-500 shrink-0">
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">{channel.title}</h4>
                    <p className="text-sm font-semibold text-gray-200 mt-1">{channel.detail}</p>
                    <p className="text-[11px] text-gray-500 mt-0.5 leading-relaxed">{channel.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Side: Contact Form (Col span 7) */}
        <div className="lg:col-span-7 bg-[#070b14] border border-gray-900 rounded-3xl p-6 lg:p-8 space-y-6">
          <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest pl-1">Inquiry Form</h3>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Your Full Name *</label>
                <input
                  type="text"
                  name="name"
                  placeholder="e.g. Sarah Jenkins"
                  value={formData.name}
                  onChange={handleInputChange}
                  className="w-full bg-[#030712] border border-gray-800 focus:border-blue-500 rounded-xl px-4 py-3 text-xs text-gray-200 placeholder-gray-500 focus:outline-none transition-colors"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Email Address *</label>
                <input
                  type="email"
                  name="email"
                  placeholder="e.g. sarah@synergy.corp"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="w-full bg-[#030712] border border-gray-800 focus:border-blue-500 rounded-xl px-4 py-3 text-xs text-gray-200 placeholder-gray-500 focus:outline-none transition-colors"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Company / Organization</label>
                <input
                  type="text"
                  name="company"
                  placeholder="e.g. Synergy Corp"
                  value={formData.company}
                  onChange={handleInputChange}
                  className="w-full bg-[#030712] border border-gray-800 focus:border-blue-500 rounded-xl px-4 py-3 text-xs text-gray-200 placeholder-gray-500 focus:outline-none transition-colors"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Subject Inquiries</label>
                <select
                  name="subject"
                  value={formData.subject}
                  onChange={handleInputChange}
                  className="w-full bg-[#030712] border border-gray-800 focus:border-blue-500 rounded-xl p-3 text-xs text-gray-300 focus:outline-none transition-colors"
                >
                  <option value="sales">Enterprise Sales Plan / Demonstration</option>
                  <option value="api">Product API Access Keys</option>
                  <option value="support">General Developer Support SLA</option>
                  <option value="talent">Talent Acquisitions & Careers</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1">Your Message Brief *</label>
              <textarea
                name="message"
                rows={5}
                placeholder="Briefly state your requirements, volume limits, compliance benchmarks, and integrations needs..."
                value={formData.message}
                onChange={handleInputChange}
                className="w-full bg-[#030712] border border-gray-800 focus:border-blue-500 rounded-xl p-4 text-xs text-gray-200 placeholder-gray-500 focus:outline-none transition-colors resize-none"
              />
            </div>

            {error && (
              <div className="p-3.5 bg-red-950/20 border border-red-900/30 text-[11px] text-red-400 font-semibold rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            {success && (
              <div className="p-3.5 bg-emerald-950/20 border border-emerald-900/30 text-[11px] text-emerald-400 font-semibold rounded-xl flex items-center gap-2">
                <CheckCircle className="w-4 h-4 shrink-0" />
                <span>Inquiry dispatched! Our LLM system architects will reply within 4 hours.</span>
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-xs font-bold text-white transition-all flex items-center justify-center gap-2 shadow-md disabled:opacity-50"
            >
              {isSubmitting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Submitting inquiry...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Dispatch Message Brief</span>
                </>
              )}
            </button>

          </form>
        </div>

      </section>

    </div>
  );
}
