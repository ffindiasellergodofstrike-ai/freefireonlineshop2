import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Cpu, ShieldCheck, Zap, Terminal, Copy, Check, Search, ArrowRight } from 'lucide-react';

export default function Resources() {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const triggerCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const sdkCodeString = `// Initialize NeuraAI Client
import { NeuraAI } from 'neura-ai-node-sdk';

const client = new NeuraAI({
  apiKey: process.env.NEURAAI_API_KEY,
  tenantId: '0x9f6'
});

// Stream context-aware synthesis responses
const response = await client.chat.synthesize({
  prompt: 'Draft technical requirements for isolated single-tenant gRPC routes',
  temperature: 0.2
});

console.log(response.text);`;

  const resourcesList = [
    {
      title: 'Prompt Engineering Mastery Guide',
      category: 'Guides',
      desc: 'Master the art of structuring hyper-focused prompts with context cached tokens to ensure 100% compliant outputs and minimize processing latencies.',
      readTime: '12 min read'
    },
    {
      title: 'Multi-Tenant Security Isolation Architecture',
      category: 'Whitepapers',
      desc: 'An exhaustive technical walkthrough detailing how NeuraAI enforces private container sandboxes, ensuring zero prompt-leakages across accounts.',
      readTime: '20 min read'
    },
    {
      title: 'Visual Workflow Event-Trigger Schemas',
      category: 'Documentation',
      desc: 'Learn how to map webhook logs, Slack channels, and SQL relational rows into visual trigger-action orchestrations in English.',
      readTime: '8 min read'
    }
  ];

  const filteredResources = resourcesList.filter(res => 
    res.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    res.desc.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div id="resources-page" className="pt-24 space-y-32">
      
      {/* Header */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 text-center space-y-4 relative">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
        <span className="text-xs font-bold text-blue-500 tracking-wider uppercase">Developer Resources</span>
        <h1 className="text-4xl md:text-5xl font-black text-white tracking-tight leading-tight">
          Master the NeuraAI SDK Stack.
        </h1>
        <p className="text-sm text-gray-400 max-w-2xl mx-auto leading-relaxed">
          Access high-fidelity guides, whitepapers on security isolation, and standard terminal CLI commands built for engineering velocity.
        </p>
      </section>

      {/* Guides, SDK Specs, and CLI Snippet Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12">
        
        {/* Left Side: Guides and Tutorials (Col span 7) */}
        <div className="lg:col-span-7 space-y-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest pl-1">Knowledge Directory</h3>
            
            {/* Search */}
            <div className="relative w-full sm:max-w-xs">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4.2 h-4.2 text-gray-500" />
              <input
                type="text"
                placeholder="Search resources..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#0b0f19] border border-gray-800 focus:border-blue-500 rounded-xl pl-9 pr-4 py-2.5 text-xs text-gray-100 placeholder-gray-500 focus:outline-none"
              />
            </div>
          </div>

          <div className="space-y-4">
            {filteredResources.map((res, index) => (
              <div 
                key={index} 
                className="bg-[#070b14] border border-gray-900 hover:border-gray-850 p-6 rounded-2xl space-y-4 flex flex-col justify-between transition-all"
              >
                <div className="space-y-2">
                  <span className="text-[9px] font-bold text-blue-400 bg-blue-500/10 border border-blue-500/20 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                    {res.category}
                  </span>
                  <h4 className="text-sm font-extrabold text-white">{res.title}</h4>
                  <p className="text-xs text-gray-400 leading-relaxed">{res.desc}</p>
                </div>
                
                <div className="flex items-center justify-between pt-2 border-t border-gray-900/50">
                  <span className="text-[10px] text-gray-500 font-semibold">{res.readTime}</span>
                  <Link
                    to="/blog"
                    className="text-xs font-bold text-blue-500 hover:text-blue-400 transition-colors flex items-center gap-1"
                  >
                    <span>Read resource</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                </div>
              </div>
            ))}

            {filteredResources.length === 0 && (
              <p className="text-xs text-gray-500 text-center py-10 font-medium">No educational resources match your search.</p>
            )}
          </div>
        </div>

        {/* Right Side: Interactive Node SDK Terminal Mockup (Col span 5) */}
        <div className="lg:col-span-5 space-y-4">
          <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest pl-1">JavaScript / Node SDK</h3>
          
          <div className="bg-gray-950/60 rounded-3xl border border-gray-900 overflow-hidden shadow-lg shadow-black/30">
            {/* Terminal Top tab */}
            <div className="bg-[#0b0f19] border-b border-gray-900 px-5 py-4 flex items-center justify-between">
              <span className="text-gray-500 font-mono text-[9px] font-bold uppercase tracking-wider">sample_neura_integration.js</span>
              <button
                onClick={() => triggerCopy('sdk', sdkCodeString)}
                className="flex items-center gap-1 px-2 py-1 rounded bg-gray-900 hover:bg-gray-800 text-[10px] text-gray-400 hover:text-white transition-colors font-semibold"
              >
                {copiedId === 'sdk' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedId === 'sdk' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>

            <pre className="p-6 font-mono text-[11px] text-gray-300 leading-relaxed overflow-x-auto whitespace-pre">
              {sdkCodeString}
            </pre>
          </div>
        </div>

      </section>

      {/* Developer CTA */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-10">
        <div className="bg-[#0b0f19] border border-gray-900 rounded-3xl p-8 lg:p-12 text-center space-y-6 max-w-4xl mx-auto">
          <h2 className="text-2xl font-extrabold text-white tracking-tight leading-tight">Need custom SDK access structures?</h2>
          <p className="text-xs text-gray-400 max-w-xl mx-auto leading-relaxed">
            Our API solutions are compatible with Python wrappers, Rust crates, and gRPC microservice configurations. Connect with our principal cloud architect to establish dedicated routes.
          </p>
          <div className="pt-2">
            <Link
              to="/contact"
              className="px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-xs font-bold text-white transition-colors"
            >
              Consult Solutions Architect
            </Link>
          </div>
        </div>
      </section>

    </div>
  );
}
