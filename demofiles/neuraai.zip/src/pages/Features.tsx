import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  MessageSquare, Sparkles, FileText, Zap, Bot, BarChart3,
  Cpu, ShieldCheck, CheckCircle, ArrowRight, ArrowDownRight, Terminal
} from 'lucide-react';

export default function Features() {
  const [activeTab, setActiveTab] = useState('chat');

  const featureTabs = [
    { 
      id: 'chat', 
      title: 'AI Chat Core', 
      icon: MessageSquare,
      headline: 'Context-aware, zero-leakage conversation intelligence.',
      desc: 'Our Chat Core runs in strictly isolated tenant environments, ensuring proprietary codebases, research notes, and operational logs are never saved, shared, or compiled into public datasets.',
      bullets: [
        'Isolated container runtimes for each workspace.',
        'Sub-80ms context caching for complex prompt backlogs.',
        'Supports deep system modeling and spec generation in pure English.',
        'No public dataset model tracking.'
      ],
      metric: '80ms',
      metricLabel: 'Context Latency'
    },
    { 
      id: 'content', 
      title: 'Content Suite', 
      icon: Sparkles,
      headline: 'Generate high-converting creative assets in seconds.',
      desc: 'Formulate localized ad copies, technical specs sheets, and cold outreach pipelines matching corporate compliance guidelines, word limits, and exact brand voices.',
      bullets: [
        'Brand-tone fine-tuning templates.',
        'Multi-lingual generation with local dialects.',
        'SEO-optimized meta description and blog hooks on autopilot.',
        'Saves up to 40% drafting cycles.'
      ],
      metric: '3s',
      metricLabel: 'Average Draft Speed'
    },
    { 
      id: 'doc', 
      title: 'Document Intelligence', 
      icon: FileText,
      headline: 'Extract complex vectors and find risks in large documents.',
      desc: 'Our document parser scans contract PDFs, backend logs, and product requirements. It generates a clear summary of compliance vectors and flags exposure alerts in real time.',
      bullets: [
        'Secure drag & drop scanning up to 100MB documents.',
        'Detects hidden development stubs and IP risks.',
        'Extracts structured compliance checklists automatically.',
        'Compatible with PDF, Word, TXT, and JSON.'
      ],
      metric: '2s',
      metricLabel: 'Doc Processing Speed'
    },
    { 
      id: 'workflow', 
      title: 'Workflow Automation', 
      icon: Zap,
      headline: 'Visual, code-free trigger-action orchestration pipelines.',
      desc: 'Link Slack notifications, HubSpot updates, or SQL databases to NeuraAI. Instruct our engine in English to trigger actions upon webhook events.',
      bullets: [
        'Visual step builder with test run monitors.',
        '150+ pre-built third-party triggers & actions.',
        'Automate specifications updates directly from Git commits.',
        'Supports nested logic branches and error failovers.'
      ],
      metric: '150+',
      metricLabel: 'Native Integrations'
    },
    { 
      id: 'agents', 
      title: 'Autonomous Agents', 
      icon: Bot,
      headline: 'Virtual workspace employees executing complex audits.',
      desc: 'Define custom hyperparameter weights and let our virtual employees run compliance checklists, marketing briefs, and code specification drafting on autopilot.',
      bullets: [
        'Adjustable temperature scales for strict or creative parameters.',
        'Enforce rigid operational boundaries per agent.',
        'Direct connection to visual workflow trigger streams.',
        'White-glove concierge agent onboarding.'
      ],
      metric: '0.0',
      metricLabel: 'Strict Temperature'
    }
  ];

  const activeFeature = featureTabs.find(tab => tab.id === activeTab);

  return (
    <div id="features-page" className="pt-24 space-y-32">
      
      {/* Hero Header */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 text-center space-y-4 relative">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
        <span className="text-xs font-bold text-blue-500 tracking-wider uppercase">Platform Features</span>
        <h1 className="text-4xl md:text-5xl font-black text-white tracking-tight leading-tight">
          Engineered for Premium AI Operations.
        </h1>
        <p className="text-sm text-gray-400 max-w-2xl mx-auto leading-relaxed">
          Unlock a comprehensive, enterprise-grade AI suite built with strict isolation, sub-150ms edge latency, and seamless visual workflows.
        </p>
      </section>

      {/* Interactive Feature Tabs */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 bg-gray-950/20 border border-gray-900 rounded-3xl p-6 lg:p-8">
          
          {/* Tabs Navigation (Col span 4) */}
          <div className="lg:col-span-4 flex flex-col gap-2">
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest pl-3 mb-3">Capabilities Panel</h3>
            {featureTabs.map(tab => {
              const TabIcon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-4 px-4 py-4 rounded-2xl text-left transition-all ${
                    activeTab === tab.id 
                      ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/10' 
                      : 'text-gray-400 hover:text-white hover:bg-gray-900/40'
                  }`}
                >
                  <div className={`w-9 h-9 rounded-lg flex items-center justify-center border transition-colors ${
                    activeTab === tab.id ? 'bg-blue-500 border-blue-400' : 'bg-[#030712] border-gray-800'
                  }`}>
                    <TabIcon className="w-4.5 h-4.5" />
                  </div>
                  <div>
                    <span className="text-sm font-bold block">{tab.title}</span>
                    <span className="text-[10px] text-gray-400/85 mt-0.5 block line-clamp-1">
                      {tab.id === 'chat' && 'Isolated chat containers'}
                      {tab.id === 'content' && 'Outreach copy & specs'}
                      {tab.id === 'doc' && 'SOC2 compliance scanners'}
                      {tab.id === 'workflow' && 'English-based webhook loops'}
                      {tab.id === 'agents' && 'Virtual agent structures'}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Active Tab Showcase (Col span 8) */}
          <div className="lg:col-span-8 bg-[#030712]/60 border border-gray-900 rounded-3xl p-6 lg:p-8 flex flex-col justify-between gap-8 min-h-[460px]">
            {activeFeature && (
              <>
                <div className="space-y-6">
                  {/* Top Header */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-gray-900 pb-4 gap-4">
                    <h2 className="text-xl md:text-2xl font-black text-white leading-snug">
                      {activeFeature.headline}
                    </h2>
                    
                    {/* Performance Stat Tag */}
                    <div className="bg-[#0b0f19] border border-gray-800 rounded-2xl px-4 py-2 text-center min-w-[120px] shrink-0">
                      <p className="text-lg font-extrabold text-blue-400 font-mono leading-none">{activeFeature.metric}</p>
                      <p className="text-[9px] text-gray-500 font-semibold uppercase mt-1 leading-none">{activeFeature.metricLabel}</p>
                    </div>
                  </div>

                  {/* Body description */}
                  <p className="text-xs text-gray-400 leading-relaxed max-w-2xl">{activeFeature.desc}</p>

                  {/* Checklist Bullets */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                    {activeFeature.bullets.map((bullet, idx) => (
                      <div key={idx} className="flex items-start gap-2.5 text-xs text-gray-300">
                        <CheckCircle className="w-4 h-4 text-blue-500 mt-0.5 shrink-0" />
                        <span>{bullet}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Bottom interactive simulator links */}
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-6 border-t border-gray-900 mt-auto">
                  <span className="text-[11px] text-gray-500 flex items-center gap-1">
                    <Terminal className="w-3.5 h-3.5 text-blue-500" />
                    <span>Try this capability live inside the interactive workspace sandbox.</span>
                  </span>
                  
                  <Link
                    to="/dashboard"
                    className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-xs font-bold text-white transition-colors flex items-center justify-center gap-1.5 shrink-0 active:scale-95 shadow-md"
                  >
                    <span>Launch Sandbox</span>
                    <ArrowRight className="w-4 h-4" />
                  </Link>
                </div>
              </>
            )}
          </div>
        </div>
      </section>

      {/* Security Architecture Deep Dive */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-tr from-gray-950/40 via-[#070b14] to-gray-950/20 border border-gray-900 rounded-3xl p-8 lg:p-12 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <span className="text-xs font-bold text-blue-500 tracking-wider uppercase">Compliance Framework</span>
            <h2 className="text-3xl font-extrabold text-white tracking-tight leading-tight">
              Absolute Data Governance. Built-In.
            </h2>
            <p className="text-xs text-gray-400 leading-relaxed">
              We enforce a strict privacy policy. Unlike general AI platforms, NeuraAI deploys your model requests into single-tenant memory units. Prompts, documents, context history, and output logs are fully encrypted and never stored or compiled into models.
            </p>
            
            <div className="space-y-4 pt-2">
              {[
                { title: 'Isolated Workspace Clusters', desc: 'Each tenant account owns an isolated database sandbox.' },
                { title: 'SOC2 & ISO Compliance Ready', desc: 'Pre-audited schemas satisfying enterprise compliance directives.' },
                { title: 'AES-256 Grade Encryption', desc: 'All data packets are encrypted during ingestion and active transit.' }
              ].map((item, idx) => (
                <div key={idx} className="flex gap-3">
                  <div className="w-5 h-5 rounded bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400 shrink-0 mt-0.5">
                    <ShieldCheck className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">{item.title}</h4>
                    <p className="text-[11px] text-gray-500 mt-0.5 leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Visual Specs Terminal Mockup */}
          <div className="bg-gray-950/60 rounded-2xl border border-gray-850 p-6 font-mono text-[11px] leading-relaxed text-gray-400 space-y-4">
            <div className="flex items-center justify-between border-b border-gray-900 pb-2.5">
              <span className="text-gray-500 uppercase tracking-widest text-[9px] font-bold">compliance_handshake.sh</span>
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
            </div>
            
            <div className="space-y-2">
              <p className="text-emerald-400">$ neuraai --authenticate-handshake --tenant-id="0x9f6"</p>
              <p className="text-gray-500">[SYSTEM] Syncing tenant certificates...</p>
              <p className="text-blue-400">✓ Isolated Single-Tenant Sandbox Configured.</p>
              <p className="text-blue-400">✓ 256-Bit TLS Payload Ingestion Protocol Verified.</p>
              <p className="text-blue-400">✓ Zero-Storage Policy initialized: Active data leaks prevented.</p>
              <p className="text-emerald-400">$ neuraai --compliance-audit --status</p>
              <p className="text-emerald-400">✓ Compliance Index: 100% (SOC2 Type II compliant boundaries)</p>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
}
