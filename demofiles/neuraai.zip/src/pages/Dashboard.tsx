import React, { useState, useRef } from 'react';
import { 
  MessageSquare, Sparkles, FileText, Zap, Cpu, BarChart3, 
  Send, Bot, ChevronRight, Play, RefreshCw, Upload, CheckCircle, 
  Copy, Plus, Trash2, ArrowRight, User, Settings, Layers, Activity
} from 'lucide-react';

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState('chat');
  const [credits, setCredits] = useState({ used: 142050, total: 500000 });

  // AI Chat State
  const [chatInput, setChatInput] = useState('');
  const [chatHistory, setChatHistory] = useState([
    { role: 'assistant', text: 'Welcome to your NeuraAI sandbox. I can assist you with system modeling, technical specifications, or automated copy drafting. What shall we design today?' }
  ]);
  const [isTyping, setIsTyping] = useState(false);

  // Content Gen State
  const [contentPrompt, setContentPrompt] = useState('');
  const [contentCategory, setContentCategory] = useState('saas-ad');
  const [contentTone, setContentTone] = useState('professional');
  const [generatedResult, setGeneratedResult] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isCopied, setIsCopied] = useState(false);

  // Doc Analysis State
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisReport, setAnalysisReport] = useState<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Workflow State
  const [workflowSteps, setWorkflowSteps] = useState([
    { id: 'step-1', type: 'trigger', name: 'Slack Hook', details: 'When message in #marketing-intel matches "PR"' },
    { id: 'step-2', type: 'action', name: 'NeuraAI Synthesize', details: 'Generate brief matching corporate guidelines' },
    { id: 'step-3', type: 'action', name: 'HubSpot Draft', details: 'Publish draft blog with high-converting hooks' }
  ]);
  const [selectedTrigger, setSelectedTrigger] = useState('Slack Hook');
  const [selectedAction, setSelectedAction] = useState('NeuraAI Synthesize');
  const [workflowTested, setWorkflowTested] = useState(false);
  const [testingProgress, setTestingProgress] = useState('');

  // AI Agents State
  const [agents, setAgents] = useState([
    { id: 'agent-1', name: 'Evelyn (Growth LLM)', role: 'Marketing Strategy', model: 'Neura-Flash-v3', status: 'Idle', temp: 0.7 },
    { id: 'agent-2', name: 'Marcus (Technical Spec)', role: 'Engineering Drafts', model: 'Neura-Ultra-v2', status: 'Idle', temp: 0.2 },
    { id: 'agent-3', name: 'Aero (Secure Audit)', role: 'Compliance Scan', model: 'Neura-Shield-v1', status: 'Active', temp: 0.0 }
  ]);
  const [selectedAgent, setSelectedAgent] = useState('agent-1');

  // Trigger file click
  const triggerFileSelect = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedFile(file);
      handleDocAnalysis(file.name);
    }
  };

  const handleDocAnalysis = (fileName: string) => {
    setIsAnalyzing(true);
    setAnalysisReport(null);
    setTimeout(() => {
      setIsAnalyzing(false);
      setAnalysisReport({
        title: fileName,
        wordCount: '4,280 words',
        readingTime: '15 mins',
        summary: 'The uploaded specifications document covers core system architecture, data ingestion models, and third-party credential handling. NeuraAI detected minor exposure risks and recommends applying strict isolated encryption containers.',
        findings: [
          'High compliance: Strictly satisfies SOC2 structural boundary requirements.',
          'Exposure Alert: Port mappings on line 142 reveal clear development stubs.',
          'Refinement Option: Model pipelines are currently configured to route via un-cached APIs.'
        ]
      });
      // Consume some credits
      setCredits(prev => ({ ...prev, used: prev.used + 1520 }));
    }, 2000);
  };

  // Chat Trigger
  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const userMessage = { role: 'user', text: chatInput };
    setChatHistory(prev => [...prev, userMessage]);
    const currentInput = chatInput;
    setChatInput('');
    setIsTyping(true);

    // Dynamic intelligent simulator replies
    setTimeout(() => {
      let replyText = "I have received your request. Let me structure an answer for you based on our core enterprise models.";
      
      const promptLower = currentInput.toLowerCase();
      if (promptLower.includes('latency') || promptLower.includes('speed')) {
        replyText = "NeuraAI API latency is optimized globally using persistent context caching. Standard edge responses average sub-150ms. If your models require sub-80ms access, our Single-Tenant Dedicated cluster offers tailored routing.";
      } else if (promptLower.includes('pricing') || promptLower.includes('cost')) {
        replyText = "We offer Free, Pro ($39/mo), and Business ($129/mo) plans. Business and Enterprise allow you to pay-as-you-go beyond the standard monthly credit allotments. Usage is monitored in real-time under your Analytics dashboard.";
      } else if (promptLower.includes('security') || promptLower.includes('privacy') || promptLower.includes('safe')) {
        replyText = "Security is our primary foundation. NeuraAI runs isolated sandbox runtimes. Prompts and proprietary corporate documents are never used for model training, matching strict ISO-27001 boundaries.";
      } else if (promptLower.includes('hello') || promptLower.includes('hi')) {
        replyText = "Hello! I am your NeuraAI intelligence partner. I can assist in drafting spec files, reviewing compliance logs, or setting up workflow automations. Type a complex task to see me break it down!";
      } else {
        replyText = `Understood. I have evaluated your request: "${currentInput}". Analyzing corporate parameters... Process completed. NeuraAI has optimized your task with 99.8% precision index. Let me know if you would like to export this script to Notion or Slack.`;
      }

      setChatHistory(prev => [...prev, { role: 'assistant', text: replyText }]);
      setIsTyping(false);
      setCredits(prev => ({ ...prev, used: Math.min(prev.used + 420, prev.total) }));
    }, 1200);
  };

  // Content Generation Simulator
  const handleContentGeneration = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contentPrompt.trim()) return;

    setIsGenerating(true);
    setGeneratedResult('');
    
    setTimeout(() => {
      let result = '';
      if (contentCategory === 'saas-ad') {
        result = `🚀 Headline: Stop Over-Engineering. Start Scaling.
        
Tired of wasting valuable developer resources configuring custom wrapper APIs? NeuraAI delivers enterprise-grade AI chat, document intelligence, and visual workflows out of the box. 

👉 Connect your databases in 5 minutes.
👉 Guarantee sub-150ms response speed.
👉 Secure isolated cloud sandboxes.

Turn ideas into results today. Get started with NeuraAI Core for free.`;
      } else if (contentCategory === 'specs') {
        result = `SYSTEM ARCHITECTURE: NEURAAI INTEGRATION PIPELINE
------------------------------------------------------
[Trigger Source] -> [Event Stream Router] -> [Isolated Model Container]
  
Specifications:
- Authentication: OAuth2 Bearer with AES-256 JWT payloads.
- Protocol: gRPC for microservices, HTTPS REST for secondary integrations.
- Latency threshold: Max limit 180ms; optimized target 110ms via Context Cache.
- Edge Policy: Failover to fallback region automatically upon heartbeat latency >250ms.`;
      } else if (contentCategory === 'email') {
        result = `Subject: Quick feedback on ${contentPrompt || 'your data operations'}?

Hi there,

I noticed your engineering team is actively building out micro-services. Many fast-growing SaaS entities hit a major bottleneck when configuring API wrappers—latencies creep past 400ms and cloud computing bills spiral out of control.

NeuraAI offers an out-of-the-box autonomous agent system that runs in isolated single-tenant sandboxes, keeping credentials safe while delivering sub-150ms response latency.

Would you be open to a 10-minute technical review next Tuesday to see our visual workflow engine in action?

Best,
The NeuraAI Architecture Team`;
      } else {
        result = `NeuraAI generated custom assets based on: "${contentPrompt}". 
Selected Tone: ${contentTone.toUpperCase()}.
Status: Code clean. Conversion performance predicted: High.`;
      }

      setGeneratedResult(result);
      setIsGenerating(false);
      setCredits(prev => ({ ...prev, used: Math.min(prev.used + 2800, prev.total) }));
    }, 1500);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedResult);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  // Add Step to Workflow
  const addWorkflowStep = () => {
    const isEven = workflowSteps.length % 2 === 0;
    const newStep = {
      id: `step-${Date.now()}`,
      type: isEven ? 'trigger' : 'action',
      name: isEven ? selectedTrigger : selectedAction,
      details: isEven 
        ? 'Listens to external source webhook' 
        : 'Processes text with NeuraAI core model'
    };
    setWorkflowSteps([...workflowSteps, newStep]);
    setCredits(prev => ({ ...prev, used: Math.min(prev.used + 500, prev.total) }));
  };

  const removeWorkflowStep = (id: string) => {
    setWorkflowSteps(workflowSteps.filter(step => step.id !== id));
  };

  // Test Workflow
  const testWorkflow = () => {
    setWorkflowTested(true);
    setTestingProgress('Connecting hooks...');
    setTimeout(() => {
      setTestingProgress('Piping triggers to NeuraAI isolated sandbox...');
      setTimeout(() => {
        setTestingProgress('Synthesizing action deliverables...');
        setTimeout(() => {
          setTestingProgress('Workflow validated! 100% test run succeeded.');
          setCredits(prev => ({ ...prev, used: Math.min(prev.used + 1200, prev.total) }));
        }, 1000);
      }, 1000);
    }, 1000);
  };

  // Adjust Agent parameter
  const updateAgentTemp = (id: string, val: string) => {
    setAgents(agents.map(agent => {
      if (agent.id === id) {
        return { ...agent, temp: parseFloat(val) };
      }
      return agent;
    }));
  };

  return (
    <div id="dashboard-page" className="pt-24 pb-20 min-h-screen bg-[#030712]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Dash Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between pb-8 border-b border-gray-900 gap-6">
          <div>
            <h1 className="text-3xl font-extrabold text-white tracking-tight flex items-center gap-2">
              Workspace Core <span className="text-xs font-semibold bg-blue-500/10 text-blue-400 border border-blue-500/20 px-2.5 py-0.5 rounded-full">SANDBOX ACTIVE</span>
            </h1>
            <p className="text-gray-400 mt-1 text-sm">
              Design, test, and preview custom LLM parameters, pipelines, and autonomous workflows.
            </p>
          </div>
          
          {/* Quick Credit Meter */}
          <div className="bg-[#0b0f19] border border-gray-800 rounded-2xl p-4 flex items-center gap-4 min-w-[280px]">
            <div className="flex-1">
              <div className="flex items-center justify-between text-xs font-semibold">
                <span className="text-gray-400">Monthly Usage Credits</span>
                <span className="text-blue-400">{((credits.used / credits.total) * 100).toFixed(1)}%</span>
              </div>
              <div className="w-full bg-gray-800 h-2 rounded-full mt-2 overflow-hidden">
                <div 
                  className="bg-gradient-to-r from-blue-500 to-indigo-500 h-full rounded-full transition-all duration-500" 
                  style={{ width: `${(credits.used / credits.total) * 100}%` }}
                />
              </div>
              <div className="flex justify-between items-center text-[11px] text-gray-500 mt-1.5">
                <span>{credits.used.toLocaleString()} tokens</span>
                <span>{credits.total.toLocaleString()} limit</span>
              </div>
            </div>
            <button 
              onClick={() => setCredits(prev => ({ ...prev, used: 142050 }))}
              className="p-2 bg-gray-800/50 hover:bg-gray-800 rounded-lg text-gray-400 hover:text-white transition-colors"
              title="Reset Sandbox Credits"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Dash Layout Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 mt-10">
          
          {/* Left Navigation Sidebar */}
          <div className="lg:col-span-1 space-y-2">
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest pl-3 mb-3">AI Product Experience</h3>
            <button
              onClick={() => setActiveTab('chat')}
              className={`flex items-center gap-3 w-full px-4 py-3.5 rounded-xl text-sm font-semibold transition-all ${
                activeTab === 'chat' 
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/10' 
                  : 'text-gray-400 hover:text-gray-200 hover:bg-gray-900/60'
              }`}
            >
              <MessageSquare className="w-4.5 h-4.5" />
              <span>AI Chat Core</span>
            </button>
            <button
              onClick={() => setActiveTab('content')}
              className={`flex items-center gap-3 w-full px-4 py-3.5 rounded-xl text-sm font-semibold transition-all ${
                activeTab === 'content' 
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/10' 
                  : 'text-gray-400 hover:text-gray-200 hover:bg-gray-900/60'
              }`}
            >
              <Sparkles className="w-4.5 h-4.5" />
              <span>Content Suite</span>
            </button>
            <button
              onClick={() => setActiveTab('doc')}
              className={`flex items-center gap-3 w-full px-4 py-3.5 rounded-xl text-sm font-semibold transition-all ${
                activeTab === 'doc' 
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/10' 
                  : 'text-gray-400 hover:text-gray-200 hover:bg-gray-900/60'
              }`}
            >
              <FileText className="w-4.5 h-4.5" />
              <span>Document Intelligence</span>
            </button>
            <button
              onClick={() => setActiveTab('workflow')}
              className={`flex items-center gap-3 w-full px-4 py-3.5 rounded-xl text-sm font-semibold transition-all ${
                activeTab === 'workflow' 
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/10' 
                  : 'text-gray-400 hover:text-gray-200 hover:bg-gray-900/60'
              }`}
            >
              <Zap className="w-4.5 h-4.5" />
              <span>Workflow Automation</span>
            </button>
            <button
              onClick={() => setActiveTab('agents')}
              className={`flex items-center gap-3 w-full px-4 py-3.5 rounded-xl text-sm font-semibold transition-all ${
                activeTab === 'agents' 
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/10' 
                  : 'text-gray-400 hover:text-gray-200 hover:bg-gray-900/60'
              }`}
            >
              <Bot className="w-4.5 h-4.5" />
              <span>Autonomous Agents</span>
            </button>
            <button
              onClick={() => setActiveTab('analytics')}
              className={`flex items-center gap-3 w-full px-4 py-3.5 rounded-xl text-sm font-semibold transition-all ${
                activeTab === 'analytics' 
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/10' 
                  : 'text-gray-400 hover:text-gray-200 hover:bg-gray-900/60'
              }`}
            >
              <BarChart3 className="w-4.5 h-4.5" />
              <span>Analytics & Metrics</span>
            </button>

            {/* Quick Helper Box */}
            <div className="bg-[#0b0f19] border border-gray-800/80 rounded-2xl p-4 mt-8">
              <div className="flex items-center gap-2 text-xs font-bold text-gray-200">
                <Cpu className="w-4 h-4 text-blue-500" />
                <span>NeuraAI Terminal v1.4</span>
              </div>
              <p className="text-[11px] text-gray-500 mt-2 leading-relaxed">
                Run sandbox testing securely. All operations reflect real model response parameters with simulated latency bounds.
              </p>
            </div>
          </div>

          {/* Right Interface Console */}
          <div className="lg:col-span-3 bg-[#070b14] border border-gray-800 rounded-3xl overflow-hidden shadow-2xl shadow-black/80 flex flex-col min-h-[560px]">
            
            {/* Console Tabs / Header */}
            <div className="bg-[#0b0f19] border-b border-gray-800 px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-3.5 h-3.5 rounded-full bg-blue-500/20 flex items-center justify-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
                </div>
                <span className="text-xs font-bold font-mono text-gray-400 uppercase tracking-widest">
                  {activeTab === 'chat' && 'interactive_chat_core.sh'}
                  {activeTab === 'content' && 'high_converting_copy_suite.exe'}
                  {activeTab === 'doc' && 'document_structural_analyzer.bin'}
                  {activeTab === 'workflow' && 'workflow_trigger_automation.json'}
                  {activeTab === 'agents' && 'autonomous_agent_matrix_config'}
                  {activeTab === 'analytics' && 'performance_latency_telemetry.log'}
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-2.5 h-2.5 rounded-full bg-red-500/40" />
                <div className="w-2.5 h-2.5 rounded-full bg-amber-500/40" />
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/40" />
              </div>
            </div>

            {/* Console Workspace Content */}
            <div className="flex-1 p-6 overflow-y-auto">
              
              {/* TAB 1: AI CHAT CORE */}
              {activeTab === 'chat' && (
                <div className="flex flex-col h-full justify-between gap-6">
                  <div className="space-y-4 max-h-[360px] overflow-y-auto pr-2">
                    {chatHistory.map((msg, index) => (
                      <div 
                        key={index} 
                        className={`flex gap-3 max-w-[85%] ${msg.role === 'user' ? 'ml-auto flex-row-reverse' : ''}`}
                      >
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border ${
                          msg.role === 'user' 
                            ? 'bg-blue-600 border-blue-500 text-white' 
                            : 'bg-gray-800 border-gray-700 text-gray-300'
                        }`}>
                          {msg.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                        </div>
                        <div className={`rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                          msg.role === 'user' 
                            ? 'bg-blue-600 text-white' 
                            : 'bg-gray-800/40 text-gray-200 border border-gray-800/80'
                        }`}>
                          <p>{msg.text}</p>
                        </div>
                      </div>
                    ))}
                    {isTyping && (
                      <div className="flex gap-3 max-w-[80%]">
                        <div className="w-8 h-8 rounded-lg bg-gray-800 border border-gray-700 text-gray-300 flex items-center justify-center">
                          <Bot className="w-4 h-4" />
                        </div>
                        <div className="rounded-2xl px-4 py-3 bg-gray-800/20 text-gray-400 text-sm border border-gray-800/80 flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                          <span className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                          <span className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                        </div>
                      </div>
                    )}
                  </div>

                  <form onSubmit={handleChatSubmit} className="relative mt-auto">
                    <input
                      type="text"
                      placeholder="Type a query (e.g. Discuss API latency, corporate privacy boundaries, or plan cost details)..."
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      className="w-full bg-[#030712] border border-gray-800 focus:border-blue-500 rounded-xl px-4 py-3 text-sm text-gray-100 placeholder-gray-500 focus:outline-none transition-colors pr-12"
                    />
                    <button
                      type="submit"
                      className="absolute right-1.5 top-1.5 bottom-1.5 bg-blue-600 hover:bg-blue-500 text-white px-3 rounded-lg flex items-center justify-center transition-colors active:scale-95"
                    >
                      <Send className="w-4.5 h-4.5" />
                    </button>
                  </form>
                </div>
              )}

              {/* TAB 2: CONTENT SUITE */}
              {activeTab === 'content' && (
                <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                  
                  {/* Left Controls */}
                  <form onSubmit={handleContentGeneration} className="md:col-span-2 space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-1.5">Asset Template</label>
                      <select 
                        value={contentCategory} 
                        onChange={(e) => setContentCategory(e.target.value)}
                        className="w-full bg-[#030712] border border-gray-800 focus:border-blue-500 rounded-xl p-2.5 text-xs text-gray-200 focus:outline-none transition-colors"
                      >
                        <option value="saas-ad">High-Converting SaaS Ad Copy</option>
                        <option value="specs">System Technical Specs</option>
                        <option value="email">Cold Sales Outreach Template</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-1.5">Writing Tone</label>
                      <div className="grid grid-cols-2 gap-2">
                        {['professional', 'persuasive', 'sleek', 'bold'].map(tone => (
                          <button
                            type="button"
                            key={tone}
                            onClick={() => setContentTone(tone)}
                            className={`px-3 py-1.5 rounded-lg text-[11px] font-semibold uppercase tracking-wider border transition-colors ${
                              contentTone === tone 
                                ? 'bg-blue-600 border-blue-500 text-white' 
                                : 'bg-[#030712] border-gray-800 text-gray-400 hover:border-gray-700'
                            }`}
                          >
                            {tone}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-1.5">Context / Prompt Keywords</label>
                      <textarea
                        rows={3}
                        placeholder="Provide keywords or target pitch parameters..."
                        value={contentPrompt}
                        onChange={(e) => setContentPrompt(e.target.value)}
                        className="w-full bg-[#030712] border border-gray-800 focus:border-blue-500 rounded-xl p-3 text-xs text-gray-200 placeholder-gray-500 focus:outline-none transition-colors resize-none"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={isGenerating || !contentPrompt.trim()}
                      className="w-full py-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-xs font-bold text-white transition-all flex items-center justify-center gap-2 shadow-md disabled:opacity-50"
                    >
                      {isGenerating ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          <span>Generating copy...</span>
                        </>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4" />
                          <span>Synthesize Copy</span>
                        </>
                      )}
                    </button>
                  </form>

                  {/* Right Output */}
                  <div className="md:col-span-3 bg-[#030712] border border-gray-800 rounded-2xl p-4 flex flex-col justify-between min-h-[300px]">
                    <div className="flex-1">
                      <div className="flex items-center justify-between border-b border-gray-900 pb-2 mb-3">
                        <span className="text-xs font-bold text-gray-400">Model Output Terminal</span>
                        {generatedResult && (
                          <button
                            onClick={copyToClipboard}
                            className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-gray-800 hover:bg-gray-700 text-[10px] font-bold text-gray-300 transition-colors"
                          >
                            {isCopied ? <CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                            <span>{isCopied ? 'Copied' : 'Copy'}</span>
                          </button>
                        )}
                      </div>
                      
                      {generatedResult ? (
                        <pre className="text-xs text-gray-300 font-mono whitespace-pre-wrap leading-relaxed">
                          {generatedResult}
                        </pre>
                      ) : (
                        <div className="h-full flex flex-col items-center justify-center text-center py-12 text-gray-500">
                          <Sparkles className="w-8 h-8 text-gray-700 mb-2 animate-pulse" />
                          <p className="text-xs max-w-xs font-medium">Provide context prompts on the left and trigger synthesis to see custom structured copy outputs.</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: DOCUMENT INTELLIGENCE */}
              {activeTab === 'doc' && (
                <div className="space-y-6">
                  
                  {/* Upload Drop Zone */}
                  <div 
                    onClick={triggerFileSelect}
                    className="border-2 border-dashed border-gray-800 hover:border-blue-500/50 rounded-2xl p-8 text-center cursor-pointer bg-[#030712]/50 hover:bg-blue-950/5 transition-all duration-300"
                  >
                    <input 
                      type="file" 
                      ref={fileInputRef}
                      onChange={handleFileChange}
                      className="hidden" 
                      accept=".pdf,.doc,.docx,.txt,.json"
                    />
                    <Upload className="w-10 h-10 text-gray-500 hover:text-blue-400 mx-auto mb-4 transition-colors" />
                    <h3 className="text-sm font-bold text-gray-200">Drag & Drop Document Here</h3>
                    <p className="text-xs text-gray-500 mt-1 max-w-sm mx-auto leading-relaxed">
                      Supports PDF, Word, TXT, or JSON (Max 100MB). Files are analyzed inside isolated single-tenant memory and never saved.
                    </p>
                    <div className="mt-4">
                      <button className="px-4 py-2 rounded-lg bg-gray-800 hover:bg-gray-700 text-xs font-bold text-gray-300 transition-colors">
                        Browse Files
                      </button>
                    </div>
                  </div>

                  {/* Processing / Result Area */}
                  {isAnalyzing && (
                    <div className="bg-[#030712] border border-gray-800 rounded-2xl p-6 text-center space-y-4">
                      <RefreshCw className="w-8 h-8 text-blue-500 animate-spin mx-auto" />
                      <div>
                        <p className="text-sm font-bold text-gray-200">Executing Structural Core Scan...</p>
                        <p className="text-xs text-gray-500 mt-1">Reading headers, cataloging parameters, and auditing vulnerability vectors...</p>
                      </div>
                    </div>
                  )}

                  {analysisReport && (
                    <div className="bg-[#030712] border border-gray-800 rounded-2xl p-6 space-y-4">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-gray-900 pb-3 gap-2">
                        <div>
                          <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
                            <FileText className="w-4.5 h-4.5 text-blue-400" />
                            {analysisReport.title}
                          </h3>
                          <div className="flex items-center gap-4 text-[11px] text-gray-500 mt-1 font-mono">
                            <span>Words: {analysisReport.wordCount}</span>
                            <span>Read Speed: {analysisReport.readingTime}</span>
                          </div>
                        </div>
                        <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">AUDIT PASSED</span>
                      </div>

                      <div className="space-y-4">
                        <div>
                          <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Structural Summary</h4>
                          <p className="text-xs text-gray-300 leading-relaxed">{analysisReport.summary}</p>
                        </div>

                        <div>
                          <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Key Core Findings</h4>
                          <ul className="space-y-2">
                            {analysisReport.findings.map((item: string, idx: number) => (
                              <li key={idx} className="flex items-start gap-2 text-xs text-gray-300">
                                <span className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5 shrink-0" />
                                <span>{item}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* TAB 4: WORKFLOW AUTOMATION */}
              {activeTab === 'workflow' && (
                <div className="space-y-6">
                  
                  {/* Visual Node Connectors */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {workflowSteps.map((step, index) => (
                      <div key={step.id} className="relative group">
                        <div className="bg-[#030712] border border-gray-800 group-hover:border-blue-500/50 rounded-2xl p-4 space-y-3 transition-colors relative">
                          <div className="flex items-center justify-between">
                            <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full ${
                              step.type === 'trigger' 
                                ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' 
                                : 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                            }`}>
                              {step.type}
                            </span>
                            <button 
                              onClick={() => removeWorkflowStep(step.id)}
                              className="text-gray-600 hover:text-red-400 transition-colors"
                              title="Delete Step"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                          <div>
                            <h4 className="text-xs font-bold text-white">{step.name}</h4>
                            <p className="text-[11px] text-gray-500 mt-1 leading-relaxed">{step.details}</p>
                          </div>
                        </div>
                        {index < workflowSteps.length - 1 && (
                          <div className="hidden md:flex absolute top-1/2 -right-2.5 -translate-y-1/2 z-10 w-5 h-5 rounded-full bg-gray-800 border border-gray-700 items-center justify-center text-gray-400">
                            <ChevronRight className="w-3.5 h-3.5" />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>

                  {/* Add Step Controller */}
                  <div className="bg-[#030712] border border-gray-800 rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
                    <div className="flex flex-wrap items-center gap-4">
                      <div>
                        <span className="text-[11px] font-bold text-gray-500 uppercase tracking-widest block mb-1">Available Triggers</span>
                        <select 
                          value={selectedTrigger} 
                          onChange={(e) => setSelectedTrigger(e.target.value)}
                          className="bg-[#0b0f19] border border-gray-800 focus:border-blue-500 rounded-lg px-2.5 py-1.5 text-xs text-gray-300 focus:outline-none"
                        >
                          <option value="Slack Hook">Slack Channel Event</option>
                          <option value="Notion Updated">Notion Page Modification</option>
                          <option value="Postgres Trigger">DB Row Modification</option>
                        </select>
                      </div>

                      <div>
                        <span className="text-[11px] font-bold text-gray-500 uppercase tracking-widest block mb-1">AI Actions</span>
                        <select 
                          value={selectedAction} 
                          onChange={(e) => setSelectedAction(e.target.value)}
                          className="bg-[#0b0f19] border border-gray-800 focus:border-blue-500 rounded-lg px-2.5 py-1.5 text-xs text-gray-300 focus:outline-none"
                        >
                          <option value="NeuraAI Synthesize">Synthesize Tone Copy</option>
                          <option value="Security Audit Stream">Execute Compliance Check</option>
                          <option value="Database SQL Pipeline">Generate SQL Syntax Schema</option>
                        </select>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={addWorkflowStep}
                        className="px-4 py-2 bg-gray-800 hover:bg-gray-700 text-xs font-bold text-gray-200 rounded-xl flex items-center gap-1.5 transition-colors"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Add Step</span>
                      </button>
                      <button
                        onClick={testWorkflow}
                        className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-xs font-bold text-white rounded-xl flex items-center gap-1.5 transition-colors"
                      >
                        <Play className="w-4 h-4" />
                        <span>Run Test</span>
                      </button>
                    </div>
                  </div>

                  {/* Test Results Output */}
                  {workflowTested && (
                    <div className="bg-gray-950/60 border border-gray-900 rounded-2xl p-4 font-mono text-xs">
                      <div className="flex items-center justify-between border-b border-gray-900 pb-2 mb-2">
                        <span className="text-gray-500">workflow_test_runner.log</span>
                        <button 
                          onClick={() => setWorkflowTested(false)}
                          className="text-gray-500 hover:text-white"
                        >
                          Clear
                        </button>
                      </div>
                      <p className="text-blue-400 animate-pulse">{testingProgress}</p>
                    </div>
                  )}
                </div>
              )}

              {/* TAB 5: AUTONOMOUS AGENTS */}
              {activeTab === 'agents' && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  
                  {/* Agents Directory */}
                  <div className="md:col-span-1 space-y-3">
                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider pl-1">Active AI Employees</h3>
                    {agents.map(agent => (
                      <button
                        key={agent.id}
                        onClick={() => setSelectedAgent(agent.id)}
                        className={`w-full text-left p-4 rounded-2xl border transition-all ${
                          selectedAgent === agent.id 
                            ? 'bg-[#030712] border-blue-500/50 shadow-md shadow-blue-500/5' 
                            : 'bg-transparent border-gray-800/80 hover:border-gray-700'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <h4 className="text-xs font-bold text-white">{agent.name}</h4>
                          <span className={`w-2 h-2 rounded-full ${agent.status === 'Active' ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                        </div>
                        <p className="text-[11px] text-gray-500 mt-1">{agent.role}</p>
                      </button>
                    ))}
                  </div>

                  {/* Agent Config Controls */}
                  <div className="md:col-span-2 bg-[#030712] border border-gray-800 rounded-2xl p-6 space-y-6">
                    {(() => {
                      const current = agents.find(a => a.id === selectedAgent);
                      if (!current) return null;
                      return (
                        <>
                          <div className="flex items-center justify-between border-b border-gray-900 pb-3">
                            <div>
                              <h3 className="text-sm font-bold text-white">{current.name}</h3>
                              <p className="text-xs text-gray-500 mt-0.5">Model Stack: {current.model}</p>
                            </div>
                            <span className="text-[10px] font-mono text-blue-400 bg-blue-500/10 border border-blue-500/20 px-2.5 py-0.5 rounded-full">
                              {current.status}
                            </span>
                          </div>

                          <div className="space-y-4">
                            <div>
                              <div className="flex justify-between items-center text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">
                                <span>Hyperparameter Temp</span>
                                <span className="font-mono text-blue-400">{current.temp.toFixed(1)}</span>
                              </div>
                              <input 
                                type="range" 
                                min="0" 
                                max="1" 
                                step="0.1"
                                value={current.temp}
                                onChange={(e) => updateAgentTemp(current.id, e.target.value)}
                                className="w-full h-1.5 bg-gray-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
                              />
                              <div className="flex justify-between text-[10px] text-gray-500 mt-1 font-mono">
                                <span>Strict compliance (0.0)</span>
                                <span>Extreme creative (1.0)</span>
                              </div>
                            </div>

                            <div className="space-y-2">
                              <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Authorized Boundaries</h4>
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                <label className="flex items-center gap-2.5 p-3 rounded-xl bg-[#0b0f19] border border-gray-800 text-xs text-gray-300">
                                  <input type="checkbox" defaultChecked className="accent-blue-600 rounded" />
                                  <span>Write Slack Summaries</span>
                                </label>
                                <label className="flex items-center gap-2.5 p-3 rounded-xl bg-[#0b0f19] border border-gray-800 text-xs text-gray-300">
                                  <input type="checkbox" defaultChecked className="accent-blue-600 rounded" />
                                  <span>Push specs to GitHub</span>
                                </label>
                                <label className="flex items-center gap-2.5 p-3 rounded-xl bg-[#0b0f19] border border-gray-800 text-xs text-gray-300">
                                  <input type="checkbox" defaultChecked={current.id === 'agent-1'} className="accent-blue-600 rounded" />
                                  <span>Draft HubSpot Campaign</span>
                                </label>
                                <label className="flex items-center gap-2.5 p-3 rounded-xl bg-[#0b0f19] border border-gray-800 text-xs text-gray-300">
                                  <input type="checkbox" defaultChecked={current.id === 'agent-3'} className="accent-blue-600 rounded" />
                                  <span>Database Read-Only access</span>
                                </label>
                              </div>
                            </div>
                          </div>
                        </>
                      );
                    })()}
                  </div>

                </div>
              )}

              {/* TAB 6: ANALYTICS & METRICS */}
              {activeTab === 'analytics' && (
                <div className="space-y-6">
                  
                  {/* Real-time Telemetry Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="bg-[#030712] border border-gray-800 rounded-2xl p-4 space-y-1">
                      <div className="flex items-center justify-between text-xs font-bold text-gray-400 uppercase tracking-wider">
                        <span>Latency Index</span>
                        <Activity className="w-4 h-4 text-emerald-500 animate-pulse" />
                      </div>
                      <p className="text-2xl font-black text-white font-mono">112ms</p>
                      <p className="text-[10px] text-emerald-400 font-medium flex items-center gap-1">
                        <span>● Stable</span>
                        <span className="text-gray-500 font-mono">Optimized via context cache</span>
                      </p>
                    </div>

                    <div className="bg-[#030712] border border-gray-800 rounded-2xl p-4 space-y-1">
                      <div className="flex items-center justify-between text-xs font-bold text-gray-400 uppercase tracking-wider">
                        <span>Security Incidents</span>
                        <CheckCircle className="w-4 h-4 text-emerald-500" />
                      </div>
                      <p className="text-2xl font-black text-white font-mono">0</p>
                      <p className="text-[10px] text-gray-500 font-mono">AES-256 isolations audit passing</p>
                    </div>

                    <div className="bg-[#030712] border border-gray-800 rounded-2xl p-4 space-y-1">
                      <div className="flex items-center justify-between text-xs font-bold text-gray-400 uppercase tracking-wider">
                        <span>Active Sandbox runs</span>
                        <Layers className="w-4 h-4 text-blue-500" />
                      </div>
                      <p className="text-2xl font-black text-white font-mono">4</p>
                      <p className="text-[10px] text-blue-400 font-medium">Auto-scaling instances ready</p>
                    </div>
                  </div>

                  {/* Analytics Bar Telemetry Simulator */}
                  <div className="bg-[#030712] border border-gray-800 rounded-2xl p-6">
                    <div className="flex justify-between items-center mb-6">
                      <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider">Daily Token Consumption History</h4>
                      <span className="text-[10px] text-gray-500 font-mono">Sep 15 - Sep 22</span>
                    </div>

                    <div className="flex items-end justify-between h-40 gap-2 px-2 border-b border-gray-800">
                      {[
                        { day: 'Tue', val: 30, tokens: '12k' },
                        { day: 'Wed', val: 45, tokens: '18k' },
                        { day: 'Thu', val: 75, tokens: '30k' },
                        { day: 'Fri', val: 60, tokens: '24k' },
                        { day: 'Sat', val: 20, tokens: '8k' },
                        { day: 'Sun', val: 15, tokens: '6k' },
                        { day: 'Mon', val: 90, tokens: '36k' },
                        { day: 'Today', val: 100, tokens: '40k', current: true }
                      ].map((item, idx) => (
                        <div key={idx} className="flex-1 flex flex-col items-center gap-2 group cursor-pointer relative">
                          
                          {/* Tooltip */}
                          <div className="absolute bottom-full mb-2 bg-[#0b0f19] border border-gray-800 text-[10px] font-bold font-mono px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap text-white z-10 shadow-lg shadow-black/80">
                            {item.tokens} tokens
                          </div>

                          <div 
                            className={`w-full max-w-[32px] rounded-t-lg transition-all duration-500 ${
                              item.current 
                                ? 'bg-gradient-to-t from-blue-600 to-indigo-500 shadow-lg shadow-blue-500/20' 
                                : 'bg-gray-800 group-hover:bg-gray-700'
                            }`} 
                            style={{ height: `${item.val}%` }} 
                          />
                          <span className="text-[10px] text-gray-500 font-medium mt-1">{item.day}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
