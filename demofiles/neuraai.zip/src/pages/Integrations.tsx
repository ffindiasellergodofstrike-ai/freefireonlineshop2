import React, { useState } from 'react';
import { INTEGRATIONS } from '../data';
import { 
  Search, Cpu, Check, AlertCircle, RefreshCw, Layers, 
  MessageSquare, BookOpen, Zap, Trash2, X, AlertTriangle 
} from 'lucide-react';

export default function Integrations() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');
  
  // Connection states
  const [connectedIds, setConnectedIds] = useState(['slack']);
  const [modalIntegration, setModalIntegration] = useState<any>(null);
  const [apiKeyVal, setApiKeyVal] = useState(''); // let's double check if apiKey state has a state updater
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [modalError, setModalError] = useState('');

  // Categories list
  const categories = ['All', 'Communication', 'Documentation', 'Engineering', 'CRM', 'Marketing', 'Data & Databases'];

  const filteredIntegrations = INTEGRATIONS.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          item.desc.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = activeCategory === 'All' || item.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const openConnectModal = (integration: any) => {
    setModalError('');
    setApiKeyVal('');
    setModalIntegration(integration);
  };

  const handleConnect = (e: React.FormEvent) => {
    e.preventDefault();
    setModalError('');
    if (!apiKeyVal.trim()) {
      setModalError('API credential token key is required.');
      return;
    }
    if (apiKeyVal.trim().length < 8) {
      setModalError('Token must be a valid AES compliant structure (minimum 8 characters).');
      return;
    }

    setIsSubmitting(true);
    setTimeout(() => {
      setConnectedIds([...connectedIds, modalIntegration.id]);
      setIsSubmitting(false);
      setModalIntegration(null);
    }, 1500);
  };

  const handleDisconnect = (id: string) => {
    setConnectedIds(connectedIds.filter(cId => cId !== id));
  };

  return (
    <div id="integrations-page" className="pt-24 space-y-20 min-h-screen">
      
      {/* Header */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 text-center space-y-4 relative">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
        <span className="text-xs font-bold text-blue-500 tracking-wider uppercase">Pipeline Syncuristics</span>
        <h1 className="text-4xl md:text-5xl font-black text-white tracking-tight leading-tight">
          150+ Native Core Integrations.
        </h1>
        <p className="text-sm text-gray-400 max-w-2xl mx-auto leading-relaxed">
          Hook up NeuraAI to your live communication briefs, documentation wikis, and engineering code backlogs instantly with absolute credential encryption.
        </p>
      </section>

      {/* Directory Console */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10 pb-20">
        
        {/* Controls Panel */}
        <div className="bg-[#0b0f19] border border-gray-900 rounded-3xl p-6 flex flex-col md:flex-row gap-6 items-center justify-between">
          
          {/* Search Bar */}
          <div className="relative w-full md:max-w-xs">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-gray-500" />
            <input
              type="text"
              placeholder="Search integrations..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#030712] border border-gray-800 focus:border-blue-500 rounded-xl pl-11 pr-4 py-3 text-sm text-gray-100 placeholder-gray-500 focus:outline-none transition-colors"
            />
          </div>

          {/* Category Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 w-full md:w-auto overflow-x-auto pb-2 md:pb-0">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3.5 py-2 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all whitespace-nowrap ${
                  activeCategory === cat 
                    ? 'bg-blue-600 text-white shadow-md' 
                    : 'bg-[#030712] border border-gray-800 text-gray-400 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Directory Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="integrations-grid">
          {filteredIntegrations.map((item) => {
            const isConnected = connectedIds.includes(item.id);
            return (
              <div 
                key={item.id} 
                className="bg-[#070b14] border border-gray-900 hover:border-gray-850 p-6 rounded-3xl space-y-6 flex flex-col justify-between transition-all duration-200"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-10 h-10 rounded-xl bg-gray-950 flex items-center justify-center border border-gray-800 text-gray-400">
                        <Cpu className="w-5 h-5 text-blue-500" />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-white">{item.name}</h4>
                        <span className="text-[10px] text-gray-500 font-semibold uppercase tracking-wider">{item.category}</span>
                      </div>
                    </div>

                    <span className={`text-[9px] font-bold uppercase px-2 py-0.5 rounded-full ${
                      item.status === 'Enterprise' 
                        ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/20' 
                        : 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                    }`}>
                      {item.status}
                    </span>
                  </div>

                  <p className="text-xs text-gray-400 leading-relaxed line-clamp-2">{item.desc}</p>
                </div>

                {/* Connection Trigger */}
                <div className="pt-4 border-t border-gray-900 flex items-center justify-between gap-4 mt-4">
                  {isConnected ? (
                    <>
                      <span className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider flex items-center gap-1">
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Connected</span>
                      </span>
                      <button
                        onClick={() => handleDisconnect(item.id)}
                        className="p-2 bg-gray-800/40 hover:bg-red-950/20 text-gray-500 hover:text-red-400 rounded-lg transition-colors"
                        title="Disconnect Integration"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </>
                  ) : (
                    <>
                      <span className="text-[10px] text-gray-500 font-semibold">Not synced</span>
                      <button
                        onClick={() => openConnectModal(item)}
                        className="px-4 py-2 rounded-xl bg-gray-900 hover:bg-gray-800 border border-gray-800 hover:border-gray-700 text-xs font-bold text-gray-300 hover:text-white transition-colors"
                      >
                        Connect
                      </button>
                    </>
                  )}
                </div>
              </div>
            );
          })}

          {filteredIntegrations.length === 0 && (
            <div className="col-span-full text-center py-20 bg-gray-950/10 border border-gray-900 rounded-3xl space-y-3">
              <AlertTriangle className="w-10 h-10 text-gray-600 mx-auto" />
              <p className="text-sm font-bold text-gray-300">No Integrations Located</p>
              <p className="text-xs text-gray-500 max-w-sm mx-auto">We couldn't locate any integration matching your search filters. Try toggling other category tabs.</p>
            </div>
          )}
        </div>
      </section>

      {/* Integration Connection Modal */}
      {modalIntegration && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/65 backdrop-blur-sm" id="connect-modal">
          <div className="bg-[#0b0f19] border border-gray-850 rounded-3xl p-6 max-w-md w-full space-y-6 shadow-2xl shadow-black relative animate-fade-in">
            
            {/* Close */}
            <button 
              onClick={() => setModalIntegration(null)}
              className="absolute right-4 top-4 p-1.5 rounded-lg text-gray-500 hover:text-white hover:bg-gray-800/50 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header */}
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gray-950 flex items-center justify-center border border-gray-800 text-blue-500 font-bold">
                  <Cpu className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Connect {modalIntegration.name}</h3>
                  <p className="text-[10px] text-gray-500 font-semibold uppercase">{modalIntegration.category}</p>
                </div>
              </div>
              <p className="text-xs text-gray-400 leading-relaxed pt-2">
                Configure connection metrics. Prompts and documents will sync automatically within safe isolated boundaries.
              </p>
            </div>

            {/* Config Form */}
            <form onSubmit={handleConnect} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase tracking-wider mb-1.5">Credential Token Key</label>
                <input
                  type="password"
                  placeholder="Paste your API key or security webhook token"
                  value={apiKeyVal}
                  onChange={(e) => setApiKeyVal(e.target.value)}
                  className="w-full bg-[#030712] border border-gray-800 focus:border-blue-500 rounded-xl px-4 py-3 text-xs text-gray-200 placeholder-gray-500 focus:outline-none transition-colors"
                />
                <span className="text-[10px] text-gray-500 mt-1.5 block leading-relaxed flex items-center gap-1">
                  <AlertCircle className="w-3 h-3 text-blue-500" />
                  Credentials are encrypted securely with client-side isolation matrices.
                </span>
              </div>

              {modalError && (
                <div className="p-3 bg-red-950/20 border border-red-900/30 text-[11px] text-red-400 rounded-xl font-medium flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{modalError}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-xs font-bold text-white transition-all flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Synchronizing tunnel...</span>
                  </>
                ) : (
                  <span>Establish Secure Connection</span>
                )}
              </button>
            </form>

          </div>
        </div>
      )}

    </div>
  );
}
