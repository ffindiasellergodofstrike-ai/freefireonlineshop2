import React from 'react';
import { Link } from 'react-router-dom';
import { Cpu, ShieldCheck, Heart, Users, CheckCircle, ArrowRight } from 'lucide-react';

export default function About() {
  const values = [
    { title: 'Isolation First', desc: 'Prompts, documents, and weights belong exclusively to you and are sandboxed safely in single-tenant clusters.', icon: ShieldCheck },
    { title: 'Edge Performance', desc: 'Optimizing context caching architectures to maintain reliable sub-150ms latencies across edge servers.', icon: Cpu },
    { title: 'Operational Value', desc: 'Turning complex backlog specifications, copies, and webhooks into real, scalable company results.', icon: Heart }
  ];

  const team = [
    { name: 'Dr. Evelyn Vance', role: 'Principal AI Systems Lead', dept: 'Model Orchestration', avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=120&h=120' },
    { name: 'Marcus Vance', role: 'Solutions Architect Director', dept: 'Customer Integrations', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=120&h=120' },
    { name: 'Elena Rostova', role: 'Chief Compliance Auditor', dept: 'Security Sandboxes', avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=120&h=120' }
  ];

  return (
    <div id="about-page" className="pt-24 space-y-32">
      
      {/* Hero Mission */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 text-center space-y-6 relative">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
        <span className="text-xs font-bold text-blue-500 tracking-wider uppercase">Our Core Mission</span>
        <h1 className="text-4xl md:text-5xl font-black text-white tracking-tight leading-tight">
          Turning Complex Ideas Into Scalable Results.
        </h1>
        <p className="text-sm text-gray-400 max-w-2xl mx-auto leading-relaxed">
          Founded in 2026, NeuraAI is engineered to deliver zero-leakage, microsecond latency generative AI matrices for fast-growing enterprises, marketers, and product teams.
        </p>
      </section>

      {/* Corporate Values */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        <h2 className="text-xl md:text-2xl font-extrabold text-center text-white tracking-tight">Our Operational Values</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {values.map((v, idx) => {
            const Icon = v.icon;
            return (
              <div key={idx} className="bg-[#070b14] border border-gray-900 p-8 rounded-3xl space-y-4">
                <div className="w-10 h-10 rounded-xl bg-gray-950 flex items-center justify-center border border-gray-800 text-blue-500">
                  <Icon className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-white">{v.title}</h3>
                <p className="text-xs text-gray-400 leading-relaxed">{v.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Leadership Board */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        <div className="text-center space-y-4 max-w-2xl mx-auto">
          <h2 className="text-xl md:text-2xl font-extrabold text-white tracking-tight">Principal AI Architects</h2>
          <p className="text-xs text-gray-400 leading-relaxed">
            Our teams represent veteran researchers, cloud security compliance inspectors, and model engineering leads committed to robust AI governance.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {team.map((t, idx) => (
            <div key={idx} className="bg-[#070b14] border border-gray-900 p-6 rounded-3xl text-center space-y-4">
              <img 
                src={t.avatar} 
                alt={t.name} 
                className="w-20 h-20 rounded-full mx-auto border border-gray-800 object-cover" 
                referrerPolicy="no-referrer"
              />
              <div>
                <h4 className="text-sm font-bold text-white">{t.name}</h4>
                <p className="text-[11px] text-gray-500 mt-1">{t.role}</p>
                <span className="inline-block mt-2 text-[9px] font-bold text-blue-400 bg-blue-500/10 border border-blue-500/20 px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                  {t.dept}
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Career block */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-10">
        <div className="bg-[#0b0f19] border border-gray-900 rounded-3xl p-8 lg:p-12 text-center space-y-6 max-w-4xl mx-auto">
          <span className="text-xs font-bold text-blue-500 tracking-wider uppercase">Open Careers</span>
          <h2 className="text-2xl font-extrabold text-white tracking-tight">Help Us Orchestrate Safely.</h2>
          <p className="text-xs text-gray-400 max-w-xl mx-auto leading-relaxed">
            Are you passionate about isolating model backlogs, programming edge caches, or developing gRPC routers? We are always looking for stellar systems architects.
          </p>
          <div className="pt-2">
            <Link
              to="/contact"
              className="px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-xs font-bold text-white transition-colors"
            >
              Contact Our Talent Team
            </Link>
          </div>
        </div>
      </section>

    </div>
  );
}
