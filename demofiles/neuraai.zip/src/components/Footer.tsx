import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Cpu, Github, Twitter, Linkedin, Youtube, Send, CheckCircle } from 'lucide-react';

export default function Footer() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [error, setError] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!email) {
      setError('Email address is required.');
      return;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError('Please enter a valid email address.');
      return;
    }
    setSubscribed(true);
    setEmail('');
    setTimeout(() => {
      setSubscribed(false);
    }, 5000);
  };

  const footerLinks = [
    {
      title: 'Product',
      links: [
        { name: 'AI Chat Core', path: '/features' },
        { name: 'Content Suite', path: '/features' },
        { name: 'Document Intelligence', path: '/features' },
        { name: 'Workflow Automation', path: '/features' },
        { name: 'Pricing Plans', path: '/pricing' },
        { name: 'Dashboard Preview', path: '/dashboard' }
      ]
    },
    {
      title: 'Solutions',
      links: [
        { name: 'Enterprise Intelligence', path: '/solutions' },
        { name: 'Marketing Pipelines', path: '/solutions' },
        { name: 'Product Engineering', path: '/solutions' },
        { name: 'Workflow Customization', path: '/solutions' }
      ]
    },
    {
      title: 'Resources',
      links: [
        { name: 'AI Blog & Research', path: '/blog' },
        { name: 'Developer Documentation', path: '/resources' },
        { name: 'SaaS Platform Guides', path: '/resources' },
        { name: 'Support Center', path: '/contact' },
        { name: 'API Reference', path: '/resources' }
      ]
    },
    {
      title: 'Company',
      links: [
        { name: 'About NeuraAI', path: '/about' },
        { name: 'Careers', path: '/about' },
        { name: 'Security Core', path: '/solutions' },
        { name: 'Privacy & Terms', path: '/about' },
        { name: 'Contact Sales', path: '/contact' }
      ]
    }
  ];

  return (
    <footer id="main-footer" className="bg-[#020610] border-t border-gray-900 pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-12 pb-16 border-b border-gray-900">
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-6">
            <Link to="/" className="flex items-center gap-2.5 group">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center shadow-md shadow-blue-500/10">
                <Cpu className="w-5.5 h-5.5 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-white via-gray-100 to-gray-300 bg-clip-text text-transparent">
                  Neura<span className="text-blue-500">AI</span>
                </span>
                <span className="text-[10px] text-gray-500 font-medium tracking-widest uppercase -mt-0.5">Enterprise Core</span>
              </div>
            </Link>
            <p className="text-gray-400 text-sm leading-relaxed max-w-sm">
              Enterprise-grade artificial intelligence engine turning complex data, workflows, and insights into immediate, scalable real-world business results.
            </p>
            {/* Social handles */}
            <div className="flex items-center gap-4">
              <a href="#" className="w-9 h-9 rounded-lg bg-gray-950 hover:bg-blue-950/20 border border-gray-900 hover:border-blue-900/30 flex items-center justify-center text-gray-400 hover:text-blue-400 transition-all duration-200" aria-label="Twitter">
                <Twitter className="w-4.5 h-4.5" />
              </a>
              <a href="#" className="w-9 h-9 rounded-lg bg-gray-950 hover:bg-blue-950/20 border border-gray-900 hover:border-blue-900/30 flex items-center justify-center text-gray-400 hover:text-blue-400 transition-all duration-200" aria-label="GitHub">
                <Github className="w-4.5 h-4.5" />
              </a>
              <a href="#" className="w-9 h-9 rounded-lg bg-gray-950 hover:bg-blue-950/20 border border-gray-900 hover:border-blue-900/30 flex items-center justify-center text-gray-400 hover:text-blue-400 transition-all duration-200" aria-label="LinkedIn">
                <Linkedin className="w-4.5 h-4.5" />
              </a>
              <a href="#" className="w-9 h-9 rounded-lg bg-gray-950 hover:bg-blue-950/20 border border-gray-900 hover:border-blue-900/30 flex items-center justify-center text-gray-400 hover:text-blue-400 transition-all duration-200" aria-label="YouTube">
                <Youtube className="w-4.5 h-4.5" />
              </a>
            </div>
          </div>

          {/* Dynamic Link Cols */}
          {footerLinks.map((col) => (
            <div key={col.title} className="space-y-4">
              <h3 className="text-xs font-semibold text-gray-200 tracking-wider uppercase">{col.title}</h3>
              <ul className="space-y-3">
                {col.links.map((link) => (
                  <li key={link.name}>
                    <Link to={link.path} className="text-sm text-gray-400 hover:text-white transition-colors">
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          {/* Newsletter Box */}
          <div className="lg:col-span-2 space-y-4">
            <h3 className="text-xs font-semibold text-gray-200 tracking-wider uppercase">Subscribe to Intel</h3>
            <p className="text-sm text-gray-400 leading-relaxed">
              Get the latest updates on generative AI safety, performance metrics, and enterprise feature releases.
            </p>
            <form onSubmit={handleSubscribe} className="space-y-2">
              <div className="relative">
                <input
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-[#070b13] border border-gray-800 focus:border-blue-500 rounded-xl px-4 py-3 text-sm text-gray-100 placeholder-gray-500 focus:outline-none transition-colors pr-12"
                />
                <button
                  type="submit"
                  className="absolute right-1.5 top-1.5 bottom-1.5 bg-blue-600 hover:bg-blue-500 text-white p-2 rounded-lg flex items-center justify-center transition-colors active:scale-95"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
              {error && <p className="text-xs text-red-500 font-medium pl-1">{error}</p>}
              {subscribed && (
                <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium pl-1">
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>Subscribed successfully! Welcome to NeuraAI Intel.</span>
                </div>
              )}
            </form>
          </div>
        </div>

        {/* Bottom Panel */}
        <div className="flex flex-col md:flex-row items-center justify-between pt-10 gap-4">
          <p className="text-xs text-gray-500">
            &copy; {new Date().getFullYear()} NeuraAI Technologies Inc. All rights reserved. Designed for elite operations.
          </p>
          <div className="flex items-center gap-6 text-xs text-gray-500">
            <Link to="/about" className="hover:text-gray-300 transition-colors">Privacy Policy</Link>
            <Link to="/about" className="hover:text-gray-300 transition-colors">Terms of Service</Link>
            <Link to="/about" className="hover:text-gray-300 transition-colors">Security Core</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
