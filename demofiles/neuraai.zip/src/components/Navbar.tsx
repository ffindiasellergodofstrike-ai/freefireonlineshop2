import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, ChevronDown, Sparkles, Cpu, Layers, Link2, BookOpen, MessageSquare, Briefcase, Zap, HelpCircle } from 'lucide-react';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setIsOpen(false);
    setActiveDropdown(null);
  }, [location]);

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  const navLinks = [
    { name: 'Home', path: '/' },
    { 
      name: 'Features', 
      path: '/features',
      dropdown: [
        { name: 'AI Chat Core', desc: 'Context-aware conversational intelligence', path: '/features', icon: MessageSquare },
        { name: 'Content Suite', desc: 'High-converting copy & asset generator', path: '/features', icon: Sparkles },
        { name: 'Document Intelligence', desc: 'Extract insights from complex documents', path: '/features', icon: BookOpen },
        { name: 'Workflow Automation', desc: 'Visual code-free trigger-action engine', path: '/features', icon: Zap }
      ]
    },
    { 
      name: 'Solutions', 
      path: '/solutions',
      dropdown: [
        { name: 'Enterprise', desc: 'Scale AI with strict security and custom models', path: '/solutions', icon: Cpu },
        { name: 'Marketing Teams', desc: 'Optimize content pipelines & ad campaigns', path: '/solutions', icon: Layers },
        { name: 'Product Engineering', desc: 'API access with micro-second latency', path: '/solutions', icon: Zap }
      ]
    },
    { name: 'Integrations', path: '/integrations' },
    { name: 'Pricing', path: '/pricing' },
    { 
      name: 'Resources', 
      path: '/resources',
      dropdown: [
        { name: 'Guides & Tutorials', desc: 'Master advanced prompt engineering', path: '/resources', icon: BookOpen },
        { name: 'Developer Docs', desc: 'SDK documentation and API references', path: '/resources', icon: Cpu },
        { name: 'Blog', desc: 'Latest insights on generative AI trends', path: '/blog', icon: MessageSquare }
      ]
    },
    { name: 'About', path: '/about' },
    { name: 'Contact', path: '/contact' }
  ];

  return (
    <nav 
      id="main-navbar"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled 
          ? 'bg-[#030712]/80 backdrop-blur-md border-b border-gray-800/50 py-4 shadow-lg shadow-black/10' 
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2.5 group" id="nav-logo">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform duration-300">
              <Cpu className="w-5.5 h-5.5 text-white" />
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-white via-gray-100 to-gray-300 bg-clip-text text-transparent">
                Neura<span className="text-blue-500">AI</span>
              </span>
              <span className="text-[10px] text-gray-500 font-medium tracking-widest uppercase -mt-0.5">Enterprise Core</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => {
              if (link.dropdown) {
                return (
                  <div 
                    key={link.name} 
                    className="relative group/dropdown"
                    onMouseEnter={() => setActiveDropdown(link.name)}
                    onMouseLeave={() => setActiveDropdown(null)}
                  >
                    <button 
                      id={`nav-drop-${link.name.toLowerCase()}`}
                      className={`flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-[14px] font-medium transition-colors ${
                        isActive(link.path) || activeDropdown === link.name
                          ? 'text-white bg-gray-800/40' 
                          : 'text-gray-400 hover:text-white hover:bg-gray-800/20'
                      }`}
                    >
                      {link.name}
                      <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${activeDropdown === link.name ? 'rotate-180' : ''}`} />
                    </button>

                    {/* Dropdown Menu */}
                    <div 
                      className={`absolute top-full left-1/2 -translate-x-1/2 mt-1.5 w-80 bg-[#0b0f19] border border-gray-800/80 rounded-2xl p-3 shadow-2xl shadow-black/60 transition-all duration-200 origin-top ${
                        activeDropdown === link.name 
                          ? 'opacity-100 scale-100 pointer-events-auto visible' 
                          : 'opacity-0 scale-95 pointer-events-none invisible'
                      }`}
                    >
                      <div className="grid gap-1">
                        {link.dropdown.map((subItem) => {
                          const Icon = subItem.icon;
                          return (
                            <Link
                              key={subItem.name}
                              to={subItem.path}
                              className="flex items-start gap-3 p-3 rounded-xl hover:bg-gray-800/50 transition-colors group/item"
                            >
                              <div className="w-9 h-9 rounded-lg bg-gray-800 flex items-center justify-center border border-gray-700/50 text-gray-400 group-hover/item:text-blue-400 group-hover/item:bg-blue-950/20 group-hover/item:border-blue-800/30 transition-colors">
                                <Icon className="w-4.5 h-4.5" />
                              </div>
                              <div className="flex-1">
                                <p className="text-[14px] font-semibold text-gray-200 group-hover/item:text-white transition-colors">
                                  {subItem.name}
                                </p>
                                <p className="text-[11px] text-gray-500 mt-0.5 line-clamp-1 leading-relaxed">
                                  {subItem.desc}
                                </p>
                              </div>
                            </Link>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                );
              }

              return (
                <Link
                  key={link.name}
                  to={link.path}
                  id={`nav-link-${link.name.toLowerCase()}`}
                  className={`px-3.5 py-2 rounded-lg text-[14px] font-medium transition-colors ${
                    isActive(link.path)
                      ? 'text-white bg-gray-800/40'
                      : 'text-gray-400 hover:text-white hover:bg-gray-800/20'
                  }`}
                >
                  {link.name}
                </Link>
              );
            })}
          </div>

          {/* Desktop CTAs */}
          <div className="hidden lg:flex items-center gap-3">
            <Link 
              to="/login" 
              id="nav-btn-login"
              className="px-4 py-2 text-[14px] font-semibold text-gray-300 hover:text-white transition-colors"
            >
              Sign In
            </Link>
            <Link 
              to="/signup" 
              id="nav-btn-signup"
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-[14px] font-semibold text-white shadow-md shadow-blue-500/10 hover:shadow-blue-500/25 transition-all duration-200 active:scale-98"
            >
              Get Started Free
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center lg:hidden gap-3">
            <Link 
              to="/signup" 
              className="px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-[12px] font-semibold text-white shadow-sm transition-all duration-150"
            >
              Start Free
            </Link>
            <button
              onClick={() => setIsOpen(!isOpen)}
              id="nav-btn-mobile-toggle"
              className="p-2 rounded-lg text-gray-400 hover:text-white hover:bg-gray-800/50 transition-colors"
              aria-label="Toggle Menu"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      <div 
        className={`fixed inset-0 top-[72px] z-40 bg-[#030712] border-t border-gray-800/60 lg:hidden transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="h-full overflow-y-auto px-4 py-6 space-y-6">
          <div className="space-y-1">
            {navLinks.map((link) => {
              if (link.dropdown) {
                return (
                  <div key={link.name} className="py-2">
                    <button
                      onClick={() => setActiveDropdown(activeDropdown === link.name ? null : link.name)}
                      className="flex items-center justify-between w-full px-4 py-2 rounded-xl text-left font-medium text-gray-200 hover:bg-gray-800/40"
                    >
                      <span>{link.name}</span>
                      <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${activeDropdown === link.name ? 'rotate-180' : ''}`} />
                    </button>
                    <div className={`mt-2 ml-4 pl-4 border-l border-gray-800 space-y-1 transition-all duration-200 overflow-hidden ${
                      activeDropdown === link.name ? 'max-h-80 opacity-100 py-1' : 'max-h-0 opacity-0'
                    }`}>
                      {link.dropdown.map((sub) => (
                        <Link
                          key={sub.name}
                          to={sub.path}
                          onClick={() => setIsOpen(false)}
                          className="block px-3 py-2 rounded-lg text-sm text-gray-400 hover:text-white hover:bg-gray-800/20"
                        >
                          <div className="font-semibold">{sub.name}</div>
                          <div className="text-[11px] text-gray-500 mt-0.5">{sub.desc}</div>
                        </Link>
                      ))}
                    </div>
                  </div>
                );
              }

              return (
                <Link
                  key={link.name}
                  to={link.path}
                  onClick={() => setIsOpen(false)}
                  className={`block px-4 py-3 rounded-xl font-medium transition-all ${
                    isActive(link.path)
                      ? 'text-white bg-gray-800/60'
                      : 'text-gray-300 hover:text-white hover:bg-gray-800/30'
                  }`}
                >
                  {link.name}
                </Link>
              );
            })}
          </div>

          <div className="pt-6 border-t border-gray-800 space-y-3">
            <Link
              to="/login"
              onClick={() => setIsOpen(false)}
              className="block w-full text-center py-3 rounded-xl border border-gray-800 text-gray-300 hover:text-white hover:bg-gray-800/30 font-semibold transition-colors"
            >
              Sign In
            </Link>
            <Link
              to="/signup"
              onClick={() => setIsOpen(false)}
              className="block w-full text-center py-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold shadow-lg shadow-blue-500/15"
            >
              Get Started Free
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}
