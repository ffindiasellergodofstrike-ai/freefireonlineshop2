import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  mockCategories,
  mockSellers,
  mockBuyers,
  mockServices,
  mockReviews,
  mockOrders,
  mockConversations,
  mockBuyerRequests,
  Category,
  Seller,
  Buyer,
  Service,
  Review,
  Order,
  Conversation,
  BuyerRequest,
  Proposal,
  ChatMessage,
  OrderMessage
} from '../data/mockData';

// Re-export types so that pages can import them directly from here
export {
  type Category,
  type Seller,
  type Buyer,
  type Service,
  type Review,
  type Order,
  type Conversation,
  type BuyerRequest,
  type Proposal,
  type ChatMessage,
  type OrderMessage
};

export interface AppUser {
  id: string;
  name: string;
  username: string;
  email: string;
  avatar: string;
  country: string;
  accountType: 'Buyer' | 'Seller' | 'Both';
  sellerProfileId?: string; // set if registered as seller
}

export interface AppNotification {
  id: string;
  text: string;
  type: 'order' | 'message' | 'proposal' | 'review' | 'system';
  createdAt: string;
  read: boolean;
}

export interface AppContextType {
  // Authentication & Profile
  currentUser: AppUser;
  activeRole: 'buyer' | 'seller' | 'admin';
  switchRole: (role: 'buyer' | 'seller' | 'admin') => void;
  updateUserProfile: (profile: Partial<AppUser>) => void;
  registerAsSeller: (profileData: Partial<Seller>) => void;
  logout: () => void;
  switchUserTemplate: (user: AppUser) => void;
  
  // Marketplace Data (Stateful)
  categories: Category[];
  sellers: Seller[];
  services: Service[];
  reviews: Review[];
  orders: Order[];
  conversations: Conversation[];
  buyerRequests: BuyerRequest[];
  notifications: AppNotification[];
  
  // Interactive Actions
  addNewService: (service: Partial<Service>) => void;
  updateServiceStatus: (id: string, status: 'Active' | 'Draft' | 'Paused') => void;
  editService: (id: string, updated: Partial<Service>) => void;
  deleteService: (id: string) => void;
  toggleServiceStatus: (id: string) => void;
  addServiceListing: (service: Service) => void;
  addCategory: (cat: Category) => void;
  
  createNewOrder: (serviceId: string, packageType: 'basic' | 'standard' | 'premium', requirements: string) => Order;
  createOrder: (serviceId: string, packageType: 'basic' | 'standard' | 'premium', requirements: string) => string;
  deliverOrder: (orderId: string, text: string, fileName: string) => void;
  submitWorkDelivery: (orderId: string, text: string, fileName: string) => void;
  updateOrderStatus: (orderId: string, status: Order['status']) => void;
  addOrderMessage: (orderId: string, sender: 'buyer' | 'seller', text: string) => void;
  approveOrderAndReview: (orderId: string, rating: number, comment: string) => void;
  requestOrderRevision: (orderId: string) => void;
  
  startOrGetConversation: (sellerId: string, buyerId: string) => string;
  sendChatMessage: (convoId: string, senderId: string, text: string, file?: string) => void;
  markChatAsRead: (convoId: string) => void;
  
  postBuyerRequest: (request: Partial<BuyerRequest>) => void;
  addBuyerRequest: (req: { title: string; description: string; budget: number; duration: string }) => void;
  submitProposalToRequest: (requestId: string, proposal: Partial<Proposal>) => void;
  
  toggleSaveService: (serviceId: string) => void;
  toggleSaveSeller: (sellerId: string) => void;
  savedServicesIds: string[];
  savedSellersIds: string[];
  
  addNotification: (text: string, type: AppNotification['type']) => void;
  markNotificationsAsRead: () => void;
  clearNotification: (id: string) => void;
  
  // Theme Toggle
  theme: 'light' | 'dark';
  toggleTheme: () => void;
  
  // Toast notifications
  toast: { message: string; type: 'success' | 'error' | 'info' } | null;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Helper to load/save from localStorage
const getLocal = <T,>(key: string, fallback: T): T => {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : fallback;
  } catch (e) {
    return fallback;
  }
};

const setLocal = <T,>(key: string, value: T) => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    // ignore
  }
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 1. Initial User Setup (Dual account by default for quick demo)
  const defaultUser: AppUser = {
    id: 'buy-1', // maps to Emily Cooper
    name: 'Emily Cooper',
    username: 'emily_cooper',
    email: 'emily@workhub.com',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&auto=format&fit=crop&q=80',
    country: 'United States',
    accountType: 'Both',
    sellerProfileId: 'sel-1' // mapped to Alex Rivera's seller profile for quick toggle!
  };

  const [currentUser, setCurrentUser] = useState<AppUser>(() => getLocal('wh_current_user', defaultUser));
  const [activeRole, setActiveRole] = useState<'buyer' | 'seller' | 'admin'>(() => getLocal('wh_active_role', 'buyer'));
  
  // 2. Database states loaded from localStorage or falling back to mockData
  const [categories, setCategories] = useState<Category[]>(() => getLocal('wh_categories', mockCategories));
  const [services, setServices] = useState<Service[]>(() => getLocal('wh_services', mockServices));
  const [sellers, setSellers] = useState<Seller[]>(() => getLocal('wh_sellers', mockSellers));
  const [orders, setOrders] = useState<Order[]>(() => getLocal('wh_orders', mockOrders));
  const [conversations, setConversations] = useState<Conversation[]>(() => getLocal('wh_conversations', mockConversations));
  const [buyerRequests, setBuyerRequests] = useState<BuyerRequest[]>(() => getLocal('wh_buyer_requests', mockBuyerRequests));
  const [savedServicesIds, setSavedServicesIds] = useState<string[]>(() => getLocal('wh_saved_services', ['ser-1', 'ser-3', 'ser-9']));
  const [savedSellersIds, setSavedSellersIds] = useState<string[]>(() => getLocal('wh_saved_sellers', ['sel-1', 'sel-2']));
  
  // Initial demo notifications
  const initialNotifications: AppNotification[] = [
    { id: 'not-1', text: 'Your order with Alex Rivera has been delivered successfully.', type: 'order', createdAt: '3 hours ago', read: false },
    { id: 'not-2', text: 'You received a new proposal on your project "Figma brand guide bundle".', type: 'proposal', createdAt: '1 day ago', read: false },
    { id: 'not-3', text: 'Welcome to WORKHUB! Find talent or list your skills today.', type: 'system', createdAt: '3 days ago', read: true }
  ];
  const [notifications, setNotifications] = useState<AppNotification[]>(() => getLocal('wh_notifications', initialNotifications));
  const [theme, setTheme] = useState<'light' | 'dark'>(() => getLocal('wh_theme', 'light'));
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  // Sync to localStorage
  useEffect(() => { setLocal('wh_current_user', currentUser); }, [currentUser]);
  useEffect(() => { setLocal('wh_active_role', activeRole); }, [activeRole]);
  useEffect(() => { setLocal('wh_categories', categories); }, [categories]);
  useEffect(() => { setLocal('wh_services', services); }, [services]);
  useEffect(() => { setLocal('wh_sellers', sellers); }, [sellers]);
  useEffect(() => { setLocal('wh_orders', orders); }, [orders]);
  useEffect(() => { setLocal('wh_conversations', conversations); }, [conversations]);
  useEffect(() => { setLocal('wh_buyer_requests', buyerRequests); }, [buyerRequests]);
  useEffect(() => { setLocal('wh_saved_services', savedServicesIds); }, [savedServicesIds]);
  useEffect(() => { setLocal('wh_saved_sellers', savedSellersIds); }, [savedSellersIds]);
  useEffect(() => { setLocal('wh_notifications', notifications); }, [notifications]);
  useEffect(() => { setLocal('wh_theme', theme); }, [theme]);

  // Dark mode class sync
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
    showToast(`Switched to ${theme === 'light' ? 'Dark' : 'Light'} Mode`, 'info');
  };

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => {
      setToast(null);
    }, 3000);
  };

  // Switch Role (Buyer <-> Seller <-> Admin)
  const switchRole = (role: 'buyer' | 'seller' | 'admin') => {
    setActiveRole(role);
    showToast(`Switched view to ${role.toUpperCase()} Workspace`, 'info');
  };

  // Update profile settings
  const updateUserProfile = (updatedFields: Partial<AppUser>) => {
    setCurrentUser(prev => {
      const merged = { ...prev, ...updatedFields };
      // Also sync standard seller name if the user has a seller profile
      if (prev.sellerProfileId) {
        setSellers(sList => sList.map(s => s.id === prev.sellerProfileId ? {
          ...s,
          name: updatedFields.name || s.name,
          avatar: updatedFields.avatar || s.avatar,
          location: updatedFields.country || s.location
        } : s));
      }
      return merged;
    });
    showToast('Profile settings updated successfully', 'success');
  };

  // Onboarding flow: Register as Seller
  const registerAsSeller = (profileData: Partial<Seller>) => {
    const newSellerId = currentUser.sellerProfileId || `sel-user-${Date.now()}`;
    const exist = sellers.find(s => s.id === newSellerId);
    
    const sellerObj: Seller = {
      id: newSellerId,
      username: currentUser.username,
      name: currentUser.name,
      avatar: currentUser.avatar,
      title: profileData.title || 'Freelance Specialist',
      bio: profileData.bio || 'Professional services provider.',
      rating: exist?.rating || 5.0,
      reviewCount: exist?.reviewCount || 0,
      completedOrders: exist?.completedOrders || 0,
      responseTime: profileData.responseTime || '1 hour',
      languages: profileData.languages || ['English'],
      location: currentUser.country,
      skills: profileData.skills || [],
      education: profileData.education || [],
      certifications: profileData.certifications || [],
      portfolio: profileData.portfolio || [],
      hourlyRate: profileData.hourlyRate || 50,
      availability: profileData.availability || 'Full-time',
      joinedDate: exist?.joinedDate || 'Sep 2026',
      isOnline: true,
      level: exist?.level || 'New Seller'
    };

    if (exist) {
      setSellers(prev => prev.map(s => s.id === newSellerId ? sellerObj : s));
    } else {
      setSellers(prev => [sellerObj, ...prev]);
    }

    setCurrentUser(prev => ({
      ...prev,
      accountType: 'Both',
      sellerProfileId: newSellerId
    }));
    
    setActiveRole('seller');
    showToast('Congratulations! Your Seller profile is published.', 'success');
    addNotification('Your professional seller profile is now active on WorkHub.', 'system');
  };

  const logout = () => {
    // Clear state
    localStorage.removeItem('wh_current_user');
    localStorage.removeItem('wh_active_role');
    showToast('Logged out of demo session', 'info');
    // reset to defaults for the template exploration
    setCurrentUser(defaultUser);
    setActiveRole('buyer');
  };

  // Add Notification helper
  const addNotification = (text: string, type: AppNotification['type']) => {
    const newNot: AppNotification = {
      id: `not-${Date.now()}`,
      text,
      type,
      createdAt: 'Just now',
      read: false
    };
    setNotifications(prev => [newNot, ...prev]);
  };

  const markNotificationsAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
    showToast('Marked all notifications as read', 'info');
  };

  const clearNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  // Toggle Save Gigs/Sellers
  const toggleSaveService = (serviceId: string) => {
    setSavedServicesIds(prev => {
      const active = prev.includes(serviceId);
      if (active) {
        showToast('Service removed from saved items', 'info');
        return prev.filter(id => id !== serviceId);
      } else {
        showToast('Service saved to your list', 'success');
        return [...prev, serviceId];
      }
    });
  };

  const toggleSaveSeller = (sellerId: string) => {
    setSavedSellersIds(prev => {
      const active = prev.includes(sellerId);
      if (active) {
        showToast('Seller removed from favorites', 'info');
        return prev.filter(id => id !== sellerId);
      } else {
        showToast('Seller added to your favorites', 'success');
        return [...prev, sellerId];
      }
    });
  };

  // Seller Gigs Operations
  const addNewService = (serviceData: Partial<Service>) => {
    const newService: Service = {
      id: `ser-user-${Date.now()}`,
      title: serviceData.title || 'I will provide custom services',
      categoryId: serviceData.categoryId || 'cat-tech',
      subcategoryId: serviceData.subcategoryId || 'General',
      sellerId: currentUser.sellerProfileId || 'sel-1',
      rating: 5.0,
      reviewCount: 0,
      views: 0,
      impressions: 0,
      ordersCount: 0,
      status: serviceData.status || 'Active',
      images: serviceData.images && serviceData.images.length > 0 ? serviceData.images : ['https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&auto=format&fit=crop&q=80'],
      description: serviceData.description || 'Service details description template.',
      tags: serviceData.tags || [],
      faq: serviceData.faq || [],
      requirements: serviceData.requirements || 'Please describe your detailed deliverables.',
      packages: serviceData.packages || {
        basic: { price: 25, deliveryTime: 3, revisions: 3, features: ['Core standard delivery'] },
        standard: { price: 75, deliveryTime: 5, revisions: 5, features: ['Premium quality deliverable'] },
        premium: { price: 150, deliveryTime: 7, revisions: -1, features: ['Unlimited priority assets deliverable'] }
      }
    };

    setServices(prev => [newService, ...prev]);
    showToast(`Service "${newService.title.slice(0, 20)}..." published successfully!`, 'success');
    addNotification(`Your new gig "${newService.title.slice(0, 25)}..." is now active.`, 'system');
  };

  const updateServiceStatus = (id: string, status: 'Active' | 'Draft' | 'Paused') => {
    setServices(prev => prev.map(s => s.id === id ? { ...s, status } : s));
    showToast(`Service status updated to ${status}`, 'success');
  };

  const editService = (id: string, updated: Partial<Service>) => {
    setServices(prev => prev.map(s => s.id === id ? { ...s, ...updated } : s));
    showToast('Service updated successfully', 'success');
  };

  const deleteService = (id: string) => {
    setServices(prev => prev.filter(s => s.id !== id));
    showToast('Service removed from catalog', 'info');
  };

  // Buyer Order flow
  const createNewOrder = (serviceId: string, packageType: 'basic' | 'standard' | 'premium', requirements: string): Order => {
    const service = services.find(s => s.id === serviceId);
    if (!service) throw new Error('Service not found');
    
    const pkg = service.packages[packageType];
    const date = new Date();
    date.setDate(date.getDate() + pkg.deliveryTime);
    
    const formatDelivery = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    const formatNow = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

    const newOrder: Order = {
      id: `WH-2026-10${500 + orders.length}`,
      serviceId,
      buyerId: currentUser.id,
      sellerId: service.sellerId,
      packageSelected: packageType,
      price: pkg.price,
      status: 'Pending',
      requirementsSubmitted: requirements,
      deliveryDate: formatDelivery,
      createdAt: formatNow,
      messages: [
        { id: `omsg-${Date.now()}-1`, sender: 'buyer', text: `Requirements submitted: ${requirements}`, timestamp: 'Just now' }
      ]
    };

    setOrders(prev => [newOrder, ...prev]);
    
    // Auto increment views/orders on the service
    setServices(prev => prev.map(s => s.id === serviceId ? { ...s, ordersCount: s.ordersCount + 1 } : s));
    
    addNotification(`New order ${newOrder.id} placed successfully.`, 'order');
    showToast('Order Placed! Complete your checklist details.', 'success');
    return newOrder;
  };

  const deliverOrder = (orderId: string, text: string, fileName: string) => {
    const delivery = {
      text,
      files: [{ name: fileName || 'deliverable.zip', url: '#' }],
      submittedAt: 'Just now'
    };

    setOrders(prev => prev.map(o => o.id === orderId ? {
      ...o,
      status: 'Delivered',
      deliverySubmission: delivery,
      messages: [
        ...o.messages,
        { id: `omsg-${Date.now()}`, sender: 'seller', text: `🚀 Delivery submitted: ${text}. Attached: ${fileName}`, timestamp: 'Just now' }
      ]
    } : o));

    showToast('Work submitted to buyer!', 'success');
    addNotification(`Order ${orderId} has been delivered. Please review it.`, 'order');
  };

  const updateOrderStatus = (orderId: string, status: Order['status']) => {
    setOrders(prev => prev.map(o => o.id === orderId ? {
      ...o,
      status,
      messages: [
        ...o.messages,
        { id: `omsg-${Date.now()}`, sender: 'system' as any, text: `Order status changed to: ${status}`, timestamp: 'Just now' }
      ]
    } : o));
    
    showToast(`Order marked as ${status}`, 'success');
    addNotification(`Order ${orderId} is now ${status}.`, 'order');
  };

  const addOrderMessage = (orderId: string, sender: 'buyer' | 'seller', text: string) => {
    const newMsg: OrderMessage = {
      id: `omsg-${Date.now()}`,
      sender,
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    
    setOrders(prev => prev.map(o => o.id === orderId ? {
      ...o,
      messages: [...o.messages, newMsg]
    } : o));
  };

  // Messaging / Chat operations
  const startOrGetConversation = (sellerId: string, buyerId: string): string => {
    const existing = conversations.find(c => c.sellerId === sellerId && c.buyerId === buyerId);
    if (existing) return existing.id;

    const newConvoId = `convo-${Date.now()}`;
    const newConvo: Conversation = {
      id: newConvoId,
      buyerId,
      sellerId,
      messages: [
        { id: `cmsg-${Date.now()}`, senderId: buyerId, text: 'Hi, I would like to inquire about your freelance listings.', timestamp: 'Just now', read: true }
      ]
    };

    setConversations(prev => [newConvo, ...prev]);
    showToast('Conversation started', 'success');
    return newConvoId;
  };

  const sendChatMessage = (convoId: string, senderId: string, text: string, file?: string) => {
    const newMsg: ChatMessage = {
      id: `cmsg-${Date.now()}`,
      senderId,
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      read: false,
      file
    };

    setConversations(prev => prev.map(c => c.id === convoId ? {
      ...c,
      messages: [...c.messages, newMsg]
    } : c));

    // Push notification to receiver if needed
    const convo = conversations.find(c => c.id === convoId);
    if (convo) {
      const recipientId = convo.buyerId === senderId ? convo.sellerId : convo.buyerId;
      addNotification(`New message received in your inbox.`, 'message');
    }
  };

  const markChatAsRead = (convoId: string) => {
    setConversations(prev => prev.map(c => c.id === convoId ? {
      ...c,
      messages: c.messages.map(m => m.senderId !== currentUser.id ? { ...m, read: true } : m)
    } : c));
  };

  // Buyer Requests / Projects boards
  const postBuyerRequest = (reqData: Partial<BuyerRequest>) => {
    const newReq: BuyerRequest = {
      id: `req-user-${Date.now()}`,
      title: reqData.title || 'Untitled Request',
      description: reqData.description || 'No description provided.',
      categoryId: reqData.categoryId || 'cat-tech',
      budget: reqData.budget || 100,
      deadline: reqData.deadline || '7 Days',
      skillsRequired: reqData.skillsRequired || [],
      buyerId: currentUser.id,
      createdAt: 'Just now',
      proposals: []
    };

    setBuyerRequests(prev => [newReq, ...prev]);
    showToast('Your custom project request is published!', 'success');
    addNotification(`Your request "${newReq.title.slice(0, 25)}..." is active.`, 'system');
  };

  // Custom operations mapping to fulfill specific page workflows
  const addCategory = (cat: Category) => {
    setCategories(prev => [...prev, cat]);
  };

  const addBuyerRequest = (req: { title: string; description: string; budget: number; duration: string }) => {
    const newReq: BuyerRequest = {
      id: `req-user-${Date.now()}`,
      title: req.title,
      description: req.description,
      categoryId: 'cat-tech',
      budget: req.budget,
      deadline: req.duration,
      skillsRequired: ['TypeScript', 'React'],
      buyerId: currentUser.id,
      createdAt: 'Just now',
      proposals: []
    };
    setBuyerRequests(prev => [newReq, ...prev]);
    addNotification(`Your request "${newReq.title.slice(0, 25)}..." is active.`, 'system');
  };

  const submitProposalToRequest = (requestId: string, propData: Partial<Proposal>) => {
    const newProposal: Proposal = {
      sellerId: currentUser.sellerProfileId || 'sel-1',
      price: propData.price || 50,
      deliveryTime: propData.deliveryTime || 3,
      coverMessage: propData.coverMessage || 'I would love to help you complete this project!',
      status: 'pending',
      createdAt: 'Just now'
    };

    setBuyerRequests(prev => prev.map(r => r.id === requestId ? {
      ...r,
      proposals: [...r.proposals, newProposal]
    } : r));

    showToast('Your proposal was sent successfully!', 'success');
    addNotification(`Proposal submitted to project request.`, 'proposal');
  };

  const createOrder = (serviceId: string, packageType: 'basic' | 'standard' | 'premium', requirements: string): string => {
    const orderObj = createNewOrder(serviceId, packageType, requirements);
    return orderObj.id;
  };

  const submitWorkDelivery = (orderId: string, text: string, fileName: string) => {
    deliverOrder(orderId, text, fileName);
  };

  const approveOrderAndReview = (orderId: string, rating: number, comment: string) => {
    // Mark order as Completed
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: 'Completed' } : o));
    
    // Auto sync rating adjustments to the service and associated seller profile
    const orderObj = orders.find(o => o.id === orderId);
    if (orderObj) {
      // Expose the rating review into the catalog
      setServices(prev => prev.map(s => s.id === orderObj.serviceId ? {
        ...s,
        rating: s.reviewCount === 0 ? rating : parseFloat(((s.rating * s.reviewCount + rating) / (s.reviewCount + 1)).toFixed(1)),
        reviewCount: s.reviewCount + 1
      } : s));

      setSellers(prev => prev.map(sel => sel.id === orderObj.sellerId ? {
        ...sel,
        rating: sel.reviewCount === 0 ? rating : parseFloat(((sel.rating * sel.reviewCount + rating) / (sel.reviewCount + 1)).toFixed(1)),
        reviewCount: sel.reviewCount + 1,
        completedOrders: sel.completedOrders + 1
      } : sel));

      addNotification(`Your delivery for Order WH-2026-${orderId} was approved! Rating: ${rating} Stars.`, 'review');
    }
    showToast('Order completed and review published!', 'success');
  };

  const requestOrderRevision = (orderId: string) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: 'Revision Requested' } : o));
    addNotification(`Revision requested for Order WH-2026-${orderId}.`, 'order');
    showToast('Revision request sent to Nikolai.', 'info');
  };

  const toggleServiceStatus = (id: string) => {
    setServices(prev => prev.map(s => {
      if (s.id === id) {
        const nextStatus = s.status === 'Active' ? 'Paused' : 'Active';
        showToast(`Listing is now ${nextStatus}`, 'success');
        return { ...s, status: nextStatus };
      }
      return s;
    }));
  };

  const addServiceListing = (service: Service) => {
    setServices(prev => [service, ...prev]);
  };

  const switchUserTemplate = (user: AppUser) => {
    setCurrentUser(user);
    showToast(`Logged in as ${user.name}`, 'success');
  };

  return (
    <AppContext.Provider value={{
      currentUser,
      activeRole,
      switchRole,
      updateUserProfile,
      registerAsSeller,
      logout,
      switchUserTemplate,
      categories,
      sellers,
      services,
      reviews: mockReviews,
      orders,
      conversations,
      buyerRequests,
      notifications,
      addNewService,
      updateServiceStatus,
      editService,
      deleteService,
      toggleServiceStatus,
      addServiceListing,
      addCategory,
      createNewOrder,
      createOrder,
      deliverOrder,
      submitWorkDelivery,
      updateOrderStatus,
      addOrderMessage,
      approveOrderAndReview,
      requestOrderRevision,
      startOrGetConversation,
      sendChatMessage,
      markChatAsRead,
      postBuyerRequest,
      addBuyerRequest,
      submitProposalToRequest,
      toggleSaveService,
      toggleSaveSeller,
      savedServicesIds,
      savedSellersIds,
      addNotification,
      markNotificationsAsRead,
      clearNotification,
      theme,
      toggleTheme,
      toast,
      showToast
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used inside an AppProvider');
  return context;
};
