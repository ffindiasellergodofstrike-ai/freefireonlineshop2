// Realistic high-quality mock data for WORKHUB marketplace template

export interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string; // Lucide icon name
  description: string;
  image: string;
}

export interface Seller {
  id: string;
  username: string;
  name: string;
  avatar: string;
  title: string;
  bio: string;
  rating: number;
  reviewCount: number;
  completedOrders: number;
  responseTime: string;
  languages: string[];
  location: string;
  skills: string[];
  education: string[];
  certifications: string[];
  portfolio: { title: string; image: string; link: string }[];
  hourlyRate: number;
  availability: string;
  joinedDate: string;
  isOnline: boolean;
  level: 'New Seller' | 'Level 1' | 'Level 2' | 'Top Rated';
}

export interface PackageDetails {
  price: number;
  deliveryTime: number; // in days
  revisions: number; // -1 for unlimited
  features: string[];
}

export interface Service {
  id: string;
  title: string;
  categoryId: string;
  subcategoryId: string;
  sellerId: string;
  rating: number;
  reviewCount: number;
  views: number;
  impressions: number;
  ordersCount: number;
  status: 'Active' | 'Draft' | 'Paused';
  images: string[];
  description: string;
  tags: string[];
  faq: { question: string; answer: string }[];
  requirements: string;
  packages: {
    basic: PackageDetails;
    standard: PackageDetails;
    premium: PackageDetails;
  };
}

export interface Buyer {
  id: string;
  username: string;
  name: string;
  avatar: string;
  country: string;
}

export interface Review {
  id: string;
  serviceId: string;
  sellerId: string;
  buyerId: string;
  rating: number;
  comment: string;
  date: string;
}

export interface OrderMessage {
  id: string;
  sender: 'buyer' | 'seller';
  text: string;
  timestamp: string;
  file?: string;
}

export interface Order {
  id: string;
  serviceId: string;
  buyerId: string;
  sellerId: string;
  packageSelected: 'basic' | 'standard' | 'premium';
  price: number;
  status: 'Pending' | 'In Progress' | 'Delivered' | 'Revision Requested' | 'Completed' | 'Cancelled';
  requirementsSubmitted: string;
  deliveryDate: string;
  createdAt: string;
  messages: OrderMessage[];
  deliverySubmission?: {
    text: string;
    files: { name: string; url: string }[];
    submittedAt: string;
  };
}

export interface ChatMessage {
  id: string;
  senderId: string;
  text: string;
  timestamp: string;
  read: boolean;
  file?: string;
}

export interface Conversation {
  id: string;
  buyerId: string;
  sellerId: string;
  messages: ChatMessage[];
}

export interface Proposal {
  sellerId: string;
  price: number;
  deliveryTime: number;
  coverMessage: string;
  status: 'pending' | 'accepted' | 'declined';
  createdAt: string;
}

export interface BuyerRequest {
  id: string;
  title: string;
  description: string;
  categoryId: string;
  budget: number;
  deadline: string;
  skillsRequired: string[];
  buyerId: string;
  createdAt: string;
  proposals: Proposal[];
}

// 1. Categories (10 items)
export const mockCategories: Category[] = [
  {
    id: 'cat-graphics',
    name: 'Graphics & Design',
    slug: 'graphics-design',
    icon: 'Palette',
    description: 'Logo design, branding, illustration, UI/UX, and web graphics.',
    image: 'https://images.unsplash.com/photo-1626785774573-4b799315345d?w=600&auto=format&fit=crop&q=60'
  },
  {
    id: 'cat-tech',
    name: 'Programming & Tech',
    slug: 'programming-tech',
    icon: 'Code',
    description: 'Web development, mobile apps, software, APIs, and databases.',
    image: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=600&auto=format&fit=crop&q=60'
  },
  {
    id: 'cat-marketing',
    name: 'Digital Marketing',
    slug: 'digital-marketing',
    icon: 'TrendingUp',
    description: 'SEO, social media, advertising, content strategy, and PPC.',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&auto=format&fit=crop&q=60'
  },
  {
    id: 'cat-video',
    name: 'Video & Animation',
    slug: 'video-animation',
    icon: 'Video',
    description: 'Video editing, explainer videos, 3D modeling, and motion graphics.',
    image: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=600&auto=format&fit=crop&q=60'
  },
  {
    id: 'cat-writing',
    name: 'Writing & Translation',
    slug: 'writing-translation',
    icon: 'FileText',
    description: 'Articles, copywriting, translation, proofreading, and resumes.',
    image: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?w=600&auto=format&fit=crop&q=60'
  },
  {
    id: 'cat-music',
    name: 'Music & Audio',
    slug: 'music-audio',
    icon: 'Music',
    description: 'Voiceover, mixing, production, sound effects, and podcasts.',
    image: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?w=600&auto=format&fit=crop&q=60'
  },
  {
    id: 'cat-business',
    name: 'Business',
    slug: 'business',
    icon: 'Briefcase',
    description: 'Virtual assistant, financial planning, consulting, and market research.',
    image: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=600&auto=format&fit=crop&q=60'
  },
  {
    id: 'cat-ai',
    name: 'AI Services',
    slug: 'ai-services',
    icon: 'Cpu',
    description: 'Prompt engineering, custom LLM agents, AI art generation, and training.',
    image: 'https://images.unsplash.com/photo-1677442136019-21780efad99a?w=600&auto=format&fit=crop&q=60'
  },
  {
    id: 'cat-consulting',
    name: 'Consulting',
    slug: 'consulting',
    icon: 'Compass',
    description: 'Legal advice, business coaching, life coaching, and architectural reviews.',
    image: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=600&auto=format&fit=crop&q=60'
  },
  {
    id: 'cat-photo',
    name: 'Photography',
    slug: 'photography',
    icon: 'Camera',
    description: 'Product photos, portrait retouching, event editing, and drone footage.',
    image: 'https://images.unsplash.com/photo-1542038784456-1ea8e935640e?w=600&auto=format&fit=crop&q=60'
  }
];

// 2. Sellers (15 items)
export const mockSellers: Seller[] = [
  {
    id: 'sel-1',
    username: 'alex_ux',
    name: 'Alex Rivera',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    title: 'Senior UI/UX Architect & Brand Expert',
    bio: 'Pristine design is not a luxury, it is an absolute necessity. Over 8 years designing high-conversion SaaS web applications, mobile interfaces, and memorable visual brands. Worked with startups and fortune 500s.',
    rating: 4.92,
    reviewCount: 142,
    completedOrders: 320,
    responseTime: '1 hour',
    languages: ['English', 'Spanish'],
    location: 'United States',
    skills: ['Figma', 'UI/UX Design', 'Wireframing', 'SaaS Design', 'Design Systems', 'Brand Strategy'],
    education: ['BFA in Graphic Design, Rhode Island School of Design'],
    certifications: ['Google UX Design Professional Certificate', 'Nielsen Norman Group UX Certified'],
    portfolio: [
      { title: 'Fintech Dashboard', image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&auto=format&fit=crop&q=60', link: '#' },
      { title: 'E-commerce App', image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&auto=format&fit=crop&q=60', link: '#' }
    ],
    hourlyRate: 85,
    availability: 'Full-time',
    joinedDate: 'Jan 2023',
    isOnline: true,
    level: 'Top Rated'
  },
  {
    id: 'sel-2',
    username: 'dev_nikolai',
    name: 'Nikolai Volkov',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    title: 'Full Stack Node & React Developer',
    bio: 'Hardcore full-stack developer focusing on Next.js, Express, Tailwind and clean code. I optimize your web apps for speed, security, and absolute performance.',
    rating: 4.98,
    reviewCount: 98,
    completedOrders: 184,
    responseTime: '2 hours',
    languages: ['English', 'Russian'],
    location: 'Germany',
    skills: ['React', 'Next.js', 'Node.js', 'Express', 'Tailwind CSS', 'PostgreSQL', 'API Development'],
    education: ['MS in Computer Science, Technical University of Munich'],
    certifications: ['AWS Certified Solutions Architect'],
    portfolio: [
      { title: 'Realtime Chat Engine', image: 'https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=400&auto=format&fit=crop&q=60', link: '#' },
      { title: 'SaaS Multi-tenant CRM', image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&auto=format&fit=crop&q=60', link: '#' }
    ],
    hourlyRate: 95,
    availability: 'Part-time',
    joinedDate: 'Mar 2022',
    isOnline: true,
    level: 'Top Rated'
  },
  {
    id: 'sel-3',
    username: 'sarah_writes',
    name: 'Sarah Jenkins',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    title: 'Conversion Copywriter & Content Marketer',
    bio: 'Words that sell. I specialize in crafting landing page copy, email campaigns, and SEO blog articles that double your engagement and convert cold prospects into loyal advocates.',
    rating: 4.88,
    reviewCount: 205,
    completedOrders: 412,
    responseTime: '1 hour',
    languages: ['English'],
    location: 'United Kingdom',
    skills: ['Copywriting', 'SEO Content Writing', 'Landing Page Copy', 'Email Marketing', 'Brand Voice'],
    education: ['BA in English Literature, University of Cambridge'],
    certifications: ['HubSpot Content Marketing Certification'],
    portfolio: [
      { title: 'SaaS Launch Email Sequence', image: 'https://images.unsplash.com/photo-1557200134-90327ee9fafa?w=400&auto=format&fit=crop&q=60', link: '#' }
    ],
    hourlyRate: 65,
    availability: 'Full-time',
    joinedDate: 'Nov 2021',
    isOnline: false,
    level: 'Level 2'
  },
  {
    id: 'sel-4',
    username: 'ai_pioneer',
    name: 'Dr. Ethan Vance',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    title: 'AI Architect & Prompt Engineer',
    bio: 'Ph.D. in AI and Cognitive Computing. I build bespoke LLM integrations, fine-tune models, design advanced prompts, and consult companies on deploying generative AI safely and profitably.',
    rating: 5.0,
    reviewCount: 43,
    completedOrders: 65,
    responseTime: '3 hours',
    languages: ['English', 'French'],
    location: 'Canada',
    skills: ['Generative AI', 'Prompt Engineering', 'LangChain', 'LlamaIndex', 'Python', 'OpenAI API'],
    education: ['Ph.D. in Computer Science, University of Toronto'],
    certifications: ['DeepLearning.AI Generative AI Specialist'],
    portfolio: [
      { title: 'Custom Support Bot AI', image: 'https://images.unsplash.com/photo-1675557009875-436f09780264?w=400&auto=format&fit=crop&q=60', link: '#' }
    ],
    hourlyRate: 150,
    availability: 'Part-time',
    joinedDate: 'May 2024',
    isOnline: true,
    level: 'Level 1'
  },
  {
    id: 'sel-5',
    username: 'mona_marketer',
    name: 'Mona Patel',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
    title: 'SMM & Paid Ads Specialist',
    bio: 'Boost your business presence. I optimize social profiles and design highly targeted Google and Meta Ads campaigns. 4.5x average ROAS for my clients.',
    rating: 4.85,
    reviewCount: 78,
    completedOrders: 110,
    responseTime: '4 hours',
    languages: ['English', 'Hindi', 'Gujarati'],
    location: 'India',
    skills: ['Facebook Ads', 'Google Ads', 'Instagram Growth', 'PPC Advertising', 'TikTok Marketing'],
    education: ['MBA in Marketing, IIM Bangalore'],
    certifications: ['Google Ads Search Professional', 'Meta Certified Buying Professional'],
    portfolio: [],
    hourlyRate: 45,
    availability: 'Full-time',
    joinedDate: 'Aug 2023',
    isOnline: false,
    level: 'Level 2'
  },
  {
    id: 'sel-6',
    username: 'lucas_lens',
    name: 'Lucas Dupont',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&auto=format&fit=crop&q=80',
    title: 'High-End Product & Portrait Photographer',
    bio: 'I render shadows and light beautifully. Studio setup based in Paris. Send me your physical products, and I will ship back elite, catalog-ready photos that elevate your brand.',
    rating: 4.96,
    reviewCount: 65,
    completedOrders: 125,
    responseTime: '2 hours',
    languages: ['English', 'French'],
    location: 'France',
    skills: ['Product Photography', 'Studio Lighting', 'Adobe Lightroom', 'Photoshop Retouching'],
    education: ['Degree in Visual Arts, École des Beaux-Arts'],
    certifications: [],
    portfolio: [
      { title: 'Perfume Launch Catalog', image: 'https://images.unsplash.com/photo-1541643600914-78b084683601?w=400&auto=format&fit=crop&q=60', link: '#' }
    ],
    hourlyRate: 110,
    availability: 'Part-time',
    joinedDate: 'Feb 2023',
    isOnline: true,
    level: 'Level 2'
  },
  {
    id: 'sel-7',
    username: 'charlie_voice',
    name: 'Charlie Henderson',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150&auto=format&fit=crop&q=80',
    title: 'Professional Voiceover Artist - Deep American Male Baritone',
    bio: 'Warm, corporate, intense, or casual. I record from a professional, double-isolated home booth using a Neumann U87 microphone. Fast 24-hour turnaround guaranteed.',
    rating: 4.94,
    reviewCount: 312,
    completedOrders: 650,
    responseTime: '1 hour',
    languages: ['English'],
    location: 'United States',
    skills: ['Voice Acting', 'Audio Production', 'Commercial Voiceover', 'Explainer Videos', 'Podcasting'],
    education: [],
    certifications: ['Certified Audio Engineer, Full Sail University'],
    portfolio: [],
    hourlyRate: 75,
    availability: 'Full-time',
    joinedDate: 'Oct 2020',
    isOnline: true,
    level: 'Top Rated'
  },
  {
    id: 'sel-8',
    username: 'hannah_consulting',
    name: 'Hannah Abbott',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
    title: 'CFO Consultant & Business Strategist',
    bio: 'I help tech startups analyze unit economics, build investor-ready financial models, and structure their Series-A pitch decks. Ex-McKinsey consultant.',
    rating: 4.91,
    reviewCount: 37,
    completedOrders: 54,
    responseTime: '5 hours',
    languages: ['English'],
    location: 'Australia',
    skills: ['Financial Modeling', 'Pitch Deck Design', 'Business Plan', 'Market Research', 'Unit Economics'],
    education: ['MBA, Wharton School of Business'],
    certifications: ['Chartered Financial Analyst (CFA)'],
    portfolio: [],
    hourlyRate: 180,
    availability: 'Part-time',
    joinedDate: 'Jul 2024',
    isOnline: false,
    level: 'Level 1'
  },
  {
    id: 'sel-9',
    username: 'yuki_video',
    name: 'Yuki Tanaka',
    avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=150&auto=format&fit=crop&q=80',
    title: 'Cinematic Video Editor & Colorist',
    bio: 'Award-winning music video and commercial editor. Expert in DaVinci Resolve, Premiere, and After Effects. Let me tell your brand\'s story through compelling cinematic sequencing.',
    rating: 4.97,
    reviewCount: 82,
    completedOrders: 140,
    responseTime: '1 hour',
    languages: ['English', 'Japanese'],
    location: 'Japan',
    skills: ['Video Editing', 'Color Grading', 'After Effects', 'Premiere Pro', 'DaVinci Resolve', 'Commercials'],
    education: ['BA in Film & Media, Tokyo University of the Arts'],
    certifications: ['DaVinci Resolve Certified Trainer'],
    portfolio: [
      { title: 'Cyberpunk Tokyo Edit', image: 'https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=400&auto=format&fit=crop&q=60', link: '#' }
    ],
    hourlyRate: 90,
    availability: 'Full-time',
    joinedDate: 'Dec 2022',
    isOnline: true,
    level: 'Level 2'
  },
  {
    id: 'sel-10',
    username: 'clara_translate',
    name: 'Clara Schmidt',
    avatar: 'https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?w=150&auto=format&fit=crop&q=80',
    title: 'Certified English-German-Spanish Translator',
    bio: 'Flawless localized manual translations. No Google Translate slop. I localize mobile apps, software dashboards, contract terms, and corporate documentation.',
    rating: 4.9,
    reviewCount: 154,
    completedOrders: 310,
    responseTime: '2 hours',
    languages: ['German', 'English', 'Spanish'],
    location: 'Austria',
    skills: ['Localization', 'Legal Translation', 'App Translation', 'Proofreading', 'Subtitling'],
    education: ['MA in Translation & Interpreting, University of Vienna'],
    certifications: ['ATA (American Translators Association) Certified'],
    portfolio: [],
    hourlyRate: 55,
    availability: 'Full-time',
    joinedDate: 'May 2021',
    isOnline: false,
    level: 'Level 2'
  },
  {
    id: 'sel-11',
    username: 'robert_3d',
    name: 'Robert Miller',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&auto=format&fit=crop&q=80',
    title: '3D Modeler & Product Visualization Artist',
    bio: 'Photorealistic Blender & Cinema4D work. I build custom 3D structures, game-ready low-poly models, and premium architectural asset visualizations.',
    rating: 4.87,
    reviewCount: 52,
    completedOrders: 89,
    responseTime: '3 hours',
    languages: ['English'],
    location: 'United States',
    skills: ['Blender', 'Cinema 4D', '3D Modeling', 'Texturing', 'Octane Render', 'Architectural Renders'],
    education: ['BS in Digital Arts, Savannah College of Art and Design'],
    certifications: [],
    portfolio: [],
    hourlyRate: 80,
    availability: 'Full-time',
    joinedDate: 'Sep 2023',
    isOnline: true,
    level: 'Level 1'
  },
  {
    id: 'sel-12',
    username: 'marta_branding',
    name: 'Marta Gomez',
    avatar: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?w=150&auto=format&fit=crop&q=80',
    title: 'High-End Brand Designer & Illustrator',
    bio: 'Injecting soul into businesses. I create complete vector brand guides, bespoke iconography, handcrafted typography, and premium custom collateral packagings.',
    rating: 4.95,
    reviewCount: 120,
    completedOrders: 230,
    responseTime: '1 hour',
    languages: ['English', 'Spanish'],
    location: 'Spain',
    skills: ['Brand Identity', 'Vector Illustration', 'Logo Design', 'Typography', 'Adobe Illustrator'],
    education: ['Design Graduate, ESDi Barcelona'],
    certifications: [],
    portfolio: [
      { title: 'Organic Cosmetics Pack', image: 'https://images.unsplash.com/photo-1608248597481-496100c8c836?w=400&auto=format&fit=crop&q=60', link: '#' }
    ],
    hourlyRate: 70,
    availability: 'Full-time',
    joinedDate: 'Nov 2022',
    isOnline: true,
    level: 'Level 2'
  },
  {
    id: 'sel-13',
    username: 'shafiq_wp',
    name: 'Shafiq Al-Mansoor',
    avatar: 'https://images.unsplash.com/photo-1513956589380-bad6acb9b9d4?w=150&auto=format&fit=crop&q=80',
    title: 'WordPress Speed Expert & Security Hardener',
    bio: 'No more slow websites. I clean malware, optimize databases, structure server caching, and elevate your Core Web Vitals to solid 95+ scores on PageSpeed Insights.',
    rating: 4.99,
    reviewCount: 167,
    completedOrders: 294,
    responseTime: '1 hour',
    languages: ['English', 'Arabic'],
    location: 'UAE',
    skills: ['WordPress', 'PageSpeed Optimization', 'Core Web Vitals', 'Website Security', 'Database Tuning'],
    education: ['B.Tech in Information Technology, Amity University Dubai'],
    certifications: ['Google Web Performance Certified'],
    portfolio: [],
    hourlyRate: 75,
    availability: 'Full-time',
    joinedDate: 'Mar 2021',
    isOnline: true,
    level: 'Top Rated'
  },
  {
    id: 'sel-14',
    username: 'elena_seo',
    name: 'Elena Rostova',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    title: 'SEO Audit & Technical SEO Master',
    bio: 'Rank #1. I structure rigorous site indexability audits, toxic link cleanses, keyword maps, and advanced on-page schema hierarchies to outrank your competitors.',
    rating: 4.89,
    reviewCount: 68,
    completedOrders: 104,
    responseTime: '2 hours',
    languages: ['English', 'German'],
    location: 'Germany',
    skills: ['SEO Auditing', 'Technical SEO', 'Keyword Research', 'SEMrush', 'Ahrefs', 'Search Console'],
    education: [],
    certifications: ['SEMrush Academy Professional Certificate'],
    portfolio: [],
    hourlyRate: 85,
    availability: 'Part-time',
    joinedDate: 'Jan 2024',
    isOnline: false,
    level: 'Level 2'
  },
  {
    id: 'sel-15',
    username: 'lucid_flow',
    name: 'Ryan Patel',
    avatar: 'https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?w=150&auto=format&fit=crop&q=80',
    title: 'Advanced Webflow & Framer Developer',
    bio: 'Pixel-perfect UI translation into active dynamic layouts. Framer and Webflow wizard. I build sleek sites with breathtaking motion grids and smooth scroll interactions.',
    rating: 4.93,
    reviewCount: 45,
    completedOrders: 78,
    responseTime: '1 hour',
    languages: ['English'],
    location: 'United Kingdom',
    skills: ['Webflow', 'Framer', 'Interactions 2.0', 'Landing Pages', 'CSS Animations'],
    education: [],
    certifications: ['Framer Authorized Expert', 'Webflow Professional Partner'],
    portfolio: [],
    hourlyRate: 100,
    availability: 'Full-time',
    joinedDate: 'Jun 2024',
    isOnline: true,
    level: 'Level 1'
  }
];

// 3. Buyers (20 items)
export const mockBuyers: Buyer[] = Array.from({ length: 20 }, (_, i) => ({
  id: `buy-${i + 1}`,
  username: `buyer_client_${i + 1}`,
  name: [
    'Emily Cooper', 'James Morgan', 'Oliver Twist', 'Sophia Loren', 'William Chen',
    'Amara Okafor', 'Luca Rossi', 'Charlotte Bronte', 'Arthur Dent', 'Mei Ling',
    'Gabriel Garcia', 'Chloe Thompson', 'Isaac Newton', 'Zara Larsson', 'David Beckham',
    'Yusuf Demir', 'Emma Watson', 'Alistair Cooke', 'Nia Jones', 'Kofi Mensah'
  ][i],
  avatar: `https://images.unsplash.com/photo-${[
    '1438761681033-6461ffad8d80', '1500648767791-00dcc994a43e', '1535713875002-d1d0cf377fde', '1544005313-94ddf0286df2', '1492562080023-ab3db95bfbce',
    '1488426862026-3ee34a7d66df', '1527980965255-d3b416303d12', '1534528741775-53994a69daeb', '1506794778202-cad84cf45f1d', '1517841905240-472988babdf9',
    '1522075469751-3a6694fb2f61', '1554151228-14d9def656e4', '1519085360753-af0119f7cbe7', '1513956589380-bad6acb9b9d4', '1507003211169-0a1dd7228f2d',
    '1501196354995-cbb51c65aaea', '1494790108377-be9c29b29330', '1504257473779-c33e445383c6', '1489424731084-a5d8b219a5bb', '1512485694743-9c9538b4e6e0'
  ][i]}?w=100&auto=format&fit=crop&q=80`,
  country: [
    'United States', 'Canada', 'United Kingdom', 'Italy', 'Singapore',
    'Nigeria', 'Italy', 'United Kingdom', 'Australia', 'China',
    'Brazil', 'United States', 'United Kingdom', 'Sweden', 'United Kingdom',
    'Turkey', 'Canada', 'Australia', 'Wales', 'Ghana'
  ][i]
}));

// 4. Services / Gigs (30 items)
export const mockServices: Service[] = [
  // alex_ux (sel-1)
  {
    id: 'ser-1',
    title: 'I will design a modern high-converting SaaS landing page in Figma',
    categoryId: 'cat-graphics',
    subcategoryId: 'UI/UX Design',
    sellerId: 'sel-1',
    rating: 4.95,
    reviewCount: 38,
    views: 1250,
    impressions: 4800,
    ordersCount: 42,
    status: 'Active',
    images: [
      'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1581291518633-83b4ebd1d83e?w=800&auto=format&fit=crop&q=80'
    ],
    description: 'Looking to turn visitors into paying customers? I specialize in crafting ultra-high-end SaaS and Web3 Landing Pages in Figma that are mathematically proportioned and highly persuasive.\n\n### What You Get:\n* Complete desktop & mobile design system\n* Fully componentized Figma source files with Auto-Layout\n* Clear typographic scale & spacing grids\n* High-converting layout backed by neuro-design research\n\n### Why work with me?\nI have designed for companies funded by YC, Sequoia, and Founders Fund. Let us create something premium together.',
    tags: ['Figma Design', 'SaaS Design', 'Landing Page', 'Web Design', 'UI UX'],
    faq: [
      { question: 'Do you provide HTML/CSS code?', answer: 'This service is strictly for UI/UX Design inside Figma. You will receive source Figma files with perfect auto-layouts. However, I can recommend elite developers or you can check Nikolai\'s profiles!' },
      { question: 'Can you use my existing branding?', answer: 'Absolutely. Send over your logo, brand guidelines, and fonts. I will adapt the design perfectly to fit your existing visual identity.' }
    ],
    requirements: 'Please share your company logo, a brief summary of what your SaaS product does, and any competitor websites whose visual layouts you respect.',
    packages: {
      basic: {
        price: 150,
        deliveryTime: 3,
        revisions: 3,
        features: ['1 Landing Page Screen', 'Desktop Version', 'Figma Source File', 'Custom Icons']
      },
      standard: {
        price: 350,
        deliveryTime: 5,
        revisions: 5,
        features: ['1 Landing Page Screen', 'Mobile Responsive Screen', 'Figma Source File', 'Custom Icons', 'Design System System Grid']
      },
      premium: {
        price: 750,
        deliveryTime: 7,
        revisions: -1,
        features: ['3 Fully Designed Pages', 'Mobile Responsive Version', 'Interactive Figma Prototype', 'Design System System Grid', 'Commercial Use License']
      }
    }
  },
  {
    id: 'ser-2',
    title: 'I will design a complete premium mobile app UI/UX system',
    categoryId: 'cat-graphics',
    subcategoryId: 'Mobile UX',
    sellerId: 'sel-1',
    rating: 4.89,
    reviewCount: 22,
    views: 980,
    impressions: 3400,
    ordersCount: 24,
    status: 'Active',
    images: [
      'https://images.unsplash.com/photo-1616004749007-aa4e71239c09?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=800&auto=format&fit=crop&q=80'
    ],
    description: 'Elevate your mobile app. I design exquisite iOS and Android UI templates focusing on native interactive flows, finger-friendly layouts, and beautiful typography.\n\nIncludes wireframing, high-fidelity styles, and visual assets assets delivery ready for Swift/Kotlin.',
    tags: ['Mobile UI', 'Figma UI', 'iOS Design', 'Android UX', 'App Prototyping'],
    faq: [],
    requirements: 'Requirements: Detailed list of app screens needed, reference apps you love, and your brand guidelines.',
    packages: {
      basic: { price: 200, deliveryTime: 4, revisions: 3, features: ['3 Key App Screens', 'iOS or Android', 'Figma File', 'Assets Export'] },
      standard: { price: 600, deliveryTime: 8, revisions: 6, features: ['10 Main Screens', 'Figma Source File', 'Interactive Prototyping', 'Complete Icon Set'] },
      premium: { price: 1200, deliveryTime: 14, revisions: -1, features: ['20 Complete Screens', 'iOS + Android adaptives', 'Full Design Tokens', 'Figma Source File', 'Priority Chat Support'] }
    }
  },
  // dev_nikolai (sel-2)
  {
    id: 'ser-3',
    title: 'I will build a full stack React, Node.js and Tailwind website',
    categoryId: 'cat-tech',
    subcategoryId: 'Web Development',
    sellerId: 'sel-2',
    rating: 4.99,
    reviewCount: 45,
    views: 1450,
    impressions: 5900,
    ordersCount: 52,
    status: 'Active',
    images: [
      'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1542831371-29b0f74f9713?w=800&auto=format&fit=crop&q=80'
    ],
    description: 'Need an industrial-grade website built? I code clean, robust React applications backed by FastNode.js / Express servers, fully secured and optimized for standard databases.\n\n### Tech Stack:\n* React & Vite / Next.js\n* Tailwind CSS with elegant transitions\n* Node.js, Express, REST/GraphQL APIs\n* PostgreSQL / MongoDB integration\n* Docker, AWS and Vercel setup\n\nPerfect for custom dashboards, web platforms, and business systems.',
    tags: ['React Developer', 'Full Stack', 'Node JS', 'Tailwind CSS', 'Web Application'],
    faq: [
      { question: 'Will you host the web application?', answer: 'I will help set up your domain and connect it to Vercel, Netlify, or AWS under your own credentials. I write a standard deployment guide.' }
    ],
    requirements: 'Provide your Figma designs, required features, database constraints, and your chosen hosting targets.',
    packages: {
      basic: { price: 299, deliveryTime: 5, revisions: 3, features: ['1 Page React SPA', 'Tailwind CSS styling', 'Express Mock API', 'Clean Source Code'] },
      standard: { price: 799, deliveryTime: 10, revisions: 5, features: ['5 Dynamic Pages React', 'Real Node.js Server API', 'PostgreSQL DB Integration', 'Admin Panels', 'Responsive Layout'] },
      premium: { price: 1599, deliveryTime: 20, revisions: -1, features: ['Complete Custom SaaS App', 'Multi-tenant Setup', 'Payment Integrations', 'Realtime WebSockets Chat', '1 Month Free Support'] }
    }
  },
  {
    id: 'ser-4',
    title: 'I will develop custom REST and GraphQL APIs with Node.js',
    categoryId: 'cat-tech',
    subcategoryId: 'APIs & Integrations',
    sellerId: 'sel-2',
    rating: 4.94,
    reviewCount: 18,
    views: 520,
    impressions: 2100,
    ordersCount: 20,
    status: 'Active',
    images: [
      'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&auto=format&fit=crop&q=80'
    ],
    description: 'Professional, secured backend architecture. I write custom API servers in Node.js / TypeScript, configure authentication (JWT, OAuth), integrate Stripe/PayPal, and configure thorough API documentation using Swagger.',
    tags: ['API Development', 'Node.js Express', 'GraphQL', 'Stripe Integration', 'Database Schema'],
    faq: [],
    requirements: 'List of endpoints, database type, and third-party webhooks/integrations needed.',
    packages: {
      basic: { price: 150, deliveryTime: 3, revisions: 2, features: ['3 API Endpoints', 'Mock Database', 'Swagger Documentation', 'JWT Auth'] },
      standard: { price: 390, deliveryTime: 6, revisions: 4, features: ['10 Solid Endpoints', 'PostgreSQL/Prisma', 'Stripe Payments Integration', 'Error Handlers System'] },
      premium: { price: 850, deliveryTime: 12, revisions: 6, features: ['Complete Microservice API', 'OAuth & Social Sign-on', 'GraphQL & REST options', 'Full Docker orchestration', 'Unit Testing Suites'] }
    }
  },
  // sarah_writes (sel-3)
  {
    id: 'ser-5',
    title: 'I will write high-converting SaaS landing page copywriting',
    categoryId: 'cat-writing',
    subcategoryId: 'Copywriting',
    sellerId: 'sel-3',
    rating: 4.92,
    reviewCount: 56,
    views: 890,
    impressions: 3100,
    ordersCount: 61,
    status: 'Active',
    images: [
      'https://images.unsplash.com/photo-1455390582262-044cdead277a?w=800&auto=format&fit=crop&q=80'
    ],
    description: 'Stop wasting traffic. I compose killer, psychology-driven copy that matches your brand persona, hooks your user immediately, and drives them directly to your checkout buttons.',
    tags: ['SaaS Copywriting', 'Landing Page Copy', 'Sales Copy', 'Email Copy', 'Content Strategist'],
    faq: [],
    requirements: 'Tell me about your product, your target audience, and what action you want them to take.',
    packages: {
      basic: { price: 95, deliveryTime: 2, revisions: 2, features: ['Headline + Hero Section', 'Value Proposition Hook', '1 CTA Section Copy'] },
      standard: { price: 250, deliveryTime: 4, revisions: 4, features: ['Full 5-Section Landing Page Copy', 'Wireframe Layout Advice', 'Competitor Voice Analysis'] },
      premium: { price: 500, deliveryTime: 6, revisions: -1, features: ['Elite Multi-page Copy bundle', 'SEO Keyword Plan', 'A/B Test Title Alternatives', 'Email Welcome Sequence Copy'] }
    }
  },
  // ai_pioneer (sel-4)
  {
    id: 'ser-6',
    title: 'I will integrate custom Gemini and OpenAI AI models into your app',
    categoryId: 'cat-ai',
    subcategoryId: 'AI Integrations',
    sellerId: 'sel-4',
    rating: 5.0,
    reviewCount: 15,
    views: 1100,
    impressions: 4200,
    ordersCount: 19,
    status: 'Active',
    images: [
      'https://images.unsplash.com/photo-1677442136019-21780efad99a?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1675557009875-436f09780264?w=800&auto=format&fit=crop&q=80'
    ],
    description: 'Embed advanced machine intelligence. I design robust wrappers, orchestrate semantic agents using LangChain, and write highly optimized context prompts for Gemini Flash, Gemini Pro, and GPT-4.\n\nIncludes dynamic streaming, automated context injection (RAG), and cost-efficient tokens monitoring.',
    tags: ['Gemini API', 'OpenAI', 'LangChain', 'AI Agent', 'Prompt Engineering'],
    faq: [],
    requirements: 'Your API Keys, current application codebase language, and the target workflows you want the AI to handle.',
    packages: {
      basic: { price: 250, deliveryTime: 3, revisions: 2, features: ['Basic AI API wrapper', 'Simple Prompt design', 'Node/Python script setup'] },
      standard: { price: 650, deliveryTime: 7, revisions: 4, features: ['Structured JSON response agent', 'RAG database connection', 'Error fallback system', 'Full API proxy routing'] },
      premium: { price: 1500, deliveryTime: 14, revisions: -1, features: ['Complete Multi-Agent LLM flow', 'Conversational memory setups', 'Gemini Live voice template integration', 'Dashboard monitoring analytics'] }
    }
  },
  // mona_marketer (sel-5)
  {
    id: 'ser-7',
    title: 'I will manage and optimize your Facebook and Instagram ads',
    categoryId: 'cat-marketing',
    subcategoryId: 'Social Media',
    sellerId: 'sel-5',
    rating: 4.81,
    reviewCount: 32,
    views: 750,
    impressions: 2900,
    ordersCount: 40,
    status: 'Active',
    images: [
      'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop&q=80'
    ],
    description: 'Grow your ecommerce or service business. I build target audience segments, deploy professional pixel-tracking networks, create beautiful ad creatives, and scale ad sets targeting lower CAC.',
    tags: ['Facebook Ads', 'Instagram Marketing', 'Meta Pixel', 'PPC Management', 'E-commerce Growth'],
    faq: [],
    requirements: 'Access to Facebook Business Manager, your monthly ad spend budget (not included in gig price), and primary image assets.',
    packages: {
      basic: { price: 80, deliveryTime: 5, revisions: 1, features: ['1 Ad Campaign Setup', '2 Target Audiences', 'Weekly Reporting'] },
      standard: { price: 200, deliveryTime: 14, revisions: 3, features: ['3 Active Ad Campaigns', 'Ad Creative Copywriting', 'Meta Pixel Audit', '14 Days Optimization'] },
      premium: { price: 450, deliveryTime: 30, revisions: 6, features: ['Full Meta Suite Management', 'A/B Creative testing', 'Retargeting funnels setup', '30 Days Complete Management'] }
    }
  },
  // lucas_lens (sel-6)
  {
    id: 'ser-8',
    title: 'I will shoot high-end professional commercial product photography',
    categoryId: 'cat-photography',
    subcategoryId: 'Product Photos',
    sellerId: 'sel-6',
    rating: 4.98,
    reviewCount: 29,
    views: 610,
    impressions: 2200,
    ordersCount: 45,
    status: 'Active',
    images: [
      'https://images.unsplash.com/photo-1541643600914-78b084683601?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&auto=format&fit=crop&q=80'
    ],
    description: 'Ship your items to my studio in Paris, France. I deliver flawless, elite catalog-ready product photos shot with custom studio strobes, clean monochromatic backdrops, and expert retouching.',
    tags: ['Product Photo', 'Amazon Listing', 'E-commerce Photos', 'Studio Lighting', 'Photoshop'],
    faq: [],
    requirements: 'You must ship your product to Paris. Orders are started after the physical package arrives at my studio.',
    packages: {
      basic: { price: 120, deliveryTime: 5, revisions: 2, features: ['3 Professional Photos', 'Pure White Background', 'High Resolution JPG', 'Basic Photoshop retouching'] },
      standard: { price: 280, deliveryTime: 7, revisions: 3, features: ['8 Professional Photos', 'White & Creative Stylized sets', 'Full Commercial Rights', 'TIFF & PNG files'] },
      premium: { price: 550, deliveryTime: 10, revisions: 5, features: ['15 Elite Photos', 'Includes lifestyle styling', 'Hero banner renders', 'Priority return shipping included'] }
    }
  },
  // charlie_voice (sel-7)
  {
    id: 'ser-9',
    title: 'I will record a deep professional American male voiceover',
    categoryId: 'cat-music',
    subcategoryId: 'Voiceover',
    sellerId: 'sel-7',
    rating: 4.96,
    reviewCount: 112,
    views: 1850,
    impressions: 6800,
    ordersCount: 210,
    status: 'Active',
    images: [
      'https://images.unsplash.com/photo-1478737270239-2f02b77fc618?w=800&auto=format&fit=crop&q=80'
    ],
    description: 'Need a powerful voice for your commercial, explainer video, audiobook, or YouTube channel? I offer an elite, deep male baritone narration recorded in a studio-grade sound booth.\n\nWarm, corporate, dramatic, or casual. Let us bring your script to life.',
    tags: ['Voiceover', 'Voice Actor', 'Male Voice', 'Narration', 'Audio Recording'],
    faq: [],
    requirements: 'Please upload your exact script text, and indicate your desired tone, speed, and pronunciations for special terms.',
    packages: {
      basic: { price: 50, deliveryTime: 2, revisions: 2, features: ['Up to 100 Words', 'HQ Audio File (WAV)', 'Commercial Rights', 'Split Files'] },
      standard: { price: 120, deliveryTime: 2, revisions: 3, features: ['Up to 300 Words', 'HQ Audio File', 'Background Music option', 'Full Commercial Rights'] },
      premium: { price: 250, deliveryTime: 3, revisions: -1, features: ['Up to 700 Words', 'Priority delivery', 'Full Broadcasting Rights', 'Professional Audio Editing'] }
    }
  },
  // hannah_consulting (sel-8)
  {
    id: 'ser-10',
    title: 'I will build an investor-ready financial model and pitch deck',
    categoryId: 'cat-business',
    subcategoryId: 'Consulting',
    sellerId: 'sel-8',
    rating: 4.9,
    reviewCount: 14,
    views: 430,
    impressions: 1800,
    ordersCount: 18,
    status: 'Active',
    images: [
      'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=800&auto=format&fit=crop&q=80'
    ],
    description: 'Prepare for your next venture-capital funding round. I create deep, rigorous 3-statement financial models (Income, Balance, Cash Flow) in Excel/Google Sheets, mapping out clear CAC/LTV cohorts, runway graphs, and valuation multiples.',
    tags: ['Financial Model', 'Pitch Deck', 'Startup Business', 'VC Investment', 'Consulting'],
    faq: [],
    requirements: 'Your current operational history, core growth assumptions, and brand assets for the deck.',
    packages: {
      basic: { price: 300, deliveryTime: 5, revisions: 2, features: ['Simple Financial Model', 'Revenue Projection', 'Excel Delivery'] },
      standard: { price: 750, deliveryTime: 10, revisions: 4, features: ['Full 3-Statement Model', 'Scenario Planning Analysis', 'Pitch Deck Outline'] },
      premium: { price: 1500, deliveryTime: 14, revisions: 6, features: ['Full Investor Suite Model', 'Premium Pitch Deck (15 Slides)', '1-on-1 Prep Call (1 hr)', 'Unlimited Revisions'] }
    }
  },
  // yuki_video (sel-9)
  {
    id: 'ser-11',
    title: 'I will edit cinematic commercials and music videos',
    categoryId: 'cat-video',
    subcategoryId: 'Video Editing',
    sellerId: 'sel-9',
    rating: 4.99,
    reviewCount: 38,
    views: 890,
    impressions: 3400,
    ordersCount: 44,
    status: 'Active',
    images: [
      'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1536240478700-b869070f9279?w=800&auto=format&fit=crop&q=80'
    ],
    description: 'Transform raw footage into visual art. I provide elite video editing with advanced color grading, sound design, custom motion title graphics, and pacing optimized for maximum emotional impact.',
    tags: ['Video Editor', 'DaVinci Resolve', 'Commercial Edit', 'Music Video', 'Colorist'],
    faq: [],
    requirements: 'Send a link to your raw video footage (Google Drive, Dropbox, etc.), references of style, and scripts.',
    packages: {
      basic: { price: 150, deliveryTime: 3, revisions: 2, features: ['30 Sec Edit', 'Full HD 1080p', 'Sound Design', 'Color Grading'] },
      standard: { price: 350, deliveryTime: 5, revisions: 4, features: ['2 Min Edit', '4K Resolution', 'Advanced Color grading', 'Sound FX & Music Mix', 'Transitions pack'] },
      premium: { price: 800, deliveryTime: 10, revisions: -1, features: ['Up to 5 Min Edit', 'Cinematic Look & Color', 'Custom Title Graphics', 'VFX Cleanups', 'VIP Delivery speed'] }
    }
  },
  // clara_translate (sel-10)
  {
    id: 'ser-12',
    title: 'I will provide flawless English-German-Spanish translation',
    categoryId: 'cat-writing',
    subcategoryId: 'Translation',
    sellerId: 'sel-10',
    rating: 4.88,
    reviewCount: 42,
    views: 410,
    impressions: 1500,
    ordersCount: 88,
    status: 'Active',
    images: [
      'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=800&auto=format&fit=crop&q=80'
    ],
    description: 'Strictly manual, professional localization. I translate software platforms, apps, user manuals, and legal agreements with native syntax flow.',
    tags: ['German Translation', 'Spanish Translator', 'Localization', 'Legal Translate', 'Proofreading'],
    faq: [],
    requirements: 'Submit your text in Word, PDF, or Markdown files.',
    packages: {
      basic: { price: 35, deliveryTime: 2, revisions: 2, features: ['Up to 500 Words', 'Proofreading included', 'TXT/PDF Delivery'] },
      standard: { price: 95, deliveryTime: 3, revisions: 4, features: ['Up to 1500 Words', 'HTML Formatting preserved', 'Glossary mapping'] },
      premium: { price: 220, deliveryTime: 5, revisions: -1, features: ['Up to 4000 Words', 'Double Review', 'Legal Context verification', 'SEO localized keyword check'] }
    }
  },
  // Additional services to reach 30 services
  // Let's populate the remaining 18 services with realistic variety across categories, mapping them to the 15 sellers
  // sel-11 (robert_3d)
  {
    id: 'ser-13',
    title: 'I will create photorealistic 3D product models and renders',
    categoryId: 'cat-graphics',
    subcategoryId: '3D modeling',
    sellerId: 'sel-11',
    rating: 4.91,
    reviewCount: 16,
    views: 450,
    impressions: 1800,
    ordersCount: 22,
    status: 'Active',
    images: ['https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80'],
    description: 'Expert photorealistic 3D rendering. I create custom Blender 3D files and realistic product mockups for cosmetics, devices, and furniture.',
    tags: ['3D Rendering', 'Blender', '3D Model', 'Photorealistic', 'Cinema 4D'],
    faq: [],
    requirements: 'Drawings or rough sketches, dimensions, and reference logos.',
    packages: {
      basic: { price: 90, deliveryTime: 4, revisions: 2, features: ['1 3D Model', '1 Photo Render', 'White BG', 'JPG file'] },
      standard: { price: 180, deliveryTime: 6, revisions: 4, features: ['1 Detailed 3D Model', '3 HD Renders', 'Stylized BG scene', 'OBJ/FBX delivery'] },
      premium: { price: 350, deliveryTime: 10, revisions: 6, features: ['Complete 3D Product suite', '6 Studio Renders', 'Blender Source Files', '360 Turntable Video'] }
    }
  },
  // sel-12 (marta_branding)
  {
    id: 'ser-14',
    title: 'I will craft complete custom visual brand identity systems',
    categoryId: 'cat-graphics',
    subcategoryId: 'Brand Logo',
    sellerId: 'sel-12',
    rating: 4.96,
    reviewCount: 34,
    views: 890,
    impressions: 3100,
    ordersCount: 41,
    status: 'Active',
    images: ['https://images.unsplash.com/photo-1626785774573-4b799315345d?w=800&auto=format&fit=crop&q=80'],
    description: 'A complete branding experience. I design unique vector logos, customized font rules, color palettes, patterns, and corporate guidelines.',
    tags: ['Brand Identity', 'Logo Design', 'Vector Illustration', 'Brand Guide', 'Typography'],
    faq: [],
    requirements: 'Company name, target demographic, brand personality keywords.',
    packages: {
      basic: { price: 120, deliveryTime: 3, revisions: 3, features: ['2 Logo Concepts', 'Color Palette', 'High-Res PNG/SVG'] },
      standard: { price: 280, deliveryTime: 5, revisions: 5, features: ['3 Logo Concepts', 'Visual Style Guide booklet', 'Business Card design', 'Vector Source Files'] },
      premium: { price: 580, deliveryTime: 8, revisions: -1, features: ['Full Brand Book (20 pages)', 'Corporate Collateral package', 'Custom Iconography set', 'Priority Revisions'] }
    }
  },
  // sel-13 (shafiq_wp)
  {
    id: 'ser-15',
    title: 'I will optimize WordPress speed and score 90 plus on PageSpeed',
    categoryId: 'cat-tech',
    subcategoryId: 'WordPress Speed',
    sellerId: 'sel-13',
    rating: 4.98,
    reviewCount: 52,
    views: 740,
    impressions: 3100,
    ordersCount: 68,
    status: 'Active',
    images: ['https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&auto=format&fit=crop&q=80'],
    description: 'Supercharge your WordPress. I optimize your database, compress images, set up cloud CDN caching, minimize CSS/JS, and fix slow server load times.',
    tags: ['WordPress Speed', 'PageSpeed Insights', 'Core Web Vitals', 'Database Optimization', 'Site Optimization'],
    faq: [],
    requirements: 'WordPress admin credentials and hosting server cPanel/SSH login details.',
    packages: {
      basic: { price: 65, deliveryTime: 2, revisions: 2, features: ['Image Compression', 'Caching setup', 'PageSpeed report before/after'] },
      standard: { price: 125, deliveryTime: 4, revisions: 4, features: ['Full CSS/JS minification', 'Database cleaning', '90+ Mobile/Desktop score', 'CDN configuration'] },
      premium: { price: 250, deliveryTime: 6, revisions: -1, features: ['VIP WordPress Audit', 'Server settings optimization', 'LCP/CLS core fixes', '6 months security monitoring'] }
    }
  },
  // sel-14 (elena_seo)
  {
    id: 'ser-16',
    title: 'I will conduct a deep technical SEO audit and competitive research',
    categoryId: 'cat-marketing',
    subcategoryId: 'SEO Audit',
    sellerId: 'sel-14',
    rating: 4.87,
    reviewCount: 19,
    views: 410,
    impressions: 1600,
    ordersCount: 26,
    status: 'Active',
    images: ['https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop&q=80'],
    description: 'Rigorous technical SEO. I find crawl errors, bloated index parameters, search console conflicts, and analyze your competitors keywords to map out a clear #1 ranking roadmap.',
    tags: ['SEO Audit', 'Technical SEO', 'Keyword Research', 'Google Console', 'Ahrefs'],
    faq: [],
    requirements: 'Your site URL, access to Search Console (optional but recommended), and 3 top competitors.',
    packages: {
      basic: { price: 75, deliveryTime: 3, revisions: 2, features: ['PDF Technical Audit report', 'Ahrefs domain report', '10 Action points checklist'] },
      standard: { price: 180, deliveryTime: 5, revisions: 4, features: ['Full Technical Audit + ScreamingFrog crawl', 'Competitor Keyword Map', 'On-page Schema fixes file'] },
      premium: { price: 390, deliveryTime: 8, revisions: 6, features: ['Full Enterprise Audit', 'Action implementation guide', '1 hr Consultation video call', '1 Month progress tracking'] }
    }
  },
  // sel-15 (lucid_flow)
  {
    id: 'ser-17',
    title: 'I will build a high-fidelity custom Webflow landing page with animations',
    categoryId: 'cat-tech',
    subcategoryId: 'Webflow Development',
    sellerId: 'sel-15',
    rating: 4.93,
    reviewCount: 12,
    views: 590,
    impressions: 2100,
    ordersCount: 17,
    status: 'Active',
    images: ['https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop&q=80'],
    description: 'Stunning interactive websites. I build pixel-perfect Webflow responsive pages with complex scroll triggers, micro-interactions, and custom CSS elements.',
    tags: ['Webflow', 'Webflow Developer', 'Interactions 2.0', 'Landing Page', 'Responsive'],
    faq: [],
    requirements: 'Figma source file design link, images/copy assets.',
    packages: {
      basic: { price: 150, deliveryTime: 3, revisions: 2, features: ['1 Page Screen Webflow', 'Standard templates edit', 'Forms connection'] },
      standard: { price: 350, deliveryTime: 5, revisions: 4, features: ['1 Custom Webflow Page', 'Smooth Scroll Animations', 'Figma pixel-perfect translation', 'SEO setup'] },
      premium: { price: 800, deliveryTime: 10, revisions: -1, features: ['Full Custom site (Up to 5 pages)', 'Complex Interactions 2.0', 'Custom GSAP scripts', 'Webflow CMS setup', '1 Hour Handover tutorial'] }
    }
  },
  // Create some simple gigs for remaining sellers to total 30
  // Let's loop sellers to add more gigs in diverse categories
  // sel-1 (alex_ux) - Gig 3
  {
    id: 'ser-18',
    title: 'I will design premium templates for Instagram and LinkedIn post templates',
    categoryId: 'cat-graphics',
    subcategoryId: 'Social Media Design',
    sellerId: 'sel-1',
    rating: 4.91,
    reviewCount: 15,
    views: 350,
    impressions: 1200,
    ordersCount: 18,
    status: 'Active',
    images: ['https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=800&auto=format&fit=crop&q=80'],
    description: 'Stay consistent. I design custom editable Figma/Canva templates for carousel cards, banners, and quotes that match your exact color identity.',
    tags: ['Instagram templates', 'Figma Canva', 'Social Design', 'LinkedIn Post', 'Banner design'],
    faq: [],
    requirements: 'Color brand palette, font requirements, logo files, and typical quotes or content headers.',
    packages: {
      basic: { price: 50, deliveryTime: 2, revisions: 2, features: ['5 Editable Templates', 'Canva/Figma access', 'Social icons'] },
      standard: { price: 100, deliveryTime: 3, revisions: 4, features: ['12 Editable Templates', 'Profile Avatar design', 'Matching brand patterns'] },
      premium: { price: 200, deliveryTime: 5, revisions: -1, features: ['30 Content templates', 'Branded highlights covers', 'Monthly feed grid plan', 'Commercial license'] }
    }
  },
  // sel-2 (dev_nikolai) - Gig 3
  {
    id: 'ser-19',
    title: 'I will optimize and configure PostgreSQL and MongoDB databases',
    categoryId: 'cat-tech',
    subcategoryId: 'Databases',
    sellerId: 'sel-2',
    rating: 4.88,
    reviewCount: 8,
    views: 310,
    impressions: 980,
    ordersCount: 10,
    status: 'Active',
    images: ['https://images.unsplash.com/photo-1544383835-bda2bc66a55d?w=800&auto=format&fit=crop&q=80'],
    description: 'Expert database tuning. I write custom SQL indexes, debug slow schema queries, resolve deadlocks, and configure replication backups for absolute data protection.',
    tags: ['SQL Database', 'PostgreSQL', 'MongoDB Schema', 'Query Optimization', 'Index tuning'],
    faq: [],
    requirements: 'Current database schema dump, connection configs, and metrics indicating slow-performing endpoints.',
    packages: {
      basic: { price: 120, deliveryTime: 2, revisions: 2, features: ['Index check', '3 query optimization fixes', 'Database config report'] },
      standard: { price: 280, deliveryTime: 4, revisions: 3, features: ['Schema refactoring', 'Index maps tuning', 'Mock connection testing', 'Slow queries list fix'] },
      premium: { price: 600, deliveryTime: 7, revisions: 5, features: ['Complete DB Re-architecture', 'Automatic backup script configs', 'Connection pooling setups', 'Post-launch 14 Days monitoring'] }
    }
  },
  // sel-3 (sarah_writes) - Gig 2
  {
    id: 'ser-20',
    title: 'I will write ultimate professional SEO-optimized articles and blogs',
    categoryId: 'cat-writing',
    subcategoryId: 'Blog Writing',
    sellerId: 'sel-3',
    rating: 4.95,
    reviewCount: 61,
    views: 720,
    impressions: 2900,
    ordersCount: 78,
    status: 'Active',
    images: ['https://images.unsplash.com/photo-1455390582262-044cdead277a?w=800&auto=format&fit=crop&q=80'],
    description: 'Articles that drive organic traffic. I write thoroughly researched, deeply engaging articles incorporating your keywords naturally to maximize Google readability.',
    tags: ['Blog post', 'SEO writing', 'Articles writer', 'Content strategy', 'Copywriting'],
    faq: [],
    requirements: 'Target topic, word count requested, keywords you want to target.',
    packages: {
      basic: { price: 45, deliveryTime: 2, revisions: 2, features: ['500 Words Article', '1 Focus Keyword', 'SEO tags (Meta + H1/H2)'] },
      standard: { price: 120, deliveryTime: 3, revisions: 4, features: ['1500 Words Deep Article', '3 Focus Keywords', 'Images suggestions', 'Competitor keyword reference'] },
      premium: { price: 250, deliveryTime: 5, revisions: -1, features: ['3000 Words Ultimate Guide', '6 Focus Keywords', 'Full content structuring', 'Internal link advice'] }
    }
  },
  // sel-4 (ai_pioneer) - Gig 2
  {
    id: 'ser-21',
    title: 'I will write custom Python scripts for data scraping and analysis',
    categoryId: 'cat-tech',
    subcategoryId: 'Python Scripts',
    sellerId: 'sel-4',
    rating: 4.96,
    reviewCount: 14,
    views: 540,
    impressions: 2100,
    ordersCount: 16,
    status: 'Active',
    images: ['https://images.unsplash.com/photo-1515879218367-8466d910aaa4?w=800&auto=format&fit=crop&q=80'],
    description: 'Elite web crawlers and data tools. I write secure Python scripts (BeautifulSoup, Selenium, Scrapy) to scrape websites and structure JSON/Excel data formats.',
    tags: ['Web scraping', 'Python scripts', 'Data extraction', 'Selenium', 'Automation Script'],
    faq: [],
    requirements: 'Target websites URLs and exact list of fields you need extracted.',
    packages: {
      basic: { price: 100, deliveryTime: 2, revisions: 2, features: ['1 Static Site scraper', 'CSV export', 'Clean Python Code'] },
      standard: { price: 250, deliveryTime: 4, revisions: 4, features: ['1 Dynamic JS Site scraper', 'Proxies rotation handling', 'Database saving script'] },
      premium: { price: 500, deliveryTime: 6, revisions: 5, features: ['Full Cloud Scraping Bot', 'Dashboard integration', 'Automated Daily schedule cron setup', 'Lifetime warranty fixes'] }
    }
  },
  // sel-5 (mona_marketer) - Gig 2
  {
    id: 'ser-22',
    title: 'I will design and optimize your LinkedIn profile and branding',
    categoryId: 'cat-marketing',
    subcategoryId: 'LinkedIn Growth',
    sellerId: 'sel-5',
    rating: 4.86,
    reviewCount: 22,
    views: 450,
    impressions: 1600,
    ordersCount: 28,
    status: 'Active',
    images: ['https://images.unsplash.com/photo-1557200134-90327ee9fafa?w=800&auto=format&fit=crop&q=80'],
    description: 'Command authority on LinkedIn. I write high-impact bio summaries, design your banner graphics, and map a 30-day corporate post posting layout.',
    tags: ['LinkedIn Profile', 'Executive branding', 'Social Profile', 'Resume review', 'LinkedIn marketing'],
    faq: [],
    requirements: 'Current resume link or list of achievements, target job industry, and high-res headshots.',
    packages: {
      basic: { price: 50, deliveryTime: 3, revisions: 2, features: ['Headline rewrites', 'About summary bio', 'Header Banner design'] },
      standard: { price: 120, deliveryTime: 5, revisions: 4, features: ['Full Profile rewrite', 'Education + Experiences optimizing', '10 custom post templates'] },
      premium: { price: 220, deliveryTime: 7, revisions: 5, features: ['Premium Executive suite rewrite', '30-day custom posting calendar', '1-on-1 resume optimization call'] }
    }
  },
  // sel-6 (lucas_lens) - Gig 2
  {
    id: 'ser-23',
    title: 'I will provide elite studio portrait and headshot photo retouching',
    categoryId: 'cat-photography',
    subcategoryId: 'Photo Retouching',
    sellerId: 'sel-6',
    rating: 4.94,
    reviewCount: 18,
    views: 310,
    impressions: 1100,
    ordersCount: 25,
    status: 'Active',
    images: ['https://images.unsplash.com/photo-1542038784456-1ea8e935640e?w=800&auto=format&fit=crop&q=80'],
    description: 'Flawless digital skin retouching. I fix lighting imperfections, remove blemishes, enhance teeth/eyes, and color correct corporate photos.',
    tags: ['Photo Editing', 'Photoshop retouching', 'Portrait correction', 'Face editing', 'Lightroom'],
    faq: [],
    requirements: 'Your raw portrait photography files in high-resolution.',
    packages: {
      basic: { price: 25, deliveryTime: 1, revisions: 2, features: ['1 Photo Retouched', 'Color adjustments', '24 hr Delivery'] },
      standard: { price: 60, deliveryTime: 2, revisions: 4, features: ['3 Photos Retouched', 'Blemish removal + skin blend', 'PSD source file'] },
      premium: { price: 150, deliveryTime: 4, revisions: 6, features: ['10 Corporate Photos', 'Commercial grade frequency separation', 'High-Res print exports'] }
    }
  },
  // sel-7 (charlie_voice) - Gig 2
  {
    id: 'ser-24',
    title: 'I will record professional warm audiobook narration and editing',
    categoryId: 'cat-music',
    subcategoryId: 'Audiobook',
    sellerId: 'sel-7',
    rating: 4.92,
    reviewCount: 45,
    views: 890,
    impressions: 2900,
    ordersCount: 52,
    status: 'Active',
    images: ['https://images.unsplash.com/photo-1590602847861-f357a9332bbc?w=800&auto=format&fit=crop&q=80'],
    description: 'Get your book ready for Audible (ACX compliant). I record and master audio with professional sound suppression, delivering clean split chapters.',
    tags: ['Audiobook narrator', 'Audible ACX', 'Voice Acting', 'Audio mastering', 'Male voice'],
    faq: [],
    requirements: 'Upload your complete book manuscript and specify the ideal voices/characters.',
    packages: {
      basic: { price: 150, deliveryTime: 5, revisions: 2, features: ['First 15 Mins Narration', 'Mastered WAV files', 'ACX standard checking'] },
      standard: { price: 450, deliveryTime: 10, revisions: 4, features: ['First 1 Hour Narration', 'Full Mastered chapters', 'Audible ready split files'] },
      premium: { price: 950, deliveryTime: 15, revisions: 6, features: ['First 3 Hours Narration', 'Pro Sound effects additions', 'Free promo intro clip', 'Priority corrections'] }
    }
  },
  // sel-8 (hannah_consulting) - Gig 2
  {
    id: 'ser-25',
    title: 'I will write a professional strategic business plan for startups',
    categoryId: 'cat-business',
    subcategoryId: 'Business Plan',
    sellerId: 'sel-8',
    rating: 4.93,
    reviewCount: 12,
    views: 310,
    impressions: 1100,
    ordersCount: 14,
    status: 'Active',
    images: ['https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=800&auto=format&fit=crop&q=80'],
    description: 'SBA compliant business proposals. I formulate complete SWOT maps, market penetration plans, and operational plans for bank loans or venture capital pitches.',
    tags: ['Business Plan', 'SWOT Analysis', 'SBA business proposal', 'Market Penetration', 'Consulting'],
    faq: [],
    requirements: 'Business details, industry focus, and targeted capital amount.',
    packages: {
      basic: { price: 150, deliveryTime: 4, revisions: 2, features: ['Business summary sheet', 'SWOT Analysis matrix', 'PDF Delivery'] },
      standard: { price: 350, deliveryTime: 7, revisions: 4, features: ['Full SBA Business Plan (15 pages)', 'Industry competitor review', 'Financial projection setup'] },
      premium: { price: 650, deliveryTime: 10, revisions: -1, features: ['Comprehensive 30-Page Business Plan', 'Full 5-year financials integration', 'Custom PPT Pitch Deck', 'Priority phone coaching'] }
    }
  },
  // sel-9 (yuki_video) - Gig 2
  {
    id: 'ser-26',
    title: 'I will design stunning social media video ads for Shopify dropshipping',
    categoryId: 'cat-video',
    subcategoryId: 'Video Ads',
    sellerId: 'sel-9',
    rating: 4.95,
    reviewCount: 33,
    views: 840,
    impressions: 2100,
    ordersCount: 38,
    status: 'Active',
    images: ['https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&auto=format&fit=crop&q=80'],
    description: 'Highly engaging Shopify video ads. I compile trending clips, write scroll-stopping hook titles, apply premium background music, and optimize for TikTok, IG reels, and YouTube Shorts format.',
    tags: ['Shopify Ads', 'TikTok Video ad', 'Video Editing', 'Dropshipping ad', 'Shorts Editor'],
    faq: [],
    requirements: 'Product AliExpress/Shopify link and competitors videos references (optional).',
    packages: {
      basic: { price: 50, deliveryTime: 2, revisions: 2, features: ['1 Tik Tok Video ad (15 sec)', 'Trending bg music', 'Subtitle captions'] },
      standard: { price: 100, deliveryTime: 3, revisions: 4, features: ['3 Tik Tok Ads alternative hooks', 'Translations included', 'Ad copy text proposal'] },
      premium: { price: 180, deliveryTime: 4, revisions: -1, features: ['5 High-Converting Viral Ads', 'Includes voiceover integration', 'Custom branding frames', 'Refund guarantee if rejected'] }
    }
  },
  // sel-10 (clara_translate) - Gig 2
  {
    id: 'ser-27',
    title: 'I will translate and localize your mobile iOS and Android app files',
    categoryId: 'cat-writing',
    subcategoryId: 'App Localization',
    sellerId: 'sel-10',
    rating: 4.9,
    reviewCount: 22,
    views: 310,
    impressions: 1100,
    ordersCount: 34,
    status: 'Active',
    images: ['https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=800&auto=format&fit=crop&q=80'],
    description: 'Perfect JSON/Strings localization. I edit translation files directly, ensuring string lengths fit mobile UI boundaries perfectly without awkward word breaks.',
    tags: ['App localization', 'JSON Translate', 'Strings file', 'German translation', 'Spanish translation'],
    faq: [],
    requirements: 'Your .strings or .json strings files, and screenshots of key panels for context.',
    packages: {
      basic: { price: 50, deliveryTime: 2, revisions: 2, features: ['Up to 500 keys translate', 'Strings file check', 'iOS/Android formatting preservation'] },
      standard: { price: 120, deliveryTime: 4, revisions: 4, features: ['Up to 1500 keys translate', 'Contextual check with app screens', 'Direct GitHub PR submission'] },
      premium: { price: 250, deliveryTime: 6, revisions: -1, features: ['Complete app localization (Up to 4000 strings)', 'German + Spanish bundles', 'Post-test translation corrections'] }
    }
  },
  // sel-11 (robert_3d) - Gig 2
  {
    id: 'ser-28',
    title: 'I will create custom low poly 3D models for games',
    categoryId: 'cat-graphics',
    subcategoryId: '3D Game Assets',
    sellerId: 'sel-11',
    rating: 4.88,
    reviewCount: 14,
    views: 310,
    impressions: 1100,
    ordersCount: 19,
    status: 'Active',
    images: ['https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=800&auto=format&fit=crop&q=80'],
    description: 'Optimized game assets. I model low-poly characters, props, and environments with fully baked textures ready for Unity and Unreal Engine import.',
    tags: ['Low poly', 'Game assets', '3D game models', 'Unity Blender', 'Unreal Asset'],
    faq: [],
    requirements: 'Visual style references, polygon count budgets, and required file formats.',
    packages: {
      basic: { price: 40, deliveryTime: 3, revisions: 2, features: ['1 Simple low-poly prop', 'Textured FBX', 'Unity package export'] },
      standard: { price: 120, deliveryTime: 5, revisions: 4, features: ['5 Low-poly props pack', 'Baked hand-painted textures', 'Optimized UV maps'] },
      premium: { price: 290, deliveryTime: 8, revisions: 6, features: ['1 Game Character + basic bones rig', 'Texturing source files', 'Blend project folder', 'Priority fixes'] }
    }
  },
  // sel-12 (marta_branding) - Gig 2
  {
    id: 'ser-29',
    title: 'I will illustrate custom vector children books and editorials',
    categoryId: 'cat-graphics',
    subcategoryId: 'Illustration',
    sellerId: 'sel-12',
    rating: 4.97,
    reviewCount: 28,
    views: 520,
    impressions: 1800,
    ordersCount: 31,
    status: 'Active',
    images: ['https://images.unsplash.com/photo-1513364776144-60967b0f800f?w=800&auto=format&fit=crop&q=80'],
    description: 'Bespoke high-end character illustrations. I create colorful vector drawing books, customized editorial covers, and digital canvas illustrations.',
    tags: ['Vector drawing', 'Book illustration', 'Character design', 'Adobe Illustrator', 'Custom drawing'],
    faq: [],
    requirements: 'Detailed story scripts and desired character descriptions (age, outfits, expressions).',
    packages: {
      basic: { price: 60, deliveryTime: 3, revisions: 3, features: ['1 Vector Character', 'Color illustration', 'High-res transparent PNG'] },
      standard: { price: 180, deliveryTime: 5, revisions: 5, features: ['3 Book Scene Illustrations', 'Background details included', 'Commercial Rights license'] },
      premium: { price: 480, deliveryTime: 10, revisions: -1, features: ['Complete Book illustrations (10 pages)', 'Front/Back covers included', 'Vector AI files folder', '100% unique design guarantee'] }
    }
  },
  // sel-13 (shafiq_wp) - Gig 2
  {
    id: 'ser-30',
    title: 'I will migrate your site to a secure premium Cloud VPS VPS Server',
    categoryId: 'cat-tech',
    subcategoryId: 'Cloud DevOps',
    sellerId: 'sel-13',
    rating: 4.94,
    reviewCount: 31,
    views: 450,
    impressions: 1600,
    ordersCount: 42,
    status: 'Active',
    images: ['https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=800&auto=format&fit=crop&q=80'],
    description: 'Get off slow shared hosting. I configure raw DigitalOcean, Linode, or AWS VPS environments with secure Nginx, SSL certificates, Firewalls, and migrate your database with zero downtime.',
    tags: ['Cloud migration', 'Linode VPS', 'Nginx setup', 'SSL Certificates', 'DevOps support'],
    faq: [],
    requirements: 'Credentials of old host, credentials of your new Cloud server provider.',
    packages: {
      basic: { price: 85, deliveryTime: 2, revisions: 2, features: ['Site backup export', 'Simple cPanel migration', 'Domain configuration'] },
      standard: { price: 180, deliveryTime: 4, revisions: 4, features: ['Nginx Server setup in VPS', 'Database schema migration', 'Free Let\'s Encrypt SSL', 'Cloudflare CDN firewall settings'] },
      premium: { price: 350, deliveryTime: 6, revisions: 5, features: ['VIP Docker clustered VPS', 'Automatic weekly backup schedule config', 'Core security hardened rules', '1 Month SLA Server response check'] }
    }
  }
];

// 5. Reviews (30 items)
export const mockReviews: Review[] = Array.from({ length: 30 }, (_, i) => {
  const ratings = [5, 5, 4, 5, 5, 4, 5, 5, 5, 5, 5, 4, 5, 5, 5, 5, 4, 5, 5, 5, 5, 4, 5, 5, 5, 5, 5, 4, 5, 5];
  const comments = [
    'Absolutely pristine quality! The seller designed an elite Figma project that exceeded our unit economics expectations.',
    'Amazing developer Nikolai. Clean full stack React code. Optimized speed, highly recommended!',
    'Great copywriter. Copied exactly our SaaS brand persona perfectly. Just a couple of minor edits but very fast response.',
    'Ethan Vance is a literal Ph.D. genius. Advanced LLM prompt system is extremely fast and scalable.',
    'Outstanding ROAS! Ad campaigns are incredibly targeted. Understood our budget limits.',
    'The physical photos returned from Paris are spectacular. Elite catalog quality and gorgeous studio shadows.',
    'Incredible deep American baritone. Charlie Henderson has an actual Neumann booth that sounds crystal clear!',
    'Superb MBA financials model. Structured series-A decks perfectly. Professional unit economics cohort charts.',
    'Stunning movie-grade color grading! Pacing is emotional and cinematic. DaVinci Resolve master.',
    'Flawless localized manual translate. No AI Google Translate slop! Localized terms precisely.',
    'Highly professional Blender game props modeler. Clean topologies, baked textures look incredible.',
    'The branding guide Marta Gomez designed has immense soul. Gorgeous vector logo sets.',
    'WordPress load time went from 6s down to 0.8s! Solid 98 score. Shafiq is a WordPress wizard!',
    'Technically bulletproof SEO Audit. Found toxic indexing parameters we had no idea existed.',
    'Sleek Framer page with beautiful microscroll animations. Clean code setup.',
    'Figma templates are editable, beautiful, and consistent. Saves our marketing team days.',
    'Highly detailed database queries index plan. Resolved deadlocks instantly. Solid Node code.',
    'Engaging SEO articles written perfectly. Readability score is excellent on SEMrush.',
    'Python Selenium scraping script runs automatically in cloud crons perfectly. Saves us hours.',
    'LinkedIn profile rewrite doubled my recruiters connection requests in 1 week. Perfect title rewrite.',
    'Photographic skin retouch was natural, high-resolution and professional. Photoshop wizard.',
    'The ACX audiobook files mastered perfectly. ACX compliance checked green. Warm narration.',
    'High-impact business plan compiled beautifully. Bank loan approved. Highly responsive consultant!',
    'Shopify Dropshipping video ad went viral on TikTok immediately. Viral hook pacing is superb.',
    'JSON app localization file strings matched sizes perfectly without layout breaking.',
    ' Unity prop low poly files loaded immediately with clean pivot points and great textures.',
    'Beautiful vector children book character. Marta Gomez has stunning illustration skills.',
    'VPS Nginx server migration is fully secured with automated backups. Zero downtime.',
    'Elite, production-quality SaaS landing page. Exceptional typography and mathematically sound grids!',
    'React Express dashboard API endpoints were highly organized. Nikola is a full stack authority.'
  ];
  return {
    id: `rev-${i + 1}`,
    serviceId: `ser-${(i % 15) + 1}`, // spread over services
    sellerId: `sel-${(i % 15) + 1}`, // spread over sellers
    buyerId: `buy-${(i % 20) + 1}`, // spread over buyers
    rating: ratings[i],
    comment: comments[i],
    date: `Sept ${Math.max(1, 20 - i)}, 2026`
  };
});

// 6. Orders (15 items)
export const mockOrders: Order[] = Array.from({ length: 15 }, (_, i) => {
  const service = mockServices[i % mockServices.length];
  const statuses: Order['status'][] = [
    'Completed', 'In Progress', 'Delivered', 'Pending', 'In Progress',
    'Completed', 'Delivered', 'Completed', 'Completed', 'Cancelled',
    'In Progress', 'Revision Requested', 'Completed', 'Completed', 'Completed'
  ];
  const packages: ('basic' | 'standard' | 'premium')[] = ['standard', 'premium', 'basic', 'standard', 'basic', 'premium', 'standard', 'basic', 'standard', 'premium', 'standard', 'basic', 'standard', 'basic', 'premium'];
  const pkgType = packages[i];
  const price = service.packages[pkgType].price;
  
  return {
    id: `WH-2026-10${482 + i}`,
    serviceId: service.id,
    buyerId: `buy-${(i % 10) + 1}`,
    sellerId: service.sellerId,
    packageSelected: pkgType,
    price: price,
    status: statuses[i],
    requirementsSubmitted: 'Company name is WorkHub. We are building a luxury freelancing system. We need emerald-teal branding with robust layouts.',
    deliveryDate: `Sept ${25 + (i % 5)}, 2026`,
    createdAt: `Sept ${10 - (i % 4)}, 2026`,
    messages: [
      { id: `omsg-${i}-1`, sender: 'buyer', text: 'Hi, I have purchased this package and submitted the required information.', timestamp: '10:15 AM' },
      { id: `omsg-${i}-2`, sender: 'seller', text: 'Thank you for the order! I have received your requirements and will begin working immediately. I will keep you updated.', timestamp: '11:30 AM' }
    ],
    deliverySubmission: statuses[i] === 'Delivered' || statuses[i] === 'Completed' ? {
      text: 'Hi there, I have completed the project exactly according to your guidelines. Let me know if you need any adjustments or revisions!',
      files: [{ name: 'workhub_final_deliverables.zip', url: '#' }],
      submittedAt: `Sept ${20 + (i % 3)}, 2026`
    } : undefined
  };
});

// 7. Conversations / Chats (10 items)
export const mockConversations: Conversation[] = Array.from({ length: 10 }, (_, i) => {
  const seller = mockSellers[i];
  const buyer = mockBuyers[i + 5];
  return {
    id: `convo-${i + 1}`,
    buyerId: buyer.id,
    sellerId: seller.id,
    messages: [
      { id: `cmsg-${i}-1`, senderId: buyer.id, text: `Hello ${seller.name}, I saw your service "${mockServices[i].title}". Can you customize this for a startup?`, timestamp: '09:12 AM', read: true },
      { id: `cmsg-${i}-2`, senderId: seller.id, text: 'Hi there! Yes, absolutely. I specialize in custom SaaS requirements. What specific customizations do you have in mind?', timestamp: '09:45 AM', read: true },
      { id: `cmsg-${i}-3`, senderId: buyer.id, text: 'We need about 3 main screens and dynamic interactive prototypes. Can we do a custom budget?', timestamp: '10:02 AM', read: false }
    ]
  };
});

// 8. Buyer Requests / Posted Projects (6 items)
export const mockBuyerRequests: BuyerRequest[] = [
  {
    id: 'req-1',
    title: 'Need premium brand strategy and custom Figma logo bundle',
    description: 'We are launching an executive fintech platform. We need an absolute premium, high-end visual brand guide, typography rules, logo suite vector source files, and 10 custom post templates for LinkedIn.',
    categoryId: 'cat-graphics',
    budget: 350,
    deadline: '7 Days',
    skillsRequired: ['Figma', 'Brand Identity', 'Logo Design', 'Vector Illustration', 'Typography'],
    buyerId: 'buy-1',
    createdAt: 'Sept 18, 2026',
    proposals: [
      { sellerId: 'sel-1', price: 350, deliveryTime: 5, coverMessage: 'I would love to craft this premium fintech brand strategy. I have designed logos for major startups and RISD design graduates.', status: 'pending', createdAt: 'Sept 19, 2026' },
      { sellerId: 'sel-12', price: 300, deliveryTime: 6, coverMessage: 'Branding is my main specialty. I create custom vectors with incredible soul. Check out my cosmetics work.', status: 'pending', createdAt: 'Sept 19, 2026' }
    ]
  },
  {
    id: 'req-2',
    title: 'Develop secure Node.js and Postgres API proxy server',
    description: 'We need a backend developer to write clean, secure API routes to proxy calls from our client React dashboard. Must include JWT authorization, error handle logging, and helmet security rules.',
    categoryId: 'cat-tech',
    budget: 500,
    deadline: '5 Days',
    skillsRequired: ['Node.js', 'Express', 'PostgreSQL', 'API Development', 'JWT'],
    buyerId: 'buy-2',
    createdAt: 'Sept 19, 2026',
    proposals: [
      { sellerId: 'sel-2', price: 480, deliveryTime: 4, coverMessage: 'I write industrial-grade Express APIs with clean structures and detailed error handling schemas.', status: 'pending', createdAt: 'Sept 20, 2026' }
    ]
  },
  {
    id: 'req-3',
    title: 'Write psychology-driven SaaS email onboarding sequence',
    description: 'Need an elite conversion copywriter to draft a 5-part autoresponder sequence to convert trial users into paid annual subscribers. Product is a developer logging service.',
    categoryId: 'cat-writing',
    budget: 200,
    deadline: '4 Days',
    skillsRequired: ['Copywriting', 'Email Marketing', 'Landing Page Copy', 'SaaS Copywriting'],
    buyerId: 'buy-3',
    createdAt: 'Sept 20, 2026',
    proposals: []
  },
  {
    id: 'req-4',
    title: 'Build high-converting Shopify Facebook Ad creative',
    description: 'We are scaling a physical posture corrector product. We need a 30-sec cinematic video ad with catchy subtitle captions, professional script copywriting, and viral hooks optimization.',
    categoryId: 'cat-video',
    budget: 80,
    deadline: '3 Days',
    skillsRequired: ['Shopify Ads', 'Video Editing', 'TikTok Video ad', 'Video Ads'],
    buyerId: 'buy-4',
    createdAt: 'Sept 21, 2026',
    proposals: [
      { sellerId: 'sel-9', price: 80, deliveryTime: 2, coverMessage: 'Shopify ads are my main bread and butter. I edit highly viral TikTok/IG hooks. 2-day quick delivery.', status: 'pending', createdAt: 'Sept 21, 2026' }
    ]
  },
  {
    id: 'req-5',
    title: 'Setup Nginx reverse proxy with SSL certifications in DigitalOcean VPS',
    description: 'Urgent task to migrate static React bundle files into raw DO Ubuntu VPS, configure Nginx with SSL blocks, redirect HTTP to HTTPS, and clean old cron scripts.',
    categoryId: 'cat-tech',
    budget: 100,
    deadline: '24 Hours',
    skillsRequired: ['Cloud DevOps', 'Nginx setup', 'SSL Certificates', 'Linode VPS'],
    buyerId: 'buy-5',
    createdAt: 'Sept 21, 2026',
    proposals: [
      { sellerId: 'sel-13', price: 100, deliveryTime: 1, coverMessage: 'I have done over 100 VPS Nginx deployments. I will complete this in under 12 hours with zero downtime.', status: 'pending', createdAt: 'Sept 22, 2026' }
    ]
  },
  {
    id: 'req-6',
    title: 'Generative AI Prompt Mapping and LLM Agents strategy',
    description: 'Need a strategist to audit our support team workflows and compile a complete prompt system structure for Gemini API context integration to reduce response latency.',
    categoryId: 'cat-ai',
    budget: 1200,
    deadline: '14 Days',
    skillsRequired: ['Generative AI', 'Prompt Engineering', 'LangChain', 'Python'],
    buyerId: 'buy-6',
    createdAt: 'Sept 21, 2026',
    proposals: []
  }
];
