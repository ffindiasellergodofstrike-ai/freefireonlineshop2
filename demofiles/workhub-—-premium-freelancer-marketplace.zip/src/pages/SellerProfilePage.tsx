import React, { useMemo } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useApp, Seller, Service } from '../context/AppContext';
import { RatingStars } from '../components/RatingStars';
import { ServiceCard } from '../components/ServiceCard';
import { MapPin, Clock, Calendar, Mail, CheckCircle2, ShieldAlert, Award, GraduationCap } from 'lucide-react';

export const SellerProfilePage: React.FC = () => {
  const { username } = useParams<{ username: string }>();
  const navigate = useNavigate();
  const {
    sellers,
    services,
    reviews,
    startOrGetConversation,
    currentUser,
    showToast
  } = useApp();

  // Find target seller profile
  const seller = useMemo(() => {
    return sellers.find(s => s.username === username);
  }, [sellers, username]);

  // Find associated gigs
  const sellerServices = useMemo(() => {
    if (!seller) return [];
    return services.filter(s => s.sellerId === seller.id && s.status === 'Active');
  }, [services, seller]);

  // Find associated reviews (all reviews of gigs that belong to this seller)
  const sellerReviews = useMemo(() => {
    if (!seller) return [];
    const gigIds = services.filter(s => s.sellerId === seller.id).map(s => s.id);
    return reviews.filter(r => gigIds.includes(r.serviceId));
  }, [reviews, services, seller]);

  if (!seller) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-4">
        <h2 className="text-lg font-bold text-neutral-800 dark:text-neutral-200">Freelancer profile not found</h2>
        <p className="text-xs text-neutral-400 mt-2">The username requested could not be resolved in our database.</p>
        <Link to="/explore" className="mt-4 px-4 py-2 bg-brand-500 text-white rounded-lg text-xs font-bold">
          Back to marketplace
        </Link>
      </div>
    );
  }

  const handleContactSeller = () => {
    const convoId = startOrGetConversation(seller.id, currentUser.id);
    navigate('/dashboard/messages');
    showToast(`Chat inbox opened with ${seller.name}`, 'info');
  };

  return (
    <div id="seller-profile-page" className="bg-[#FBFBFA] dark:bg-neutral-950 text-neutral-800 dark:text-neutral-100 pb-24 transition-colors">
      
      {/* PROFILE COVER BANNER */}
      <div className="h-44 sm:h-56 bg-gradient-to-r from-emerald-800 to-teal-700 dark:from-neutral-900 dark:to-neutral-850 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:16px_16px]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-20 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          
          {/* LEFT 1/4 COLUMN - PROFILE BRIEF CARD */}
          <div className="col-span-1 space-y-6">
            <div className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800/80 p-6 rounded-2xl shadow-sm text-center flex flex-col items-center">
              
              {/* Avatar Frame with Online Dot */}
              <div className="relative mb-4">
                <img
                  src={seller.avatar}
                  alt={seller.name}
                  className="w-24 h-24 rounded-full object-cover border-4 border-white dark:border-neutral-900 shadow-md bg-neutral-100 dark:bg-neutral-800"
                />
                <span className={`absolute bottom-1 right-1 w-4.5 h-4.5 rounded-full border-4 border-white dark:border-neutral-900 ${seller.isOnline ? 'bg-emerald-500' : 'bg-neutral-300'}`} title={seller.isOnline ? 'Online now' : 'Offline'} />
              </div>

              <h2 className="text-base font-extrabold text-neutral-900 dark:text-white leading-tight">
                {seller.name}
              </h2>
              <p className="text-xs text-neutral-400 dark:text-neutral-500 font-semibold mb-2">
                @{seller.username}
              </p>

              {/* Badges/Tiers */}
              <span className="px-2.5 py-0.5 rounded-full bg-brand-50 dark:bg-brand-950 text-brand-700 dark:text-brand-300 text-[9px] font-bold uppercase tracking-wider mb-4">
                {seller.level}
              </span>

              {/* Ratings */}
              <div className="flex items-center gap-1.5 justify-center mb-5 w-full">
                <RatingStars rating={seller.rating} size={13} />
                <span className="text-xs font-extrabold text-neutral-800 dark:text-neutral-200">{seller.rating.toFixed(2)}</span>
                <span className="text-xs text-neutral-400">({seller.reviewCount})</span>
              </div>

              {/* Actions */}
              <div className="w-full space-y-2 pt-2 border-t border-neutral-50 dark:border-neutral-800">
                <button
                  onClick={handleContactSeller}
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-brand-500 hover:bg-brand-600 text-white text-xs font-bold rounded-xl transition-all cursor-pointer shadow-sm"
                >
                  <Mail size={13} />
                  <span>Contact Freelancer</span>
                </button>
              </div>

              {/* Metadata Details */}
              <div className="w-full space-y-3.5 pt-6 border-t border-neutral-50 dark:border-neutral-800 text-left text-xs text-neutral-500 dark:text-neutral-400 mt-6 font-semibold">
                <div className="flex justify-between items-center">
                  <span className="flex items-center gap-1.5 text-neutral-400">
                    <MapPin size={13} />
                    <span>Location</span>
                  </span>
                  <span className="text-neutral-800 dark:text-neutral-200">{seller.location}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="flex items-center gap-1.5 text-neutral-400">
                    <Clock size={13} />
                    <span>Response Time</span>
                  </span>
                  <span className="text-neutral-800 dark:text-neutral-200">{seller.responseTime}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="flex items-center gap-1.5 text-neutral-400">
                    <Calendar size={13} />
                    <span>Joined</span>
                  </span>
                  <span className="text-neutral-800 dark:text-neutral-200">{seller.joinedDate}</span>
                </div>
              </div>

            </div>

            {/* LANGUAGES, SKILLS */}
            <div className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800/80 p-6 rounded-2xl shadow-sm space-y-6">
              
              {/* Languages */}
              <div>
                <h3 className="text-xs font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider mb-3">Languages</h3>
                <div className="flex flex-wrap gap-1.5">
                  {seller.languages.map(lang => (
                    <span key={lang} className="text-[10px] font-bold text-neutral-600 dark:text-neutral-400 px-2.5 py-1 rounded bg-neutral-50 dark:bg-neutral-850/60 border border-neutral-100 dark:border-neutral-800">
                      {lang}
                    </span>
                  ))}
                </div>
              </div>

              {/* Skills tags */}
              <div>
                <h3 className="text-xs font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider mb-3">Skills</h3>
                <div className="flex flex-wrap gap-1.5">
                  {seller.skills.map(skill => (
                    <span key={skill} className="text-[10px] font-bold text-brand-700 dark:text-brand-400 px-2.5 py-1 rounded-md bg-brand-50/50 dark:bg-brand-950/20 border border-brand-100/40 dark:border-brand-900/20">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              {/* Certifications and Educations */}
              <div className="space-y-4 pt-2 border-t border-neutral-50 dark:border-neutral-800">
                <div className="flex items-start gap-2.5">
                  <Award className="text-neutral-400 mt-0.5 flex-shrink-0" size={15} />
                  <div>
                    <h4 className="text-[11px] font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">Certifications</h4>
                    <p className="text-[10px] text-neutral-400 font-medium mt-0.5">WorkHub Verified Elite Seller Badge</p>
                  </div>
                </div>
                <div className="flex items-start gap-2.5">
                  <GraduationCap className="text-neutral-400 mt-0.5 flex-shrink-0" size={16} />
                  <div>
                    <h4 className="text-[11px] font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">Education</h4>
                    <p className="text-[10px] text-neutral-400 font-medium mt-0.5">B.Sc. Computer Engineering / Design Arts</p>
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* RIGHT 3/4 COLUMN - BIO, ACTIVE SERVICES, REVIEWS */}
          <div className="col-span-1 lg:col-span-3 space-y-8">
            
            {/* Header description biography */}
            <div className="bg-white dark:bg-neutral-900 p-6 rounded-2xl border border-neutral-100 dark:border-neutral-800 shadow-sm space-y-4">
              <h3 className="text-sm font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-widest pb-3 border-b border-neutral-50 dark:border-neutral-800">
                Professional Overview
              </h3>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 leading-relaxed font-semibold whitespace-pre-line">
                {seller.bio}
              </p>
            </div>

            {/* Gigs lists */}
            <div className="space-y-4">
              <div className="flex items-center justify-between pl-1">
                <h3 className="text-base font-extrabold text-neutral-900 dark:text-white">
                  My Published Services ({sellerServices.length})
                </h3>
              </div>

              {sellerServices.length === 0 ? (
                <div className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800/80 rounded-xl p-8 text-center text-xs text-neutral-400">
                  Nikolai has paused his active service listings temporarily. Please contact him directly.
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {sellerServices.map(service => (
                    <ServiceCard key={service.id} service={service} />
                  ))}
                </div>
              )}
            </div>

            {/* Reviews list */}
            <div className="bg-white dark:bg-neutral-900 p-6 rounded-2xl border border-neutral-100 dark:border-neutral-800 shadow-sm space-y-6">
              <div className="flex items-center justify-between pb-3 border-b border-neutral-50 dark:border-neutral-800">
                <h3 className="text-sm font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-widest">
                  Recent Feedback reviews ({sellerReviews.length})
                </h3>
                <div className="flex items-center gap-1">
                  <span className="text-xs font-bold text-neutral-400">Average Rating:</span>
                  <RatingStars rating={seller.rating} size={11} />
                  <span className="text-xs font-extrabold text-neutral-800 dark:text-neutral-200">{seller.rating.toFixed(2)}</span>
                </div>
              </div>

              {sellerReviews.length === 0 ? (
                <div className="text-center py-8 text-xs text-neutral-400">
                  No verified client feedback available yet for Nikolai.
                </div>
              ) : (
                <div className="divide-y divide-neutral-50 dark:divide-neutral-800 space-y-5">
                  {sellerReviews.map((rev) => (
                    <div key={rev.id} className="pt-5 first:pt-0 space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-full bg-brand-50 flex items-center justify-center font-bold text-xs text-brand-600">
                            B
                          </div>
                          <div>
                            <span className="text-xs font-bold text-neutral-800 dark:text-neutral-200">Verified Client</span>
                            <p className="text-[9px] text-neutral-400">Project: Logo / Web Application development</p>
                          </div>
                        </div>
                        <span className="text-[10px] text-neutral-400">{rev.date}</span>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <RatingStars rating={rev.rating} size={11} />
                        <span className="text-xs font-bold text-neutral-700 dark:text-neutral-300">{rev.rating}.0</span>
                      </div>

                      <p className="text-xs text-neutral-500 dark:text-neutral-400 leading-relaxed italic">
                        &quot;{rev.comment}&quot;
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>

        </div>
      </div>

    </div>
  );
};
