import React, { useState, useEffect, useMemo } from 'react';
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { useApp, Service } from '../context/AppContext';
import { ServiceCard } from '../components/ServiceCard';
import { Search, SlidersHorizontal, ChevronDown, Check, Star, X, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const Explore: React.FC = () => {
  const { services, categories, sellers } = useApp();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  
  // URL Queries
  const query = searchParams.get('q') || '';
  const categorySlug = searchParams.get('category') || '';

  // Local Filter States
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [minPrice, setMinPrice] = useState<number>(0);
  const [maxPrice, setMaxPrice] = useState<number>(2000);
  const [deliveryTime, setDeliveryTime] = useState<number | null>(null); // max days
  const [selectedLevels, setSelectedLevels] = useState<string[]>([]);
  const [minRating, setMinRating] = useState<number>(0);
  const [onlineOnly, setOnlineOnly] = useState<boolean>(false);
  const [selectedLanguage, setSelectedLanguage] = useState<string>('All');
  
  // Sorting State
  const [sortBy, setSortBy] = useState<string>('recommended'); // recommended, price_asc, price_desc, rating, orders

  // Mobile Filter Overlay Toggle
  const [showMobileFilters, setShowMobileFilters] = useState<boolean>(false);

  // Sync state with URL Category if modified
  useEffect(() => {
    if (categorySlug) {
      const matchedCat = categories.find(c => c.slug === categorySlug);
      if (matchedCat) {
        setSelectedCategories([matchedCat.id]);
      }
    } else {
      setSelectedCategories([]);
    }
  }, [categorySlug, categories]);

  // Available Filter Options
  const levelOptions = ['Top Rated', 'Level 2', 'Level 1', 'New Seller'];
  const languageOptions = ['All', 'English', 'Spanish', 'German', 'Japanese', 'French'];

  // Reset all filters
  const resetFilters = () => {
    setSelectedCategories([]);
    setMinPrice(0);
    setMaxPrice(2000);
    setDeliveryTime(null);
    setSelectedLevels([]);
    setMinRating(0);
    setOnlineOnly(false);
    setSelectedLanguage('All');
    setSearchParams({});
    setShowMobileFilters(false);
  };

  // 1. FILTERING LOGIC
  const filteredServices = useMemo(() => {
    return services.filter((service) => {
      // Status check (must be active for public browsing)
      if (service.status !== 'Active') return false;

      // Search Query text search
      if (query.trim()) {
        const term = query.toLowerCase();
        const seller = sellers.find(s => s.id === service.sellerId);
        const matchTitle = service.title.toLowerCase().includes(term);
        const matchDesc = service.description.toLowerCase().includes(term);
        const matchTags = service.tags.some(t => t.toLowerCase().includes(term));
        const matchCat = service.subcategoryId.toLowerCase().includes(term);
        const matchSeller = seller ? seller.name.toLowerCase().includes(term) || seller.username.toLowerCase().includes(term) : false;
        
        if (!matchTitle && !matchDesc && !matchTags && !matchCat && !matchSeller) {
          return false;
        }
      }

      // Category filter
      if (selectedCategories.length > 0 && !selectedCategories.includes(service.categoryId)) {
        return false;
      }

      // Budget filter (Basic package price)
      const basicPrice = service.packages.basic.price;
      if (basicPrice < minPrice || basicPrice > maxPrice) {
        return false;
      }

      // Delivery Time filter (Basic package delivery)
      const basicDelivery = service.packages.basic.deliveryTime;
      if (deliveryTime !== null && basicDelivery > deliveryTime) {
        return false;
      }

      // Seller Level & Language & Online checks
      const seller = sellers.find(s => s.id === service.sellerId);
      if (seller) {
        if (selectedLevels.length > 0 && !selectedLevels.includes(seller.level)) {
          return false;
        }
        if (onlineOnly && !seller.isOnline) {
          return false;
        }
        if (selectedLanguage !== 'All' && !seller.languages.includes(selectedLanguage)) {
          return false;
        }
      } else {
        return false; // must have a seller
      }

      // Rating filter
      if (service.rating < minRating) {
        return false;
      }

      return true;
    });
  }, [services, sellers, query, selectedCategories, minPrice, maxPrice, deliveryTime, selectedLevels, minRating, onlineOnly, selectedLanguage]);

  // 2. SORTING LOGIC
  const sortedServices = useMemo(() => {
    const arr = [...filteredServices];
    switch (sortBy) {
      case 'price_asc':
        return arr.sort((a, b) => a.packages.basic.price - b.packages.basic.price);
      case 'price_desc':
        return arr.sort((a, b) => b.packages.basic.price - a.packages.basic.price);
      case 'rating':
        return arr.sort((a, b) => b.rating - a.rating);
      case 'orders':
        return arr.sort((a, b) => b.ordersCount - a.ordersCount);
      case 'recommended':
      default:
        // sort by a combo of rating and orders
        return arr.sort((a, b) => (b.rating * b.ordersCount) - (a.rating * a.ordersCount));
    }
  }, [filteredServices, sortBy]);

  // Header Title Text
  const headerTitleText = useMemo(() => {
    if (query) return `Search Results for "${query}"`;
    if (categorySlug) {
      const matchedCat = categories.find(c => c.slug === categorySlug);
      return matchedCat ? matchedCat.name : 'Explore Services';
    }
    return 'All Services';
  }, [query, categorySlug, categories]);

  // Quick category select handler
  const handleCategorySelectToggle = (catId: string) => {
    setSelectedCategories(prev => {
      const index = prev.indexOf(catId);
      if (index > -1) {
        const updated = prev.filter(id => id !== catId);
        // remove URL category slug if we cleared everything or selected something else
        if (updated.length === 0) {
          setSearchParams(query ? { q: query } : {});
        }
        return updated;
      } else {
        const updated = [...prev, catId];
        // update URL category to match the first selected
        const catObj = categories.find(c => c.id === catId);
        if (catObj) {
          setSearchParams(query ? { q: query, category: catObj.slug } : { category: catObj.slug });
        }
        return updated;
      }
    });
  };

  const handleLevelSelectToggle = (level: string) => {
    setSelectedLevels(prev =>
      prev.includes(level) ? prev.filter(l => l !== level) : [...prev, level]
    );
  };

  const FilterSidebarContent = () => (
    <div className="space-y-6 text-xs select-none">
      {/* Category Accordion */}
      <div className="border-b border-neutral-100 dark:border-neutral-800 pb-5">
        <h4 className="font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider mb-3">Categories</h4>
        <div className="space-y-2">
          {categories.map((cat) => {
            const isChecked = selectedCategories.includes(cat.id);
            return (
              <label key={cat.id} className="flex items-center gap-2 cursor-pointer text-neutral-600 dark:text-neutral-400 font-medium hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                <input
                  type="checkbox"
                  checked={isChecked}
                  onChange={() => handleCategorySelectToggle(cat.id)}
                  className="rounded border-neutral-300 text-brand-500 focus:ring-brand-500 h-3.5 w-3.5"
                />
                <span>{cat.name}</span>
              </label>
            );
          })}
        </div>
      </div>

      {/* Budget Slider */}
      <div className="border-b border-neutral-100 dark:border-neutral-800 pb-5">
        <h4 className="font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider mb-3">Budget Range</h4>
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <div className="flex-1">
              <span className="text-[10px] text-neutral-400 font-bold block mb-1">MIN PRICE</span>
              <div className="flex items-center gap-1 px-2 py-1.5 rounded-md bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700/60 font-semibold text-neutral-700 dark:text-neutral-300">
                <span>$</span>
                <input
                  type="number"
                  value={minPrice}
                  onChange={(e) => setMinPrice(Math.max(0, parseInt(e.target.value) || 0))}
                  className="w-full bg-transparent border-none p-0 focus:ring-0 text-xs text-current font-bold"
                />
              </div>
            </div>
            <div className="flex-1">
              <span className="text-[10px] text-neutral-400 font-bold block mb-1">MAX PRICE</span>
              <div className="flex items-center gap-1 px-2 py-1.5 rounded-md bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700/60 font-semibold text-neutral-700 dark:text-neutral-300">
                <span>$</span>
                <input
                  type="number"
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(Math.max(0, parseInt(e.target.value) || 2000))}
                  className="w-full bg-transparent border-none p-0 focus:ring-0 text-xs text-current font-bold"
                />
              </div>
            </div>
          </div>
          <input
            type="range"
            min="0"
            max="2000"
            step="25"
            value={maxPrice}
            onChange={(e) => setMaxPrice(parseInt(e.target.value))}
            className="w-full accent-brand-500 bg-neutral-200 dark:bg-neutral-700 rounded-lg h-1.5 cursor-pointer"
          />
        </div>
      </div>

      {/* Delivery Time Option Buttons */}
      <div className="border-b border-neutral-100 dark:border-neutral-800 pb-5">
        <h4 className="font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider mb-3">Delivery Time</h4>
        <div className="grid grid-cols-2 gap-1.5">
          {[
            { label: 'Anytime', val: null },
            { label: 'Up to 24hr', val: 1 },
            { label: 'Up to 3 days', val: 3 },
            { label: 'Up to 7 days', val: 7 }
          ].map((item) => {
            const isActive = deliveryTime === item.val;
            return (
              <button
                key={item.label}
                onClick={() => setDeliveryTime(item.val)}
                className={`py-2 px-2.5 rounded-lg border text-center font-bold transition-all text-[11px] cursor-pointer ${isActive ? 'bg-brand-500 border-brand-500 text-white shadow-xs' : 'bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 text-neutral-600 dark:text-neutral-400 hover:border-neutral-300 dark:hover:border-neutral-700'}`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Seller Level Options */}
      <div className="border-b border-neutral-100 dark:border-neutral-800 pb-5">
        <h4 className="font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider mb-3">Seller Tiers</h4>
        <div className="space-y-2">
          {levelOptions.map((level) => {
            const isChecked = selectedLevels.includes(level);
            return (
              <label key={level} className="flex items-center gap-2 cursor-pointer text-neutral-600 dark:text-neutral-400 font-medium hover:text-brand-600 transition-colors">
                <input
                  type="checkbox"
                  checked={isChecked}
                  onChange={() => handleLevelSelectToggle(level)}
                  className="rounded border-neutral-300 text-brand-500 focus:ring-brand-500 h-3.5 w-3.5"
                />
                <span>{level}</span>
              </label>
            );
          })}
        </div>
      </div>

      {/* Minimum Rating */}
      <div className="border-b border-neutral-100 dark:border-neutral-800 pb-5">
        <h4 className="font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider mb-3">Minimum Rating</h4>
        <div className="space-y-1">
          {[4.9, 4.5, 4.0, 0].map((star) => {
            const isActive = minRating === star;
            return (
              <button
                key={star}
                onClick={() => setMinRating(star)}
                className={`w-full flex items-center gap-2 p-1.5 rounded-md font-semibold transition-colors text-left cursor-pointer ${isActive ? 'bg-brand-50 dark:bg-brand-950/30 text-brand-700 dark:text-brand-300' : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-50 dark:hover:bg-neutral-850'}`}
              >
                <div className="flex items-center gap-0.5">
                  <Star size={12} className={`fill-amber-400 text-amber-400 ${star === 0 ? 'text-neutral-300 fill-none' : ''}`} />
                  <span className="text-xs">{star === 0 ? 'Any rating' : `${star.toFixed(1)} & up`}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Languages & Online toggles */}
      <div className="space-y-4 pb-5">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">Online Now</h4>
            <p className="text-[10px] text-neutral-400 font-medium">Show only online sellers</p>
          </div>
          <button
            onClick={() => setOnlineOnly(!onlineOnly)}
            className={`w-9 h-5 rounded-full p-0.5 transition-colors cursor-pointer focus:outline-hidden ${onlineOnly ? 'bg-emerald-500' : 'bg-neutral-200 dark:bg-neutral-800'}`}
          >
            <div className={`w-4 h-4 rounded-full bg-white transition-transform duration-200 ${onlineOnly ? 'translate-x-4' : ''}`} />
          </button>
        </div>

        <div>
          <h4 className="font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider mb-2">Seller Language</h4>
          <select
            value={selectedLanguage}
            onChange={(e) => setSelectedLanguage(e.target.value)}
            className="w-full px-2 py-1.5 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-lg text-xs font-semibold focus:ring-brand-500 text-neutral-700 dark:text-neutral-300 focus:border-brand-500"
          >
            {languageOptions.map((lang) => (
              <option key={lang} value={lang}>{lang}</option>
            ))}
          </select>
        </div>
      </div>

      <button
        onClick={resetFilters}
        className="w-full py-2.5 rounded-lg font-bold bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-850 dark:hover:bg-neutral-800 text-neutral-600 dark:text-neutral-300 transition-colors text-xs cursor-pointer"
      >
        Clear All Filters
      </button>
    </div>
  );

  return (
    <div id="explore-page" className="min-h-screen bg-[#FBFBFA] dark:bg-neutral-950 text-neutral-800 dark:text-neutral-100 pb-20 transition-colors">
      
      {/* Header Info Area */}
      <div className="bg-white dark:bg-neutral-900 border-b border-neutral-100 dark:border-neutral-800/80 py-8 mb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <span className="text-[10px] font-extrabold tracking-widest uppercase text-neutral-400">Marketplace Search</span>
              <h1 className="text-xl sm:text-2xl font-extrabold text-neutral-900 dark:text-white mt-1">
                {headerTitleText}
              </h1>
              <p className="text-xs text-neutral-400 mt-1">
                Found {sortedServices.length} dynamic services matching your target criteria
              </p>
            </div>

            {/* Sort & Mobile buttons bar */}
            <div className="flex items-center gap-3 w-full sm:w-auto">
              <button
                onClick={() => setShowMobileFilters(true)}
                className="flex md:hidden items-center justify-center gap-1.5 flex-1 sm:flex-initial py-2 px-3 text-xs font-bold rounded-lg bg-neutral-50 border border-neutral-200 text-neutral-700 dark:bg-neutral-800 dark:border-neutral-700 dark:text-neutral-300 cursor-pointer"
              >
                <SlidersHorizontal size={13} />
                <span>Filters</span>
              </button>

              <div className="flex items-center gap-2 flex-1 sm:flex-initial justify-end">
                <span className="text-xs font-semibold text-neutral-400 hidden lg:inline">Sort by:</span>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="py-2 pl-3 pr-8 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 text-xs font-bold rounded-lg text-neutral-700 dark:text-neutral-300 focus:ring-brand-500 focus:border-brand-500 cursor-pointer"
                >
                  <option value="recommended">Recommended</option>
                  <option value="price_asc">Price: Low to High</option>
                  <option value="price_desc">Price: High to Low</option>
                  <option value="rating">Best Rated</option>
                  <option value="orders">Most Orders</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid Block */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* 1. Desktop Filters Sidebar */}
          <aside className="hidden md:block col-span-1 bg-white dark:bg-neutral-900 p-5 rounded-xl border border-neutral-100 dark:border-neutral-800/80 h-fit sticky top-24 shadow-2xs">
            <FilterSidebarContent />
          </aside>

          {/* 2. Gigs Grid Result Area */}
          <main className="col-span-1 md:col-span-3">
            {sortedServices.length === 0 ? (
              <div className="flex flex-col items-center justify-center p-12 py-20 text-center bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 rounded-xl max-w-xl mx-auto shadow-2xs">
                <div className="flex items-center justify-center w-14 h-14 rounded-full bg-neutral-50 dark:bg-neutral-850 text-neutral-400 dark:text-neutral-600 mb-4">
                  <Search size={22} />
                </div>
                <h3 className="text-base font-bold text-neutral-800 dark:text-neutral-200 mb-2">No listings found</h3>
                <p className="text-xs text-neutral-400 dark:text-neutral-500 leading-relaxed max-w-sm mb-6">
                  We couldn&apos;t find any professional services matching your exact filtering guidelines. Try broadening your budget limit, clearing subcategories, or typing another keyword.
                </p>
                <button
                  onClick={resetFilters}
                  className="px-5 py-2.5 rounded-lg font-bold bg-brand-500 hover:bg-brand-600 text-white text-xs transition-colors shadow-xs"
                >
                  Reset All Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {sortedServices.map((service) => (
                  <ServiceCard key={service.id} service={service} />
                ))}
              </div>
            )}
          </main>

        </div>
      </div>

      {/* 3. Mobile Filters Slide-over / Bottom sheet Overlay */}
      <AnimatePresence>
        {showMobileFilters && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowMobileFilters(false)}
              className="fixed inset-0 bg-black z-100"
            />
            
            {/* Sheet drawer */}
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25 }}
              className="fixed inset-x-0 bottom-0 max-h-[85vh] bg-white dark:bg-neutral-900 rounded-t-2xl p-5 overflow-y-auto z-100 shadow-2xl border-t border-neutral-100 dark:border-neutral-800"
            >
              <div className="flex items-center justify-between pb-4 border-b border-neutral-100 dark:border-neutral-800 mb-5 sticky top-0 bg-white dark:bg-neutral-900 z-10">
                <span className="font-bold text-sm text-neutral-800 dark:text-white">Filter Search Listings</span>
                <button
                  onClick={() => setShowMobileFilters(false)}
                  className="p-1 text-neutral-400 hover:text-neutral-600"
                >
                  <X size={18} />
                </button>
              </div>
              <FilterSidebarContent />
            </motion.div>
          </>
        )}
      </AnimatePresence>

    </div>
  );
};
