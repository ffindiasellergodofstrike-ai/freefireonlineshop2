import React, { useState, useMemo } from 'react';
import { useApp, Order, Service, Conversation } from '../context/AppContext';
import { Link, useNavigate } from 'react-router-dom';
import { RatingStars } from '../components/RatingStars';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';
import {
  DollarSign,
  TrendingUp,
  Inbox,
  Clock,
  Layers,
  CheckCircle2,
  ToggleLeft,
  ToggleRight,
  ExternalLink,
  MessageSquare,
  Send,
  Sparkles,
  Zap,
  ArrowRight
} from 'lucide-react';

export const SellerDashboard: React.FC = () => {
  const navigate = useNavigate();
  const {
    currentUser,
    orders,
    services,
    sellers,
    conversations,
    buyerRequests,
    toggleServiceStatus,
    sendChatMessage,
    showToast
  } = useApp();

  const [activeTab, setActiveTab] = useState<'orders' | 'gigs' | 'chats' | 'requests'>('orders');

  // Active chat thread index state
  const [selectedConvoId, setSelectedConvoId] = useState<string | null>(null);
  const [chatInput, setChatInput] = useState('');

  // 1. DATA CALCULATIONS
  // Orders belonging to this seller
  const sellerOrders = useMemo(() => orders.filter(o => o.sellerId === currentUser.id), [orders, currentUser]);
  
  // Services belonging to this seller
  const sellerGigs = useMemo(() => services.filter(s => s.sellerId === currentUser.id), [services, currentUser]);

  // Aggregate metrics
  const totalEarnings = useMemo(() => {
    return sellerOrders.filter(o => o.status === 'Completed').reduce((sum, o) => sum + o.price, 0);
  }, [sellerOrders]);

  const activeWorkOrders = useMemo(() => {
    return sellerOrders.filter(o => o.status !== 'Completed');
  }, [sellerOrders]);

  const completedOrdersCount = useMemo(() => {
    return sellerOrders.filter(o => o.status === 'Completed').length;
  }, [sellerOrders]);

  // Active Chat thread
  const activeConversation = useMemo(() => {
    if (!selectedConvoId) return null;
    return conversations.find(c => c.id === selectedConvoId);
  }, [conversations, selectedConvoId]);

  // Chat target participant name
  const activeChatTargetName = useMemo(() => {
    if (!activeConversation) return '';
    const otherId = activeConversation.buyerId === currentUser.id ? activeConversation.sellerId : activeConversation.buyerId;
    if (otherId === 'usr-102') return 'Sophia James (Buyer)';
    return 'Client Account';
  }, [activeConversation, currentUser]);

  // 2. RECHARTS DATA PREPARATION
  const earningsChartData = [
    { month: 'Apr', sales: 1200 },
    { month: 'May', sales: 1900 },
    { month: 'Jun', sales: 3400 },
    { month: 'Jul', sales: 2200 },
    { month: 'Aug', sales: 4800 },
    { month: 'Sep', sales: totalEarnings || 3500 }
  ];

  const viewsChartData = [
    { day: 'Mon', views: 120 },
    { day: 'Tue', views: 240 },
    { day: 'Wed', views: 180 },
    { day: 'Thu', views: 320 },
    { day: 'Fri', views: 290 },
    { day: 'Sat', views: 410 },
    { day: 'Sun', views: 380 }
  ];

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || !selectedConvoId) return;
    sendChatMessage(selectedConvoId, currentUser.id, chatInput.trim());
    setChatInput('');
  };

  const handleApplyToRequest = (reqTitle: string, reqBudget: number) => {
    showToast(`Proposal sent successfully for: ${reqTitle}!`, 'success');
  };

  return (
    <div id="seller-dashboard" className="bg-[#FBFBFA] dark:bg-neutral-950 text-neutral-800 dark:text-neutral-100 pb-24 pt-10 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Profile Brief Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-10">
          <div>
            <span className="text-[10px] font-extrabold tracking-widest uppercase text-neutral-400">Freelancer Workspace Dashboard</span>
            <h1 className="text-xl sm:text-2xl font-extrabold text-neutral-900 dark:text-white mt-1">
              Store Manager: Nikolai
            </h1>
            <p className="text-xs text-neutral-400 mt-1">Review payouts metrics, toggle service listings, and coordinate deliveries.</p>
          </div>
          
          <div className="flex items-center gap-2">
            <Link
              to="/create-service"
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg bg-brand-500 hover:bg-brand-600 text-white font-bold text-xs shadow-xs cursor-pointer transition-colors"
            >
              <Zap size={12} className="fill-white" />
              <span>Publish a Service Gig</span>
            </Link>
          </div>
        </div>

        {/* 1. SELLER ANALYTICS CARDS GRID */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-6 mb-10">
          
          <div className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 p-5 rounded-2xl shadow-xs space-y-1.5">
            <span className="text-[10px] text-neutral-400 font-bold block uppercase tracking-wider">Withdrawable Earnings</span>
            <h3 className="text-2xl font-extrabold text-neutral-900 dark:text-white">${totalEarnings}</h3>
            <p className="text-[10px] text-emerald-500 font-semibold italic">Approved payouts cleared</p>
          </div>

          <div className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 p-5 rounded-2xl shadow-xs space-y-1.5">
            <span className="text-[10px] text-neutral-400 font-bold block uppercase tracking-wider">Active Queue Orders</span>
            <h3 className="text-2xl font-extrabold text-brand-600 dark:text-brand-400">{activeWorkOrders.length} Gigs</h3>
            <p className="text-[10px] text-neutral-500 font-semibold italic">Must complete & deliver</p>
          </div>

          <div className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 p-5 rounded-2xl shadow-xs space-y-1.5">
            <span className="text-[10px] text-neutral-400 font-bold block uppercase tracking-wider">Completed Deliveries</span>
            <h3 className="text-2xl font-extrabold text-neutral-900 dark:text-white">{completedOrdersCount} Hires</h3>
            <p className="text-[10px] text-neutral-500 font-semibold italic">100% on-time completion</p>
          </div>

          <div className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 p-5 rounded-2xl shadow-xs space-y-1.5">
            <span className="text-[10px] text-neutral-400 font-bold block uppercase tracking-wider">Conversion rate</span>
            <h3 className="text-2xl font-extrabold text-neutral-900 dark:text-white">7.2%</h3>
            <p className="text-[10px] text-emerald-500 font-semibold italic">+1.5% from previous week</p>
          </div>

        </div>

        {/* 2. DYNAMIC RECHARTS VISUALIZATION DATA PANEL */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
          {/* Earnings Chart */}
          <div className="bg-white dark:bg-neutral-900 p-5 border border-neutral-100 dark:border-neutral-800 rounded-2xl shadow-xs space-y-4">
            <h4 className="text-xs font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider border-b border-neutral-50 dark:border-neutral-800 pb-3">
              Monthly Sales Earnings ($)
            </h4>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={earningsChartData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E5E5" />
                  <XAxis dataKey="month" stroke="#A3A3A3" fontSize={10} tickLine={false} />
                  <YAxis stroke="#A3A3A3" fontSize={10} tickLine={false} />
                  <Tooltip cursor={{ fill: 'rgba(0, 0, 0, 0.02)' }} />
                  <Bar dataKey="sales" fill="#10B981" radius={[4, 4, 0, 0]} barSize={25} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Views Chart */}
          <div className="bg-white dark:bg-neutral-900 p-5 border border-neutral-100 dark:border-neutral-800 rounded-2xl shadow-xs space-y-4">
            <h4 className="text-xs font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider border-b border-neutral-50 dark:border-neutral-800 pb-3">
              Gig Traffic Impressions Views
            </h4>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={viewsChartData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E5E5" />
                  <XAxis dataKey="day" stroke="#A3A3A3" fontSize={10} tickLine={false} />
                  <YAxis stroke="#A3A3A3" fontSize={10} tickLine={false} />
                  <Tooltip />
                  <Line type="monotone" dataKey="views" stroke="#10B981" strokeWidth={2.5} dot={{ fill: '#10B981', r: 4 }} activeDot={{ r: 6 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* 3. TAB SELECTIONS */}
        <div className="flex border-b border-neutral-200 dark:border-neutral-850 mb-8 overflow-x-auto text-xs font-bold uppercase select-none">
          {[
            { id: 'orders', label: `Deliverable Orders (${activeWorkOrders.length})`, icon: Clock },
            { id: 'gigs', label: `My Gigs storefront (${sellerGigs.length})`, icon: Layers },
            { id: 'chats', label: `Inquiries Chats Inbox (${conversations.length})`, icon: MessageSquare },
            { id: 'requests', label: `Apply to Requests (${buyerRequests.length})`, icon: Inbox }
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-3.5 px-4 border-b-2 flex items-center gap-2 whitespace-nowrap cursor-pointer transition-all ${isActive ? 'border-brand-500 text-brand-600 dark:text-brand-400 bg-brand-50/20 dark:bg-brand-950/10' : 'border-transparent text-neutral-400 hover:text-neutral-600 hover:bg-neutral-50/20 dark:hover:bg-neutral-800/30'}`}
              >
                <Icon size={13} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* 4. SELLER VIEWPORTS */}
        <div className="space-y-6">
          
          {/* TAB A: MY DELIVERABLE ORDERS */}
          {activeTab === 'orders' && (
            <div className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 rounded-2xl overflow-hidden shadow-xs">
              {sellerOrders.length === 0 ? (
                <div className="p-12 text-center text-xs text-neutral-400">
                  No active orders in queue! Share your Gigs to start receiving commissions.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-neutral-50/50 dark:bg-neutral-950 border-b border-neutral-100 dark:border-neutral-800 text-neutral-400 font-bold uppercase tracking-wider text-[10px]">
                        <th className="p-4 pl-6">Order ID</th>
                        <th className="p-4">Listing Detail</th>
                        <th className="p-4">Investment</th>
                        <th className="p-4">Status</th>
                        <th className="p-4 pr-6 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-50 dark:divide-neutral-800 font-medium">
                      {sellerOrders.map((ord) => {
                        const srv = services.find(s => s.id === ord.serviceId);
                        return (
                          <tr key={ord.id} className="hover:bg-neutral-50/20 dark:hover:bg-neutral-850/20">
                            <td className="p-4 pl-6 font-bold text-neutral-500">WH-2026-{ord.id}</td>
                            <td className="p-4">
                              <span className="font-semibold text-neutral-800 dark:text-neutral-250 block truncate max-w-sm">
                                {srv?.title}
                              </span>
                              <span className="text-[9px] uppercase font-bold text-neutral-400 block mt-0.5">{ord.packageSelected} Package</span>
                            </td>
                            <td className="p-4 font-bold text-neutral-900 dark:text-neutral-100">${ord.price}</td>
                            <td className="p-4">
                              <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase ${ord.status === 'Completed' ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400' : ord.status === 'Delivered' ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400' : 'bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-400'}`}>
                                {ord.status}
                              </span>
                            </td>
                            <td className="p-4 pr-6 text-right">
                              <Link
                                to={`/dashboard/order/${ord.id}`}
                                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-[10px] font-extrabold uppercase bg-brand-500 hover:bg-brand-600 text-white shadow-3xs cursor-pointer transition-colors"
                              >
                                <span>Manage & Deliver</span>
                                <ExternalLink size={10} />
                              </Link>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* TAB B: MY GIGS LISTING */}
          {activeTab === 'gigs' && (
            <div className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 rounded-2xl overflow-hidden shadow-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-neutral-50/50 dark:bg-neutral-950 border-b border-neutral-100 dark:border-neutral-800 text-neutral-400 font-bold uppercase tracking-wider text-[10px]">
                      <th className="p-4 pl-6">Service listing detail</th>
                      <th className="p-4">Tier Packages</th>
                      <th className="p-4">Review Stats</th>
                      <th className="p-4">Status</th>
                      <th className="p-4 pr-6 text-right">Settings</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-50 dark:divide-neutral-800 font-medium">
                    {sellerGigs.map((gig) => (
                      <tr key={gig.id} className="hover:bg-neutral-50/20">
                        <td className="p-4 pl-6">
                          <div className="flex items-center gap-3">
                            <img src={gig.images[0]} alt="" className="w-12 aspect-video object-cover rounded-lg bg-neutral-100" />
                            <span className="font-semibold text-neutral-800 dark:text-neutral-100 block max-w-xs truncate">{gig.title}</span>
                          </div>
                        </td>
                        <td className="p-4">
                          <span className="font-bold text-neutral-700 dark:text-neutral-300 block">Basic: ${gig.packages.basic.price}</span>
                          <span className="text-[9px] text-neutral-400 font-bold block">Premium: ${gig.packages.premium.price}</span>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-1">
                            <RatingStars rating={gig.rating} size={11} />
                            <span className="text-neutral-600 font-bold">({gig.reviewCount})</span>
                          </div>
                        </td>
                        <td className="p-4">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${gig.status === 'Active' ? 'bg-emerald-100 text-emerald-800' : 'bg-neutral-100 text-neutral-600'}`}>
                            {gig.status}
                          </span>
                        </td>
                        <td className="p-4 pr-6 text-right space-x-1.5">
                          <button
                            onClick={() => toggleServiceStatus(gig.id)}
                            className="p-1.5 rounded-lg text-neutral-500 hover:text-brand-500 transition-colors cursor-pointer"
                            title={gig.status === 'Active' ? 'Pause Listing' : 'Activate Listing'}
                          >
                            {gig.status === 'Active' ? <ToggleRight size={22} className="text-emerald-500" /> : <ToggleLeft size={22} className="text-neutral-400" />}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB C: INQUIRIES CHATS INBOX */}
          {activeTab === 'chats' && (
            <div className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 rounded-2xl overflow-hidden shadow-xs grid grid-cols-1 md:grid-cols-3 h-[450px]">
              
              {/* Left Inbox Thread list */}
              <div className="col-span-1 border-r border-neutral-100 dark:border-neutral-800 overflow-y-auto divide-y divide-neutral-50 dark:divide-neutral-800 select-none">
                <div className="p-4 bg-neutral-50/50 dark:bg-neutral-950/40 border-b border-neutral-100 dark:border-neutral-800 text-[10px] font-extrabold uppercase tracking-widest text-neutral-400">
                  Open Threads
                </div>
                {conversations.map((convo) => {
                  const isSelected = selectedConvoId === convo.id;
                  const otherId = convo.buyerId === currentUser.id ? convo.sellerId : convo.buyerId;
                  const targetName = otherId === 'usr-102' ? 'Sophia James (Buyer)' : 'Client Account';
                  const lastMsg = convo.messages[convo.messages.length - 1];
                  return (
                    <button
                      key={convo.id}
                      onClick={() => setSelectedConvoId(convo.id)}
                      className={`w-full p-4 text-left block transition-colors cursor-pointer hover:bg-neutral-50/40 ${isSelected ? 'bg-brand-50/20 dark:bg-brand-950/15 border-l-2 border-brand-500' : ''}`}
                    >
                      <h4 className="text-xs font-bold text-neutral-800 dark:text-neutral-100 truncate">{targetName}</h4>
                      <p className="text-[10px] text-neutral-400 truncate mt-0.5 font-medium">{lastMsg?.text || 'No chat logs yet.'}</p>
                    </button>
                  );
                })}
              </div>

              {/* Right Active chat viewport */}
              <div className="col-span-1 md:col-span-2 flex flex-col h-full bg-neutral-50/30 dark:bg-neutral-900/10">
                {activeConversation ? (
                  <>
                    {/* Header */}
                    <div className="p-4 bg-white dark:bg-neutral-900 border-b border-neutral-100 dark:border-neutral-800 flex justify-between items-center">
                      <span className="text-xs font-bold text-neutral-800 dark:text-neutral-200">{activeChatTargetName}</span>
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                    </div>

                    {/* Viewport */}
                    <div className="flex-1 p-4 overflow-y-auto space-y-3">
                      {activeConversation.messages.map((m) => {
                        const isMine = m.senderId === currentUser.id;
                        return (
                          <div key={m.id} className={`flex flex-col max-w-[85%] text-xs ${isMine ? 'ml-auto items-end' : 'mr-auto items-start'}`}>
                            <div className={`p-3 rounded-2xl font-semibold leading-relaxed ${isMine ? 'bg-brand-500 text-white rounded-tr-none' : 'bg-white dark:bg-neutral-800 border border-neutral-200/50 dark:border-neutral-700/50 text-neutral-800 dark:text-neutral-200 rounded-tl-none'}`}>
                              {m.text}
                            </div>
                            <span className="text-[8px] text-neutral-400 mt-0.5">{m.timestamp}</span>
                          </div>
                        );
                      })}
                    </div>

                    {/* Send box */}
                    <form onSubmit={handleSendMessage} className="p-3 bg-white dark:bg-neutral-900 border-t border-neutral-100 dark:border-neutral-800 flex items-center gap-2">
                      <input
                        type="text"
                        placeholder="Type standard inquiry updates..."
                        value={chatInput}
                        onChange={(e) => setChatInput(e.target.value)}
                        className="flex-1 text-xs px-3.5 py-2.5 bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 dark:border-neutral-800 rounded-lg focus:outline-hidden"
                      />
                      <button type="submit" className="p-2.5 bg-brand-500 hover:bg-brand-600 text-white rounded-lg cursor-pointer">
                        <Send size={13} />
                      </button>
                    </form>
                  </>
                ) : (
                  <div className="flex flex-col items-center justify-center flex-1 text-center p-8 text-xs text-neutral-400 space-y-2">
                    <MessageSquare size={22} className="text-neutral-300" />
                    <span>Select an inquiry thread from the left index panel to open real-time chat coordination.</span>
                  </div>
                )}
              </div>

            </div>
          )}

          {/* TAB D: APPLY TO BUYER REQUESTS */}
          {activeTab === 'requests' && (
            <div className="space-y-4">
              {buyerRequests.map((req) => (
                <div key={req.id} className="bg-white dark:bg-neutral-900 p-5 border border-neutral-100 dark:border-neutral-800 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="space-y-1.5 flex-1 max-w-2xl text-left">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded bg-amber-100 text-amber-800 font-bold text-[9px] uppercase">Client brief</span>
                      <h4 className="text-xs font-bold text-neutral-800 dark:text-neutral-150">{req.title}</h4>
                    </div>
                    <p className="text-[11px] text-neutral-400 leading-relaxed font-semibold">{req.description}</p>
                    <div className="flex items-center gap-3 pt-1 text-[10px] text-neutral-400 font-bold">
                      <span>Proposed budget: <strong className="text-neutral-700 dark:text-neutral-300">${req.budget}</strong></span>
                      <span>•</span>
                      <span>Target duration: {req.deadline}</span>
                    </div>
                  </div>

                  <button
                    onClick={() => handleApplyToRequest(req.title, req.budget)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-brand-50 hover:bg-brand-100 text-brand-600 dark:bg-brand-950/40 dark:text-brand-400 text-xs font-extrabold rounded-lg border border-brand-100/40 dark:border-brand-900/40 cursor-pointer transition-colors"
                  >
                    <span>Submit Bid Proposal</span>
                    <ArrowRight size={11} />
                  </button>
                </div>
              ))}
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
