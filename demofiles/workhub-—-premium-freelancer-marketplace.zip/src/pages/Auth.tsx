import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Shield, Sparkles, UserCheck, Key, ArrowRight, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

export const Auth: React.FC = () => {
  const navigate = useNavigate();
  const { switchUserTemplate, showToast, currentUser } = useApp();
  
  const [email, setEmail] = useState('nikolai.architect@workhub.com');
  const [password, setPassword] = useState('••••••••••••');

  // Simulated login trigger
  const handleSimulatedLogin = (userType: 'both' | 'buyer' | 'admin') => {
    if (userType === 'admin') {
      switchUserTemplate({
        id: 'admin-1',
        name: 'Admin Operator',
        username: 'admin_root',
        email: 'admin@workhub.com',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        country: 'Switzerland',
        accountType: 'Both'
      });
      showToast('Signed in as Admin Operator Demo!', 'success');
      navigate('/admin');
    } else if (userType === 'buyer') {
      switchUserTemplate({
        id: 'buy-2',
        name: 'Sophia James',
        username: 'sophia_tech',
        email: 'sophia@innovate.co',
        avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
        country: 'United Kingdom',
        accountType: 'Buyer'
      });
      showToast('Welcome back, Signed in as Sophia (Buyer CTO)!', 'success');
      navigate('/');
    } else {
      switchUserTemplate({
        id: 'sel-1',
        name: 'Nikolai Tesla',
        username: 'nikolai_designs',
        email: 'nikolai.architect@workhub.com',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
        country: 'Serbia',
        accountType: 'Both',
        sellerProfileId: 'sel-1'
      });
      showToast('Welcome back, Signed in as Nikolai (Dual Freelancer)!', 'success');
      navigate('/');
    }
  };

  return (
    <div id="auth-page" className="min-h-screen flex flex-col items-center justify-center bg-[#FBFBFA] dark:bg-neutral-950 px-4 py-16 transition-colors">
      
      <div className="max-w-md w-full space-y-8">
        {/* Top Logo and Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-11 h-11 rounded-xl bg-brand-500 text-white font-bold text-xl shadow-md shadow-brand-500/20">
            W
          </div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-neutral-900 dark:text-white pt-2">
            Sign In to Your WorkHub Profile
          </h2>
          <p className="text-xs text-neutral-400">
            Experience various dashboards and order workflows instantly.
          </p>
        </div>

        {/* Dynamic Credentials Selector Box */}
        <div className="bg-white dark:bg-neutral-900 p-6 rounded-2xl border border-neutral-100 dark:border-neutral-800 shadow-md space-y-6">
          
          <div className="space-y-3">
            <h3 className="text-[11px] font-extrabold uppercase tracking-widest text-neutral-400">
              Simulate Active Profiles (Quick login Shortcuts)
            </h3>

            <div className="grid grid-cols-1 gap-2.5">
              
              {/* Option A: Both (Nikolai) */}
              <button
                onClick={() => handleSimulatedLogin('both')}
                className="w-full flex items-center justify-between p-3.5 rounded-xl border border-neutral-150 dark:border-neutral-800 hover:border-brand-500 dark:hover:border-brand-500 bg-neutral-50 dark:bg-neutral-950 text-left transition-all cursor-pointer group"
              >
                <div className="flex items-center gap-3">
                  <img
                    src="https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=100&auto=format&fit=crop&q=80"
                    alt="Nikolai"
                    className="w-8 h-8 rounded-full object-cover border border-neutral-200"
                  />
                  <div>
                    <span className="text-xs font-bold text-neutral-800 dark:text-neutral-200 group-hover:text-brand-600 transition-colors">Nikolai (Dual Seller/Buyer)</span>
                    <p className="text-[9px] text-neutral-400">Preloaded Gigs, active buyer orders, chats.</p>
                  </div>
                </div>
                <UserCheck size={14} className="text-neutral-400 group-hover:text-brand-500" />
              </button>

              {/* Option B: Buyer (Sophia) */}
              <button
                onClick={() => handleSimulatedLogin('buyer')}
                className="w-full flex items-center justify-between p-3.5 rounded-xl border border-neutral-150 dark:border-neutral-800 hover:border-brand-500 dark:hover:border-brand-500 bg-neutral-50 dark:bg-neutral-950 text-left transition-all cursor-pointer group"
              >
                <div className="flex items-center gap-3">
                  <img
                    src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80"
                    alt="Sophia"
                    className="w-8 h-8 rounded-full object-cover border border-neutral-200"
                  />
                  <div>
                    <span className="text-xs font-bold text-neutral-800 dark:text-neutral-200 group-hover:text-brand-600 transition-colors">Sophia (Corporate Buyer)</span>
                    <p className="text-[9px] text-neutral-400">Preloaded spends tracker, reviews, active hires.</p>
                  </div>
                </div>
                <UserCheck size={14} className="text-neutral-400 group-hover:text-brand-500" />
              </button>

              {/* Option C: Admin Portal */}
              <button
                onClick={() => handleSimulatedLogin('admin')}
                className="w-full flex items-center justify-between p-3.5 rounded-xl border border-amber-100 dark:border-amber-900/30 hover:border-amber-500 bg-amber-50/25 dark:bg-amber-950/10 text-left transition-all cursor-pointer group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-amber-100 dark:bg-amber-950 flex items-center justify-center text-amber-600">
                    <Shield size={14} />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-amber-800 dark:text-amber-200 group-hover:text-amber-600 transition-colors">System Admin Operator</span>
                    <p className="text-[9px] text-neutral-400">Enterprise summary dashboard & logs tables.</p>
                  </div>
                </div>
                <ArrowRight size={14} className="text-amber-400" />
              </button>

            </div>
          </div>

          {/* Form input elements for design authenticity */}
          <div className="space-y-3.5 pt-5 border-t border-neutral-100 dark:border-neutral-850">
            <div>
              <label className="text-[9px] font-extrabold text-neutral-400 block mb-1">EMAIL ADDRESS</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full text-xs font-semibold px-3 py-2 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900"
                disabled
              />
            </div>
            <div>
              <label className="text-[9px] font-extrabold text-neutral-400 block mb-1">SECRET PASSWORD</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full text-xs font-semibold px-3 py-2 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 text-neutral-400"
                disabled
              />
            </div>
          </div>

          <button
            onClick={() => handleSimulatedLogin('both')}
            className="w-full py-3 bg-brand-500 hover:bg-brand-600 text-white font-bold text-xs rounded-xl shadow-sm cursor-pointer transition-colors"
          >
            Sign In with Active Session
          </button>

        </div>

        {/* Security / Info badges below */}
        <div className="flex items-center gap-2 justify-center text-[10px] text-neutral-400 font-semibold italic text-center">
          <Sparkles className="text-brand-500" size={12} />
          <span>No external databases required. Authenticated profiles persist in LocalStorage.</span>
        </div>

      </div>

    </div>
  );
};
