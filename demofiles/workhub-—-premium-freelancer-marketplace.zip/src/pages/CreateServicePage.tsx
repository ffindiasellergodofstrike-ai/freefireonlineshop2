import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp, Service } from '../context/AppContext';
import { Layers, ArrowLeft, Check, Sparkles, Tag } from 'lucide-react';

export const CreateServicePage: React.FC = () => {
  const navigate = useNavigate();
  const { categories, addServiceListing, currentUser, showToast } = useApp();

  // Form states
  const [title, setTitle] = useState('I will develop custom AI tools with Gemini API and Node.js');
  const [category, setCategory] = useState(categories[1]?.id || '');
  const [desc, setDesc] = useState('I will craft robust server-side APIs and integrate advanced LLM models like Gemini Flash into your active database flow with custom schemas.');
  const [tags, setTags] = useState('ai, gemini, api, nodejs');

  const [basicPrice, setBasicPrice] = useState(120);
  const [basicTime, setBasicTime] = useState(3);
  
  const [standardPrice, setStandardPrice] = useState(280);
  const [standardTime, setStandardTime] = useState(5);

  const [premiumPrice, setPremiumPrice] = useState(550);
  const [premiumTime, setPremiumTime] = useState(7);

  const handlePublish = (e: React.FormEvent) => {
    e.preventDefault();
    if (title.length < 15 || desc.length < 30) {
      showToast('Title must be 15+ and description 30+ characters!', 'error');
      return;
    }

    const newGigId = `srv-${Date.now()}`;
    const newService: Service = {
      id: newGigId,
      sellerId: currentUser.id,
      categoryId: category,
      subcategoryId: categories.find(c => c.id === category)?.name || 'Development',
      title: title,
      description: desc,
      images: [
        'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800&auto=format&fit=crop&q=80'
      ],
      rating: 5.0,
      reviewCount: 0,
      ordersCount: 0,
      views: 0,
      impressions: 0,
      faq: [{ question: 'What is required to start?', answer: 'Your custom API keys and standard system briefings.' }],
      requirements: 'Please supply design assets or workflow outlines to proceed.',
      tags: tags.split(',').map(t => t.trim()),
      status: 'Active',
      packages: {
        basic: {
          price: Number(basicPrice),
          deliveryTime: Number(basicTime),
          revisions: 2,
          features: ['Gemini API config', 'Node.js proxy setup', 'Source Code Access']
        },
        standard: {
          price: Number(standardPrice),
          deliveryTime: Number(standardTime),
          revisions: 5,
          features: ['Up to 3 endpoints', 'Stripe Proxy', 'Gemini API config', 'Source Code Access', 'Responsive Demo']
        },
        premium: {
          price: Number(premiumPrice),
          deliveryTime: Number(premiumTime),
          revisions: -1,
          features: ['Complete Server-side Platform', 'Cloud Run readiness', 'Gemini Streaming Support', 'Source Code Access', 'Responsive Demo', '24/7 SLA Support']
        }
      }
    };

    addServiceListing(newService);
    showToast('Your custom Gig listing is now live in the active browse feed!', 'success');
    navigate('/dashboard/seller');
  };

  return (
    <div id="create-service-page" className="min-h-screen bg-[#FBFBFA] dark:bg-neutral-950 text-neutral-800 dark:text-neutral-100 py-16 transition-colors">
      <div className="max-w-2xl mx-auto px-4">
        
        {/* Back link */}
        <button
          onClick={() => navigate('/dashboard/seller')}
          className="inline-flex items-center gap-1.5 text-xs font-bold text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200 mb-6 cursor-pointer"
        >
          <ArrowLeft size={13} />
          <span>Back to Seller Dashboard</span>
        </button>

        <div className="border-b border-neutral-100 dark:border-neutral-850 pb-4 mb-8 space-y-1">
          <h1 className="text-xl sm:text-2xl font-extrabold text-neutral-900 dark:text-white">Publish a Custom Service Gig</h1>
          <p className="text-xs text-neutral-400">Outline standard prices and features to draw enterprise interest instantly.</p>
        </div>

        <form onSubmit={handlePublish} className="bg-white dark:bg-neutral-900 p-6 sm:p-8 rounded-2xl border border-neutral-100 dark:border-neutral-800 shadow-sm space-y-6">
          
          <div>
            <label className="text-[10px] font-bold text-neutral-400 block mb-1">GIG CAMPAIGN TITLE</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full text-xs font-semibold px-3 py-2.5 rounded-lg border border-neutral-250 dark:border-neutral-850 focus:outline-hidden"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-[10px] font-bold text-neutral-400 block mb-1">COMPETENCY CATEGORY</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full text-xs font-semibold px-3 py-2.5 rounded-lg border border-neutral-250 dark:border-neutral-850 focus:outline-hidden bg-neutral-50 dark:bg-neutral-900"
              >
                {categories.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[10px] font-bold text-neutral-400 block mb-1">SEARCH TAGS (COMMA SEPARATED)</label>
              <input
                type="text"
                value={tags}
                onChange={(e) => setTags(e.target.value)}
                className="w-full text-xs font-semibold px-3 py-2.5 rounded-lg border border-neutral-250 dark:border-neutral-850 focus:outline-hidden"
                placeholder="figma, react, code"
                required
              />
            </div>
          </div>

          <div>
            <label className="text-[10px] font-bold text-neutral-400 block mb-1">COMPREHENSIVE GIG DESCRIPTION</label>
            <textarea
              value={desc}
              onChange={(e) => setDesc(e.target.value)}
              rows={4}
              className="w-full text-xs font-medium px-3.5 py-2.5 rounded-lg border border-neutral-250 dark:border-neutral-850 focus:outline-hidden"
              required
            />
          </div>

          {/* Pricing packages briefs */}
          <div className="border-t border-neutral-50 dark:border-neutral-800 pt-6">
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-800 dark:text-neutral-200 mb-4 flex items-center gap-1.5">
              <Layers size={13} className="text-brand-500" />
              <span>Configure 3 Tier Package Levels</span>
            </h3>

            <div className="grid grid-cols-3 gap-3">
              {/* Basic */}
              <div className="p-3 bg-neutral-50 dark:bg-neutral-950 rounded-xl space-y-3.5 border border-neutral-100 dark:border-neutral-850">
                <span className="text-[9px] font-extrabold uppercase text-neutral-400 block tracking-wider">Basic package</span>
                <div>
                  <label className="text-[8px] text-neutral-400 font-bold block mb-1">PRICE ($)</label>
                  <input
                    type="number"
                    value={basicPrice}
                    onChange={(e) => setBasicPrice(Math.max(5, parseInt(e.target.value) || 0))}
                    className="w-full text-xs font-bold px-2 py-1.5 rounded border border-neutral-250 focus:outline-hidden text-center"
                  />
                </div>
                <div>
                  <label className="text-[8px] text-neutral-400 font-bold block mb-1">DELIVERY (DAYS)</label>
                  <input
                    type="number"
                    value={basicTime}
                    onChange={(e) => setBasicTime(Math.max(1, parseInt(e.target.value) || 0))}
                    className="w-full text-xs font-bold px-2 py-1.5 rounded border border-neutral-250 focus:outline-hidden text-center"
                  />
                </div>
              </div>

              {/* Standard */}
              <div className="p-3 bg-neutral-50 dark:bg-neutral-950 rounded-xl space-y-3.5 border border-neutral-100 dark:border-neutral-850">
                <span className="text-[9px] font-extrabold uppercase text-neutral-400 block tracking-wider">Standard tier</span>
                <div>
                  <label className="text-[8px] text-neutral-400 font-bold block mb-1">PRICE ($)</label>
                  <input
                    type="number"
                    value={standardPrice}
                    onChange={(e) => setStandardPrice(Math.max(5, parseInt(e.target.value) || 0))}
                    className="w-full text-xs font-bold px-2 py-1.5 rounded border border-neutral-250 focus:outline-hidden text-center"
                  />
                </div>
                <div>
                  <label className="text-[8px] text-neutral-400 font-bold block mb-1">DELIVERY (DAYS)</label>
                  <input
                    type="number"
                    value={standardTime}
                    onChange={(e) => setStandardTime(Math.max(1, parseInt(e.target.value) || 0))}
                    className="w-full text-xs font-bold px-2 py-1.5 rounded border border-neutral-250 focus:outline-hidden text-center"
                  />
                </div>
              </div>

              {/* Premium */}
              <div className="p-3 bg-neutral-50 dark:bg-neutral-950 rounded-xl space-y-3.5 border border-neutral-100 dark:border-neutral-850">
                <span className="text-[9px] font-extrabold uppercase text-neutral-400 block tracking-wider">Premium package</span>
                <div>
                  <label className="text-[8px] text-neutral-400 font-bold block mb-1">PRICE ($)</label>
                  <input
                    type="number"
                    value={premiumPrice}
                    onChange={(e) => setPremiumPrice(Math.max(5, parseInt(e.target.value) || 0))}
                    className="w-full text-xs font-bold px-2 py-1.5 rounded border border-neutral-250 focus:outline-hidden text-center"
                  />
                </div>
                <div>
                  <label className="text-[8px] text-neutral-400 font-bold block mb-1">DELIVERY (DAYS)</label>
                  <input
                    type="number"
                    value={premiumTime}
                    onChange={(e) => setPremiumTime(Math.max(1, parseInt(e.target.value) || 0))}
                    className="w-full text-xs font-bold px-2 py-1.5 rounded border border-neutral-250 focus:outline-hidden text-center"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Submit button */}
          <button
            type="submit"
            className="w-full py-3.5 bg-brand-500 hover:bg-brand-600 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer flex items-center justify-center gap-1.5"
          >
            <Check size={14} />
            <span>Launch Service Gig Live</span>
          </button>

        </form>

      </div>
    </div>
  );
};
