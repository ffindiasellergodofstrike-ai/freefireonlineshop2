import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp, Seller, Service } from '../context/AppContext';
import { Check, ArrowRight, ArrowLeft, Upload, ShieldCheck, Tag, Info, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const Onboarding: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser, categories, registerAsSeller, addServiceListing, showToast, switchRole } = useApp();

  // Wizard Active Step (1 to 4)
  const [step, setStep] = useState(1);

  // Form States: Step 1 - Personal Info
  const [fullName, setFullName] = useState(currentUser.name);
  const [title, setTitle] = useState('Senior Full Stack Developer');
  const [bio, setBio] = useState('An experienced consultant specialized in crafting scalable applications and beautiful user interfaces.');
  const [locationStr, setLocationStr] = useState('San Francisco, USA');
  
  // Form States: Step 2 - Competencies & Payouts
  const [skills, setSkills] = useState('React, Tailwind CSS, TypeScript, Node.js');
  const [languages, setLanguages] = useState('English, Spanish');
  const [responseTime, setResponseTime] = useState('1 hour');

  // Form States: Step 3 - First Gig Setup
  const [gigTitle, setGigTitle] = useState('I will design and build a modern React application with Tailwind CSS');
  const [gigCategory, setGigCategory] = useState(categories[0]?.id || '');
  const [gigDesc, setGigDesc] = useState('I will provide clean, responsive, and pixel-perfect React application frontend using modern practices and layout animations.');
  const [gigTags, setGigTags] = useState('react, vite, tailwind, typescript');
  const [basicPrice, setBasicPrice] = useState(99);
  const [standardPrice, setStandardPrice] = useState(249);
  const [premiumPrice, setPremiumPrice] = useState(499);

  // Error handling
  const [errors, setErrors] = useState<string>('');

  const nextStep = () => {
    // Validate current step
    setErrors('');
    if (step === 1) {
      if (!fullName.trim() || !title.trim() || bio.length < 20) {
        setErrors('Please fill in all details. Biography must be at least 20 characters.');
        return;
      }
    } else if (step === 2) {
      if (!skills.trim() || !languages.trim()) {
        setErrors('Skills and languages are required.');
        return;
      }
    } else if (step === 3) {
      if (gigTitle.length < 15 || gigDesc.length < 30 || !gigCategory) {
        setErrors('Gig Title must be 15+ chars, description must be 30+ chars, and category must be selected.');
        return;
      }
    }
    setStep(prev => prev + 1);
  };

  const prevStep = () => {
    setErrors('');
    setStep(prev => prev - 1);
  };

  const handleSubmitOnboarding = () => {
    try {
      // 1. Create Seller profile
      const newSeller: Seller = {
        id: currentUser.id,
        username: currentUser.username,
        name: fullName,
        avatar: currentUser.avatar,
        title: title,
        bio: bio,
        location: locationStr,
        languages: languages.split(',').map(l => l.trim()),
        skills: skills.split(',').map(s => s.trim()),
        responseTime: responseTime,
        joinedDate: 'Sep 2026',
        rating: 5.0,
        reviewCount: 0,
        completedOrders: 0,
        hourlyRate: 45,
        availability: 'Full Time',
        education: [],
        certifications: [],
        portfolio: [],
        isOnline: true,
        level: 'New Seller'
      };

      // 2. Create First Service listing
      const newServiceId = `srv-${Date.now()}`;
      const newService: Service = {
        id: newServiceId,
        sellerId: currentUser.id,
        categoryId: gigCategory,
        subcategoryId: categories.find(c => c.id === gigCategory)?.name || 'Development',
        title: gigTitle,
        description: gigDesc,
        images: [
          'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=800&auto=format&fit=crop&q=80'
        ],
        rating: 5.0,
        reviewCount: 0,
        ordersCount: 0,
        views: 0,
        impressions: 0,
        faq: [{ question: 'What is required to start?', answer: 'Your custom API keys and standard system briefings.' }],
        requirements: 'Please supply design assets or workflow outlines to proceed.',
        tags: gigTags.split(',').map(t => t.trim()),
        status: 'Active',
        packages: {
          basic: {
            price: Number(basicPrice),
            deliveryTime: 3,
            revisions: 2,
            features: ['1 Page Source Code', 'Tailwind CSS styling', 'Responsive Layout', 'Deployment Setup']
          },
          standard: {
            price: Number(standardPrice),
            deliveryTime: 5,
            revisions: 5,
            features: ['Up to 5 Pages', 'Tailwind CSS styling', 'Interactive Forms', 'Context Integration', 'Deployment Setup']
          },
          premium: {
            price: Number(premiumPrice),
            deliveryTime: 7,
            revisions: -1, // unlimited
            features: ['Complete Frontend Platform', 'Full-stack Express Proxy', 'State synchronization', 'Custom illustrations', 'Deployment Setup', 'Source Code Access']
          }
        }
      };

      // Save to global context / local storage
      registerAsSeller(newSeller);
      addServiceListing(newService);

      // Force role switch to Seller
      switchRole('seller');

      showToast('Welcome to WorkHub Seller Workspace! Your first gig is live!', 'success');
      navigate('/dashboard/seller');
    } catch (e) {
      console.error(e);
      setErrors('Onboarding failed. Please review input fields.');
    }
  };

  return (
    <div id="onboarding-page" className="min-h-screen bg-[#FBFBFA] dark:bg-neutral-950 text-neutral-800 dark:text-neutral-100 py-16 transition-colors">
      <div className="max-w-2xl mx-auto px-4">
        
        {/* Wizard Headers Header */}
        <div className="text-center mb-10 space-y-2">
          <span className="text-[10px] font-extrabold uppercase tracking-widest text-brand-600 dark:text-brand-400">Join the Elite</span>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white">Become a Freelancer on WorkHub</h1>
          <p className="text-xs text-neutral-400">Build your professional store, set custom prices, and earn on your own terms.</p>
        </div>

        {/* Dynamic Progress Timeline Dots */}
        <div className="relative flex items-center justify-between mb-12 max-w-md mx-auto">
          <div className="absolute left-0 right-0 h-0.5 bg-neutral-200 dark:bg-neutral-800 top-1/2 -translate-y-1/2 z-0" />
          <div
            className="absolute left-0 h-0.5 bg-brand-500 top-1/2 -translate-y-1/2 z-0 transition-all duration-300"
            style={{ width: `${((step - 1) / 3) * 100}%` }}
          />

          {[1, 2, 3, 4].map((s) => {
            const isCompleted = step > s;
            const isActive = step === s;
            return (
              <div
                key={s}
                className={`relative z-10 w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs border transition-all duration-300 ${isCompleted ? 'bg-brand-500 border-brand-500 text-white' : isActive ? 'bg-white dark:bg-neutral-900 border-brand-500 text-brand-600' : 'bg-neutral-100 dark:bg-neutral-800 border-neutral-200 dark:border-neutral-700 text-neutral-400'}`}
              >
                {isCompleted ? <Check size={14} /> : s}
              </div>
            );
          })}
        </div>

        {/* Form Container Card */}
        <div className="bg-white dark:bg-neutral-900 p-6 sm:p-8 border border-neutral-100 dark:border-neutral-800 rounded-2xl shadow-sm space-y-6">
          
          {/* Validation Alert Area */}
          {errors && (
            <div className="flex items-start gap-2 p-4 bg-rose-50 dark:bg-rose-950/30 border border-rose-100 dark:border-rose-900/50 rounded-xl text-xs text-rose-600 dark:text-rose-400 font-medium">
              <AlertCircle className="flex-shrink-0 mt-0.5" size={15} />
              <span>{errors}</span>
            </div>
          )}

          <AnimatePresence mode="wait">
            
            {/* STEP 1: PERSONAL Resume details */}
            {step === 1 && (
              <motion.div
                key="step-1"
                initial={{ opacity: 0, x: 15 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -15 }}
                className="space-y-4"
              >
                <div className="border-b border-neutral-50 dark:border-neutral-850 pb-3 mb-5">
                  <h3 className="font-extrabold text-base text-neutral-900 dark:text-white">Step 1: Personal Showcase Details</h3>
                  <p className="text-[11px] text-neutral-400">Describe your professional identity to prospective buyers.</p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-bold text-neutral-400 block mb-1">FULL NAME</label>
                    <input
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      className="w-full text-xs font-semibold px-3 py-2.5 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 focus:outline-hidden text-neutral-800 dark:text-white"
                      placeholder="e.g. Jane Doe"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-neutral-400 block mb-1">LOCATION & REGION</label>
                    <input
                      type="text"
                      value={locationStr}
                      onChange={(e) => setLocationStr(e.target.value)}
                      className="w-full text-xs font-semibold px-3 py-2.5 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 focus:outline-hidden text-neutral-800 dark:text-white"
                      placeholder="e.g. California, USA"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-neutral-400 block mb-1">PROFESSIONAL TITLE</label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full text-xs font-semibold px-3 py-2.5 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 focus:outline-hidden text-neutral-800 dark:text-white"
                    placeholder="e.g. Elite UI Designer & Web Architect"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-neutral-400 block mb-1">BIOGRAPHY SUMMARY</label>
                  <textarea
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    rows={4}
                    className="w-full text-xs font-semibold px-3 py-2.5 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 focus:outline-hidden text-neutral-800 dark:text-white"
                    placeholder="Describe your background, years of work, tools, and experience..."
                  />
                </div>
              </motion.div>
            )}

            {/* STEP 2: PROFESSIONAL COMPETENCIES */}
            {step === 2 && (
              <motion.div
                key="step-2"
                initial={{ opacity: 0, x: 15 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -15 }}
                className="space-y-4"
              >
                <div className="border-b border-neutral-50 dark:border-neutral-850 pb-3 mb-5">
                  <h3 className="font-extrabold text-base text-neutral-900 dark:text-white">Step 2: Skills & Communication</h3>
                  <p className="text-[11px] text-neutral-400">List your expert capabilities and support options.</p>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-neutral-400 block mb-1">SKILLS & TOOLS (COMMA SEPARATED)</label>
                  <input
                    type="text"
                    value={skills}
                    onChange={(e) => setSkills(e.target.value)}
                    className="w-full text-xs font-semibold px-3 py-2.5 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 focus:outline-hidden text-neutral-800 dark:text-white"
                    placeholder="React, TypeScript, Figma, Tailwind, Next.js"
                  />
                  <span className="text-[9px] text-neutral-400 font-semibold block mt-1.5 flex items-center gap-1">
                    <Tag size={10} />
                    <span>Type skills separated by commas to compile individual visual tags.</span>
                  </span>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-neutral-400 block mb-1">LANGUAGES (COMMA SEPARATED)</label>
                  <input
                    type="text"
                    value={languages}
                    onChange={(e) => setLanguages(e.target.value)}
                    className="w-full text-xs font-semibold px-3 py-2.5 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 focus:outline-hidden text-neutral-800 dark:text-white"
                    placeholder="English (Fluent), Spanish (Conversational)"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-bold text-neutral-400 block mb-1">AVERAGE CHAT RESPONSE TIME</label>
                  <select
                    value={responseTime}
                    onChange={(e) => setResponseTime(e.target.value)}
                    className="w-full text-xs font-semibold px-3 py-2.5 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 focus:outline-hidden text-neutral-800 dark:text-white"
                  >
                    <option value="1 hour">Within 1 hour (Fastest)</option>
                    <option value="2 hours">Within 2 hours</option>
                    <option value="5 hours">Within 5 hours</option>
                    <option value="1 day">Within 1 day</option>
                  </select>
                </div>
              </motion.div>
            )}

            {/* STEP 3: CREATE FIRST GIG LISTING */}
            {step === 3 && (
              <motion.div
                key="step-3"
                initial={{ opacity: 0, x: 15 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -15 }}
                className="space-y-4"
              >
                <div className="border-b border-neutral-50 dark:border-neutral-850 pb-3 mb-5">
                  <h3 className="font-extrabold text-base text-neutral-900 dark:text-white">Step 3: Launch Your First Gig Listing</h3>
                  <p className="text-[11px] text-neutral-400">Specify what services you want to sell in the active marketplace.</p>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-neutral-400 block mb-1">GIG/SERVICE TITLE</label>
                  <input
                    type="text"
                    value={gigTitle}
                    onChange={(e) => setGigTitle(e.target.value)}
                    className="w-full text-xs font-semibold px-3 py-2.5 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 focus:outline-hidden text-neutral-800 dark:text-white"
                    placeholder="I will design your landing page in Figma..."
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-bold text-neutral-400 block mb-1">PRIMARY CATEGORY</label>
                    <select
                      value={gigCategory}
                      onChange={(e) => setGigCategory(e.target.value)}
                      className="w-full text-xs font-semibold px-3 py-2.5 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 focus:outline-hidden text-neutral-800 dark:text-white"
                    >
                      {categories.map(c => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] font-bold text-neutral-400 block mb-1">GIG TAGS (COMMA SEPARATED)</label>
                    <input
                      type="text"
                      value={gigTags}
                      onChange={(e) => setGigTags(e.target.value)}
                      className="w-full text-xs font-semibold px-3 py-2.5 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 focus:outline-hidden text-neutral-800 dark:text-white"
                      placeholder="react, figma, saas"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-neutral-400 block mb-1">SERVICE DESCRIPTION</label>
                  <textarea
                    value={gigDesc}
                    onChange={(e) => setGigDesc(e.target.value)}
                    rows={3}
                    className="w-full text-xs font-semibold px-3 py-2.5 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-900 focus:outline-hidden text-neutral-800 dark:text-white"
                    placeholder="What deliverables, pages, and work process are included?"
                  />
                </div>

                {/* Package prices grid */}
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="text-[9px] font-extrabold text-neutral-400 block mb-1">BASIC PACKAGE ($)</label>
                    <input
                      type="number"
                      value={basicPrice}
                      onChange={(e) => setBasicPrice(Math.max(5, parseInt(e.target.value) || 0))}
                      className="w-full text-xs font-bold px-3 py-2 rounded-lg border border-neutral-250 dark:border-neutral-850 focus:outline-hidden text-center"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-extrabold text-neutral-400 block mb-1">STANDARD ($)</label>
                    <input
                      type="number"
                      value={standardPrice}
                      onChange={(e) => setStandardPrice(Math.max(5, parseInt(e.target.value) || 0))}
                      className="w-full text-xs font-bold px-3 py-2 rounded-lg border border-neutral-250 dark:border-neutral-850 focus:outline-hidden text-center"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-extrabold text-neutral-400 block mb-1">PREMIUM ($)</label>
                    <input
                      type="number"
                      value={premiumPrice}
                      onChange={(e) => setPremiumPrice(Math.max(5, parseInt(e.target.value) || 0))}
                      className="w-full text-xs font-bold px-3 py-2 rounded-lg border border-neutral-250 dark:border-neutral-850 focus:outline-hidden text-center"
                    />
                  </div>
                </div>
              </motion.div>
            )}

            {/* STEP 4: REVIEW AND PUBLISH */}
            {step === 4 && (
              <motion.div
                key="step-4"
                initial={{ opacity: 0, x: 15 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -15 }}
                className="space-y-6 text-center py-4"
              >
                <div className="flex items-center justify-center w-14 h-14 rounded-full bg-emerald-50 dark:bg-emerald-950 text-emerald-500 mx-auto mb-3">
                  <ShieldCheck size={30} />
                </div>

                <div>
                  <h3 className="font-extrabold text-base text-neutral-900 dark:text-white">Everything is configured!</h3>
                  <p className="text-[11px] text-neutral-400 mt-1 max-w-sm mx-auto leading-relaxed">
                    By submitting, your WorkHub Buyer account gains Seller permissions. Your custom Gigs listing is registered and fully browsable by visitors instantly.
                  </p>
                </div>

                <div className="bg-neutral-50 dark:bg-neutral-900/40 p-4 rounded-xl border border-neutral-100 dark:border-neutral-800 text-left space-y-2 max-w-md mx-auto">
                  <div className="flex justify-between text-xs font-medium text-neutral-500">
                    <span>Account Profile</span>
                    <span className="font-bold text-neutral-800 dark:text-neutral-200">@{currentUser.username} (Both)</span>
                  </div>
                  <div className="flex justify-between text-xs font-medium text-neutral-500">
                    <span>Professional Role</span>
                    <span className="font-bold text-neutral-800 dark:text-neutral-200">{title}</span>
                  </div>
                  <div className="flex justify-between text-xs font-medium text-neutral-500">
                    <span>First Gig price</span>
                    <span className="font-bold text-brand-600 dark:text-brand-400">Basic at ${basicPrice}</span>
                  </div>
                </div>
              </motion.div>
            )}

          </AnimatePresence>

          {/* Action Footer Buttons inside Form */}
          <div className="flex justify-between items-center pt-6 border-t border-neutral-100 dark:border-neutral-850">
            {step > 1 ? (
              <button
                onClick={prevStep}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold rounded-lg border border-neutral-200 text-neutral-500 hover:bg-neutral-50 transition-colors cursor-pointer"
              >
                <ArrowLeft size={13} />
                <span>Previous</span>
              </button>
            ) : (
              <div />
            )}

            {step < 4 ? (
              <button
                onClick={nextStep}
                className="inline-flex items-center gap-1.5 px-5 py-2.5 text-xs font-bold rounded-lg bg-brand-500 hover:bg-brand-600 text-white transition-colors cursor-pointer"
              >
                <span>Continue</span>
                <ArrowRight size={13} />
              </button>
            ) : (
              <button
                onClick={handleSubmitOnboarding}
                className="inline-flex items-center gap-1.5 px-6 py-2.5 text-xs font-bold rounded-lg bg-brand-500 hover:bg-brand-600 text-white transition-colors cursor-pointer shadow-sm shadow-brand-500/10"
              >
                <span>Publish Gigs & Activate Profile</span>
                <Check size={14} />
              </button>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
