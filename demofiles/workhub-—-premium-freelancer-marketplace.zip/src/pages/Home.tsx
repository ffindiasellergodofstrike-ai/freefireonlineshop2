import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Search, ChevronDown, CheckCircle2, Shield, Star, Award, Zap, HelpCircle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { CategoryCard } from '../components/CategoryCard';
import { ServiceCard } from '../components/ServiceCard';
import { SellerCard } from '../components/SellerCard';
import { motion, AnimatePresence } from 'motion/react';

export const Home: React.FC = () => {
  const { categories, services, sellers, reviews } = useApp();
  const navigate = useNavigate();
  const [searchVal, setSearchVal] = useState('');
  
  // Accordion state for FAQs
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchVal.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchVal.trim())}`);
    }
  };

  const trendingTags = ['AI Prompting', 'React Fullstack', 'SaaS Figma', 'SEO Auditing', 'DaVinci Colorist'];

  const faqItems = [
    {
      q: 'How does WorkHub protect my payments?',
      a: 'WorkHub utilizes an advanced virtual escrow system. When a buyer selects a package and clicks checkout, funds are secured by the platform. The freelancer receives payment only after you review and approve the submitted work deliverables.'
    },
    {
      q: 'Can a single account act as both a buyer and a seller?',
      a: 'Absolutely! WorkHub supports unified dual profiles. From the top navigation bar, you can instantly click "Switch to Selling" to manage your services and orders, and "Switch to Buying" to hire other freelancers.'
    },
    {
      q: 'How do revisions work for ordered gigs?',
      a: 'Each service listing has packages (Basic, Standard, Premium) that define a specific number of included revisions. If the delivered work needs adjustments, buyers can click "Request Revision" on their order management page.'
    },
    {
      q: 'Are there any registration or monthly platform fees?',
      a: 'Registering on WorkHub is completely free! For buyers, a minor 2.5% platform handling fee is added at checkout. For sellers, standard payout commissions are calculated at withdrawal.'
    }
  ];

  // Pick some outstanding services to display (Active status only)
  const activeServices = services.filter(s => s.status === 'Active');
  const trendingServices = activeServices.slice(0, 4);
  const recommendedServices = activeServices.slice(4, 8);
  const featuredSellers = sellers.slice(0, 3);

  return (
    <div id="home-page" className="flex flex-col min-h-screen bg-[#FBFBFA] dark:bg-neutral-950 transition-colors">
      
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden pt-20 pb-16 bg-gradient-to-b from-brand-50/50 to-white dark:from-brand-950/20 dark:to-neutral-950">
        <div className="absolute inset-0 z-0 opacity-40 dark:opacity-10 pointer-events-none">
          <div className="absolute top-10 left-10 w-96 h-96 bg-brand-200 rounded-full blur-3xl" />
          <div className="absolute bottom-10 right-10 w-80 h-80 bg-emerald-100 rounded-full blur-3xl" />
        </div>

        <div className="relative z-10 max-w-5xl mx-auto px-4 text-center">
          
          {/* Eyebrow Label */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-brand-100 dark:bg-brand-950/60 border border-brand-200/50 dark:border-brand-900/30 text-brand-700 dark:text-brand-300 text-[10px] font-extrabold tracking-wider uppercase mb-6"
          >
            <Zap size={11} className="fill-brand-500 text-brand-500" />
            <span>Find Talent. Sell Skills. Get Work Done.</span>
          </motion.div>

          {/* Main Display Title */}
          <motion.h1
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight text-neutral-900 dark:text-white mb-6 leading-tight max-w-4xl mx-auto"
          >
            Find the perfect <span className="text-brand-500">freelance talent</span> for your next breakthrough.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-sm sm:text-base text-neutral-500 dark:text-neutral-400 max-w-2xl mx-auto leading-relaxed mb-10 font-medium"
          >
            Connect with pre-vetted engineers, elite designers, copywriting architects, and certified AI developers specialized in scaling businesses.
          </motion.p>

          {/* Large Hero Search Box */}
          <motion.form
            onSubmit={handleSearchSubmit}
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            className="flex items-center p-2 rounded-2xl bg-white dark:bg-neutral-900 shadow-xl border border-neutral-100 dark:border-neutral-800/80 max-w-2xl mx-auto mb-6"
          >
            <div className="flex-1 relative flex items-center pl-3">
              <Search className="text-neutral-400 mr-2.5 flex-shrink-0" size={18} />
              <input
                type="text"
                placeholder="Try &quot;Figma design&quot;, &quot;React app&quot;, or &quot;Gemini integration&quot;..."
                value={searchVal}
                onChange={(e) => setSearchVal(e.target.value)}
                className="w-full text-xs font-semibold text-neutral-800 dark:text-neutral-100 placeholder-neutral-400 bg-transparent border-none focus:outline-hidden focus:ring-0"
              />
            </div>
            <button
              type="submit"
              className="px-6 py-3 rounded-xl bg-brand-500 hover:bg-brand-600 text-white font-bold text-xs transition-colors shadow-sm shadow-brand-500/20"
            >
              Search
            </button>
          </motion.form>

          {/* Quick Trending Links */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="flex flex-wrap items-center justify-center gap-2 text-xs"
          >
            <span className="font-bold text-neutral-400 dark:text-neutral-500 mr-1">Trending:</span>
            {trendingTags.map((tag) => (
              <button
                key={tag}
                onClick={() => {
                  setSearchVal(tag);
                  navigate(`/search?q=${encodeURIComponent(tag)}`);
                }}
                className="px-3 py-1 rounded-full bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 hover:border-brand-500 dark:hover:border-brand-500 text-[11px] font-semibold text-neutral-600 dark:text-neutral-400 hover:text-brand-600 dark:hover:text-brand-400 transition-all shadow-2xs cursor-pointer"
              >
                {tag}
              </button>
            ))}
          </motion.div>

        </div>
      </section>

      {/* 2. CATEGORIES DIRECTORY */}
      <section className="py-20 bg-white dark:bg-neutral-900 border-y border-neutral-50 dark:border-neutral-800/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="flex items-end justify-between mb-10">
            <div>
              <span className="text-[10px] font-extrabold uppercase tracking-widest text-brand-600 dark:text-brand-400">
                Browse Directory
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white mt-1">
                Explore Top Categories
              </h2>
            </div>
            <button
              onClick={() => navigate('/explore')}
              className="text-xs font-bold text-brand-600 dark:text-brand-400 hover:underline"
            >
              See all categories →
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
            {categories.map((cat) => (
              <CategoryCard key={cat.id} category={cat} />
            ))}
          </div>

        </div>
      </section>

      {/* 3. TRENDING GIGS GRID */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="flex items-end justify-between mb-10">
            <div>
              <span className="text-[10px] font-extrabold uppercase tracking-widest text-brand-600 dark:text-brand-400">
                Trending Right Now
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white mt-1">
                Most Popular Services
              </h2>
            </div>
            <button
              onClick={() => navigate('/explore')}
              className="text-xs font-bold text-brand-600 dark:text-brand-400 hover:underline"
            >
              Browse active listings →
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {trendingServices.map((service) => (
              <ServiceCard key={service.id} service={service} />
            ))}
          </div>

        </div>
      </section>

      {/* 4. MEET TOP RATED FREELANCERS */}
      <section className="py-20 bg-neutral-50 dark:bg-neutral-900/40 border-y border-neutral-100 dark:border-neutral-800/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="flex items-end justify-between mb-10">
            <div>
              <span className="text-[10px] font-extrabold uppercase tracking-widest text-brand-600 dark:text-brand-400">
                Certified Professionals
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white mt-1">
                Popular Freelancers
              </h2>
            </div>
            <button
              onClick={() => navigate('/explore')}
              className="text-xs font-bold text-brand-600 dark:text-brand-400 hover:underline"
            >
              Discover all talent →
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {featuredSellers.map((seller) => (
              <SellerCard key={seller.id} seller={seller} />
            ))}
          </div>

        </div>
      </section>

      {/* 5. RECOMMENDED GIGS GRID */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="mb-10 text-center">
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-brand-600 dark:text-brand-400">
              Personalized Selections
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white mt-1">
              Recommended For You
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {recommendedServices.map((service) => (
              <ServiceCard key={service.id} service={service} />
            ))}
          </div>

        </div>
      </section>

      {/* 6. HOW WORKHUB WORKS */}
      <section className="py-20 bg-white dark:bg-neutral-900 border-y border-neutral-100 dark:border-neutral-800/60">
        <div className="max-w-5xl mx-auto px-4">
          <div className="text-center mb-16">
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-brand-600 dark:text-brand-400">
              Process Flow
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white mt-1">
              How WorkHub Works
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {/* For Buyers */}
            <div className="space-y-6">
              <h3 className="text-lg font-bold text-neutral-800 dark:text-neutral-100 flex items-center gap-2 pb-3 border-b border-neutral-100 dark:border-neutral-800">
                <div className="flex items-center justify-center w-6 h-6 rounded-md bg-brand-500 text-white text-xs font-bold">1</div>
                <span>For Buyers & Clients</span>
              </h3>
              <ul className="space-y-4">
                <li className="flex gap-3">
                  <CheckCircle2 className="text-emerald-500 flex-shrink-0 mt-0.5" size={16} />
                  <div>
                    <h4 className="text-xs font-bold text-neutral-800 dark:text-neutral-200">Discover Elite Talent</h4>
                    <p className="text-[11px] text-neutral-400 mt-0.5">Browse 30+ premade services or search specific skills manually.</p>
                  </div>
                </li>
                <li className="flex gap-3">
                  <CheckCircle2 className="text-emerald-500 flex-shrink-0 mt-0.5" size={16} />
                  <div>
                    <h4 className="text-xs font-bold text-neutral-800 dark:text-neutral-200">Secure Payments Escrow</h4>
                    <p className="text-[11px] text-neutral-400 mt-0.5">Checkout with a mock credit card. Payment remains locked until delivery.</p>
                  </div>
                </li>
                <li className="flex gap-3">
                  <CheckCircle2 className="text-emerald-500 flex-shrink-0 mt-0.5" size={16} />
                  <div>
                    <h4 className="text-xs font-bold text-neutral-800 dark:text-neutral-200">Track & Complete</h4>
                    <p className="text-[11px] text-neutral-400 mt-0.5">Chat in real-time, inspect files, request revisions, or publish reviews.</p>
                  </div>
                </li>
              </ul>
            </div>

            {/* For Sellers */}
            <div className="space-y-6">
              <h3 className="text-lg font-bold text-neutral-800 dark:text-neutral-100 flex items-center gap-2 pb-3 border-b border-neutral-100 dark:border-neutral-800">
                <div className="flex items-center justify-center w-6 h-6 rounded-md bg-brand-500 text-white text-xs font-bold">2</div>
                <span>For Sellers & Freelancers</span>
              </h3>
              <ul className="space-y-4">
                <li className="flex gap-3">
                  <CheckCircle2 className="text-emerald-500 flex-shrink-0 mt-0.5" size={16} />
                  <div>
                    <h4 className="text-xs font-bold text-neutral-800 dark:text-neutral-200">Set Up Your Profile</h4>
                    <p className="text-[11px] text-neutral-400 mt-0.5">Click &quot;Become a Seller&quot;, outline your credentials, portfolio, and rates.</p>
                  </div>
                </li>
                <li className="flex gap-3">
                  <CheckCircle2 className="text-emerald-500 flex-shrink-0 mt-0.5" size={16} />
                  <div>
                    <h4 className="text-xs font-bold text-neutral-800 dark:text-neutral-200">List Your Gigs</h4>
                    <p className="text-[11px] text-neutral-400 mt-0.5">Publish custom packages (Basic, Standard, Premium) at your chosen pricing.</p>
                  </div>
                </li>
                <li className="flex gap-3">
                  <CheckCircle2 className="text-emerald-500 flex-shrink-0 mt-0.5" size={16} />
                  <div>
                    <h4 className="text-xs font-bold text-neutral-800 dark:text-neutral-200">Deliver & Get Paid</h4>
                    <p className="text-[11px] text-neutral-400 mt-0.5">Work with clients on orders, submit final archives, and view earnings logs.</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>

        </div>
      </section>

      {/* 7. FREQUENTLY ASKED QUESTIONS */}
      <section className="py-20">
        <div className="max-w-3xl mx-auto px-4">
          <div className="text-center mb-12">
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-brand-600 dark:text-brand-400">
              Have Questions?
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 dark:text-white mt-1">
              Frequently Asked Questions
            </h2>
          </div>

          <div className="space-y-4">
            {faqItems.map((item, index) => {
              const isOpen = activeFaq === index;
              return (
                <div
                  key={index}
                  className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800/80 rounded-xl overflow-hidden transition-all duration-200"
                >
                  <button
                    onClick={() => setActiveFaq(isOpen ? null : index)}
                    className="w-full flex items-center justify-between p-5 text-left text-xs font-bold text-neutral-800 dark:text-neutral-200 focus:outline-hidden"
                  >
                    <span>{item.q}</span>
                    <ChevronDown
                      size={14}
                      className={`text-neutral-400 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`}
                    />
                  </button>
                  <AnimatePresence>
                    {isOpen && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden border-t border-neutral-50 dark:border-neutral-800"
                      >
                        <p className="p-5 text-xs text-neutral-500 dark:text-neutral-400 leading-relaxed">
                          {item.a}
                        </p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 8. TESTIMONIAL PANEL */}
      <section className="py-20 bg-emerald-950 text-white relative overflow-hidden rounded-t-3xl md:rounded-t-[40px]">
        <div className="absolute top-0 right-0 w-80 h-80 bg-brand-600 rounded-full blur-3xl opacity-20 pointer-events-none" />
        <div className="max-w-4xl mx-auto px-4 text-center">
          
          <Award size={36} className="text-brand-400 mx-auto mb-6" />
          
          <p className="serif-display text-lg sm:text-2xl italic font-medium leading-relaxed max-w-3xl mx-auto mb-8 text-neutral-100">
            &quot;WorkHub has completely refactored how our design team sources high-end engineers. We found Nikolai and Alex on here and they turned our wireframe models into fully coded React platforms in under 10 days. The dual buyer/seller layout is incredibly clean.&quot;
          </p>

          <div className="flex items-center justify-center gap-3">
            <img
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80"
              alt="Sophia James"
              className="w-10 h-10 rounded-full object-cover border-2 border-brand-400 shadow-sm"
            />
            <div className="text-left">
              <h4 className="text-xs font-bold">Sophia James</h4>
              <p className="text-[10px] text-brand-300">CTO at PayGrid Fintech</p>
            </div>
          </div>
          
        </div>
      </section>

    </div>
  );
};
