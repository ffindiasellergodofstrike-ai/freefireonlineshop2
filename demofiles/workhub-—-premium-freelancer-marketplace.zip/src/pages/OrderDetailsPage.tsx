import React, { useState, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useApp, Order, Service, Review } from '../context/AppContext';
import { RatingStars } from '../components/RatingStars';
import {
  Clock,
  CheckCircle2,
  AlertCircle,
  FileText,
  UploadCloud,
  Check,
  Send,
  MessageSquare,
  Shield,
  HelpCircle,
  Undo2,
  Sparkles,
  Download
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const OrderDetailsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const {
    orders,
    services,
    sellers,
    activeRole,
    currentUser,
    submitWorkDelivery,
    approveOrderAndReview,
    requestOrderRevision,
    showToast
  } = useApp();

  const [deliveryNotes, setDeliveryNotes] = useState('Here is the complete source archive containing all configured styles, responsive layout files, and optimized icons as requested.');
  const [deliveryFile, setDeliveryFile] = useState('workhub-production-source.zip');

  // Review states (For Buyer)
  const [rating, setRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('Nikolai did an outstanding job! Code is incredibly clean, modular, and performance is superb. Will definitely hire again.');

  // Order Messenger states
  const [chatMessage, setChatMessage] = useState('');
  const [internalLogs, setInternalLogs] = useState<{ sender: string; text: string; time: string }[]>([
    { sender: 'System', text: 'Secure Escrow payment completed successfully.', time: 'Sep 22, 10:00 AM' },
    { sender: 'System', text: 'Buyer instructions and guidelines preloaded into project workspace.', time: 'Sep 22, 10:01 AM' }
  ]);

  const order = useMemo(() => orders.find(o => o.id === id), [orders, id]);

  const service = useMemo(() => {
    if (!order) return null;
    return services.find(s => s.id === order.serviceId);
  }, [services, order]);

  const seller = useMemo(() => {
    if (!service) return null;
    return sellers.find(s => s.id === service.sellerId);
  }, [sellers, service]);

  if (!order || !service || !seller) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-4">
        <h2 className="text-lg font-bold text-neutral-800 dark:text-neutral-200">Order record not found</h2>
        <p className="text-xs text-neutral-400 mt-2">The order code might be incorrect or deleted from localStorage.</p>
        <Link to="/" className="mt-4 px-4 py-2 bg-brand-500 text-white rounded-lg text-xs font-bold">
          Return to Hub
        </Link>
      </div>
    );
  }

  // Determine if logged-in user is Buyer or Seller in this specific transaction
  const isUserSeller = activeRole === 'seller' && currentUser.id === order.sellerId;
  const isUserBuyer = activeRole === 'buyer' && currentUser.id === order.buyerId;

  const handleDeliverWorkSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!deliveryNotes.trim() || !deliveryFile.trim()) {
      showToast('Delivery notes and filename are required!', 'error');
      return;
    }
    submitWorkDelivery(order.id, deliveryNotes, deliveryFile);
    setInternalLogs(prev => [
      ...prev,
      { sender: 'Freelancer', text: `Submitted deliverable files: ${deliveryFile}`, time: 'Just Now' }
    ]);
  };

  const handleRevisionRequestSubmit = () => {
    requestOrderRevision(order.id);
    setInternalLogs(prev => [
      ...prev,
      { sender: 'Buyer', text: 'Revision requested: Please adjust layout padding and optimize loading logs.', time: 'Just Now' }
    ]);
  };

  const handleApproveCompleteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewComment.trim()) {
      showToast('Please leave a short review comment!', 'error');
      return;
    }
    approveOrderAndReview(order.id, rating, reviewComment);
    setInternalLogs(prev => [
      ...prev,
      { sender: 'System', text: 'Order completed. Escrow payouts disbursed successfully.', time: 'Just Now' }
    ]);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatMessage.trim()) return;
    setInternalLogs(prev => [
      ...prev,
      {
        sender: isUserSeller ? 'Freelancer' : 'Buyer',
        text: chatMessage,
        time: 'Just Now'
      }
    ]);
    setChatMessage('');
  };

  // Stepper helper
  const getStatusStepIndex = () => {
    switch (order.status) {
      case 'Pending':
        return 1;
      case 'Revision Requested':
        return 1;
      case 'Delivered':
        return 2;
      case 'Completed':
        return 3;
      default:
        return 1;
    }
  };

  const currentStep = getStatusStepIndex();

  return (
    <div id="order-details-page" className="bg-[#FBFBFA] dark:bg-neutral-950 text-neutral-800 dark:text-neutral-100 pb-24 transition-colors">
      
      {/* 1. ORDER LIFECYCLE PROGRESS STEPPER */}
      <div className="bg-white dark:bg-neutral-900 border-b border-neutral-100 dark:border-neutral-800/80 py-8 mb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between text-left gap-4">
            <div>
              <span className="text-[10px] font-extrabold tracking-widest uppercase text-neutral-400">Escrow Transaction Code</span>
              <h1 className="text-xl font-extrabold text-neutral-900 dark:text-white mt-0.5 flex items-center gap-2">
                <span>Order Reference: WH-2026-{order.id}</span>
                <span className={`px-2.5 py-0.5 rounded text-[10px] font-bold ${order.status === 'Completed' ? 'bg-emerald-100 text-emerald-800' : order.status === 'Delivered' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'}`}>
                  {order.status}
                </span>
              </h1>
            </div>
            
            <div className="text-xs font-semibold text-neutral-400">
              <span className="block text-right">Target budget: <strong className="text-brand-600 dark:text-brand-400">${order.price}</strong></span>
              <span className="block text-right mt-1">Initiated: {order.createdAt}</span>
            </div>
          </div>

          {/* Graphical timeline timeline */}
          <div className="relative flex items-center justify-between max-w-2xl mx-auto pt-6 pb-2">
            <div className="absolute left-0 right-0 h-0.5 bg-neutral-200 dark:bg-neutral-800 top-1/2 -translate-y-1/2 z-0" />
            <div
              className="absolute left-0 h-0.5 bg-brand-500 top-1/2 -translate-y-1/2 z-0 transition-all duration-500"
              style={{ width: `${((currentStep - 1) / 2) * 100}%` }}
            />

            {[
              { label: 'Brief Submitted', s: 1 },
              { label: 'Work Deliverable', s: 2 },
              { label: 'Order Completed', s: 3 }
            ].map((stepObj) => {
              const isCompleted = currentStep >= stepObj.s;
              const isActive = currentStep === stepObj.s;
              return (
                <div key={stepObj.label} className="relative z-10 flex flex-col items-center gap-2">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs border transition-all duration-300 ${isCompleted ? 'bg-brand-500 border-brand-500 text-white' : 'bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-700 text-neutral-400'}`}>
                    {isCompleted ? <Check size={14} /> : stepObj.s}
                  </div>
                  <span className={`text-[10px] font-bold uppercase tracking-wider ${isCompleted ? 'text-brand-600 dark:text-brand-400' : 'text-neutral-400'}`}>
                    {stepObj.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* LEFT COLUMN - ACTION PORTALS, BRIEFING DESCRIPTION */}
          <div className="col-span-1 lg:col-span-2 space-y-6">
            
            {/* 1. DYNAMIC ACTION WORKSPACE PANEL */}
            <div className="bg-white dark:bg-neutral-900 p-6 rounded-2xl border border-neutral-100 dark:border-neutral-800 shadow-sm space-y-5">
              <div className="flex items-center gap-2 pb-3 border-b border-neutral-50 dark:border-neutral-800">
                <Sparkles className="text-brand-500" size={16} />
                <h3 className="text-xs font-bold uppercase tracking-widest text-neutral-800 dark:text-neutral-200">
                  Transaction Action Center
                </h3>
              </div>

              {/* SELLER VIEW - WORK SUBMISSION FORM */}
              {isUserSeller && (
                <div className="space-y-4">
                  {order.status === 'Pending' || order.status === 'Revision Requested' ? (
                    <form onSubmit={handleDeliverWorkSubmit} className="space-y-4">
                      <div className="p-4 bg-blue-50/50 dark:bg-blue-950/15 border border-blue-100 dark:border-blue-900/30 rounded-xl text-xs text-blue-700 dark:text-blue-300 font-semibold flex items-start gap-2">
                        <AlertCircle className="flex-shrink-0 mt-0.5" size={15} />
                        <div>
                          <span>Ready to deliver?</span>
                          <p className="font-medium text-[10px] text-neutral-400 mt-0.5">Please paste your completed URL, Figma asset, or select simulated file below to deliver to the buyer.</p>
                        </div>
                      </div>

                      <div>
                        <label className="text-[9px] font-extrabold text-neutral-400 block mb-1">ARCHIVE OR LINK SUBMISSION NAME</label>
                        <input
                          type="text"
                          value={deliveryFile}
                          onChange={(e) => setDeliveryFile(e.target.value)}
                          className="w-full text-xs font-bold px-3.5 py-2 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950"
                          required
                        />
                      </div>

                      <div>
                        <label className="text-[9px] font-extrabold text-neutral-400 block mb-1">NOTES TO THE CLIENT</label>
                        <textarea
                          value={deliveryNotes}
                          onChange={(e) => setDeliveryNotes(e.target.value)}
                          rows={3}
                          className="w-full text-xs font-semibold px-3.5 py-2 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950"
                          required
                        />
                      </div>

                      <button
                        type="submit"
                        className="w-full py-3 bg-brand-500 hover:bg-brand-600 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer flex items-center justify-center gap-1.5 transition-colors"
                      >
                        <UploadCloud size={14} />
                        <span>Submit Work Deliverable</span>
                      </button>
                    </form>
                  ) : order.status === 'Delivered' ? (
                    <div className="p-8 text-center text-xs text-neutral-400 space-y-2 bg-neutral-50 dark:bg-neutral-950 rounded-xl">
                      <CheckCircle2 className="text-amber-500 mx-auto" size={32} />
                      <h4 className="font-bold text-neutral-800 dark:text-neutral-200">Work submitted successfully</h4>
                      <p className="max-w-sm mx-auto leading-relaxed">Awaiting buyer review. Sophia James will inspect the deliveries and either approve payouts or request revisions within 3 business days.</p>
                    </div>
                  ) : (
                    <div className="p-8 text-center text-xs text-neutral-400 space-y-2 bg-emerald-50/20 dark:bg-emerald-950/10 border border-emerald-100/30 dark:border-emerald-900/20 rounded-xl">
                      <CheckCircle2 className="text-emerald-500 mx-auto animate-bounce" size={32} />
                      <h4 className="font-bold text-neutral-800 dark:text-neutral-200">Order successfully completed!</h4>
                      <p className="max-w-sm mx-auto leading-relaxed">Secured escrow payouts disbursed. Payout added to your Seller Balance log.</p>
                    </div>
                  )}
                </div>
              )}

              {/* BUYER VIEW - APPROVE & RATING FORM */}
              {isUserBuyer && (
                <div className="space-y-4">
                  {order.status === 'Pending' || order.status === 'Revision Requested' ? (
                    <div className="p-8 text-center text-xs text-neutral-400 space-y-2 bg-neutral-50 dark:bg-neutral-950 rounded-xl">
                      <Clock className="text-brand-500 mx-auto" size={32} />
                      <h4 className="font-bold text-neutral-800 dark:text-neutral-200">Work in Progress</h4>
                      <p className="max-w-sm mx-auto leading-relaxed">Nikolai is hard at work compiling your design systems and layout prototypes. The expected deliverable date is listed on the sidebar.</p>
                    </div>
                  ) : order.status === 'Delivered' ? (
                    <div className="space-y-6">
                      
                      {/* Delivery brief info */}
                      <div className="p-4 bg-amber-50/50 dark:bg-amber-950/15 border border-amber-100 dark:border-amber-900/30 rounded-xl text-xs space-y-2.5">
                        <span className="font-bold text-amber-800 dark:text-amber-400 block uppercase tracking-wider text-[10px]">Freelancer Submission Notes</span>
                        <p className="text-neutral-600 dark:text-neutral-300 font-medium leading-relaxed italic">
                          &quot;{order.deliverySubmission?.text || deliveryNotes}&quot;
                        </p>
                        <div className="flex items-center gap-2 pt-2 border-t border-amber-100/40">
                          <Download size={13} className="text-amber-500" />
                          <span className="font-bold text-neutral-700 dark:text-neutral-300 truncate underline cursor-pointer hover:text-brand-500">
                            {order.deliverySubmission?.files?.[0]?.name || deliveryFile}
                          </span>
                        </div>
                      </div>

                      {/* Approval Review form */}
                      <form onSubmit={handleApproveCompleteSubmit} className="space-y-4 border-t border-neutral-100 dark:border-neutral-800 pt-5">
                        <div className="space-y-1">
                          <label className="text-[10px] font-bold text-neutral-400 block">
                            SELECT GIG RATING (1-5 STARS)
                          </label>
                          <div className="flex items-center gap-2">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <button
                                key={star}
                                type="button"
                                onClick={() => setRating(star)}
                                className="p-1 focus:outline-hidden cursor-pointer hover:scale-110 transition-transform"
                              >
                                <RatingStars rating={star <= rating ? 5 : 0} size={22} />
                              </button>
                            ))}
                            <span className="text-xs font-extrabold text-neutral-800 dark:text-white ml-2">{rating}.0 / 5.0</span>
                          </div>
                        </div>

                        <div>
                          <label className="text-[10px] font-bold text-neutral-400 block mb-1">FEEDBACK REVIEW REMARKS</label>
                          <textarea
                            value={reviewComment}
                            onChange={(e) => setReviewComment(e.target.value)}
                            rows={3}
                            className="w-full text-xs font-semibold px-3.5 py-2.5 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950"
                            required
                          />
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                          <button
                            type="button"
                            onClick={handleRevisionRequestSubmit}
                            className="py-3 rounded-xl border border-neutral-200 hover:bg-neutral-50 font-bold text-neutral-500 text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            <Undo2 size={13} />
                            <span>Request Revision</span>
                          </button>

                          <button
                            type="submit"
                            className="py-3 rounded-xl bg-brand-500 hover:bg-brand-600 text-white font-bold text-xs shadow-md shadow-brand-500/10 flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                          >
                            <Check size={14} />
                            <span>Approve & Complete Order</span>
                          </button>
                        </div>
                      </form>
                    </div>
                  ) : (
                    <div className="p-8 text-center text-xs text-neutral-400 space-y-2 bg-emerald-50/25 dark:bg-emerald-950/10 border border-emerald-100/30 dark:border-emerald-900/30 rounded-xl">
                      <CheckCircle2 className="text-emerald-500 mx-auto" size={32} />
                      <h4 className="font-bold text-neutral-800 dark:text-neutral-200">Order successfully approved and completed!</h4>
                      <p className="max-w-sm mx-auto leading-relaxed">Thank you for rating Nikolai! Your feedback was published on his profile portfolio storefront.</p>
                    </div>
                  )}
                </div>
              )}

              {/* DEMO INSTRUCTIONS EXPLAINER WHEN VIEWED AS NEITHER (fallback/manager mode) */}
              {!isUserBuyer && !isUserSeller && (
                <div className="p-4 bg-amber-50/50 dark:bg-amber-950/15 border border-amber-100 dark:border-amber-900/30 rounded-xl text-xs space-y-2">
                  <span className="font-bold text-amber-800 dark:text-amber-400 block uppercase tracking-wider text-[10px]">Simulated workspace notice</span>
                  <p className="text-neutral-500 font-semibold leading-relaxed">
                    You are currently viewing this Order as a global supervisor. To perform actions, please toggle your workspace role in the top header menu:
                  </p>
                  <div className="flex gap-2.5 pt-1.5">
                    <span className="px-2 py-0.5 rounded bg-brand-100 dark:bg-brand-950 text-brand-800 dark:text-brand-300 font-bold text-[9px] uppercase">
                      Current role: {activeRole.toUpperCase()}
                    </span>
                  </div>
                </div>
              )}

            </div>

            {/* 2. ORDER REQUIREMENTS BRIEF CARD */}
            <div className="bg-white dark:bg-neutral-900 p-6 rounded-2xl border border-neutral-100 dark:border-neutral-800 shadow-sm space-y-3.5">
              <h3 className="text-sm font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-widest pb-3 border-b border-neutral-50 dark:border-neutral-800">
                Buyer Project Instructions Brief
              </h3>
              <div className="p-4 rounded-xl bg-neutral-50 dark:bg-neutral-950 border border-neutral-100 dark:border-neutral-850 text-xs">
                <p className="text-neutral-600 dark:text-neutral-400 leading-relaxed font-semibold">
                  {order.requirementsSubmitted || 'No initial requirements found. Defaulting to general prototype design instructions.'}
                </p>
              </div>
            </div>

            {/* 3. ESCROW DISCUSSIONS LOG FEED */}
            <div className="bg-white dark:bg-neutral-900 rounded-2xl border border-neutral-100 dark:border-neutral-800 shadow-sm overflow-hidden flex flex-col h-[400px]">
              
              {/* Box header */}
              <div className="px-5 py-4 border-b border-neutral-50 dark:border-neutral-800 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <MessageSquare size={14} className="text-brand-500" />
                  <span className="text-xs font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">Escrow Activity Logs & Chat</span>
                </div>
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" title="System Live connected" />
              </div>

              {/* Messages viewport logs */}
              <div className="flex-1 p-5 overflow-y-auto space-y-3.5 bg-neutral-50/50 dark:bg-neutral-900/30">
                {internalLogs.map((log, index) => {
                  const isSys = log.sender === 'System';
                  const isFreelancerLog = log.sender === 'Freelancer';
                  return (
                    <div
                      key={index}
                      className={`flex flex-col max-w-[85%] text-xs ${isSys ? 'mx-auto text-center' : isFreelancerLog ? 'ml-auto items-end' : 'mr-auto items-start'}`}
                    >
                      {isSys ? (
                        <div className="px-3.5 py-1.5 rounded-full bg-neutral-200/60 dark:bg-neutral-800 text-[10px] text-neutral-500 font-semibold italic text-center">
                          {log.text}
                        </div>
                      ) : (
                        <>
                          <span className="text-[9px] text-neutral-400 font-extrabold uppercase mb-0.5">{log.sender}</span>
                          <div className={`p-3 rounded-2xl font-semibold leading-relaxed ${isFreelancerLog ? 'bg-brand-500 text-white rounded-tr-none' : 'bg-white dark:bg-neutral-850 border border-neutral-150/40 dark:border-neutral-800 text-neutral-800 dark:text-neutral-200 rounded-tl-none shadow-3xs'}`}>
                            {log.text}
                          </div>
                          <span className="text-[8px] text-neutral-400 mt-0.5">{log.time}</span>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>

              {/* Inputs bottom bar */}
              <form onSubmit={handleSendMessage} className="p-3 bg-white dark:bg-neutral-900 border-t border-neutral-100 dark:border-neutral-800 flex items-center gap-2">
                <input
                  type="text"
                  placeholder="Type updates or coordination notes..."
                  value={chatMessage}
                  onChange={(e) => setChatMessage(e.target.value)}
                  className="flex-1 text-xs px-3 py-2 border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950 focus:outline-hidden rounded-lg"
                />
                <button
                  type="submit"
                  className="p-2 bg-brand-500 hover:bg-brand-600 text-white rounded-lg flex items-center justify-center transition-colors cursor-pointer"
                >
                  <Send size={13} />
                </button>
              </form>

            </div>

          </div>

          {/* RIGHT COLUMN - TRANSACTION METADATA */}
          <div className="col-span-1 space-y-6">
            
            {/* 1. SECURE ESCROW POLICY STAMP CARD */}
            <div className="bg-emerald-950 text-emerald-100 p-5 rounded-2xl border border-emerald-900 shadow-sm relative overflow-hidden space-y-4">
              <div className="absolute top-0 right-0 w-20 h-20 bg-emerald-800 rounded-full blur-xl opacity-20 pointer-events-none" />
              <div className="flex items-center gap-2 pb-2.5 border-b border-emerald-900">
                <Shield className="text-brand-400 flex-shrink-0" size={16} />
                <h4 className="text-[10px] font-extrabold uppercase tracking-widest text-brand-300">WorkHub Escrow Certified</h4>
              </div>
              <p className="text-[11px] text-neutral-300 leading-relaxed font-semibold">
                Funds are held in secure virtual escrow. Disbursements occur automatically upon client approval or after the delivery review deadline expires.
              </p>
            </div>

            {/* 2. INITIATED GIG SERVICE BRIEF SUMMARY CARD */}
            <div className="bg-white dark:bg-neutral-900 p-5 rounded-2xl border border-neutral-100 dark:border-neutral-800 shadow-xs space-y-4">
              <h4 className="text-xs font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider pb-2 border-b border-neutral-50 dark:border-neutral-800">
                Purchased Listing
              </h4>

              <div className="flex gap-3">
                <img
                  src={service.images[0]}
                  alt={service.title}
                  className="w-16 aspect-video object-cover rounded-lg bg-neutral-100"
                  referrerPolicy="no-referrer"
                />
                <div className="min-w-0 flex-1">
                  <h5 className="text-xs font-bold text-neutral-800 dark:text-neutral-250 line-clamp-2 hover:underline leading-relaxed">
                    <Link to={`/service/${service.id}`}>{service.title}</Link>
                  </h5>
                  <span className="inline-block mt-1 text-[9px] font-extrabold uppercase bg-brand-50 dark:bg-brand-950 text-brand-700 dark:text-brand-300 px-1.5 py-0.5 rounded">
                    {order.packageSelected} Tier
                  </span>
                </div>
              </div>

              {/* Seller details line */}
              <div className="flex items-center justify-between pt-3 border-t border-neutral-50 dark:border-neutral-800 text-xs text-neutral-500 font-semibold">
                <span className="text-neutral-400 font-semibold">Freelancer:</span>
                <Link to={`/seller/${seller.username}`} className="font-bold text-neutral-800 dark:text-neutral-200 hover:underline">
                  @{seller.username}
                </Link>
              </div>

              <div className="flex items-center justify-between text-xs text-neutral-500 font-semibold">
                <span className="text-neutral-400 font-semibold">Investment:</span>
                <span className="font-extrabold text-neutral-800 dark:text-neutral-200">${order.price}</span>
              </div>
            </div>

          </div>

        </div>
      </div>

    </div>
  );
};
