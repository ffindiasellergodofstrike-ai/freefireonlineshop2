import React, { useState, useMemo } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useApp, Service, Seller } from '../context/AppContext';
import { RatingStars } from '../components/RatingStars';
import { ServiceCard } from '../components/ServiceCard';
import {
  Clock,
  RotateCw,
  Check,
  ChevronRight,
  Heart,
  Share2,
  MessageSquare,
  ChevronDown,
  Mail,
  Calendar,
  MapPin,
  FileText,
  Star
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const ServiceDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const {
    services,
    sellers,
    reviews,
    toggleSaveService,
    savedServicesIds,
    startOrGetConversation,
    currentUser,
    showToast
  } = useApp();

  // Find target service
  const service = useMemo(() => services.find(s => s.id === id), [services, id]);

  // Find associated seller
  const seller = useMemo(() => {
    if (!service) return null;
    return sellers.find(s => s.id === service.sellerId);
  }, [sellers, service]);

  // Selected package tab: basic, standard, premium
  const [selectedPackage, setSelectedPackage] = useState<'basic' | 'standard' | 'premium'>('standard');
  const [activeFaq, setActiveFaq] = useState<number | null>(null);
  const [activeGalleryIndex, setActiveGalleryIndex] = useState(0);

  if (!service || !seller) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-4">
        <h2 className="text-lg font-bold text-neutral-800 dark:text-neutral-200">Service listing not found</h2>
        <p className="text-xs text-neutral-400 mt-2">The gig ID might be invalid or has been paused by the seller.</p>
        <Link to="/explore" className="mt-4 px-4 py-2 bg-brand-500 text-white rounded-lg text-xs font-bold">
          Back to marketplace
        </Link>
      </div>
    );
  }

  const isSaved = savedServicesIds.includes(service.id);
  const currentPkgDetails = service.packages[selectedPackage];

  // Filter reviews matching this specific service
  const serviceReviews = reviews.filter(r => r.serviceId === service.id);

  // Find related services (same category, excluding this one)
  const relatedServices = services
    .filter(s => s.categoryId === service.categoryId && s.id !== service.id && s.status === 'Active')
    .slice(0, 3);

  const handleContactSeller = () => {
    const convoId = startOrGetConversation(seller.id, currentUser.id);
    navigate('/dashboard/messages');
    showToast(`Chat inbox opened with ${seller.name}`, 'info');
  };

  const handleCheckoutRedirect = () => {
    navigate(`/checkout?serviceId=${service.id}&package=${selectedPackage}`);
  };

  return (
    <div id="service-detail-page" className="bg-[#FBFBFA] dark:bg-neutral-950 text-neutral-800 dark:text-neutral-100 pb-24 transition-colors">
      
      {/* 1. BREADCRUMBS BAR */}
      <div className="bg-white dark:bg-neutral-900 border-b border-neutral-100 dark:border-neutral-800/80 py-3.5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-1.5 text-[10px] sm:text-xs font-bold text-neutral-400 uppercase tracking-wider">
            <Link to="/" className="hover:text-brand-500">Home</Link>
            <ChevronRight size={12} />
            <Link to="/explore" className="hover:text-brand-500">Marketplace</Link>
            <ChevronRight size={12} />
            <Link to={`/explore?category=${service.categoryId}`} className="hover:text-brand-500 truncate">
              {service.subcategoryId || 'Listing'}
            </Link>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* LEFT 2/3 COLUMN - DESCRIPTION, PORTFOLIO & REVIEWS */}
          <div className="col-span-1 lg:col-span-2 space-y-8">
            
            {/* Title Block */}
            <div className="space-y-4">
              <h1 className="text-xl sm:text-2xl md:text-3xl font-extrabold text-neutral-900 dark:text-white leading-snug">
                {service.title}
              </h1>

              {/* Seller Brief Bar */}
              <div className="flex flex-wrap items-center gap-4 py-2 border-y border-neutral-100 dark:border-neutral-800/80">
                <div className="flex items-center gap-2.5">
                  <img
                    src={seller.avatar}
                    alt={seller.name}
                    className="w-9 h-9 rounded-full object-cover border border-neutral-100 dark:border-neutral-700"
                  />
                  <div>
                    <Link to={`/seller/${seller.username}`} className="text-xs font-bold text-neutral-800 dark:text-neutral-200 hover:underline flex items-center gap-1.5">
                      <span>{seller.name}</span>
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" title="Online" />
                    </Link>
                    <p className="text-[10px] text-neutral-400">@{seller.username}</p>
                  </div>
                </div>

                <div className="h-4 w-px bg-neutral-200 dark:bg-neutral-800" />

                <div className="flex items-center gap-1.5">
                  <RatingStars rating={service.rating} size={14} />
                  <span className="text-xs font-bold text-neutral-800 dark:text-neutral-200">
                    {service.rating.toFixed(2)}
                  </span>
                  <span className="text-xs text-neutral-400">
                    ({service.reviewCount} reviews)
                  </span>
                </div>

                <div className="h-4 w-px bg-neutral-200 dark:bg-neutral-800" />

                <span className="px-2 py-0.5 rounded bg-brand-50 dark:bg-brand-950 text-brand-700 dark:text-brand-300 text-[10px] font-bold uppercase tracking-wider">
                  {seller.level}
                </span>
              </div>
            </div>

            {/* Gallery Image Box */}
            <div className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 rounded-2xl overflow-hidden shadow-sm">
              <div className="relative aspect-video w-full bg-neutral-100 dark:bg-neutral-850">
                <img
                  src={service.images[activeGalleryIndex]}
                  alt={`${service.title} - view ${activeGalleryIndex + 1}`}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Slider Thumbnails navigation */}
              {service.images.length > 1 && (
                <div className="p-3 bg-neutral-50 dark:bg-neutral-900 flex gap-2 border-t border-neutral-50 dark:border-neutral-800">
                  {service.images.map((img, index) => (
                    <button
                      key={img}
                      onClick={() => setActiveGalleryIndex(index)}
                      className={`w-20 aspect-video rounded-md overflow-hidden border-2 transition-all cursor-pointer ${activeGalleryIndex === index ? 'border-brand-500 opacity-100 scale-102' : 'border-transparent opacity-60 hover:opacity-100'}`}
                    >
                      <img src={img} alt="Thumbnail" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Gig Description */}
            <div className="bg-white dark:bg-neutral-900 p-6 rounded-2xl border border-neutral-100 dark:border-neutral-800 shadow-sm space-y-4">
              <h3 className="text-sm font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-widest pb-3 border-b border-neutral-50 dark:border-neutral-800">
                About This Service
              </h3>
              <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed whitespace-pre-line">
                {service.description}
              </p>

              {/* Keywords list tags */}
              <div className="flex flex-wrap gap-2 pt-4">
                {service.tags.map(tag => (
                  <span key={tag} className="text-[10px] font-semibold text-neutral-500 dark:text-neutral-400 bg-neutral-50 dark:bg-neutral-800 border border-neutral-100 dark:border-neutral-700/60 px-2.5 py-1 rounded-md">
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            {/* About Seller Profile Block */}
            <div className="bg-white dark:bg-neutral-900 p-6 rounded-2xl border border-neutral-100 dark:border-neutral-800 shadow-sm space-y-5">
              <h3 className="text-sm font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-widest pb-3 border-b border-neutral-50 dark:border-neutral-800">
                About The Freelancer
              </h3>

              <div className="flex items-start gap-4">
                <img
                  src={seller.avatar}
                  alt={seller.name}
                  className="w-16 h-16 rounded-full object-cover border border-neutral-100 dark:border-neutral-700 shadow-xs"
                />
                <div className="flex-1 space-y-1">
                  <h4 className="font-bold text-neutral-800 dark:text-neutral-200 text-sm">{seller.name}</h4>
                  <p className="text-xs text-neutral-500 dark:text-neutral-400 font-medium">{seller.title}</p>
                  <div className="flex items-center gap-4 text-[11px] text-neutral-400 font-semibold pt-1">
                    <span className="flex items-center gap-1">
                      <MapPin size={12} />
                      <span>{seller.location}</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock size={12} />
                      <span>Avg response: {seller.responseTime}</span>
                    </span>
                  </div>
                </div>
              </div>

              <p className="text-xs text-neutral-500 dark:text-neutral-400 leading-relaxed bg-neutral-50 dark:bg-neutral-850/40 p-4 rounded-xl">
                {seller.bio}
              </p>

              <div className="flex flex-wrap gap-3 pt-2">
                <button
                  onClick={handleContactSeller}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold bg-neutral-50 hover:bg-neutral-100 border border-neutral-200 text-neutral-700 dark:bg-neutral-800 dark:border-neutral-700 dark:text-neutral-300 transition-colors cursor-pointer"
                >
                  <Mail size={13} />
                  <span>Contact Freelancer</span>
                </button>
                <Link
                  to={`/seller/${seller.username}`}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-bold bg-brand-50 hover:bg-brand-100 text-brand-600 dark:bg-brand-950/40 dark:text-brand-400 border border-brand-100 dark:border-brand-900/30 transition-colors"
                >
                  <span>View Public Portfolio</span>
                </Link>
              </div>
            </div>

            {/* FAQs Accordion */}
            {service.faq && service.faq.length > 0 && (
              <div className="space-y-4">
                <h3 className="text-sm font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-widest pl-1">
                  Frequently Asked Questions
                </h3>
                <div className="space-y-2">
                  {service.faq.map((faq, index) => {
                    const isOpen = activeFaq === index;
                    return (
                      <div
                        key={index}
                        className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800/80 rounded-xl overflow-hidden transition-all duration-200"
                      >
                        <button
                          onClick={() => setActiveFaq(isOpen ? null : index)}
                          className="w-full flex items-center justify-between p-4.5 text-left text-xs font-bold text-neutral-800 dark:text-neutral-200 focus:outline-hidden"
                        >
                          <span>{faq.question}</span>
                          <ChevronDown
                            size={14}
                            className={`text-neutral-400 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`}
                          />
                        </button>
                        <AnimatePresence>
                          {isOpen && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: 'auto', opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              className="overflow-hidden border-t border-neutral-50 dark:border-neutral-800"
                            >
                              <p className="p-4.5 text-xs text-neutral-500 dark:text-neutral-400 leading-relaxed">
                                {faq.answer}
                              </p>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Reviews Block Feed */}
            <div className="bg-white dark:bg-neutral-900 p-6 rounded-2xl border border-neutral-100 dark:border-neutral-800 shadow-sm space-y-6">
              <div className="flex items-center justify-between pb-3 border-b border-neutral-50 dark:border-neutral-800">
                <h3 className="text-sm font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-widest">
                  Client Reviews ({serviceReviews.length})
                </h3>
                <div className="flex items-center gap-1">
                  <Star size={13} className="fill-amber-400 text-amber-400" />
                  <span className="text-xs font-extrabold text-neutral-800 dark:text-neutral-200">{service.rating.toFixed(2)}</span>
                </div>
              </div>

              {serviceReviews.length === 0 ? (
                <div className="text-center py-8 text-xs text-neutral-400">
                  No written reviews yet for this listing. Be the first to order!
                </div>
              ) : (
                <div className="divide-y divide-neutral-50 dark:divide-neutral-800 space-y-5">
                  {serviceReviews.map((rev) => (
                    <div key={rev.id} className="pt-5 first:pt-0 space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-full bg-brand-100 dark:bg-brand-950/60 flex items-center justify-center font-bold text-xs text-brand-600 dark:text-brand-400">
                            B
                          </div>
                          <div>
                            <span className="text-xs font-bold text-neutral-800 dark:text-neutral-200">Verified Client</span>
                            <p className="text-[9px] text-neutral-400">Country: Global</p>
                          </div>
                        </div>
                        <span className="text-[10px] text-neutral-400">{rev.date}</span>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <RatingStars rating={rev.rating} size={11} />
                        <span className="text-xs font-bold text-neutral-700 dark:text-neutral-300">{rev.rating}.0</span>
                      </div>

                      <p className="text-xs text-neutral-500 dark:text-neutral-400 leading-relaxed font-medium">
                        &quot;{rev.comment}&quot;
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>

          {/* RIGHT STICKY PACKAGE PRICING CARD */}
          <div className="col-span-1">
            <div className="sticky top-24 space-y-6">
              
              {/* Main Pricing Package Selection Panel */}
              <div className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800/80 rounded-2xl shadow-md overflow-hidden">
                
                {/* 3 Package selection Tabs */}
                <div className="grid grid-cols-3 border-b border-neutral-100 dark:border-neutral-800">
                  {(['basic', 'standard', 'premium'] as const).map(tab => (
                    <button
                      key={tab}
                      onClick={() => setSelectedPackage(tab)}
                      className={`py-3.5 text-xs font-bold uppercase tracking-wider text-center border-b-2 cursor-pointer transition-all ${selectedPackage === tab ? 'border-brand-500 text-brand-600 dark:text-brand-400 bg-brand-50/20 dark:bg-brand-950/10' : 'border-transparent text-neutral-400 hover:text-neutral-600 hover:bg-neutral-50/50 dark:hover:bg-neutral-800/30'}`}
                    >
                      {tab}
                    </button>
                  ))}
                </div>

                {/* Package details Body */}
                <div className="p-6 space-y-5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-neutral-400">
                      Investment
                    </span>
                    <span className="text-2xl font-extrabold text-neutral-900 dark:text-white">
                      ${currentPkgDetails.price}
                    </span>
                  </div>

                  <p className="text-[11px] text-neutral-400 font-semibold uppercase leading-relaxed tracking-wider">
                    Package Deliverables Summary
                  </p>

                  <div className="flex items-center justify-between py-2 border-y border-neutral-50 dark:border-neutral-800 text-[11px] text-neutral-500 font-bold uppercase tracking-wider">
                    <span className="flex items-center gap-1.5">
                      <Clock size={13} className="text-neutral-400" />
                      <span>{currentPkgDetails.deliveryTime} Days Delivery</span>
                    </span>
                    <span className="flex items-center gap-1.5">
                      <RotateCw size={12} className="text-neutral-400" />
                      <span>
                        {currentPkgDetails.revisions === -1 ? 'Unlimited' : `${currentPkgDetails.revisions} Revisions`}
                      </span>
                    </span>
                  </div>

                  {/* Bullet features checklists */}
                  <ul className="space-y-2.5 pt-1">
                    {currentPkgDetails.features.map(feat => (
                      <li key={feat} className="flex items-start gap-2 text-xs font-medium text-neutral-600 dark:text-neutral-400">
                        <Check size={14} className="text-emerald-500 flex-shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>

                  {/* Continue Button */}
                  <button
                    onClick={handleCheckoutRedirect}
                    className="w-full py-3.5 px-4 rounded-xl bg-brand-500 hover:bg-brand-600 text-white font-bold text-xs shadow-md shadow-brand-500/20 transition-all flex items-center justify-center gap-1.5 cursor-pointer mt-4"
                  >
                    <span>Proceed to Secure Checkout</span>
                    <ChevronRight size={14} />
                  </button>

                  <p className="text-[10px] text-neutral-400 text-center font-medium leading-relaxed">
                    Virtual Escrow Secured Payouts. Satisfactions guaranteed.
                  </p>
                </div>
              </div>

              {/* Share/Actions block */}
              <div className="flex items-center justify-between px-4 py-3 bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 rounded-xl shadow-2xs">
                <button
                  onClick={() => toggleSaveService(service.id)}
                  className="flex items-center gap-1.5 text-xs font-bold text-neutral-500 hover:text-rose-500 transition-colors cursor-pointer"
                >
                  <Heart size={14} className={isSaved ? 'fill-rose-500 text-rose-500' : ''} />
                  <span>{isSaved ? 'Saved in list' : 'Save this Gig'}</span>
                </button>

                <button
                  onClick={() => {
                    navigator.clipboard.writeText(window.location.href);
                    showToast('Link copied to clipboard!', 'success');
                  }}
                  className="flex items-center gap-1.5 text-xs font-bold text-neutral-500 hover:text-brand-500 transition-colors cursor-pointer"
                >
                  <Share2 size={13} />
                  <span>Share Gig</span>
                </button>
              </div>

            </div>
          </div>

        </div>

        {/* RELATED GIGS FOOTER PANEL */}
        {relatedServices.length > 0 && (
          <div className="pt-20 border-t border-neutral-100 dark:border-neutral-800/80 mt-20 space-y-8">
            <h3 className="text-base sm:text-lg font-bold text-neutral-900 dark:text-white">
              Related Services Recommended For You
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              {relatedServices.map(rel => (
                <div key={rel.id} className="h-full">
                  <ServiceCard service={rel} />
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
