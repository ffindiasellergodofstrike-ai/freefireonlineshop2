import React, { useState, useMemo } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Shield, CreditCard, ChevronRight, CheckCircle2, Lock, FileText, Sparkles, Loader } from 'lucide-react';

export const Checkout: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { services, sellers, createOrder, showToast } = useApp();

  const serviceId = searchParams.get('serviceId') || '';
  const tier = (searchParams.get('package') || 'standard') as 'basic' | 'standard' | 'premium';

  // Find target service
  const service = useMemo(() => services.find(s => s.id === serviceId), [services, serviceId]);
  
  // Find associated seller
  const seller = useMemo(() => {
    if (!service) return null;
    return sellers.find(s => s.id === service.sellerId);
  }, [sellers, service]);

  // Briefing instructions state
  const [requirements, setRequirements] = useState('');
  
  // Credit Card States (Preloaded with authentic placeholders)
  const [cardName, setCardName] = useState('SOPHIA JAMES');
  const [cardNumber, setCardNumber] = useState('4111 2222 3333 4444');
  const [cardExpiry, setCardExpiry] = useState('12/28');
  const [cardCvv, setCardCvv] = useState('321');

  const [loading, setLoading] = useState(false);

  if (!service || !seller) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-4">
        <h2 className="text-lg font-bold text-neutral-800 dark:text-neutral-200">Checkout target invalid</h2>
        <p className="text-xs text-neutral-400 mt-1">Please select an active service package from the browse directory first.</p>
        <Link to="/explore" className="mt-4 px-4 py-2 bg-brand-500 text-white rounded-lg text-xs font-bold">
          Browse Marketplace Gigs
        </Link>
      </div>
    );
  }

  const pkgDetails = service.packages[tier];
  const subtotal = pkgDetails.price;
  const handlingFee = parseFloat((subtotal * 0.025).toFixed(2));
  const total = subtotal + handlingFee;

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!requirements.trim()) {
      showToast('Please provide brief project guidelines for the freelancer!', 'error');
      return;
    }

    setLoading(true);

    // Simulate standard credit validation delay
    setTimeout(() => {
      const newOrderId = createOrder(service.id, tier, requirements);
      setLoading(false);
      showToast(`Order secured! Order Reference: WH-2026-${newOrderId}`, 'success');
      navigate(`/dashboard/order/${newOrderId}`);
    }, 1500);
  };

  return (
    <div id="checkout-page" className="bg-[#FBFBFA] dark:bg-neutral-950 text-neutral-800 dark:text-neutral-100 pb-24 pt-10 transition-colors">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Checkout Header Progress title */}
        <div className="flex items-center gap-3 mb-10 pb-5 border-b border-neutral-100 dark:border-neutral-850">
          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-brand-50 dark:bg-brand-950 text-brand-500">
            <Lock size={15} />
          </div>
          <div>
            <h1 className="text-lg sm:text-xl font-extrabold text-neutral-900 dark:text-white">Secure Checkout Panel</h1>
            <p className="text-[10px] text-neutral-400 uppercase tracking-widest font-bold">Escrow Payout Safety Guaranteed</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* LEFT 2/3 COLUMN: CHECKOUT STEPS FORM */}
          <form onSubmit={handlePlaceOrder} className="col-span-1 lg:col-span-2 space-y-6">
            
            {/* STEP 1: PROJECT BRIEFING */}
            <div className="bg-white dark:bg-neutral-900 p-6 rounded-2xl border border-neutral-100 dark:border-neutral-800 shadow-xs space-y-4">
              <div className="flex items-center gap-2 pb-3 border-b border-neutral-50 dark:border-neutral-800">
                <div className="flex items-center justify-center w-5.5 h-5.5 rounded-md bg-brand-500 text-white font-bold text-xs">1</div>
                <h3 className="text-xs font-bold uppercase tracking-widest text-neutral-800 dark:text-neutral-200">
                  Freelancer Project Guidelines
                </h3>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold text-neutral-400 block">
                  REQUIREMENTS BRIEF (REQUIRED)
                </label>
                <textarea
                  value={requirements}
                  onChange={(e) => setRequirements(e.target.value)}
                  rows={4}
                  required
                  placeholder="Share details, website wireframes, copy instructions, or API key configurations for Nikolai to begin work..."
                  className="w-full text-xs font-medium px-4 py-3 rounded-xl border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950 focus:outline-hidden text-neutral-800 dark:text-white focus:ring-1 focus:ring-brand-500 focus:border-brand-500 placeholder-neutral-400"
                />
                <span className="text-[10px] text-neutral-400 font-semibold block flex items-center gap-1.5 pt-1">
                  <FileText size={12} className="text-neutral-400" />
                  <span>These instructions will be preloaded inside Nikolai&apos;s Workspace dashboard.</span>
                </span>
              </div>
            </div>

            {/* STEP 2: CREDIT CARD DETAILS */}
            <div className="bg-white dark:bg-neutral-900 p-6 rounded-2xl border border-neutral-100 dark:border-neutral-800 shadow-xs space-y-5">
              <div className="flex items-center gap-2 pb-3 border-b border-neutral-50 dark:border-neutral-800">
                <div className="flex items-center justify-center w-5.5 h-5.5 rounded-md bg-brand-500 text-white font-bold text-xs">2</div>
                <h3 className="text-xs font-bold uppercase tracking-widest text-neutral-800 dark:text-neutral-200">
                  Simulated Billing Settlement
                </h3>
              </div>

              {/* Sample test numbers hint */}
              <div className="flex items-start gap-2.5 p-3.5 bg-brand-50/50 dark:bg-brand-950/15 border border-brand-100/30 dark:border-brand-900/30 rounded-xl text-[11px] text-brand-700 dark:text-brand-300 font-medium">
                <Sparkles className="flex-shrink-0 mt-0.5" size={14} />
                <span>We preloaded active simulated credentials below! Feel free to modify, or click check directly without real payments risk.</span>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-[9px] font-extrabold text-neutral-400 block mb-1">CARDHOLDER NAME</label>
                  <input
                    type="text"
                    value={cardName}
                    onChange={(e) => setCardName(e.target.value)}
                    className="w-full text-xs font-bold px-3.5 py-2.5 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950 focus:outline-hidden"
                    required
                  />
                </div>

                <div>
                  <label className="text-[9px] font-extrabold text-neutral-400 block mb-1">CREDIT CARD NUMBER</label>
                  <div className="relative flex items-center">
                    <input
                      type="text"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      className="w-full text-xs font-bold px-3.5 py-2.5 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950 focus:outline-hidden"
                      required
                    />
                    <CreditCard size={15} className="absolute right-3.5 text-neutral-400" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[9px] font-extrabold text-neutral-400 block mb-1">EXPIRATION DATE</label>
                    <input
                      type="text"
                      value={cardExpiry}
                      onChange={(e) => setCardExpiry(e.target.value)}
                      className="w-full text-xs font-bold px-3.5 py-2.5 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950 text-center"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-extrabold text-neutral-400 block mb-1">CVV SECURE CODE</label>
                    <input
                      type="text"
                      value={cardCvv}
                      onChange={(e) => setCardCvv(e.target.value)}
                      className="w-full text-xs font-bold px-3.5 py-2.5 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950 text-center"
                      maxLength={4}
                      required
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* SECURE SUBMIT GROUP */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 rounded-xl shadow-2xs">
              <span className="text-[10px] text-neutral-400 font-bold italic flex items-center gap-1.5">
                <Shield size={13} className="text-emerald-500" />
                <span>256-bit SSL encrypted transmission connection</span>
              </span>
              <button
                type="submit"
                disabled={loading}
                className="w-full sm:w-auto px-8 py-3 rounded-xl bg-brand-500 hover:bg-brand-600 text-white font-bold text-xs shadow-md shadow-brand-500/20 flex items-center justify-center gap-2 cursor-pointer transition-colors"
              >
                {loading ? (
                  <>
                    <Loader size={14} className="animate-spin" />
                    <span>Processing secured Escrow...</span>
                  </>
                ) : (
                  <>
                    <span>Confirm and Place Order</span>
                    <ChevronRight size={14} />
                  </>
                )}
              </button>
            </div>

          </form>

          {/* RIGHT 1/3 COLUMN: ORDER COST ESTIMATE SUMMARY */}
          <div className="col-span-1">
            <div className="bg-white dark:bg-neutral-900 p-6 rounded-2xl border border-neutral-100 dark:border-neutral-800/80 shadow-md space-y-6">
              
              <h3 className="text-xs font-extrabold text-neutral-800 dark:text-neutral-200 uppercase tracking-widest pb-3 border-b border-neutral-50 dark:border-neutral-800">
                Order Summary
              </h3>

              {/* Service Gig mini preview card */}
              <div className="flex items-start gap-3">
                <img
                  src={service.images[0]}
                  alt={service.title}
                  className="w-16 aspect-video object-cover rounded-lg bg-neutral-100 border border-neutral-150 dark:border-neutral-850"
                  referrerPolicy="no-referrer"
                />
                <div className="flex-1 min-w-0">
                  <h4 className="text-xs font-bold text-neutral-800 dark:text-neutral-100 hover:text-brand-500 line-clamp-2 leading-relaxed">
                    {service.title}
                  </h4>
                  <p className="text-[9px] text-brand-600 dark:text-brand-400 font-extrabold uppercase mt-1">
                    {tier} tier Package
                  </p>
                </div>
              </div>

              {/* Package detailed items bullets summary */}
              <div className="bg-neutral-50 dark:bg-neutral-950 p-4 rounded-xl space-y-2">
                <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">Included Services:</span>
                <div className="flex justify-between text-[11px] text-neutral-500 font-bold uppercase">
                  <span>Delivery Duration</span>
                  <span className="text-neutral-800 dark:text-neutral-200">{pkgDetails.deliveryTime} Days</span>
                </div>
                <div className="flex justify-between text-[11px] text-neutral-500 font-bold uppercase">
                  <span>Included Revisions</span>
                  <span className="text-neutral-800 dark:text-neutral-200">
                    {pkgDetails.revisions === -1 ? 'Unlimited' : `${pkgDetails.revisions} Revisions`}
                  </span>
                </div>
              </div>

              {/* Billing Costs detail lines */}
              <div className="space-y-3.5 pt-5 border-t border-neutral-100 dark:border-neutral-800 text-xs">
                <div className="flex justify-between items-center text-neutral-500 font-medium">
                  <span>Subtotal</span>
                  <span className="font-bold text-neutral-800 dark:text-neutral-200">${subtotal}</span>
                </div>
                <div className="flex justify-between items-center text-neutral-500 font-medium">
                  <span>WorkHub handling fee (2.5%)</span>
                  <span className="font-bold text-neutral-800 dark:text-neutral-200">${handlingFee}</span>
                </div>
                <div className="flex justify-between items-center text-neutral-500 font-medium pt-3 border-t border-neutral-50 dark:border-neutral-800">
                  <span className="text-sm font-bold text-neutral-800 dark:text-neutral-100">Total settlement</span>
                  <span className="text-lg font-extrabold text-brand-600 dark:text-brand-400">${total}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-neutral-100 dark:border-neutral-800/80">
                <div className="flex items-center gap-1.5 justify-center text-[10px] text-neutral-400 font-semibold">
                  <Lock size={11} className="text-brand-500" />
                  <span>Payments settled via simulated SSL.</span>
                </div>
              </div>

            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
