import React, { useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useApp, Order, Seller, Category } from '../context/AppContext';
import { RatingStars } from '../components/RatingStars';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';
import {
  ShieldAlert,
  Database,
  Users,
  Layers,
  FolderPlus,
  TrendingUp,
  FileSpreadsheet,
  Check,
  Zap,
  Activity,
  Award
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const {
    orders,
    sellers,
    categories,
    addCategory,
    approveOrderAndReview,
    showToast
  } = useApp();

  // Active sub-tab
  const [subTab, setSubTab] = useState<'orders' | 'sellers' | 'categories'>('orders');

  // New category form state
  const [catName, setCatName] = useState('Mobile Engineering');
  const [catIcon, setCatIcon] = useState('Cpu');
  const [catDesc, setCatDesc] = useState('Hire senior Swift and Kotlin developers specialized in native application building.');

  // Statistics
  const totalVolume = useMemo(() => orders.reduce((sum, o) => sum + o.price, 0), [orders]);
  const activeEscrowVolume = useMemo(() => {
    return orders.filter(o => o.status !== 'Completed').reduce((sum, o) => sum + o.price, 0);
  }, [orders]);

  const platformRevenue = useMemo(() => {
    return parseFloat((totalVolume * 0.025).toFixed(2));
  }, [totalVolume]);

  const handleCreateCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!catName.trim() || !catDesc.trim()) {
      showToast('Please fill in category name and details!', 'error');
      return;
    }
    const newSlug = catName.toLowerCase().replace(/\s+/g, '-');
    addCategory({
      id: `cat-${Date.now()}`,
      name: catName,
      slug: newSlug,
      icon: catIcon,
      description: catDesc,
      image: 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=500&auto=format&fit=crop&q=80'
    });
    setCatName('');
    setCatDesc('');
    showToast(`New category "${catName}" registered successfully!`, 'success');
  };

  const handleAdminForceComplete = (orderId: string) => {
    approveOrderAndReview(orderId, 5, 'Settle-disbursement forced via Admin Operator Console.');
    showToast(`Order ${orderId} administrative settlement complete! Escrow disbursed.`, 'success');
  };

  // Recharts data
  const dailySettlementsData = [
    { date: 'Sep 15', volume: 4500 },
    { date: 'Sep 16', volume: 6200 },
    { date: 'Sep 17', volume: 5100 },
    { date: 'Sep 18', volume: 8300 },
    { date: 'Sep 19', volume: 7400 },
    { date: 'Sep 20', volume: totalVolume || 9500 }
  ];

  const weeklyFeeData = [
    { week: 'Wk 34', fee: 120 },
    { week: 'Wk 35', fee: 240 },
    { week: 'Wk 36', fee: 380 },
    { week: 'Wk 37', fee: platformRevenue || 450 }
  ];

  return (
    <div id="admin-dashboard" className="bg-[#FBFBFA] dark:bg-neutral-950 text-neutral-800 dark:text-neutral-100 pb-24 pt-10 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title area */}
        <div className="border-b border-neutral-100 dark:border-neutral-850 pb-5 mb-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-9 h-9 rounded-xl bg-amber-500 text-white font-bold text-lg shadow-xs shadow-amber-500/20">
              <Database size={18} />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-extrabold text-neutral-900 dark:text-white">Admin System Operations Panel</h1>
              <p className="text-xs text-neutral-400">Auditing and overseeing platform ledger, account logs, and category indices.</p>
            </div>
          </div>

          <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400 border border-amber-100 dark:border-amber-900/30 text-[10px] font-bold uppercase tracking-wider">
            <Activity size={12} className="animate-pulse" />
            <span>Operational Sandbox Live</span>
          </span>
        </div>

        {/* 1. OPERATIONS STATISTICS */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-6 mb-10 text-xs">
          
          <div className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 p-5 rounded-2xl shadow-xs space-y-1">
            <span className="text-[10px] text-neutral-400 font-bold block uppercase tracking-wider">Gross Transaction Volume</span>
            <h3 className="text-2xl font-extrabold text-neutral-900 dark:text-white">${totalVolume}</h3>
            <p className="text-[10px] text-neutral-500 font-semibold italic">Marketplace transaction cumulative sum</p>
          </div>

          <div className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 p-5 rounded-2xl shadow-xs space-y-1">
            <span className="text-[10px] text-neutral-400 font-bold block uppercase tracking-wider">Locked Escrow Pool</span>
            <h3 className="text-2xl font-extrabold text-amber-600 dark:text-amber-400">${activeEscrowVolume}</h3>
            <p className="text-[10px] text-neutral-500 font-semibold italic">Capital secured awaiting buyer approval</p>
          </div>

          <div className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 p-5 rounded-2xl shadow-xs space-y-1">
            <span className="text-[10px] text-neutral-400 font-bold block uppercase tracking-wider">Platform Commission (2.5%)</span>
            <h3 className="text-2xl font-extrabold text-emerald-500 dark:text-emerald-400">${platformRevenue}</h3>
            <p className="text-[10px] text-neutral-500 font-semibold italic">Net transaction handling volume</p>
          </div>

          <div className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 p-5 rounded-2xl shadow-xs space-y-1">
            <span className="text-[10px] text-neutral-400 font-bold block uppercase tracking-wider">Registered Freelancers</span>
            <h3 className="text-2xl font-extrabold text-neutral-900 dark:text-white">{sellers.length} Profiles</h3>
            <p className="text-[10px] text-neutral-500 font-semibold italic">Certified elite active sellers</p>
          </div>

        </div>

        {/* 2. OPERATIONAL PLOTS */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
          
          <div className="bg-white dark:bg-neutral-900 p-5 border border-neutral-100 dark:border-neutral-800 rounded-2xl shadow-xs space-y-4">
            <h4 className="text-xs font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider border-b border-neutral-50 dark:border-neutral-800 pb-3">
              Daily Marketplace Settlements ($)
            </h4>
            <div className="h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={dailySettlementsData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E5E5" />
                  <XAxis dataKey="date" stroke="#A3A3A3" fontSize={10} tickLine={false} />
                  <YAxis stroke="#A3A3A3" fontSize={10} tickLine={false} />
                  <Tooltip />
                  <Area type="monotone" dataKey="volume" stroke="#F59E0B" fill="rgba(245, 158, 11, 0.1)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-white dark:bg-neutral-900 p-5 border border-neutral-100 dark:border-neutral-800 rounded-2xl shadow-xs space-y-4">
            <h4 className="text-xs font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider border-b border-neutral-50 dark:border-neutral-800 pb-3">
              Platform Fees Commission Accumulation ($)
            </h4>
            <div className="h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={weeklyFeeData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E5E5" />
                  <XAxis dataKey="week" stroke="#A3A3A3" fontSize={10} tickLine={false} />
                  <YAxis stroke="#A3A3A3" fontSize={10} tickLine={false} />
                  <Tooltip cursor={{ fill: 'rgba(0,0,0,0.01)' }} />
                  <Bar dataKey="fee" fill="#10B981" radius={[4, 4, 0, 0]} barSize={25} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

        </div>

        {/* 3. DUAL SUB-TAB TOGGLES */}
        <div className="flex border-b border-neutral-200 dark:border-neutral-850 mb-8 overflow-x-auto text-xs font-bold uppercase select-none">
          {[
            { id: 'orders', label: `System Orders Ledger (${orders.length})`, icon: FileSpreadsheet },
            { id: 'sellers', label: `Freelancers registry (${sellers.length})`, icon: Users },
            { id: 'categories', label: `Categories Auditor (${categories.length})`, icon: Layers }
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = subTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setSubTab(tab.id as any)}
                className={`py-3.5 px-4 border-b-2 flex items-center gap-2 whitespace-nowrap cursor-pointer transition-all ${isActive ? 'border-amber-500 text-amber-600 dark:text-amber-400 bg-amber-50/20 dark:bg-amber-950/10' : 'border-transparent text-neutral-400 hover:text-neutral-600 hover:bg-neutral-50/20 dark:hover:bg-neutral-800/30'}`}
              >
                <Icon size={13} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* 4. OPERATIONAL WORKSPACE ACTIONS */}
        <div className="space-y-6">
          
          {/* TAB A: SYSTEM ORDERS LEDGER */}
          {subTab === 'orders' && (
            <div className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 rounded-2xl overflow-hidden shadow-xs">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-neutral-50/50 dark:bg-neutral-950/40 border-b border-neutral-100 dark:border-neutral-800 text-neutral-400 font-bold uppercase tracking-wider text-[10px]">
                    <th className="p-4 pl-6">Order ID</th>
                    <th className="p-4">Buyer ID</th>
                    <th className="p-4">Seller ID</th>
                    <th className="p-4">Price</th>
                    <th className="p-4">Date</th>
                    <th className="p-4">Status</th>
                    <th className="p-4 pr-6 text-right">Audit override</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-50 dark:divide-neutral-800 font-medium">
                  {orders.map((ord) => (
                    <tr key={ord.id} className="hover:bg-neutral-50/10">
                      <td className="p-4 pl-6 font-bold text-neutral-500">WH-2026-{ord.id}</td>
                      <td className="p-4 text-neutral-500 font-semibold">@{ord.buyerId === 'usr-102' ? 'sophia' : 'buyer'}</td>
                      <td className="p-4 text-neutral-500 font-semibold">@{ord.sellerId === 'usr-101' ? 'nikolai' : 'seller'}</td>
                      <td className="p-4 font-bold text-neutral-900 dark:text-neutral-100">${ord.price}</td>
                      <td className="p-4 text-neutral-400">{ord.createdAt}</td>
                      <td className="p-4">
                        <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase ${ord.status === 'Completed' ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400' : ord.status === 'Delivered' ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400' : 'bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-400'}`}>
                          {ord.status}
                        </span>
                      </td>
                      <td className="p-4 pr-6 text-right">
                        {ord.status !== 'Completed' ? (
                          <button
                            onClick={() => handleAdminForceComplete(ord.id)}
                            className="inline-flex items-center gap-1 px-2.5 py-1 text-[10px] font-extrabold uppercase bg-amber-50 hover:bg-amber-100 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400 border border-amber-100 dark:border-amber-900/40 rounded-md cursor-pointer transition-colors"
                          >
                            <Check size={10} />
                            <span>Force Settle</span>
                          </button>
                        ) : (
                          <span className="text-[10px] font-bold text-neutral-400">Settle archived</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* TAB B: FREELANCERS DIRECTORY */}
          {subTab === 'sellers' && (
            <div className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 rounded-2xl overflow-hidden shadow-xs">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-neutral-50/50 dark:bg-neutral-950/40 border-b border-neutral-100 dark:border-neutral-800 text-neutral-400 font-bold uppercase tracking-wider text-[10px]">
                    <th className="p-4 pl-6">Profile</th>
                    <th className="p-4">Expert title</th>
                    <th className="p-4">Region</th>
                    <th className="p-4">Rating average</th>
                    <th className="p-4 pr-6 text-right">Workspace link</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-50 dark:divide-neutral-800 font-medium">
                  {sellers.map((sel) => (
                    <tr key={sel.id} className="hover:bg-neutral-50/10">
                      <td className="p-4 pl-6">
                        <div className="flex items-center gap-2.5">
                          <img src={sel.avatar} className="w-7 h-7 rounded-full object-cover border border-neutral-200" alt="" />
                          <div>
                            <span className="font-bold text-neutral-850 dark:text-neutral-100 block">{sel.name}</span>
                            <span className="text-[9px] text-neutral-400 block">@{sel.username}</span>
                          </div>
                        </div>
                      </td>
                      <td className="p-4 text-neutral-600 dark:text-neutral-350 font-semibold">{sel.title}</td>
                      <td className="p-4 font-bold text-neutral-500">{sel.location}</td>
                      <td className="p-4">
                        <div className="flex items-center gap-1.5">
                          <RatingStars rating={sel.rating} size={11} />
                          <span className="font-bold text-neutral-700">{sel.rating.toFixed(2)}</span>
                        </div>
                      </td>
                      <td className="p-4 pr-6 text-right">
                        <Link
                          to={`/seller/${sel.username}`}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded text-[10px] font-extrabold uppercase bg-neutral-100 hover:bg-neutral-200 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300 transition-colors"
                        >
                          <span>Storefront</span>
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* TAB C: CATEGORIES SYSTEM AUDITOR */}
          {subTab === 'categories' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              
              {/* Add category form */}
              <div className="col-span-1 bg-white dark:bg-neutral-900 p-5 rounded-2xl border border-neutral-100 dark:border-neutral-800 shadow-xs space-y-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-neutral-800 dark:text-neutral-200 border-b border-neutral-50 dark:border-neutral-800 pb-2 flex items-center gap-1.5">
                  <FolderPlus size={13} className="text-amber-500" />
                  <span>Register Category</span>
                </h4>
                
                <form onSubmit={handleCreateCategory} className="space-y-4">
                  <div>
                    <label className="text-[9px] font-extrabold text-neutral-400 block mb-1">CATEGORY DISPLAY NAME</label>
                    <input
                      type="text"
                      value={catName}
                      onChange={(e) => setCatName(e.target.value)}
                      className="w-full text-xs font-semibold px-3 py-2 rounded-lg border border-neutral-200 dark:border-neutral-850"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-[9px] font-extrabold text-neutral-400 block mb-1">LUCIDE ICON MAP KEY</label>
                    <select
                      value={catIcon}
                      onChange={(e) => setCatIcon(e.target.value)}
                      className="w-full text-xs font-semibold px-3 py-2 bg-neutral-50 dark:bg-neutral-950 border border-neutral-200 rounded-lg"
                    >
                      <option value="Cpu">Cpu (Engineering)</option>
                      <option value="Palette">Palette (Graphics)</option>
                      <option value="Code">Code (Software)</option>
                      <option value="Briefcase">Briefcase (SaaS Consulting)</option>
                      <option value="Camera">Camera (Media)</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[9px] font-extrabold text-neutral-400 block mb-1">BRIEF DESCRIPTION STATEMENT</label>
                    <textarea
                      value={catDesc}
                      onChange={(e) => setCatDesc(e.target.value)}
                      rows={3}
                      className="w-full text-xs font-semibold px-3 py-2 rounded-lg border border-neutral-200"
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs rounded-xl shadow-xs cursor-pointer transition-colors"
                  >
                    Register Category Index
                  </button>
                </form>
              </div>

              {/* Category audit list */}
              <div className="col-span-2 bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 rounded-2xl overflow-hidden shadow-xs">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-neutral-50/50 dark:bg-neutral-950 border-b border-neutral-100 dark:border-neutral-800 text-neutral-400 font-bold uppercase tracking-wider text-[10px]">
                      <th className="p-4 pl-6">Display name</th>
                      <th className="p-4">Url Category Slug</th>
                      <th className="p-4">Description brief</th>
                      <th className="p-4 pr-6 text-right">Mapped icon</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-50 dark:divide-neutral-800 font-medium">
                    {categories.map((cat) => (
                      <tr key={cat.id} className="hover:bg-neutral-50/10">
                        <td className="p-4 pl-6 font-bold text-neutral-800 dark:text-neutral-100">{cat.name}</td>
                        <td className="p-4 font-mono text-neutral-400 text-[10px]">{cat.slug}</td>
                        <td className="p-4 text-neutral-500 font-semibold max-w-xs truncate">{cat.description}</td>
                        <td className="p-4 pr-6 text-right font-mono text-neutral-400">{cat.icon}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
};
