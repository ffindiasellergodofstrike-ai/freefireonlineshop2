import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { Link, useNavigate } from 'react-router-dom';
import { ServiceCard } from '../components/ServiceCard';
import { SellerCard } from '../components/SellerCard';
import {
  Briefcase,
  TrendingUp,
  Clock,
  Heart,
  Users,
  CheckCircle2,
  ExternalLink,
  PlusCircle,
  FileSpreadsheet,
  HelpCircle,
  ArrowRight,
  Database
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const BuyerDashboard: React.FC = () => {
  const navigate = useNavigate();
  const {
    currentUser,
    orders,
    services,
    sellers,
    savedServicesIds,
    savedSellersIds,
    buyerRequests,
    addBuyerRequest,
    showToast
  } = useApp();

  const [activeTab, setActiveTab] = useState<'hires' | 'saved-gigs' | 'saved-freelancers' | 'requests'>('hires');

  // Request form state
  const [requestTitle, setRequestTitle] = useState('Build a custom payment flow with Stripe and React');
  const [requestDesc, setRequestDesc] = useState('We are looking for a senior front-end engineer to build a multi-step credit card and Stripe integration wizard using TypeScript. Must be fully responsive.');
  const [requestBudget, setRequestBudget] = useState(350);
  const [requestDuration, setRequestDuration] = useState('5 days');

  const [showRequestForm, setShowRequestForm] = useState(false);

  // Filter orders matching current buyer ID
  const buyerOrders = useMemo(() => orders.filter(o => o.buyerId === currentUser.id), [orders, currentUser]);

  // Aggregate metrics
  const totalSpend = useMemo(() => buyerOrders.reduce((acc, o) => acc + o.price, 0), [buyerOrders]);
  const activeOrders = useMemo(() => buyerOrders.filter(o => o.status !== 'Completed'), [buyerOrders]);
  const completedOrders = useMemo(() => buyerOrders.filter(o => o.status === 'Completed'), [buyerOrders]);

  // Resolve Saved Gigs
  const bookmarkedGigs = useMemo(() => {
    return services.filter(s => savedServicesIds.includes(s.id));
  }, [services, savedServicesIds]);

  // Resolve Saved Freelancers
  const bookmarkedFreelancers = useMemo(() => {
    return sellers.filter(sel => savedSellersIds.includes(sel.id));
  }, [sellers, savedSellersIds]);

  const handlePostRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!requestTitle.trim() || !requestDesc.trim()) {
      showToast('Title and description are required!', 'error');
      return;
    }
    addBuyerRequest({
      title: requestTitle,
      description: requestDesc,
      budget: Number(requestBudget),
      duration: requestDuration
    });
    setRequestTitle('');
    setRequestDesc('');
    setShowRequestForm(false);
    showToast('Project Briefing posted to Buyer Requests feed!', 'success');
  };

  return (
    <div id="buyer-dashboard" className="bg-[#FBFBFA] dark:bg-neutral-950 text-neutral-800 dark:text-neutral-100 pb-24 pt-10 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Welcome Brief Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-10">
          <div>
            <span className="text-[10px] font-extrabold tracking-widest uppercase text-neutral-400">Buyer Workspace Dashboard</span>
            <h1 className="text-xl sm:text-2xl font-extrabold text-neutral-900 dark:text-white mt-1">
              Welcome back, {currentUser.name}
            </h1>
            <p className="text-xs text-neutral-400 mt-1">Manage hires, monitor payments escrow, and audit pending deliverables.</p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setShowRequestForm(!showRequestForm)}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-lg bg-brand-500 hover:bg-brand-600 text-white font-bold text-xs shadow-sm cursor-pointer transition-colors"
            >
              <PlusCircle size={13} />
              <span>Post a Project Briefing</span>
            </button>
          </div>
        </div>

        {/* 1. KEY METRICS BLOCKS GRID */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-10">
          
          <div className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 p-5 rounded-2xl shadow-xs space-y-2">
            <span className="text-[10px] text-neutral-400 font-bold block uppercase tracking-wider">Invested Capital</span>
            <h3 className="text-2xl font-extrabold text-neutral-900 dark:text-white">${totalSpend}</h3>
            <p className="text-[10px] text-neutral-500 font-semibold italic">Cumulative billing transactions</p>
          </div>

          <div className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 p-5 rounded-2xl shadow-xs space-y-2">
            <span className="text-[10px] text-neutral-400 font-bold block uppercase tracking-wider">Active Escrow Orders</span>
            <h3 className="text-2xl font-extrabold text-brand-600 dark:text-brand-400">{activeOrders.length} Gigs</h3>
            <p className="text-[10px] text-neutral-500 font-semibold italic">Safely locked in transaction escrow</p>
          </div>

          <div className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 p-5 rounded-2xl shadow-xs space-y-2">
            <span className="text-[10px] text-neutral-400 font-bold block uppercase tracking-wider">Completed Milestones</span>
            <h3 className="text-2xl font-extrabold text-neutral-900 dark:text-white">{completedOrders.length} Projects</h3>
            <p className="text-[10px] text-neutral-500 font-semibold italic">Disbursed deliverables approved</p>
          </div>

        </div>

        {/* Dynamic Project Request Slider Modal Form */}
        <AnimatePresence>
          {showRequestForm && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="bg-white dark:bg-neutral-900 p-6 rounded-2xl border border-brand-200/50 dark:border-neutral-800 shadow-md mb-10 space-y-4"
            >
              <h3 className="font-extrabold text-sm text-neutral-900 dark:text-white border-b border-neutral-100 dark:border-neutral-800 pb-2 mb-4">Post a Buyer Request (Project Briefing)</h3>
              <form onSubmit={handlePostRequest} className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="text-[10px] font-bold text-neutral-400 block mb-1">PROJECT TITLE</label>
                  <input
                    type="text"
                    value={requestTitle}
                    onChange={(e) => setRequestTitle(e.target.value)}
                    className="w-full text-xs font-semibold px-3 py-2 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950"
                    placeholder="Brief summary of required services..."
                    required
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="text-[10px] font-bold text-neutral-400 block mb-1">DESCRIPTION BRIEF</label>
                  <textarea
                    value={requestDesc}
                    onChange={(e) => setRequestDesc(e.target.value)}
                    rows={3}
                    className="w-full text-xs font-semibold px-3 py-2 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950"
                    placeholder="Specify tools, delivery days, custom milestones, reference codes..."
                    required
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-neutral-400 block mb-1">PROPOSED BUDGET ($)</label>
                  <input
                    type="number"
                    value={requestBudget}
                    onChange={(e) => setRequestBudget(Math.max(5, parseInt(e.target.value) || 0))}
                    className="w-full text-xs font-semibold px-3 py-2 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950"
                    required
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold text-neutral-400 block mb-1">REQUIRED DURATION</label>
                  <input
                    type="text"
                    value={requestDuration}
                    onChange={(e) => setRequestDuration(e.target.value)}
                    className="w-full text-xs font-semibold px-3 py-2 rounded-lg border border-neutral-200 dark:border-neutral-800 bg-neutral-50 dark:bg-neutral-950"
                    required
                  />
                </div>
                <div className="sm:col-span-2 flex justify-end gap-2 pt-2 border-t border-neutral-100 dark:border-neutral-800">
                  <button
                    type="button"
                    onClick={() => setShowRequestForm(false)}
                    className="px-3.5 py-2 rounded-lg border border-neutral-200 text-neutral-500 hover:bg-neutral-50 text-xs font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-lg bg-brand-500 hover:bg-brand-600 text-white text-xs font-bold"
                  >
                    Publish Request
                  </button>
                </div>
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        {/* 2. TAB TOGGLERS LIST */}
        <div className="flex border-b border-neutral-200 dark:border-neutral-800/80 mb-8 overflow-x-auto text-xs font-bold uppercase select-none">
          {[
            { id: 'hires', label: `My Hires & Orders (${buyerOrders.length})`, icon: Briefcase },
            { id: 'saved-gigs', label: `Saved Gigs (${bookmarkedGigs.length})`, icon: Heart },
            { id: 'saved-freelancers', label: `Saved Freelancers (${bookmarkedFreelancers.length})`, icon: Users },
            { id: 'requests', label: `Project Requests (${buyerRequests.length})`, icon: FileSpreadsheet }
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-3.5 px-4 border-b-2 flex items-center gap-2 whitespace-nowrap cursor-pointer transition-all ${isActive ? 'border-brand-500 text-brand-600 dark:text-brand-400 bg-brand-50/20 dark:bg-brand-950/10' : 'border-transparent text-neutral-400 hover:text-neutral-600 hover:bg-neutral-50/20 dark:hover:bg-neutral-800/30'}`}
              >
                <Icon size={13} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* 3. DYNAMIC TAB VIEWPORTS */}
        <div className="space-y-6">
          
          {/* TAB A: HIRES TABLE */}
          {activeTab === 'hires' && (
            <div className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 rounded-2xl overflow-hidden shadow-xs">
              {buyerOrders.length === 0 ? (
                <div className="p-12 text-center text-xs text-neutral-400">
                  You haven&apos;t placed any hiring orders yet. Explore active freelancer services to get started!
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-neutral-50/50 dark:bg-neutral-950/40 border-b border-neutral-100 dark:border-neutral-800 text-neutral-400 font-bold uppercase tracking-wider text-[10px]">
                        <th className="p-4 pl-6">Order Reference</th>
                        <th className="p-4">Listing Detail</th>
                        <th className="p-4">Freelancer</th>
                        <th className="p-4">Investment</th>
                        <th className="p-4">Status</th>
                        <th className="p-4 pr-6 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-50 dark:divide-neutral-800 font-medium">
                      {buyerOrders.map((ord) => {
                        const srv = services.find(s => s.id === ord.serviceId);
                        const sel = sellers.find(s => s.id === ord.sellerId);
                        return (
                          <tr key={ord.id} className="hover:bg-neutral-50/30 dark:hover:bg-neutral-800/20">
                            <td className="p-4 pl-6 font-bold text-neutral-500">WH-2026-{ord.id}</td>
                            <td className="p-4">
                              <span className="font-semibold text-neutral-800 dark:text-neutral-250 block max-w-sm truncate hover:underline">
                                <Link to={`/service/${ord.serviceId}`}>{srv?.title}</Link>
                              </span>
                              <span className="text-[9px] uppercase font-bold text-brand-600 mt-0.5 block">{ord.packageSelected} Package</span>
                            </td>
                            <td className="p-4 font-semibold text-neutral-700 dark:text-neutral-300">@{sel?.username}</td>
                            <td className="p-4 font-bold text-neutral-900 dark:text-neutral-100">${ord.price}</td>
                            <td className="p-4">
                              <span className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase ${ord.status === 'Completed' ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400' : ord.status === 'Delivered' ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400 font-extrabold animate-pulse' : 'bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-400'}`}>
                                {ord.status}
                              </span>
                            </td>
                            <td className="p-4 pr-6 text-right">
                              <Link
                                to={`/dashboard/order/${ord.id}`}
                                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[10px] font-extrabold uppercase bg-brand-50 hover:bg-brand-100 dark:bg-brand-950/40 text-brand-600 dark:text-brand-400 border border-brand-100/40 dark:border-brand-900/40 cursor-pointer transition-colors"
                              >
                                <span>Track Progress</span>
                                <ExternalLink size={10} />
                              </Link>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* TAB B: SAVED GIGS FEED */}
          {activeTab === 'saved-gigs' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {bookmarkedGigs.length === 0 ? (
                <div className="col-span-full bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 rounded-xl p-12 text-center text-xs text-neutral-400">
                  Your bookmarked folder is empty. Go ahead and heart your favorite freelancer listings!
                </div>
              ) : (
                bookmarkedGigs.map(g => (
                  <ServiceCard key={g.id} service={g} />
                ))
              )}
            </div>
          )}

          {/* TAB C: SAVED FREELANCERS */}
          {activeTab === 'saved-freelancers' && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
              {bookmarkedFreelancers.length === 0 ? (
                <div className="col-span-full bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 rounded-xl p-12 text-center text-xs text-neutral-400">
                  No saved freelancers. Tap follow/heart profiles from search pages.
                </div>
              ) : (
                bookmarkedFreelancers.map(s => (
                  <SellerCard key={s.id} seller={s} />
                ))
              )}
            </div>
          )}

          {/* TAB D: PROJECT REQUESTS */}
          {activeTab === 'requests' && (
            <div className="space-y-4">
              {buyerRequests.length === 0 ? (
                <div className="bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 rounded-xl p-12 text-center text-xs text-neutral-400">
                  You haven&apos;t posted any customized briefs yet. Click the &quot;Post a Project Briefing&quot; button above.
                </div>
              ) : (
                buyerRequests.map(req => (
                  <div key={req.id} className="bg-white dark:bg-neutral-900 p-5 border border-neutral-100 dark:border-neutral-850 rounded-xl shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="space-y-1.5 flex-1 max-w-2xl">
                      <h4 className="text-xs font-bold text-neutral-800 dark:text-neutral-100">{req.title}</h4>
                      <p className="text-[11px] text-neutral-400 dark:text-neutral-500 leading-relaxed font-semibold">{req.description}</p>
                      <div className="flex items-center gap-3 pt-1 text-[10px] text-neutral-400 font-bold">
                        <span>Duration target: {req.deadline}</span>
                        <span>•</span>
                        <span>Published: {req.createdAt || 'Just now'}</span>
                      </div>
                    </div>

                    <div className="flex items-end flex-col gap-2.5">
                      <span className="text-xs font-semibold text-neutral-400">Target Budget:</span>
                      <span className="text-lg font-extrabold text-brand-600 dark:text-brand-400">${req.budget}</span>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
