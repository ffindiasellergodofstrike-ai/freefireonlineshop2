import React from 'react';
import { Heart, Star } from 'lucide-react';
import { useApp, Service } from '../context/AppContext';
import { RatingStars } from './RatingStars';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';

interface ServiceCardProps {
  service: Service;
}

export const ServiceCard: React.FC<ServiceCardProps> = ({ service }) => {
  const { sellers, savedServicesIds, toggleSaveService } = useApp();
  
  // Find associated seller
  const seller = sellers.find(s => s.id === service.sellerId);
  const isSaved = savedServicesIds.includes(service.id);

  if (!seller) return null;

  return (
    <motion.div
      id={`service-card-${service.id}`}
      whileHover={{ y: -6 }}
      transition={{ duration: 0.2 }}
      className="group relative flex flex-col h-full bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow"
    >
      {/* Thumbnail */}
      <div className="relative aspect-video w-full overflow-hidden bg-neutral-100 dark:bg-neutral-800">
        <Link to={`/service/${service.id}`}>
          <img
            src={service.images[0]}
            alt={service.title}
            loading="lazy"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        </Link>
        
        {/* Heart Bookmark Button */}
        <button
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            toggleSaveService(service.id);
          }}
          className="absolute top-3 right-3 flex items-center justify-center w-8 h-8 rounded-full bg-white/80 dark:bg-neutral-900/80 backdrop-blur-xs shadow-xs text-neutral-600 dark:text-neutral-300 hover:text-rose-500 hover:bg-white dark:hover:bg-neutral-950 transition-all duration-200"
        >
          <Heart
            size={16}
            className={`${isSaved ? 'fill-rose-500 text-rose-500' : 'text-current'}`}
          />
        </button>

        {/* Level badge */}
        {seller.level && (
          <span className="absolute bottom-3 left-3 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-black/70 dark:bg-neutral-950/70 text-white rounded-md backdrop-blur-xs">
            {seller.level}
          </span>
        )}
      </div>

      {/* Content */}
      <div className="flex flex-col flex-1 p-4">
        {/* Seller Info */}
        <div className="flex items-center gap-2 mb-3">
          <Link to={`/seller/${seller.username}`} className="flex items-center gap-2 group-hover:opacity-90">
            <img
              src={seller.avatar}
              alt={seller.name}
              className="w-6 h-6 rounded-full object-cover border border-neutral-200 dark:border-neutral-700"
            />
            <span className="text-xs font-semibold text-neutral-800 dark:text-neutral-200 hover:underline">
              {seller.name}
            </span>
          </Link>
          <span className="ml-auto w-1.5 h-1.5 rounded-full bg-emerald-500" title="Online" />
        </div>

        {/* Title */}
        <Link to={`/service/${service.id}`} className="flex-1">
          <h3 className="text-sm font-medium text-neutral-800 dark:text-neutral-100 hover:text-brand-500 dark:hover:text-brand-400 line-clamp-2 leading-relaxed mb-3">
            {service.title}
          </h3>
        </Link>

        {/* Rating */}
        <div className="flex items-center gap-1.5 pt-2 border-t border-neutral-50 dark:border-neutral-800 mb-4">
          <RatingStars rating={service.rating} size={13} />
          <span className="text-xs text-neutral-500 dark:text-neutral-400 font-medium">
            {service.rating.toFixed(1)}
          </span>
          <span className="text-xs text-neutral-400">
            ({service.reviewCount})
          </span>
        </div>

        {/* Price Tag Footer */}
        <div className="flex items-center justify-between pt-3 border-t border-neutral-100 dark:border-neutral-800">
          <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 dark:text-neutral-500">
            Starting at
          </span>
          <span className="text-base font-bold text-neutral-900 dark:text-neutral-100">
            ${service.packages.basic.price}
          </span>
        </div>
      </div>
    </motion.div>
  );
};
