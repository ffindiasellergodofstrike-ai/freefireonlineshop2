import React from 'react';
import {
  Palette,
  Code,
  TrendingUp,
  Video,
  FileText,
  Music,
  Briefcase,
  Cpu,
  Compass,
  Camera,
  HelpCircle
} from 'lucide-react';
import { Category } from '../context/AppContext';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';

interface CategoryCardProps {
  category: Category;
}

const IconResolver: React.FC<{ name: string; size?: number; className?: string }> = ({
  name,
  size = 22,
  className = ''
}) => {
  switch (name) {
    case 'Palette':
      return <Palette size={size} className={className} />;
    case 'Code':
      return <Code size={size} className={className} />;
    case 'TrendingUp':
      return <TrendingUp size={size} className={className} />;
    case 'Video':
      return <Video size={size} className={className} />;
    case 'FileText':
      return <FileText size={size} className={className} />;
    case 'Music':
      return <Music size={size} className={className} />;
    case 'Briefcase':
      return <Briefcase size={size} className={className} />;
    case 'Cpu':
      return <Cpu size={size} className={className} />;
    case 'Compass':
      return <Compass size={size} className={className} />;
    case 'Camera':
      return <Camera size={size} className={className} />;
    default:
      return <HelpCircle size={size} className={className} />;
  }
};

export const CategoryCard: React.FC<CategoryCardProps> = ({ category }) => {
  return (
    <Link id={`category-card-${category.id}`} to={`/category/${category.slug}`} className="block">
      <motion.div
        whileHover={{ scale: 1.02, y: -2 }}
        className="flex flex-col items-center p-5 bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 rounded-xl hover:shadow-md transition-all text-center h-full group"
      >
        {/* Icon Circle */}
        <div className="flex items-center justify-center w-12 h-12 rounded-full bg-brand-50 dark:bg-brand-950/40 text-brand-600 dark:text-brand-400 group-hover:bg-brand-500 group-hover:text-white transition-all duration-300 mb-3">
          <IconResolver name={category.icon} className="transition-transform duration-300 group-hover:rotate-6" />
        </div>
        
        {/* Title */}
        <h3 className="text-sm font-semibold text-neutral-800 dark:text-neutral-100 mb-1 group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors">
          {category.name}
        </h3>
        
        {/* Description */}
        <p className="text-[11px] text-neutral-400 dark:text-neutral-500 line-clamp-2 leading-relaxed">
          {category.description}
        </p>
      </motion.div>
    </Link>
  );
};
