import React, { useEffect, useState } from 'react';
import { useApp } from '../context/AppContext';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const Toast: React.FC = () => {
  const { toast } = useApp();
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (toast) {
      setVisible(true);
      const timer = setTimeout(() => {
        setVisible(false);
      }, 2700);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  if (!toast) return null;

  const getIcon = () => {
    switch (toast.type) {
      case 'success':
        return <CheckCircle2 className="text-emerald-500" size={18} />;
      case 'error':
        return <AlertCircle className="text-rose-500" size={18} />;
      case 'info':
      default:
        return <Info className="text-blue-500" size={18} />;
    }
  };

  const getBg = () => {
    switch (toast.type) {
      case 'success':
        return 'bg-emerald-50/95 border-emerald-100 dark:bg-emerald-950/90 dark:border-emerald-900/50';
      case 'error':
        return 'bg-rose-50/95 border-rose-100 dark:bg-rose-950/90 dark:border-rose-900/50';
      case 'info':
      default:
        return 'bg-blue-50/95 border-blue-100 dark:bg-blue-950/90 dark:border-blue-900/50';
    }
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          id="toast-notification"
          initial={{ opacity: 0, y: 50, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 20, scale: 0.95 }}
          transition={{ type: 'spring', stiffness: 300, damping: 25 }}
          className={`fixed bottom-6 right-6 z-100 flex items-center gap-3 px-4 py-3 rounded-xl border shadow-xl backdrop-blur-md max-w-sm ${getBg()}`}
        >
          <div className="flex-shrink-0">{getIcon()}</div>
          <p className="text-sm font-medium text-neutral-800 dark:text-neutral-200">
            {toast.message}
          </p>
          <button
            onClick={() => setVisible(false)}
            className="text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200 transition-colors ml-2"
          >
            <X size={14} />
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
