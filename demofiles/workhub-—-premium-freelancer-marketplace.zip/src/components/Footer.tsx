import React from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Globe, Heart, Shield, HelpCircle, CheckCircle } from 'lucide-react';

export const Footer: React.FC = () => {
  const { categories } = useApp();

  return (
    <footer className="bg-white dark:bg-neutral-900 border-t border-neutral-100 dark:border-neutral-800/80 pt-16 pb-8 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top footer navigation grid */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8 pb-12 border-b border-neutral-100 dark:border-neutral-800">
          
          {/* Brand block */}
          <div className="col-span-2 space-y-4">
            <Link to="/" className="flex items-center gap-2">
              <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-brand-500 text-white font-bold text-base shadow-sm">
                W
              </div>
              <span className="text-lg font-extrabold tracking-tight dark:text-white">
                WORK<span className="text-brand-500">HUB</span>
              </span>
            </Link>
            <p className="text-xs text-neutral-400 dark:text-neutral-500 leading-relaxed max-w-sm">
              WorkHub is an elite, premium freelancer marketplace platform connecting world-class creators and builders with high-growth startups and visionary businesses.
            </p>
            <p className="text-[10px] text-neutral-400 dark:text-neutral-500 font-semibold italic flex items-center gap-1.5">
              <Shield size={12} className="text-brand-500" />
              <span>Certified Safe Escrow & Work Delivery</span>
            </p>
          </div>

          {/* Categories col */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">
              Categories
            </h4>
            <ul className="space-y-2 text-xs font-medium text-neutral-500 dark:text-neutral-400">
              {categories.slice(0, 5).map((cat) => (
                <li key={cat.id}>
                  <Link to={`/category/${cat.slug}`} className="hover:text-brand-500 transition-colors">
                    {cat.name}
                  </Link>
                </li>
              ))}
              <li>
                <Link to="/explore" className="text-brand-600 hover:underline">
                  All Categories
                </Link>
              </li>
            </ul>
          </div>

          {/* About/Press col */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">
              About & Community
            </h4>
            <ul className="space-y-2 text-xs font-medium text-neutral-500 dark:text-neutral-400">
              <li>
                <Link to="/explore" className="hover:text-brand-500 transition-colors">
                  Careers & Culture
                </Link>
              </li>
              <li>
                <Link to="/explore" className="hover:text-brand-500 transition-colors">
                  Press & Media Kit
                </Link>
              </li>
              <li>
                <Link to="/explore" className="hover:text-brand-500 transition-colors">
                  Partnerships
                </Link>
              </li>
              <li>
                <Link to="/explore" className="hover:text-brand-500 transition-colors">
                  Trust & Safety Guidelines
                </Link>
              </li>
              <li>
                <Link to="/admin" className="text-neutral-700 dark:text-neutral-300 font-bold hover:underline">
                  Admin System View
                </Link>
              </li>
            </ul>
          </div>

          {/* Freelancers pathway */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-neutral-800 dark:text-neutral-200 uppercase tracking-wider">
              For Freelancers
            </h4>
            <ul className="space-y-2 text-xs font-medium text-neutral-500 dark:text-neutral-400">
              <li>
                <Link to="/become-a-seller" className="hover:text-brand-500 transition-colors">
                  Become a Seller
                </Link>
              </li>
              <li>
                <Link to="/dashboard/seller" className="hover:text-brand-500 transition-colors">
                  Seller Dashboard Hub
                </Link>
              </li>
              <li>
                <Link to="/buyer-requests" className="hover:text-brand-500 transition-colors">
                  Browse Projects Requests
                </Link>
              </li>
              <li>
                <Link to="/create-service" className="hover:text-brand-500 transition-colors">
                  Publish a Service listing
                </Link>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom footer bar */}
        <div className="flex flex-col md:flex-row items-center justify-between pt-8 space-y-4 md:space-y-0 text-[11px] text-neutral-400">
          <div className="flex items-center gap-1">
            <span>© 2026 WORKHUB Inc. All rights reserved.</span>
            <span className="hidden md:inline mx-1.5">•</span>
            <span className="text-neutral-500 font-semibold">Premium Marketplace Template</span>
          </div>
          
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <Globe size={11} />
              <span>English / USD</span>
            </span>
            <span className="flex items-center gap-1 text-neutral-500">
              <span>Made with</span>
              <Heart size={10} className="fill-rose-500 text-rose-500" />
              <span>for AI Studio Builders</span>
            </span>
          </div>
        </div>

      </div>
    </footer>
  );
};
