import React from 'react';
import { MapPin, ArrowRight, Heart } from 'lucide-react';
import { useApp, Seller } from '../context/AppContext';
import { RatingStars } from './RatingStars';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';

interface SellerCardProps {
  seller: Seller;
}

export const SellerCard: React.FC<SellerCardProps> = ({ seller }) => {
  const { savedSellersIds, toggleSaveSeller } = useApp();
  const isSaved = savedSellersIds.includes(seller.id);

  return (
    <motion.div
      id={`seller-card-${seller.id}`}
      whileHover={{ y: -4 }}
      className="relative flex flex-col p-5 bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 rounded-xl shadow-xs hover:shadow-md transition-all"
    >
      {/* Heart Save Button */}
      <button
        onClick={() => toggleSaveSeller(seller.id)}
        className="absolute top-4 right-4 flex items-center justify-center w-8 h-8 rounded-full bg-neutral-50 dark:bg-neutral-800 text-neutral-500 dark:text-neutral-400 hover:text-rose-500 transition-colors"
      >
        <Heart size={15} className={isSaved ? 'fill-rose-500 text-rose-500' : ''} />
      </button>

      {/* Header Profile Info */}
      <div className="flex items-start gap-4 mb-4">
        <img
          src={seller.avatar}
          alt={seller.name}
          className="w-14 h-14 rounded-full object-cover border border-neutral-100 dark:border-neutral-700 shadow-xs"
        />
        <div className="flex-1 min-w-0">
          <Link to={`/seller/${seller.username}`} className="hover:underline block">
            <h3 className="font-semibold text-neutral-800 dark:text-neutral-100 text-base truncate">
              {seller.name}
            </h3>
          </Link>
          <p className="text-xs text-neutral-400 dark:text-neutral-500 font-medium truncate">
            @{seller.username}
          </p>
          <div className="flex items-center gap-1 text-[11px] text-neutral-500 dark:text-neutral-400 mt-1">
            <MapPin size={11} className="text-neutral-400" />
            <span>{seller.location}</span>
          </div>
        </div>
      </div>

      {/* Professional Title */}
      <p className="text-xs font-semibold text-neutral-700 dark:text-neutral-300 line-clamp-1 mb-2">
        {seller.title}
      </p>

      {/* Bio excerpt */}
      <p className="text-xs text-neutral-500 dark:text-neutral-400 line-clamp-2 leading-relaxed mb-4">
        {seller.bio}
      </p>

      {/* Rating & Orders */}
      <div className="flex items-center gap-2 mb-4 pt-3 border-t border-neutral-50 dark:border-neutral-800">
        <RatingStars rating={seller.rating} size={12} />
        <span className="text-xs font-bold text-neutral-700 dark:text-neutral-300">
          {seller.rating.toFixed(2)}
        </span>
        <span className="text-xs text-neutral-400 dark:text-neutral-500">
          ({seller.reviewCount} reviews)
        </span>
      </div>

      {/* Skills badglist */}
      <div className="flex flex-wrap gap-1.5 mb-5 flex-1">
        {seller.skills.slice(0, 3).map((skill: string) => (
          <span
            key={skill}
            className="text-[10px] font-semibold text-neutral-600 dark:text-neutral-300 px-2 py-0.5 rounded bg-neutral-50 dark:bg-neutral-800/80 border border-neutral-100 dark:border-neutral-700/50"
          >
            {skill}
          </span>
        ))}
        {seller.skills.length > 3 && (
          <span className="text-[9px] font-bold text-neutral-400 px-1 py-0.5">
            +{seller.skills.length - 3} more
          </span>
        )}
      </div>

      {/* CTA Button */}
      <Link
        to={`/seller/${seller.username}`}
        className="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-bold text-brand-600 dark:text-brand-400 bg-brand-50 dark:bg-brand-950/40 hover:bg-brand-100 dark:hover:bg-brand-950/70 border border-brand-100 dark:border-brand-900/40 rounded-lg transition-colors"
      >
        <span>View Profile & Gigs</span>
        <ArrowRight size={12} />
      </Link>
    </motion.div>
  );
};
