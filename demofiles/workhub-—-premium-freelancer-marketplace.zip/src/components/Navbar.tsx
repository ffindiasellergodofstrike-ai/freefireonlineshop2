import React, { useState, useRef, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import {
  Search,
  Bell,
  MessageSquare,
  User,
  LogOut,
  Settings,
  Grid,
  Sun,
  Moon,
  Menu,
  X,
  Briefcase,
  Layers,
  Heart,
  PlusCircle,
  Database,
  ArrowLeftRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const Navbar: React.FC = () => {
  const {
    currentUser,
    activeRole,
    switchRole,
    notifications,
    conversations,
    markNotificationsAsRead,
    theme,
    toggleTheme,
    logout
  } = useApp();

  const navigate = useNavigate();
  const location = useLocation();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notifDropdownOpen, setNotifDropdownOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
  
  const notifRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);

  // Close dropdowns on click outside
  useEffect(() => {
    const clickOutside = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setNotifDropdownOpen(false);
      }
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) {
        setProfileDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', clickOutside);
    return () => document.removeEventListener('mousedown', clickOutside);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    } else {
      navigate('/explore');
    }
  };

  const unreadNotifsCount = notifications.filter(n => !n.read).length;
  const unreadMessagesCount = conversations.reduce((count, c) => {
    const unreadInConvo = c.messages.filter(m => m.senderId !== currentUser.id && !m.read).length;
    return count + (unreadInConvo > 0 ? 1 : 0);
  }, 0);

  return (
    <nav className="sticky top-0 z-50 w-full bg-white/95 dark:bg-neutral-900/95 backdrop-blur-md border-b border-neutral-100 dark:border-neutral-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo */}
          <div className="flex items-center gap-6">
            <Link to="/" className="flex items-center gap-2 group">
              <div className="flex items-center justify-center w-9 h-9 rounded-xl bg-brand-500 text-white font-bold text-lg shadow-sm shadow-brand-500/30 group-hover:bg-brand-600 transition-colors">
                W
              </div>
              <span className="text-xl font-extrabold tracking-tight bg-gradient-to-r from-neutral-900 to-neutral-700 dark:from-white dark:to-neutral-300 bg-clip-text text-transparent">
                WORK<span className="text-brand-500 font-bold">HUB</span>
              </span>
            </Link>

            {/* Desktop Search Bar */}
            <form onSubmit={handleSearchSubmit} className="hidden md:flex items-center max-w-sm relative">
              <div className="relative flex items-center w-64 lg:w-80 group">
                <input
                  type="text"
                  placeholder="Search services or skills..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full px-4 py-2 pl-10 text-xs font-medium rounded-full bg-neutral-50 dark:bg-neutral-800/80 border border-neutral-200 dark:border-neutral-700/60 focus:outline-hidden focus:ring-1 focus:ring-brand-500 focus:border-brand-500 dark:text-neutral-100 transition-all"
                />
                <Search size={14} className="absolute left-3.5 text-neutral-400 group-focus-within:text-brand-500 transition-colors" />
                <button type="submit" className="hidden" />
              </div>
            </form>
          </div>

          {/* Desktop Right items */}
          <div className="hidden md:flex items-center gap-4">
            
            {/* Swapper button (Fiverr style) */}
            {currentUser.accountType === 'Both' && (
              <button
                onClick={() => {
                  switchRole(activeRole === 'buyer' ? 'seller' : 'buyer');
                  navigate(activeRole === 'buyer' ? '/dashboard/seller' : '/dashboard/buyer');
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-full bg-brand-50 dark:bg-brand-950/40 text-brand-700 dark:text-brand-300 hover:bg-brand-100 dark:hover:bg-brand-950/80 border border-brand-100 dark:border-brand-900/30 transition-all cursor-pointer"
              >
                <ArrowLeftRight size={12} />
                <span>Switch to {activeRole === 'buyer' ? 'Selling' : 'Buying'}</span>
              </button>
            )}

            {currentUser.accountType === 'Buyer' && activeRole === 'buyer' && (
              <Link
                to="/become-a-seller"
                className="text-xs font-bold text-neutral-600 dark:text-neutral-300 hover:text-brand-600 dark:hover:text-brand-400 transition-colors"
              >
                Become a Seller
              </Link>
            )}

            {/* Direct dashboard shortcut link */}
            <Link
              to={activeRole === 'seller' ? '/dashboard/seller' : '/dashboard/buyer'}
              className="text-xs font-semibold text-neutral-600 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white transition-colors"
            >
              Dashboard
            </Link>

            <Link
              to="/explore"
              className="text-xs font-semibold text-neutral-600 dark:text-neutral-300 hover:text-neutral-900 dark:hover:text-white transition-colors"
            >
              Explore Gigs
            </Link>

            {/* Mode toggle */}
            <button
              onClick={toggleTheme}
              className="p-2 rounded-full hover:bg-neutral-50 dark:hover:bg-neutral-800 text-neutral-500 dark:text-neutral-400 hover:text-brand-500 transition-colors"
              aria-label="Toggle theme"
            >
              {theme === 'light' ? <Moon size={16} /> : <Sun size={16} />}
            </button>

            {/* Chat Link */}
            <Link
              to="/dashboard/messages"
              className="relative p-2 rounded-full hover:bg-neutral-50 dark:hover:bg-neutral-800 text-neutral-500 dark:text-neutral-400 hover:text-brand-500 transition-colors"
            >
              <MessageSquare size={16} />
              {unreadMessagesCount > 0 && (
                <span className="absolute top-1.5 right-1.5 flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-500"></span>
                </span>
              )}
            </Link>

            {/* Notification Center Dropdown */}
            <div className="relative" ref={notifRef}>
              <button
                onClick={() => setNotifDropdownOpen(!notifDropdownOpen)}
                className="relative p-2 rounded-full hover:bg-neutral-50 dark:hover:bg-neutral-800 text-neutral-500 dark:text-neutral-400 hover:text-brand-500 transition-colors"
              >
                <Bell size={16} />
                {unreadNotifsCount > 0 && (
                  <span className="absolute top-1 right-1 flex h-4 w-4 items-center justify-center text-[9px] font-bold text-white bg-brand-500 rounded-full">
                    {unreadNotifsCount}
                  </span>
                )}
              </button>

              <AnimatePresence>
                {notifDropdownOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className="absolute right-0 mt-2.5 w-80 bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 rounded-xl shadow-xl overflow-hidden z-100"
                  >
                    <div className="flex items-center justify-between p-3.5 border-b border-neutral-100 dark:border-neutral-800 bg-neutral-50/50 dark:bg-neutral-900/50">
                      <span className="text-xs font-bold text-neutral-800 dark:text-neutral-200">Notifications</span>
                      {unreadNotifsCount > 0 && (
                        <button
                          onClick={markNotificationsAsRead}
                          className="text-[10px] font-semibold text-brand-600 hover:underline"
                        >
                          Mark all read
                        </button>
                      )}
                    </div>
                    <div className="divide-y divide-neutral-50 dark:divide-neutral-800 max-h-64 overflow-y-auto">
                      {notifications.length === 0 ? (
                        <div className="p-6 text-center text-xs text-neutral-400">
                          No notifications
                        </div>
                      ) : (
                        notifications.map((notif) => (
                          <div
                            key={notif.id}
                            className={`p-3 text-xs transition-colors hover:bg-neutral-50/50 dark:hover:bg-neutral-800/30 ${!notif.read ? 'bg-brand-50/30 dark:bg-brand-950/10' : ''}`}
                          >
                            <p className="text-neutral-700 dark:text-neutral-300 font-medium mb-1">{notif.text}</p>
                            <span className="text-[10px] text-neutral-400">{notif.createdAt}</span>
                          </div>
                        ))
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Profile Menu Dropdown */}
            <div className="relative" ref={profileRef}>
              <button
                onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                className="flex items-center gap-1.5 focus:outline-hidden"
              >
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-8 h-8 rounded-full object-cover border border-neutral-200 dark:border-neutral-700 shadow-xs cursor-pointer"
                />
              </button>

              <AnimatePresence>
                {profileDropdownOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 10, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    className="absolute right-0 mt-2.5 w-56 bg-white dark:bg-neutral-900 border border-neutral-100 dark:border-neutral-800 rounded-xl shadow-xl overflow-hidden z-100"
                  >
                    {/* User profile brief */}
                    <div className="p-4 border-b border-neutral-100 dark:border-neutral-800 bg-neutral-50/40 dark:bg-neutral-900/30">
                      <p className="text-xs font-bold text-neutral-800 dark:text-neutral-200 truncate">{currentUser.name}</p>
                      <p className="text-[10px] text-neutral-400 dark:text-neutral-500 truncate">@{currentUser.username}</p>
                      <div className="mt-2 inline-flex items-center px-2 py-0.5 rounded bg-brand-100 dark:bg-brand-950 text-brand-800 dark:text-brand-300 text-[9px] font-bold">
                        Workspace: {activeRole.toUpperCase()}
                      </div>
                    </div>

                    <div className="p-1 divide-y divide-neutral-50 dark:divide-neutral-800 text-xs">
                      <div className="py-1">
                        <Link
                          to={activeRole === 'seller' ? '/dashboard/seller' : '/dashboard/buyer'}
                          className="flex items-center gap-2 px-3 py-2 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-50 dark:hover:bg-neutral-800/60 rounded-md font-medium"
                        >
                          <Grid size={13} className="text-neutral-400" />
                          <span>Dashboard Overview</span>
                        </Link>
                        <Link
                          to="/dashboard/profile"
                          className="flex items-center gap-2 px-3 py-2 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-50 dark:hover:bg-neutral-800/60 rounded-md font-medium"
                        >
                          <User size={13} className="text-neutral-400" />
                          <span>My Account Profile</span>
                        </Link>
                      </div>

                      <div className="py-1">
                        <Link
                          to="/admin"
                          className="flex items-center gap-2 px-3 py-2 text-neutral-700 dark:text-neutral-300 hover:bg-amber-50 dark:hover:bg-amber-950/40 hover:text-amber-700 dark:hover:text-amber-400 rounded-md font-bold"
                        >
                          <Database size={13} className="text-amber-500" />
                          <span>Admin Portal Demo</span>
                        </Link>
                        <Link
                          to="/dashboard/settings"
                          className="flex items-center gap-2 px-3 py-2 text-neutral-700 dark:text-neutral-300 hover:bg-neutral-50 dark:hover:bg-neutral-800/60 rounded-md font-medium"
                        >
                          <Settings size={13} className="text-neutral-400" />
                          <span>Account Settings</span>
                        </Link>
                      </div>

                      <div className="py-1">
                        <button
                          onClick={() => {
                            setProfileDropdownOpen(false);
                            logout();
                          }}
                          className="w-full flex items-center gap-2 px-3 py-2 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-md font-medium"
                        >
                          <LogOut size={13} />
                          <span>Sign Out</span>
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          {/* Mobile menu toggle buttons */}
          <div className="flex md:hidden items-center gap-3">
            <button
              onClick={toggleTheme}
              className="p-1.5 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-500"
            >
              {theme === 'light' ? <Moon size={15} /> : <Sun size={15} />}
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-1.5 rounded-md hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-600 dark:text-neutral-300"
            >
              {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Panel */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden border-t border-neutral-100 dark:border-neutral-800 bg-white dark:bg-neutral-900 shadow-lg overflow-hidden"
          >
            <div className="p-4 space-y-4 text-xs font-semibold text-neutral-700 dark:text-neutral-300">
              
              {/* Dynamic Search */}
              <form onSubmit={handleSearchSubmit} className="relative">
                <input
                  type="text"
                  placeholder="Search services or freelancers..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full px-4 py-2.5 pl-10 text-xs rounded-lg bg-neutral-50 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 focus:outline-hidden"
                />
                <Search size={14} className="absolute left-3.5 top-3 text-neutral-400" />
              </form>

              <div className="flex flex-col gap-3 py-2 border-b border-neutral-50 dark:border-neutral-800">
                {currentUser.accountType === 'Both' && (
                  <button
                    onClick={() => {
                      switchRole(activeRole === 'buyer' ? 'seller' : 'buyer');
                      setMobileMenuOpen(false);
                      navigate(activeRole === 'buyer' ? '/dashboard/seller' : '/dashboard/buyer');
                    }}
                    className="w-full flex items-center justify-center gap-2 py-2 px-4 rounded-lg bg-brand-50 dark:bg-brand-950/40 text-brand-700 dark:text-brand-300 border border-brand-100 dark:border-brand-900/30"
                  >
                    <ArrowLeftRight size={13} />
                    <span>Switch to {activeRole === 'buyer' ? 'Selling' : 'Buying'}</span>
                  </button>
                )}
                
                <Link
                  to={activeRole === 'seller' ? '/dashboard/seller' : '/dashboard/buyer'}
                  className="py-2 px-1 hover:text-brand-500"
                >
                  Workspace Dashboard ({activeRole.toUpperCase()})
                </Link>
                <Link to="/explore" className="py-2 px-1 hover:text-brand-500">
                  Explore Freelance Gigs
                </Link>
                <Link to="/dashboard/messages" className="flex items-center gap-2 py-2 px-1 hover:text-brand-500">
                  <span>Messages Inbox</span>
                  {unreadMessagesCount > 0 && (
                    <span className="px-1.5 py-0.5 rounded-full bg-brand-500 text-white text-[9px]">
                      {unreadMessagesCount} new
                    </span>
                  )}
                </Link>
                <Link to="/admin" className="py-2 px-1 text-amber-600 dark:text-amber-400 font-bold">
                  Admin System Template
                </Link>
              </div>

              <div className="flex items-center gap-3">
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-9 h-9 rounded-full object-cover border border-neutral-200"
                />
                <div>
                  <p className="text-xs font-bold text-neutral-800 dark:text-white">{currentUser.name}</p>
                  <p className="text-[10px] text-neutral-400">@{currentUser.username}</p>
                </div>
              </div>

              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  logout();
                }}
                className="w-full text-center py-2.5 rounded-lg bg-rose-50 dark:bg-rose-950/30 text-rose-600 dark:text-rose-400 font-bold"
              >
                Sign Out
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};
