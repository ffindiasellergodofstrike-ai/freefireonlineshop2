import React from 'react';
import { Star, StarHalf } from 'lucide-react';

interface RatingStarsProps {
  rating: number;
  size?: number;
  showText?: boolean;
  reviewCount?: number;
  textClassName?: string;
}

export const RatingStars: React.FC<RatingStarsProps> = ({
  rating,
  size = 14,
  showText = false,
  reviewCount,
  textClassName = 'text-xs text-neutral-500 dark:text-neutral-400 font-medium'
}) => {
  const fullStars = Math.floor(rating);
  const hasHalfStar = rating % 1 >= 0.4 && rating % 1 <= 0.8;
  const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);

  return (
    <div id="rating-stars" className="flex items-center gap-1">
      <div className="flex items-center gap-0.5">
        {Array.from({ length: fullStars }).map((_, i) => (
          <Star key={`full-${i}`} size={size} className="fill-amber-400 text-amber-400" />
        ))}
        {hasHalfStar && (
          <div className="relative">
            <Star key="half-empty" size={size} className="text-neutral-200 dark:text-neutral-700" />
            <div className="absolute top-0 left-0 overflow-hidden w-1/2">
              <Star key="half-full" size={size} className="fill-amber-400 text-amber-400" />
            </div>
          </div>
        )}
        {Array.from({ length: emptyStars }).map((_, i) => (
          <Star key={`empty-${i}`} size={size} className="text-neutral-200 dark:text-neutral-700" />
        ))}
      </div>
      {showText && (
        <span className={`${textClassName} ml-1`}>
          {rating.toFixed(2)}{' '}
          {reviewCount !== undefined && `(${reviewCount})`}
        </span>
      )}
    </div>
  );
};
