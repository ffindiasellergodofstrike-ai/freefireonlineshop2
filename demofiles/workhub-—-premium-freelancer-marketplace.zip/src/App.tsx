import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Toast } from './components/Toast';

// Pages Modular imports
import { Home } from './pages/Home';
import { Explore } from './pages/Explore';
import { ServiceDetail } from './pages/ServiceDetail';
import { SellerProfilePage } from './pages/SellerProfilePage';
import { Onboarding } from './pages/Onboarding';
import { Auth } from './pages/Auth';
import { Checkout } from './pages/Checkout';
import { OrderDetailsPage } from './pages/OrderDetailsPage';
import { BuyerDashboard } from './pages/BuyerDashboard';
import { SellerDashboard } from './pages/SellerDashboard';
import { AdminDashboard } from './pages/AdminDashboard';
import { CreateServicePage } from './pages/CreateServicePage';

export default function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <div id="workhub-app-root" className="min-h-screen flex flex-col bg-[#FBFBFA] dark:bg-neutral-950 text-neutral-800 dark:text-neutral-100 transition-colors duration-200">
          
          {/* Global Navigation header */}
          <Navbar />

          {/* Floating Toast notification alerts */}
          <Toast />

          {/* Core Routes mapping */}
          <main className="flex-1">
            <Routes>
              {/* Home */}
              <Route path="/" element={<Home />} />

              {/* Exploration & Searches (Combined statefully under Unified Explore) */}
              <Route path="/explore" element={<Explore />} />
              <Route path="/search" element={<Explore />} />
              <Route path="/category/:categorySlug" element={<Explore />} />

              {/* Listing Details */}
              <Route path="/service/:id" element={<ServiceDetail />} />

              {/* Public Freelancer Storefront Portfolio */}
              <Route path="/seller/:username" element={<SellerProfilePage />} />

              {/* Authenticated Profile selection */}
              <Route path="/auth" element={<Auth />} />

              {/* Seller Onboarding (Become a Seller wizard) */}
              <Route path="/become-a-seller" element={<Onboarding />} />

              {/* Create new Service Listing */}
              <Route path="/create-service" element={<CreateServicePage />} />

              {/* Secure Checkout Pipeline */}
              <Route path="/checkout" element={<Checkout />} />

              {/* Dashboards workspaces */}
              <Route path="/dashboard/buyer" element={<BuyerDashboard />} />
              <Route path="/dashboard/seller" element={<SellerDashboard />} />
              <Route path="/dashboard/messages" element={<SellerDashboard />} />
              
              {/* Individual Escrow Order Details Tracker */}
              <Route path="/dashboard/order/:id" element={<OrderDetailsPage />} />

              {/* Administrative Systems Console */}
              <Route path="/admin" element={<AdminDashboard />} />

              {/* Fallback redirect safely back to home */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </main>

          {/* Shared Site Map Footer */}
          <Footer />

        </div>
      </BrowserRouter>
    </AppProvider>
  );
}
