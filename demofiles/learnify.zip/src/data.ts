import { Course, Instructor, PricingPlan, FAQItem, Testimonial } from './types';

export const INSTRUCTORS: Instructor[] = [
  {
    id: 'inst-1',
    name: 'Alex Rivers',
    role: 'Senior Full-Stack Engineer & Core Contributor',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80',
    bio: 'Alex is a veteran developer with over 12 years of industry experience. Formerly a tech lead at Netflix and Stripe, he currently specializes in React frameworks, Node.js microservices, and modern UI engineering. He is passionate about breaking down complex concepts into simple, structured modules.',
    rating: 4.85,
    reviewsCount: 3120,
    studentsCount: 17570,
    coursesCount: 2,
    specialties: ['React', 'Node.js', 'TypeScript', 'Flutter', 'Next.js'],
    socials: {
      twitter: 'https://twitter.com/alexrivers_dev',
      linkedin: 'https://linkedin.com/in/alexrivers',
      website: 'https://alexrivers.io'
    }
  },
  {
    id: 'inst-2',
    name: 'Sophia Chen',
    role: 'Lead UI/UX Designer & Brand Strategist',
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&h=150&q=80',
    bio: 'Sophia is an award-winning digital designer who has crafted interfaces for startups and Fortune 500 tech firms alike. With a design methodology centered on user empathy and business value, her courses focus on Figma workflows, cognitive design theory, usability testing, and visual heuristics.',
    rating: 4.91,
    reviewsCount: 2450,
    studentsCount: 12550,
    coursesCount: 1,
    specialties: ['Figma', 'UX Research', 'Design Systems', 'Micro-interactions'],
    socials: {
      twitter: 'https://twitter.com/sophiadesigns',
      linkedin: 'https://linkedin.com/in/sophiachen-design',
      website: 'https://sophiachen.design'
    }
  },
  {
    id: 'inst-3',
    name: 'Dr. Marcus Vance',
    role: 'Data Scientist & AI Researcher',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&h=150&q=80',
    bio: 'Dr. Marcus Vance holds a PhD in Computer Science from Stanford University. He spent six years at Google Brain as a research scientist, specializing in natural language processing and reinforcement learning. His teaching emphasizes rigorous mathematics made approachable with hands-on Python projects.',
    rating: 4.79,
    reviewsCount: 1890,
    studentsCount: 9150,
    coursesCount: 1,
    specialties: ['Python', 'Machine Learning', 'TensorFlow', 'Neural Networks', 'Pandas'],
    socials: {
      linkedin: 'https://linkedin.com/in/marcusvance-data',
      website: 'https://marcusvance.ai'
    }
  },
  {
    id: 'inst-4',
    name: 'Sarah Jenkins',
    role: 'Growth Marketing Executive',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&h=150&q=80',
    bio: 'Sarah Jenkins is a veteran growth marketer who has scaled SaaS platforms from zero to millions in annual recurring revenue. She advises startups globally on search engine optimization, content strategy, targeted media acquisition, and data-driven marketing loops.',
    rating: 4.68,
    reviewsCount: 1140,
    studentsCount: 6800,
    coursesCount: 1,
    specialties: ['SEO', 'Google Ads', 'Content Strategy', 'Funnel Optimization'],
    socials: {
      twitter: 'https://twitter.com/sarahgrowths',
      linkedin: 'https://linkedin.com/in/sarahjenkins-marketing'
    }
  },
  {
    id: 'inst-5',
    name: 'Michael Chang',
    role: 'Principal Product Manager',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&h=150&q=80',
    bio: 'Michael is a senior product leader who has managed major product suites at Uber, Airbnb, and Microsoft. Over his 15-year career, he has launched international products across logistics, accommodation, and SaaS. He specializes in product strategy, roadmap scaling, and agile facilitation.',
    rating: 4.82,
    reviewsCount: 950,
    studentsCount: 4230,
    coursesCount: 1,
    specialties: ['Agile Methodologies', 'Product Discovery', 'Roadmapping', 'User Analytics'],
    socials: {
      linkedin: 'https://linkedin.com/in/michaelchang-pm',
      website: 'https://changproduct.com'
    }
  }
];

export const CATEGORIES = [
  {
    id: 'cat-1',
    name: 'Tech & Development',
    slug: 'development',
    count: 14,
    icon: 'Code',
    description: 'Learn modern programming languages, full-stack frameworks, mobile app development, and cloud architecture.',
    banner: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'cat-2',
    name: 'Design & Creative',
    slug: 'design',
    count: 8,
    icon: 'Palette',
    description: 'Master UI/UX layouts, graphic styling, creative branding, motion design, and industry standard prototyping tools.',
    banner: 'https://images.unsplash.com/photo-1581291518655-9523c932dedf?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'cat-3',
    name: 'Data & AI',
    slug: 'data-ai',
    count: 11,
    icon: 'Cpu',
    description: 'Master statistical analysis, deep neural networks, quantitative python libraries, and data engineering patterns.',
    banner: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'cat-4',
    name: 'Business & Marketing',
    slug: 'business-marketing',
    count: 15,
    icon: 'TrendingUp',
    description: 'Explore actionable growth hacks, product discovery framework strategies, and customer retention metrics.',
    banner: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'cat-5',
    name: 'Finance & Accounting',
    slug: 'finance',
    count: 6,
    icon: 'DollarSign',
    description: 'Understand corporate financial sheets, cryptocurrency networks, portfolio modeling, and personal investment strategies.',
    banner: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 'cat-6',
    name: 'Personal Development',
    slug: 'personal-growth',
    count: 9,
    icon: 'UserCheck',
    description: 'Build leadership competencies, strategic public speaking, productivity habits, and emotional communication.',
    banner: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1200&q=80'
  }
];

export const COURSES: Course[] = [
  {
    id: 'course-1',
    title: 'The Ultimate Web Development Bootcamp',
    instructorId: 'inst-1',
    instructorName: 'Alex Rivers',
    instructorTitle: 'Senior Full-Stack Engineer',
    instructorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80',
    category: 'Tech & Development',
    categorySlug: 'development',
    rating: 4.85,
    studentsCount: 12450,
    duration: '42 hours',
    level: 'All Levels',
    price: 99.99,
    discountPercent: 20,
    thumbnailUrl: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=600&q=80',
    description: 'Master HTML5, CSS3, JavaScript ES6+, React, Node.js, Express, and MongoDB by building 10 production-grade SaaS applications from the ground up.',
    overview: 'This comprehensive bootcamp is structured carefully to take you from a complete coding novice to an industry-ready full-stack engineer. Every topic is grounded in real-world application building. You will write clean, optimized, and responsive code, understanding both client-side interactivity and robust backend APIs.',
    requirements: [
      'A computer running macOS, Windows, or Linux with internet access.',
      'No prior programming or computer science knowledge required — we start at zero.'
    ],
    whatYouLearn: [
      'Write standards-compliant, semantic HTML5 structure and advanced CSS3 responsive grids.',
      'Master fundamental JavaScript programming: variables, scopes, closures, promises, and async operations.',
      'Construct beautiful interactive user interfaces with React, state hooks, routing, and Tailwind layout utilities.',
      'Build scalable server architectures with Express, REST APIs, middleware filters, and structured data queries.',
      'Implement industry-standard secure user authentication, token headers, and password hashing procedures.'
    ],
    sections: [
      {
        id: 'c1-sec-1',
        title: 'Introduction & Setup',
        lessons: [
          { id: 'c1-l1', title: 'Welcome & Curriculum Overview', duration: '12:45', isPreview: true },
          { id: 'c1-l2', title: 'How to Get Help & Join our Community', duration: '05:30', isPreview: true },
          { id: 'c1-l3', title: 'Setting Up Your Environment: VS Code & Terminal', duration: '18:15', isPreview: false }
        ]
      },
      {
        id: 'c1-sec-2',
        title: 'Advanced JavaScript (ES6+)',
        lessons: [
          { id: 'c1-l4', title: 'Understanding Scope, Hoisting, and Closures', duration: '24:50', isPreview: true },
          { id: 'c1-l5', title: 'Asynchronous Workflows: Promises & Async/Await', duration: '31:10', isPreview: false },
          { id: 'c1-l6', title: 'Modern Array Methods & Object Destructuring', duration: '19:40', isPreview: false }
        ]
      },
      {
        id: 'c1-sec-3',
        title: 'React Fundamentals',
        lessons: [
          { id: 'c1-l7', title: 'Thinking in Components & JSX Syntax', duration: '22:15', isPreview: false },
          { id: 'c1-l8', title: 'Mastering State & Event Handlers (useState)', duration: '28:40', isPreview: false },
          { id: 'c1-l9', title: 'The Component Lifecycle and useEffect', duration: '35:20', isPreview: false }
        ]
      },
      {
        id: 'c1-sec-4',
        title: 'Backend Mastery with Node & Express',
        lessons: [
          { id: 'c1-l10', title: 'Understanding Event Loop & Server Setup', duration: '18:30', isPreview: false },
          { id: 'c1-l11', title: 'Designing Clean RESTful Endpoints', duration: '27:15', isPreview: false },
          { id: 'c1-l12', title: 'Creating Secure Token-Based Session Controllers', duration: '33:10', isPreview: false }
        ]
      }
    ],
    reviews: [
      {
        id: 'c1-r1',
        userName: 'David Miller',
        rating: 5,
        date: '2026-08-14',
        comment: 'This is hands down the best course on web development available online. Alex has an incredible teaching style that avoids technical jargon and focuses heavily on practical coding. The projects we built are already in my personal portfolio!'
      },
      {
        id: 'c1-r2',
        userName: 'Elena Petrova',
        rating: 4,
        date: '2026-09-02',
        comment: 'Very intensive and thorough. The React section was crystal clear, though the Node database setup was a bit fast. Highly recommend for aspiring junior developers.'
      }
    ]
  },
  {
    id: 'course-2',
    title: 'UI/UX Design Masterclass: Figma to High-Fidelity Mockups',
    instructorId: 'inst-2',
    instructorName: 'Sophia Chen',
    instructorTitle: 'Lead UI/UX Designer',
    instructorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&h=150&q=80',
    category: 'Design & Creative',
    categorySlug: 'design',
    rating: 4.91,
    studentsCount: 8320,
    duration: '28 hours',
    level: 'All Levels',
    price: 89.99,
    discountPercent: 15,
    thumbnailUrl: 'https://images.unsplash.com/photo-1581291518655-9523c932dedf?auto=format&fit=crop&w=600&q=80',
    description: 'Learn professional UI patterns, user-centered research methodologies, wireframing, high-fidelity responsive styling, and modern prototyping in Figma.',
    overview: 'This masterclass is designed to help you think like a world-class UI/UX designer. We bypass generic screen replicas to explore the absolute core of design thinking: solving real human problems through intuitive, visual hierarchies. You will learn typography scales, robust color systems, responsive layouts, design token exports, and interactive micro-animations.',
    requirements: [
      'A computer with a web browser (Figma is free and runs in the browser or app).',
      'No background in drawing, sketching, or software design required.'
    ],
    whatYouLearn: [
      'Apply solid cognitive user-experience heuristics to resolve complex layout problems.',
      'Master Figma tools: auto-layout systems, reusable component libraries, and interactive prototyping.',
      'Establish visual architecture: optimal grids, mathematical typography scales, and accessible contrast palettes.',
      'Plan user research, empathy maps, interactive journey paths, and low-fidelity structural wires.',
      'Create high-fidelity mobile and desktop mockups with fluid responsive behavior.'
    ],
    sections: [
      {
        id: 'c2-sec-1',
        title: 'The Fundamentals of UX Thinking',
        lessons: [
          { id: 'c2-l1', title: 'What is UI vs UX? Myths & Realities', duration: '15:20', isPreview: true },
          { id: 'c2-l2', title: 'Understanding Cognitive Overload & Fitts Law', duration: '22:10', isPreview: true },
          { id: 'c2-l3', title: 'Mapping User Personas & Practical Journeys', duration: '18:45', isPreview: false }
        ]
      },
      {
        id: 'c2-sec-2',
        title: 'Mastering Figma Foundations',
        lessons: [
          { id: 'c2-l4', title: 'Getting Started: Interface, Frames, and Vectors', duration: '24:30', isPreview: false },
          { id: 'c2-l5', title: 'Power-up with Auto Layout 4.0: Stack & Fill', duration: '38:15', isPreview: false },
          { id: 'c2-l6', title: 'Designing Reusable Component Sets & Variables', duration: '31:40', isPreview: false }
        ]
      },
      {
        id: 'c2-sec-3',
        title: 'Visual Design Systems',
        lessons: [
          { id: 'c2-l7', title: 'Establishing Mathematical Typography Scales', duration: '19:10', isPreview: false },
          { id: 'c2-l8', title: 'Accessible Color Palettes & Contrast Compliance', duration: '26:50', isPreview: false }
        ]
      }
    ],
    reviews: [
      {
        id: 'c2-r1',
        userName: 'Chloe Fontaine',
        rating: 5,
        date: '2026-07-28',
        comment: 'Sophia is an outstanding mentor. Her approach to auto-layout and design systems transformed my messy Figma canvas into highly organized developer-friendly components.'
      },
      {
        id: 'c2-r2',
        userName: 'Jason Vance',
        rating: 5,
        date: '2026-09-10',
        comment: 'Outstanding! The module on cognitive UX gave me an entire vocabulary to justify my design choices to client engineers. Best value ever.'
      }
    ]
  },
  {
    id: 'course-3',
    title: 'Data Science & Machine Learning with Python',
    instructorId: 'inst-3',
    instructorName: 'Dr. Marcus Vance',
    instructorTitle: 'AI Researcher',
    instructorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&h=150&q=80',
    category: 'Data & AI',
    categorySlug: 'data-ai',
    rating: 4.79,
    studentsCount: 9150,
    duration: '35 hours',
    level: 'Intermediate',
    price: 119.99,
    discountPercent: 25,
    thumbnailUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=600&q=80',
    description: 'Dive deep into Pandas, NumPy, Scikit-Learn, TensorFlow, and deep learning neural networks. Write real data prediction models.',
    overview: 'Transform into an AI-ready data analyst. Guided by Dr. Vance, you will write practical Python scripts to process massive datasets, perform explorative statistical analyses, and train custom deep learning neural networks. You will master both foundational data science models and state-of-the-art predictive networks.',
    requirements: [
      'Basic conceptual understanding of programming (loops, conditions).',
      'High school level math or algebra basics.'
    ],
    whatYouLearn: [
      'Analyze and clean dirty data files utilizing NumPy and Pandas matrices.',
      'Construct beautiful data visualization dashboards with Matplotlib and Seaborn.',
      'Implement regression, clustering, classification, and decision tree logic.',
      'Train, test, and tune supervised and unsupervised learning algorithms.',
      'Build multi-layer artificial neural networks using TensorFlow and Keras.'
    ],
    sections: [
      {
        id: 'c3-sec-1',
        title: 'Mathematical Foundations & Python Basics',
        lessons: [
          { id: 'c3-l1', title: 'Python Environments and Jupyter Notebook Setup', duration: '14:20', isPreview: true },
          { id: 'c3-l2', title: 'Data Structures: Lists, Tuples, and Dictionaries', duration: '20:15', isPreview: false },
          { id: 'c3-l3', title: 'Vectors and Matrix Operations with NumPy', duration: '28:40', isPreview: false }
        ]
      },
      {
        id: 'c3-sec-2',
        title: 'Data Wrangling with Pandas',
        lessons: [
          { id: 'c3-l4', title: 'Reading CSVs, Excel, and JSON into DataFrames', duration: '22:10', isPreview: true },
          { id: 'c3-l5', title: 'Handling Null Values, Outliers, and Grouping', duration: '31:45', isPreview: false },
          { id: 'c3-l6', title: 'Merging, Joining, and Reshaping Data Collections', duration: '25:30', isPreview: false }
        ]
      },
      {
        id: 'c3-sec-3',
        title: 'Machine Learning Pipelines',
        lessons: [
          { id: 'c3-l7', title: 'Understanding Train/Test Split & Cross-Validation', duration: '19:40', isPreview: false },
          { id: 'c3-l8', title: 'Building Logistic Regression Models with Scikit-Learn', duration: '34:20', isPreview: false }
        ]
      }
    ],
    reviews: [
      {
        id: 'c3-r1',
        userName: 'Marcus Aurelius',
        rating: 4,
        date: '2026-08-05',
        comment: 'Dr. Vance breaks down complex linear algebra into animations and visual diagrams. Some linear regression models were hard but the Jupyter notebook files were perfectly explained.'
      }
    ]
  },
  {
    id: 'course-4',
    title: 'Growth Marketing & Funnel Scaling Strategy',
    instructorId: 'inst-4',
    instructorName: 'Sarah Jenkins',
    instructorTitle: 'Growth Executive',
    instructorAvatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&h=150&q=80',
    category: 'Business & Marketing',
    categorySlug: 'business-marketing',
    rating: 4.68,
    studentsCount: 6800,
    duration: '18 hours',
    level: 'Beginner',
    price: 49.99,
    discountPercent: 10,
    thumbnailUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=600&q=80',
    description: 'Learn SEO, high-impact Google Ads, advanced email copywriting, automated conversion optimization, and data analytics dashboards.',
    overview: 'Marketing is no longer just about guessing campaigns. It is a precise engineering loop. In this course, you will learn the exact funnel strategy used to scale high-growth startups from early-stage traction to multi-million dollar channels. You will construct complete SEO maps, design copy for ads, and implement automated retention emails.',
    requirements: [
      'No marketing experience required. A basic business idea or product is helpful.'
    ],
    whatYouLearn: [
      'Audit search engine visibility and execute high-yield keyword strategies.',
      'Build profitable Google and Meta Ads structures, measuring acquisition cost.',
      'Write highly persuasive email campaigns and configure conversion hooks.',
      'Build dynamic landing page designs optimized to convert passive traffic.',
      'Measure key product-marketing metrics: CAC, LTV, Churn, and ARPU.'
    ],
    sections: [
      {
        id: 'c4-sec-1',
        title: 'Modern Funnel Architecture',
        lessons: [
          { id: 'c4-l1', title: 'The AAARRR Pirate Funnel Explained', duration: '12:15', isPreview: true },
          { id: 'c4-l2', title: 'Mapping the Modern Digital User Journey', duration: '18:50', isPreview: false }
        ]
      },
      {
        id: 'c4-sec-2',
        title: 'Advanced SEO Tactics',
        lessons: [
          { id: 'c4-l3', title: 'How Search Engines Rank Content in 2026', duration: '25:10', isPreview: true },
          { id: 'c4-l4', title: 'Keyword Intention Mapping & Content Clusters', duration: '32:40', isPreview: false }
        ]
      }
    ],
    reviews: []
  },
  {
    id: 'course-5',
    title: 'Product Management Masterclass: Build & Launch Products',
    instructorId: 'inst-5',
    instructorName: 'Michael Chang',
    instructorTitle: 'Principal PM',
    instructorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&h=150&q=80',
    category: 'Business & Marketing',
    categorySlug: 'business-marketing',
    rating: 4.82,
    studentsCount: 4230,
    duration: '24 hours',
    level: 'All Levels',
    price: 79.99,
    discountPercent: 0,
    thumbnailUrl: 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?auto=format&fit=crop&w=600&q=80',
    description: 'Master the complete product manager lifecycle: customer discovery, agile backlogs, PRD writing, roadmaps, and metric telemetry.',
    overview: 'Learn how to pilot cross-functional product development squads. This course is built on fifteen years of product leadership at Airbnb and Microsoft, giving you the real-world frameworks, product documentation templates, and communication strategy needed to excel as a PM in top-tier tech firms.',
    requirements: [
      'A baseline understanding of how tech companies operate is helpful.'
    ],
    whatYouLearn: [
      'Write highly detailed, actionable Product Requirement Documents (PRDs).',
      'Prioritize complex engineering features utilizing RICE and MoSCoW matrices.',
      'Lead agile scrum ceremonies: sprint planning, retrospective, and reviews.',
      'Establish telemetry frameworks to track user engagement and churn patterns.',
      'Coordinate alignments across Design, Engineering, Marketing, and Sales.'
    ],
    sections: [
      {
        id: 'c5-sec-1',
        title: 'Core Roles & Competencies',
        lessons: [
          { id: 'c5-l1', title: 'The Day in the Life of a Tech PM', duration: '14:10', isPreview: true },
          { id: 'c5-l2', title: 'PM vs. Product Owner vs. Project Manager', duration: '11:45', isPreview: true }
        ]
      },
      {
        id: 'c5-sec-2',
        title: 'Strategic Prioritization Frameworks',
        lessons: [
          { id: 'c5-l3', title: 'The RICE Framework: Score Features Numerically', duration: '28:15', isPreview: false },
          { id: 'c5-l4', title: 'Building Dynamic Product Roadmaps that Align Teams', duration: '35:10', isPreview: false }
        ]
      }
    ],
    reviews: []
  },
  {
    id: 'course-6',
    title: 'Cross-Platform Mobile Apps with Flutter & Dart',
    instructorId: 'inst-1',
    instructorName: 'Alex Rivers',
    instructorTitle: 'Senior Full-Stack Engineer',
    instructorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80',
    category: 'Tech & Development',
    categorySlug: 'development',
    rating: 4.88,
    studentsCount: 5120,
    duration: '30 hours',
    level: 'Intermediate',
    price: 94.99,
    discountPercent: 30,
    thumbnailUrl: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=600&q=80',
    description: 'Build native high-performance iOS and Android applications with a single Dart codebase. Master state management and device API controls.',
    overview: 'Why build two separate apps when you can compile natively to both iOS and Android with Flutter? Guided by Alex Rivers, this course will lead you through Dart basics, widget compositions, nested structural navigations, Riverpod state management, and real device controls like cameras and local storage databases.',
    requirements: [
      'Basic knowledge of programming concepts (variables, loops, arrays).'
    ],
    whatYouLearn: [
      'Write highly clean, object-oriented code utilizing Dart syntax.',
      'Assemble responsive nested widget interfaces matching Cupertino and Material specs.',
      'Control global application data layers using Riverpod state management.',
      'Query device storage, system cameras, and geographical location variables.',
      'Configure build settings and compile production builds for Apple & Google stores.'
    ],
    sections: [
      {
        id: 'c6-sec-1',
        title: 'Dart Language Essentials',
        lessons: [
          { id: 'c6-l1', title: 'Intro to Dart Syntax, Classes, and Methods', duration: '18:10', isPreview: true },
          { id: 'c6-l2', title: 'Asynchronous Dart: Futures & Stream Hooks', duration: '22:45', isPreview: false }
        ]
      },
      {
        id: 'c6-sec-2',
        title: 'Building Interactive UIs with Widgets',
        lessons: [
          { id: 'c6-l3', title: 'Stateless vs. Stateful Widgets in Detail', duration: '29:30', isPreview: true },
          { id: 'c6-l4', title: 'Handling Input Forms, Validation, and Lists', duration: '31:10', isPreview: false }
        ]
      }
    ],
    reviews: []
  }
];

export const PRICING_PLANS: PricingPlan[] = [
  {
    name: 'Single Class',
    priceMonthly: 0,
    priceAnnually: 0,
    description: 'Perfect for learners looking to purchase courses individually with lifetime access.',
    features: [
      'Pay-per-course enrollment options',
      'Lifetime access to purchased items',
      'Individual course certificate downloads',
      'Direct lesson question boards',
      'Downloadable course resource packets'
    ],
    ctaText: 'Explore Individual Courses',
    isPopular: false
  },
  {
    name: 'All-Access Pro',
    priceMonthly: 29,
    priceAnnually: 19,
    description: 'The premier subscription providing unlimited access to our entire professional library.',
    features: [
      'Unlimited access to all 50+ classes',
      'Every upcoming class included instantly',
      'Interactive coding sandboxes & labs',
      'Members-only monthly live sessions',
      'Priority live chat support with mentors',
      'Verified platform learning paths'
    ],
    ctaText: 'Start Pro Free Trial',
    isPopular: true
  },
  {
    name: 'Learnify Enterprise',
    priceMonthly: 89,
    priceAnnually: 59,
    description: 'Custom scalable learning solutions tailored for engineering and product design organizations.',
    features: [
      'Everything in All-Access Pro plan',
      'Dedicated Customer Success Coordinator',
      'Custom learning path creations',
      'Team skill progression telemetry panels',
      'API integrations with corporate LMS',
      'Bulk seat billing with volume discounts'
    ],
    ctaText: 'Schedule Team Demo',
    isPopular: false
  }
];

export const FAQS: FAQItem[] = [
  {
    question: 'How long do I keep access to courses I buy individually?',
    answer: 'Any course you purchase individually includes complete, uninterrupted lifetime access. This includes any future lecture updates, supplemental resources, and coding file corrections that the instructor releases.'
  },
  {
    question: 'Can I cancel my All-Access Pro subscription at any point?',
    answer: 'Absolutely. You can manage or cancel your All-Access Pro membership with a single click inside your account billing settings. If you cancel, you will keep unlimited platform access until the conclusion of your active billing period.'
  },
  {
    question: 'Do these courses offer verified certificates of completion?',
    answer: 'Yes! Once you view and finish 100% of the lessons in any course, a high-resolution, shareable digital certificate is automatically generated for your profile. You can download it as a PDF or share it directly to your LinkedIn page.'
  },
  {
    question: 'Are there any interactive code files or design templates included?',
    answer: 'Yes. Every course on Learnify comes with a dedicated resource hub. Depending on the subject, this includes fully annotated GitHub code repositories, Figma source design files, Jupyter notebook data files, or PDF workbook templates.'
  },
  {
    question: 'Can I request a refund if a course does not meet my needs?',
    answer: 'We offer a complete, hassle-free 30-day money-back guarantee on all individual course purchases. If you are not fully satisfied with the material, simply reach out to our help center for a direct refund.'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 'test-1',
    name: 'Marcus Brody',
    role: 'Junior Frontend Developer at Canva',
    avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&h=150&q=80',
    comment: 'The Web Development Bootcamp was my absolute key to breaking into tech. In four months, I went from knowing zero CSS to passing Canvas technical interview. The curriculum is incredibly practical.',
    rating: 5,
    courseName: 'The Ultimate Web Development Bootcamp'
  },
  {
    id: 'test-2',
    name: 'Emily Watson',
    role: 'Product Designer at Figma',
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&h=150&q=80',
    comment: 'I recommended Sophias UI/UX Masterclass to all junior designers joining our incubator. The auto-layout workflow sessions alone are worth ten times the course price. Truly commercial-grade instruction.',
    rating: 5,
    courseName: 'UI/UX Design Masterclass: Figma to High-Fidelity Mockups'
  },
  {
    id: 'test-3',
    name: 'Niels Henderson',
    role: 'Data Analyst at Revolut',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&h=150&q=80',
    comment: 'Dr. Vance has a rare teaching gift. He makes machine learning algorithms mathematically logical without letting you drown in academic notation. The Python project folders are exceptionally neat.',
    rating: 5,
    courseName: 'Data Science & Machine Learning with Python'
  }
];
