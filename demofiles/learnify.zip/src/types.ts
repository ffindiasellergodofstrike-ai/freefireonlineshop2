export interface Lesson {
  id: string;
  title: string;
  duration: string;
  videoUrl?: string;
  isPreview?: boolean;
}

export interface CourseSection {
  id: string;
  title: string;
  lessons: Lesson[];
}

export interface Review {
  id: string;
  userName: string;
  rating: number;
  date: string;
  comment: string;
}

export interface Course {
  id: string;
  title: string;
  instructorId: string;
  instructorName: string;
  instructorTitle: string;
  instructorAvatar: string;
  category: string;
  categorySlug: string;
  rating: number;
  studentsCount: number;
  duration: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced' | 'All Levels';
  price: number;
  discountPercent: number; // e.g. 20 for 20%
  thumbnailUrl: string;
  description: string;
  overview: string;
  requirements: string[];
  whatYouLearn: string[];
  sections: CourseSection[];
  reviews: Review[];
}

export interface Instructor {
  id: string;
  name: string;
  role: string;
  avatarUrl: string;
  bio: string;
  rating: number;
  reviewsCount: number;
  studentsCount: number;
  coursesCount: number;
  specialties: string[];
  socials: {
    twitter?: string;
    linkedin?: string;
    website?: string;
  };
}

export interface PricingPlan {
  name: string;
  priceMonthly: number;
  priceAnnually: number;
  description: string;
  features: string[];
  ctaText: string;
  isPopular: boolean;
}

export interface FAQItem {
  question: string;
  answer: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  avatarUrl: string;
  comment: string;
  rating: number;
  courseName: string;
}
