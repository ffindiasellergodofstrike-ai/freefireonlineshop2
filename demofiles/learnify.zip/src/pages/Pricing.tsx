import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Check, Info, HelpCircle, ShieldAlert } from 'lucide-react';
import { PRICING_PLANS } from '../data';

export const Pricing: React.FC = () => {
  const [isAnnual, setIsAnnual] = useState(false);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  const checkoutSimulation = (planName: string, price: number) => {
    alert(`Thank you for choosing the ${planName} plan!\n\nThis checkout flow is fully integrated for Vercel, and in a production deployment, this would safely route directly to a server-side Stripe Checkout session.`);
  };

  const planComparison = [
    { feature: 'Individual course purchases (lifetime access)', single: 'Check', pro: 'Check', ent: 'Check' },
    { feature: 'High-res certificate download (PDF & LinkedIn)', single: 'Check', pro: 'Check', ent: 'Check' },
    { feature: 'Syllabus resource files & downloads', single: 'Check', pro: 'Check', ent: 'Check' },
    { feature: 'Unlimited access to all 50+ classes', single: 'Minus', pro: 'Check', ent: 'Check' },
    { feature: 'Upcoming monthly class releases', single: 'Minus', pro: 'Check', ent: 'Check' },
    { feature: 'Interactive coding sandboxes & labs', single: 'Minus', pro: 'Check', ent: 'Check' },
    { feature: 'Members-only monthly live masterclasses', single: 'Minus', pro: 'Check', ent: 'Check' },
    { feature: 'Dedicated Customer Success Coordinator', single: 'Minus', pro: 'Minus', ent: 'Check' },
    { feature: 'LMS API integrations & SSO controls', single: 'Minus', pro: 'Minus', ent: 'Check' },
    { feature: 'Team telemetry panels & progress tracking', single: 'Minus', pro: 'Minus', ent: 'Check' },
  ];

  const pricingFaqs = [
    {
      q: 'Is there a contract or commitment period?',
      a: 'No contracts. All-Access Pro and Enterprise memberships operate on a rolling subscription basis. You are free to upgrade, downgrade, or cancel your active subscription plan at any point through your billing portal.'
    },
    {
      q: 'Do you offer localized pricing tiers?',
      a: 'Yes, Learnify uses automated geographic systems to adjust checkout prices to your localized currency standard to ensure global learning accessibility.'
    },
    {
      q: 'What is your refund policy?',
      a: 'We offer a complete, hassle-free, 30-day money-back guarantee for all individual courses purchased on our platform. Subscriptions can be canceled at any time to halt upcoming billing loops.'
    }
  ];

  return (
    <div id="pricing-page" className="bg-neutral-50/50 pb-20 pt-8">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Page Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h1 className="text-3xl font-extrabold tracking-tight text-neutral-900 sm:text-4xl">
            Memberships & Pricing Plans
          </h1>
          <p className="mt-3 text-sm text-neutral-500">
            Pay once for lifetime access to individual courses, or unlock our entire catalog and interactive coding sandboxes with our All-Access subscription.
          </p>

          {/* Monthly/Annual Toggle */}
          <div className="mt-8 inline-flex items-center gap-3 bg-neutral-100 p-1 rounded-full border border-neutral-200 shadow-inner">
            <button
              onClick={() => setIsAnnual(false)}
              className={`rounded-full px-5 py-1.5 text-xs font-bold transition-all ${
                !isAnnual ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-500 hover:text-neutral-900'
              }`}
            >
              Monthly Billing
            </button>
            <button
              onClick={() => setIsAnnual(true)}
              className={`rounded-full px-5 py-1.5 text-xs font-bold transition-all ${
                isAnnual ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-500 hover:text-neutral-900'
              }`}
            >
              Annual Billing <span className="text-[10px] text-green-600 font-bold ml-1">Save 35%</span>
            </button>
          </div>
        </div>

        {/* 1. Plans Cards Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch mb-16">
          {PRICING_PLANS.map((plan, i) => {
            const price = isAnnual ? plan.priceAnnually : plan.priceMonthly;
            const period = isAnnual ? '/yr' : '/mo';
            
            return (
              <div
                key={i}
                className={`relative flex flex-col p-6 sm:p-8 rounded-2xl bg-white border ${
                  plan.isPopular
                    ? 'border-blue-500 shadow-xl ring-1 ring-blue-500/10'
                    : 'border-neutral-100 shadow-sm'
                }`}
              >
                {plan.isPopular && (
                  <span className="absolute -top-3 left-1/2 -translate-y-1/2 rounded-full bg-blue-600 px-3.5 py-1 text-[10px] font-bold uppercase tracking-wider text-white shadow-md">
                    Most Popular
                  </span>
                )}
                
                <h3 className="text-lg font-bold text-neutral-900">{plan.name}</h3>
                <p className="mt-2 text-xs text-neutral-500 min-h-[2.5rem] leading-relaxed">{plan.description}</p>
                
                <div className="mt-5 flex items-baseline gap-1">
                  <span className="text-4xl font-extrabold text-neutral-900">${price}</span>
                  {plan.priceMonthly > 0 && <span className="text-sm font-semibold text-neutral-400">{period}</span>}
                </div>

                <div className="my-6 border-t border-neutral-100" />

                <ul className="space-y-3.5 flex-1 mb-8">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2.5 text-xs text-neutral-600">
                      <Check className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                      <span className="leading-tight">{feature}</span>
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => checkoutSimulation(plan.name, price)}
                  className={`w-full flex h-11 items-center justify-center rounded-xl text-xs font-bold transition-all shadow-sm ${
                    plan.isPopular
                      ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-100'
                      : 'bg-neutral-50 hover:bg-neutral-100 text-neutral-800'
                  }`}
                >
                  {plan.ctaText}
                </button>
              </div>
            );
          })}
        </div>

        {/* 2. Platform Comparison Matrix Table */}
        <div className="hidden md:block rounded-2xl border border-neutral-100 bg-white shadow-sm p-6 sm:p-8 mb-16 overflow-hidden">
          <h2 className="text-lg font-bold text-neutral-950 mb-6">Compare Platform Access</h2>
          
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-neutral-100 text-neutral-400 font-bold uppercase tracking-wider">
                <th className="pb-4 font-bold">Platform Capabilities</th>
                <th className="pb-4 text-center font-bold">Single Course</th>
                <th className="pb-4 text-center font-bold">All-Access Pro</th>
                <th className="pb-4 text-center font-bold">Learnify Enterprise</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-50 text-neutral-600">
              {planComparison.map((row, i) => (
                <tr key={i} className="hover:bg-neutral-50/50 transition-colors">
                  <td className="py-3.5 font-medium text-neutral-800">{row.feature}</td>
                  <td className="py-3.5 text-center">
                    {row.single === 'Check' ? (
                      <Check className="h-4 w-4 text-emerald-500 mx-auto" />
                    ) : (
                      <span className="text-neutral-300">—</span>
                    )}
                  </td>
                  <td className="py-3.5 text-center">
                    {row.pro === 'Check' ? (
                      <Check className="h-4 w-4 text-emerald-500 mx-auto" />
                    ) : (
                      <span className="text-neutral-300">—</span>
                    )}
                  </td>
                  <td className="py-3.5 text-center">
                    {row.ent === 'Check' ? (
                      <Check className="h-4 w-4 text-emerald-500 mx-auto" />
                    ) : (
                      <span className="text-neutral-300">—</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* 3. Pricing FAQ Details */}
        <div className="max-w-3xl mx-auto rounded-2xl border border-neutral-100 bg-white p-6 sm:p-8 shadow-sm">
          <div className="flex items-center gap-2 mb-6 border-b border-neutral-50 pb-4">
            <HelpCircle className="h-5 w-5 text-blue-600" />
            <h2 className="text-base font-bold text-neutral-950">Pricing & Billing FAQs</h2>
          </div>

          <div className="space-y-4">
            {pricingFaqs.map((faq, index) => {
              const isOpen = activeFaq === index;
              return (
                <div key={index} className="border-b border-neutral-50 last:border-0 pb-4 last:pb-0">
                  <button
                    onClick={() => setActiveFaq(isOpen ? null : index)}
                    className="flex w-full items-center justify-between text-left text-xs font-bold text-neutral-800 hover:text-blue-600 transition-colors"
                  >
                    <span>{faq.q}</span>
                    <span className="text-neutral-400 font-bold ml-4">{isOpen ? '−' : '+'}</span>
                  </button>
                  {isOpen && (
                    <p className="mt-2 text-xs text-neutral-500 leading-relaxed bg-neutral-50/50 rounded-lg p-3">
                      {faq.a}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </div>
  );
};
