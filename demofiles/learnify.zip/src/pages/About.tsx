import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Users, Compass, ShieldCheck, Heart, Sparkles, Award } from 'lucide-react';

export const About: React.FC = () => {
  const values = [
    {
      title: 'Pedagogical Integrity',
      desc: 'We strictly reject shallow, speed-run lectures. Every curriculum is paced logically to deliver deep conceptual clarity and practical fluency.',
      icon: Compass,
      color: 'bg-blue-50 text-blue-600',
    },
    {
      title: 'Active Practitioner Guidance',
      desc: 'We believe people learn best from practitioners, not pure academics. Every mentor is active in their field, writing code or designing software daily.',
      icon: Users,
      color: 'bg-emerald-50 text-emerald-600',
    },
    {
      title: 'Actionable Portfolio Output',
      desc: 'Every syllabus focuses on building portfolio items. Our students do not simply answer multiple-choice questions; they build actual SaaS and Figma layouts.',
      icon: Award,
      color: 'bg-indigo-50 text-indigo-600',
    },
  ];

  return (
    <div id="about-page" className="flex flex-col gap-16 md:gap-24 pb-16 pt-8">
      
      {/* 1. Hero / Mission Intro */}
      <section className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 text-center">
        <span className="inline-flex items-center gap-1.5 rounded-full bg-blue-50 px-3.5 py-1 text-xs font-semibold text-blue-700 mb-6">
          <Sparkles className="h-3.5 w-3.5 animate-pulse" />
          <span>Our Mission & Vision</span>
        </span>
        
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-neutral-900 leading-none mb-6">
          We build programs that <span className="text-blue-600 font-extrabold">move you</span> forward.
        </h1>
        
        <p className="text-base sm:text-lg text-neutral-600 max-w-3xl mx-auto leading-relaxed">
          Learnify was founded in 2024 to disrupt the online coding boot camp industry. We replaced dry, outdated slide decks and un-paced programming lists with rigorous, high-fidelity masterclasses led directly by active software leads and UI designers.
        </p>

        <div className="mt-12 rounded-3xl border border-neutral-100 bg-white p-4 shadow-xl overflow-hidden max-w-3xl mx-auto">
          <img
            src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=800&q=80"
            alt="Office workspace team collaboration"
            className="rounded-2xl object-cover aspect-[16/9] w-full"
            referrerPolicy="no-referrer"
          />
        </div>
      </section>

      {/* 2. Philosophy & Values */}
      <section className="bg-neutral-50 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-xs font-extrabold tracking-widest text-blue-600 uppercase mb-2">Our Core DNA</h2>
            <p className="text-2xl sm:text-3xl font-bold text-neutral-900 tracking-tight">
              Learning Design Philosophy
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {values.map((v, idx) => {
              const Icon = v.icon;
              return (
                <div key={idx} className="flex flex-col bg-white p-6 rounded-2xl border border-neutral-100 shadow-sm">
                  <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${v.color} mb-5 shadow-sm`}>
                    <Icon className="h-5 w-5" />
                  </div>
                  <h3 className="text-base font-bold text-neutral-900 mb-2">{v.title}</h3>
                  <p className="text-xs text-neutral-500 leading-relaxed">{v.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* 3. CTA to Catalog */}
      <section className="mx-auto max-w-4xl px-4 sm:px-6 text-center">
        <div className="rounded-2xl border border-blue-100 bg-blue-50/30 p-8 sm:p-12">
          <h2 className="text-xl sm:text-2xl font-bold text-neutral-950 mb-3">Unlock your true potential today</h2>
          <p className="text-xs text-neutral-500 leading-relaxed max-w-xl mx-auto mb-6">
            Join forty-five thousand global students who have bypass-loaded their skill stacks. Search our curated catalogs or subscribe for unlimited access.
          </p>
          <div className="flex gap-4 justify-center items-center">
            <Link
              to="/courses"
              className="flex h-11 items-center justify-center rounded-full bg-blue-600 hover:bg-blue-700 text-white px-6 text-xs font-bold transition-all shadow-md shadow-blue-100"
            >
              Browse Catalog
            </Link>
            <Link
              to="/contact"
              className="flex h-11 items-center justify-center rounded-full bg-white hover:bg-neutral-50 text-neutral-800 px-6 text-xs font-bold transition-all border border-neutral-200"
            >
              Get in Touch
            </Link>
          </div>
        </div>
      </section>

    </div>
  );
};
