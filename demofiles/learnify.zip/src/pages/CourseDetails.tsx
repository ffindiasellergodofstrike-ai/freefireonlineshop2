import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Star, Clock, GraduationCap, Users, Check, ArrowRight, ChevronDown, ChevronUp, Play, Trophy, ShieldCheck, Heart } from 'lucide-react';
import { COURSES, INSTRUCTORS } from '../data';
import { useApp } from '../context/AppContext';

export const CourseDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { enrollInCourse, isEnrolled } = useApp();
  const [activeAccordion, setActiveAccordion] = useState<string | null>('c1-sec-1'); // Default open first section
  const [isLiked, setIsLiked] = useState(false);

  const course = COURSES.find((c) => c.id === id);

  if (!course) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-16 text-center">
        <h2 className="text-2xl font-bold text-neutral-900">Course Not Found</h2>
        <p className="text-neutral-500 mt-2">The syllabus or learning track you requested could not be located.</p>
        <Link to="/courses" className="mt-6 inline-flex items-center gap-2 rounded-full bg-blue-600 text-white px-6 py-2.5 text-xs font-bold shadow-md">
          Back to Catalog
        </Link>
      </div>
    );
  }

  const {
    title,
    instructorName,
    instructorTitle,
    instructorAvatar,
    category,
    rating,
    studentsCount,
    duration,
    level,
    price,
    discountPercent,
    thumbnailUrl,
    description,
    overview,
    requirements,
    whatYouLearn,
    sections,
    reviews
  } = course;

  const enrolled = isEnrolled(course.id);
  const finalPrice = discountPercent > 0 ? price * (1 - discountPercent / 100) : price;

  const handleEnrollClick = () => {
    if (enrolled) {
      navigate(`/course-player/${course.id}`);
    } else {
      enrollInCourse(course.id);
      // Optional state-driven feedback or immediate redirection
      navigate(`/course-player/${course.id}`);
    }
  };

  const toggleAccordion = (sectionId: string) => {
    setActiveAccordion(activeAccordion === sectionId ? null : sectionId);
  };

  return (
    <div id="course-details-page" className="bg-neutral-50/50 pb-20">
      
      {/* 1. Header Hero Banner */}
      <section className="bg-neutral-900 text-white py-12 md:py-16 relative">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            <div className="lg:col-span-8 flex flex-col items-start">
              {/* Category Breadcrumb */}
              <span className="inline-flex items-center rounded-full bg-white/10 px-3 py-1 text-xs font-semibold text-blue-300 mb-6">
                {category}
              </span>

              {/* Title */}
              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight mb-4 leading-tight">
                {title}
              </h1>

              {/* Tagline description */}
              <p className="text-sm sm:text-base text-neutral-300 max-w-3xl mb-6 leading-relaxed">
                {description}
              </p>

              {/* Course Meta Info */}
              <div className="flex flex-wrap items-center gap-6 text-xs text-neutral-300 mt-2">
                <div className="flex items-center gap-1.5 text-amber-400 font-bold">
                  <Star className="h-4 w-4 fill-amber-400" />
                  <span>{rating.toFixed(2)} Rating</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Users className="h-4 w-4 text-neutral-400" />
                  <span>{studentsCount.toLocaleString()} Enrolled</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Clock className="h-4 w-4 text-neutral-400" />
                  <span>{duration}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <GraduationCap className="h-4 w-4 text-neutral-400" />
                  <span>{level}</span>
                </div>
              </div>

              {/* Author Row */}
              <div className="flex items-center gap-3 mt-6">
                <img
                  src={instructorAvatar}
                  alt={instructorName}
                  className="h-10 w-10 rounded-full object-cover border border-neutral-700"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <span className="block text-xs text-neutral-400">Created directly by</span>
                  <Link to={`/instructor/${course.instructorId}`} className="text-sm font-bold text-white hover:text-blue-400 transition-colors">
                    {instructorName} <span className="text-xs font-medium text-neutral-400">— {instructorTitle}</span>
                  </Link>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 2. Page Core Grid content */}
      <section className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 mt-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* LEFT SIDE CONTENT - SYLLABUS DETAILS */}
          <div className="lg:col-span-8 flex flex-col gap-10">
            
            {/* What you will learn section */}
            <div className="rounded-2xl border border-neutral-100 bg-white p-6 sm:p-8 shadow-sm">
              <h2 className="text-lg font-bold text-neutral-950 mb-5">What you will master in this class</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {whatYouLearn.map((item, idx) => (
                  <div key={idx} className="flex items-start gap-3 text-xs text-neutral-600 leading-normal">
                    <div className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-blue-50 text-blue-600 mt-0.5">
                      <Check className="h-3 w-3" />
                    </div>
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Course Overview description text */}
            <div className="flex flex-col gap-4">
              <h2 className="text-lg font-bold text-neutral-900">Course Overview</h2>
              <p className="text-xs sm:text-sm text-neutral-600 leading-relaxed">
                {overview}
              </p>
            </div>

            {/* Curriculum Accordion */}
            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
                <h2 className="text-lg font-bold text-neutral-900">Curriculum Syllabus</h2>
                <span className="text-xs font-medium text-neutral-500">
                  {sections.length} modules • {sections.flatMap(s => s.lessons).length} lessons
                </span>
              </div>

              <div className="space-y-3">
                {sections.map((section) => {
                  const isOpen = activeAccordion === section.id;
                  return (
                    <div
                      key={section.id}
                      className="rounded-xl border border-neutral-100 bg-white shadow-sm overflow-hidden"
                    >
                      <button
                        onClick={() => toggleAccordion(section.id)}
                        className="flex w-full items-center justify-between gap-4 p-5 text-left text-sm font-bold text-neutral-800 hover:text-neutral-900 transition-colors"
                      >
                        <div>
                          <span>{section.title}</span>
                          <span className="block text-[10px] text-neutral-400 font-medium mt-1">
                            {section.lessons.length} lessons
                          </span>
                        </div>
                        {isOpen ? <ChevronUp className="h-4 w-4 text-blue-600" /> : <ChevronDown className="h-4 w-4 text-neutral-400" />}
                      </button>
                      
                      {isOpen && (
                        <div className="border-t border-neutral-50 bg-neutral-50/20 divide-y divide-neutral-50">
                          {section.lessons.map((lesson) => (
                            <div
                              key={lesson.id}
                              className="flex items-center justify-between gap-4 py-3.5 px-6 text-xs text-neutral-600"
                            >
                              <div className="flex items-center gap-3">
                                <Play className="h-3.5 w-3.5 text-neutral-400 shrink-0" />
                                <span className={lesson.isPreview ? "font-semibold text-neutral-800" : ""}>{lesson.title}</span>
                              </div>
                              <div className="flex items-center gap-3">
                                {lesson.isPreview && (
                                  <span className="rounded-md bg-blue-50 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-blue-600">
                                    Preview Lecture
                                  </span>
                                )}
                                <span className="text-neutral-400">{lesson.duration}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Requirements section */}
            <div className="flex flex-col gap-4">
              <h2 className="text-lg font-bold text-neutral-900">Pre-requisites</h2>
              <ul className="space-y-2.5">
                {requirements.map((req, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-xs text-neutral-600 leading-normal">
                    <div className="h-1.5 w-1.5 rounded-full bg-blue-600 shrink-0 mt-1.5" />
                    <span>{req}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Instructor Profile Details */}
            <div className="rounded-2xl border border-neutral-100 bg-white p-6 sm:p-8 shadow-sm">
              <h2 className="text-lg font-bold text-neutral-950 mb-5">Your Class Instructor</h2>
              
              <div className="flex flex-col sm:flex-row gap-6 items-start">
                <img
                  src={instructorAvatar}
                  alt={instructorName}
                  className="h-20 w-20 rounded-xl object-cover shrink-0 border border-neutral-100"
                  referrerPolicy="no-referrer"
                />
                
                <div className="flex-1">
                  <h3 className="text-base font-bold text-neutral-900">
                    <Link to={`/instructor/${course.instructorId}`} className="hover:text-blue-600 transition-colors">
                      {instructorName}
                    </Link>
                  </h3>
                  <p className="text-xs text-neutral-400 font-medium mt-0.5">{instructorTitle}</p>
                  
                  {/* Bio brief */}
                  <p className="text-xs text-neutral-500 mt-4 leading-relaxed">
                    Alex Rivers and Sophia Chen are vetted, highly rated senior professionals teaching multiple courses on our network. Click their names to read their full pedagogical career paths and specialty skills.
                  </p>
                  
                  <Link
                    to={`/instructor/${course.instructorId}`}
                    className="mt-4 text-xs font-bold text-blue-600 hover:text-blue-700 inline-flex items-center gap-1"
                  >
                    <span>View instructor details</span>
                    <ArrowRight className="h-3 w-3" />
                  </Link>
                </div>
              </div>
            </div>

            {/* Reviews Section */}
            <div className="flex flex-col gap-6">
              <h2 className="text-lg font-bold text-neutral-900">Student Reviews</h2>
              
              {reviews.length === 0 ? (
                <p className="text-xs text-neutral-500 italic">No reviews have been submitted for this syllabus yet.</p>
              ) : (
                <div className="space-y-4">
                  {reviews.map((rev) => (
                    <div
                      key={rev.id}
                      className="p-5 rounded-xl border border-neutral-100 bg-white shadow-sm flex flex-col gap-3"
                    >
                      <div className="flex justify-between items-start gap-4">
                        <div>
                          <h4 className="text-xs font-bold text-neutral-900">{rev.userName}</h4>
                          <span className="text-[10px] text-neutral-400">{rev.date}</span>
                        </div>
                        <div className="flex items-center gap-0.5 text-amber-400">
                          {[...Array(rev.rating)].map((_, i) => (
                            <Star key={i} className="h-3.5 w-3.5 fill-current" />
                          ))}
                        </div>
                      </div>
                      <p className="text-xs text-neutral-600 leading-relaxed">
                        {rev.comment}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>

          {/* RIGHT SIDE STICKY PURCHASE PANEL */}
          <div className="lg:col-span-4 lg:sticky lg:top-24 flex flex-col gap-6">
            <div className="overflow-hidden rounded-2xl border border-neutral-100 bg-white shadow-xl">
              
              {/* Media Thumbnail */}
              <div className="relative aspect-video w-full overflow-hidden bg-neutral-900">
                <img
                  src={thumbnailUrl}
                  alt={title}
                  className="h-full w-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-neutral-950/40 flex items-center justify-center">
                  <div className="flex h-14 w-14 items-center justify-center rounded-full bg-white text-neutral-950 shadow-lg hover:scale-105 transition-transform duration-200">
                    <Play className="h-6 w-6 text-blue-600 fill-blue-600 ml-1" />
                  </div>
                </div>
                <span className="absolute bottom-3 left-3 rounded bg-neutral-950/80 backdrop-blur px-2 py-0.5 text-[10px] font-bold text-white uppercase tracking-wider">
                  Course Preview
                </span>
              </div>

              {/* Purchase Body */}
              <div className="p-6">
                
                {/* Pricing summary */}
                <div className="flex items-baseline gap-2.5 mb-5">
                  <span className="text-3xl font-extrabold text-neutral-900">${finalPrice.toFixed(2)}</span>
                  {discountPercent > 0 && (
                    <>
                      <span className="text-sm text-neutral-400 line-through">${price.toFixed(2)}</span>
                      <span className="text-xs font-bold text-emerald-600">{discountPercent}% OFF</span>
                    </>
                  )}
                </div>

                {/* Primary Button */}
                <button
                  id="enroll-cta-btn"
                  onClick={handleEnrollClick}
                  className={`w-full flex h-12 items-center justify-center gap-2 rounded-xl text-sm font-bold transition-all shadow-md ${
                    enrolled
                      ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-100'
                      : 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-100'
                  }`}
                >
                  <span>{enrolled ? 'Resume Syllabus' : 'Enroll and Start Today'}</span>
                  <ArrowRight className="h-4 w-4" />
                </button>

                <p className="mt-3 text-center text-[10px] text-neutral-400">
                  {enrolled ? 'You are enrolled in this program.' : '30-Day Money Back Guarantee • Instant Access'}
                </p>

                {/* Checklist */}
                <div className="mt-6 border-t border-neutral-50 pt-5 flex flex-col gap-3">
                  <div className="flex items-center gap-3 text-xs text-neutral-600">
                    <Clock className="h-4 w-4 text-neutral-400 shrink-0" />
                    <span>{duration} of on-demand lectures</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-neutral-600">
                    <Trophy className="h-4 w-4 text-neutral-400 shrink-0" />
                    <span>Verified completion certificate download</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-neutral-600">
                    <ShieldCheck className="h-4 w-4 text-neutral-400 shrink-0" />
                    <span>Direct question board connection</span>
                  </div>
                </div>

                {/* Like / Wishlist and Share */}
                <div className="mt-6 border-t border-neutral-50 pt-4 flex gap-3">
                  <button
                    onClick={() => setIsLiked(!isLiked)}
                    className={`flex-1 flex h-10 items-center justify-center gap-2 rounded-lg border text-xs font-semibold transition-all ${
                      isLiked
                        ? 'border-rose-100 bg-rose-50 text-rose-600'
                        : 'border-neutral-200 hover:bg-neutral-50 text-neutral-600'
                    }`}
                  >
                    <Heart className={`h-4 w-4 ${isLiked ? 'fill-rose-500 text-rose-500' : ''}`} />
                    <span>{isLiked ? 'Syllabus Liked' : 'Save Syllabus'}</span>
                  </button>
                </div>

              </div>
            </div>
          </div>

        </div>
      </section>

    </div>
  );
};
