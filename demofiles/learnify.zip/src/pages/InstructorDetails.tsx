import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Star, GraduationCap, Users, Globe, Twitter, Linkedin, BookOpen, MessageSquare } from 'lucide-react';
import { INSTRUCTORS, COURSES } from '../data';
import { CourseCard } from '../components/CourseCard';

export const InstructorDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();

  const inst = INSTRUCTORS.find((i) => i.id === id);

  if (!inst) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-16 text-center">
        <h2 className="text-2xl font-bold text-neutral-900">Instructor Not Found</h2>
        <p className="text-neutral-500 mt-2">The educator profile you requested could not be located.</p>
        <Link to="/instructors" className="mt-6 inline-flex items-center gap-2 rounded-full bg-blue-600 text-white px-6 py-2.5 text-xs font-bold shadow-md">
          Back to Faculty Directory
        </Link>
      </div>
    );
  }

  const {
    name,
    role,
    avatarUrl,
    bio,
    rating,
    reviewsCount,
    studentsCount,
    coursesCount,
    specialties,
    socials
  } = inst;

  // Filter courses taught by this specific instructor
  const instructorCourses = COURSES.filter((c) => c.instructorId === inst.id);

  const stats = [
    { label: 'Total Learners', value: studentsCount.toLocaleString(), icon: Users },
    { label: 'Active Curriculums', value: coursesCount, icon: GraduationCap },
    { label: 'Platform Reviews', value: reviewsCount.toLocaleString(), icon: MessageSquare },
    { label: 'Average Score', value: rating.toFixed(2), icon: Star },
  ];

  return (
    <div id="instructor-details-page" className="bg-neutral-50/50 pb-20 pt-8">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Core Layout Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column - Card profile overview */}
          <div className="lg:col-span-4 flex flex-col gap-6 sticky top-24">
            <div className="rounded-2xl border border-neutral-100 bg-white p-6 shadow-sm text-center flex flex-col items-center">
              
              <img
                src={avatarUrl}
                alt={name}
                className="h-28 w-28 rounded-full object-cover shadow-md border p-1 border-neutral-100 mb-4"
                referrerPolicy="no-referrer"
              />

              <h1 className="text-xl font-extrabold text-neutral-950">{name}</h1>
              <p className="text-xs text-neutral-400 font-medium leading-normal mt-1 px-4">{role}</p>

              {/* Social Channels Row */}
              <div className="flex gap-3 mt-6">
                {socials.twitter && (
                  <a href={socials.twitter} target="_blank" rel="noreferrer" className="flex h-9 w-9 items-center justify-center rounded-xl bg-neutral-50 hover:bg-blue-50 text-neutral-400 hover:text-blue-500 transition-all border border-neutral-100">
                    <Twitter className="h-4 w-4" />
                  </a>
                )}
                {socials.linkedin && (
                  <a href={socials.linkedin} target="_blank" rel="noreferrer" className="flex h-9 w-9 items-center justify-center rounded-xl bg-neutral-50 hover:bg-blue-50 text-neutral-400 hover:text-blue-700 transition-all border border-neutral-100">
                    <Linkedin className="h-4 w-4" />
                  </a>
                )}
                {socials.website && (
                  <a href={socials.website} target="_blank" rel="noreferrer" className="flex h-9 w-9 items-center justify-center rounded-xl bg-neutral-50 hover:bg-blue-50 text-neutral-400 hover:text-blue-600 transition-all border border-neutral-100">
                    <Globe className="h-4 w-4" />
                  </a>
                )}
              </div>

              {/* Specialties Tag Matrix */}
              <div className="border-t border-neutral-50 pt-5 mt-6 w-full text-left">
                <h3 className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider mb-3">Instructed Specialties</h3>
                <div className="flex flex-wrap gap-1.5">
                  {specialties.map((spec, i) => (
                    <span
                      key={i}
                      className="rounded bg-neutral-50 border border-neutral-100 px-2.5 py-1 text-[10px] font-semibold text-neutral-500 uppercase tracking-wide"
                    >
                      {spec}
                    </span>
                  ))}
                </div>
              </div>

            </div>
          </div>

          {/* Right Column - In-depth Biography & Instructed Programs list */}
          <div className="lg:col-span-8 flex flex-col gap-8">
            
            {/* Stats Dashboard Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {stats.map((s, i) => {
                const Icon = s.icon;
                return (
                  <div key={i} className="rounded-xl border border-neutral-100 bg-white p-4 shadow-sm text-center sm:text-left flex flex-col sm:flex-row items-center gap-3">
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-blue-50 text-blue-600">
                      <Icon className="h-5 w-5" />
                    </div>
                    <div>
                      <span className="block text-sm font-extrabold text-neutral-900">{s.value}</span>
                      <span className="block text-[10px] text-neutral-400 uppercase font-bold tracking-wide mt-0.5">{s.label}</span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* About Biography Section */}
            <div className="rounded-2xl border border-neutral-100 bg-white p-6 sm:p-8 shadow-sm flex flex-col gap-4">
              <h2 className="text-lg font-bold text-neutral-900">About {name}</h2>
              <p className="text-xs sm:text-sm text-neutral-600 leading-relaxed">
                {bio}
              </p>
              <p className="text-xs sm:text-sm text-neutral-600 leading-relaxed">
                As a core member of Learnify’s masterclass steering committee, {name} maintains rigorous standards of curriculum pacing, visual resource assets, and post-session question board support to ensure a premium learning experience.
              </p>
            </div>

            {/* Instructed Programs Catalog list */}
            <div className="flex flex-col gap-6">
              <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
                <h2 className="text-lg font-bold text-neutral-900">Instructed Programs ({instructorCourses.length})</h2>
                <span className="text-xs font-medium text-neutral-500">Live enrollments open</span>
              </div>

              {instructorCourses.length === 0 ? (
                <div className="flex flex-col items-center justify-center text-center p-10 border border-dashed border-neutral-200 rounded-2xl bg-white">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-neutral-100 text-neutral-400 mb-3">
                    <BookOpen className="h-6 w-6" />
                  </div>
                  <h3 className="text-sm font-bold text-neutral-800">No active programs listed</h3>
                  <p className="text-xs text-neutral-500 mt-1">This instructor is currently drafting upcoming curriculum files.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {instructorCourses.map((course) => (
                    <CourseCard key={course.id} course={course} />
                  ))}
                </div>
              )}
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
