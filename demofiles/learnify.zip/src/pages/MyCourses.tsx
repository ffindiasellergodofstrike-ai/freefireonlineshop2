import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Award, Play, CheckCircle, Clock } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { COURSES } from '../data';

export const MyCourses: React.FC = () => {
  const { enrolledCourses } = useApp();
  const [activeTab, setActiveTab] = useState<'all' | 'progress' | 'completed'>('all');

  // Map enrolled courses to complete details
  const enrolledFullCourses = enrolledCourses.map((e) => {
    const course = COURSES.find((c) => c.id === e.courseId);
    return {
      ...course,
      progressPercent: e.progressPercent,
      enrolledAt: e.enrolledAt,
      lastAccessedAt: e.lastAccessedAt
    };
  }).filter(c => c.id !== undefined);

  // Categorize
  const filteredCourses = enrolledFullCourses.filter((course) => {
    if (activeTab === 'progress') {
      return course.progressPercent > 0 && course.progressPercent < 100;
    }
    if (activeTab === 'completed') {
      return course.progressPercent === 100;
    }
    return true; // 'all'
  });

  return (
    <div id="my-courses-page" className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 pb-16">
      
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-10 text-center sm:text-left">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight text-neutral-900 sm:text-4xl">
            My Learning Catalog
          </h1>
          <p className="mt-2 text-sm text-neutral-500 max-w-3xl">
            Track your ongoing progress, review completed lecture chapters, and download earned masterclass certificates in your customized portal space.
          </p>
        </div>
        <Link
          to="/courses"
          className="rounded-full bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-6 py-2.5 transition-all shadow-md shrink-0"
        >
          Explore More Syllabi
        </Link>
      </div>

      {/* Tabs Row */}
      <div className="flex gap-4 border-b border-neutral-100 pb-2 mb-8">
        {[
          { key: 'all', label: `All Programs (${enrolledFullCourses.length})` },
          { key: 'progress', label: 'In Progress' },
          { key: 'completed', label: 'Completed Tracks' }
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key as any)}
            className={`pb-3 text-xs font-bold transition-all relative ${
              activeTab === tab.key
                ? 'text-blue-600 font-extrabold'
                : 'text-neutral-400 hover:text-neutral-800'
            }`}
          >
            {tab.label}
            {activeTab === tab.key && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-600 rounded-full" />
            )}
          </button>
        ))}
      </div>

      {/* Grid listing */}
      {filteredCourses.length === 0 ? (
        <div className="flex flex-col items-center justify-center text-center py-16 px-4 border border-dashed border-neutral-200 rounded-2xl bg-white shadow-sm">
          <div className="flex h-14 w-14 items-center justify-center rounded-full bg-neutral-100 text-neutral-400 mb-4">
            <BookOpen className="h-7 w-7" />
          </div>
          <h3 className="text-base font-bold text-neutral-900">No courses fit active tab</h3>
          <p className="text-xs text-neutral-500 max-w-sm mt-1 leading-relaxed">
            There are no curriculums listed under this filter index. Continue learning active tracks or browse the course directory.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredCourses.map((course) => {
            if (!course) return null;
            const progress = course.progressPercent;
            const isCompleted = progress === 100;

            return (
              <div
                key={course.id}
                className="flex flex-col rounded-2xl border border-neutral-100 bg-white overflow-hidden shadow-sm hover:shadow-xl hover:border-blue-100 transition-all duration-300"
              >
                {/* Image backdrop thumbnail */}
                <div className="relative aspect-video bg-neutral-100 overflow-hidden">
                  <img
                    src={course.thumbnailUrl}
                    alt={course.title}
                    className="h-full w-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <span className="absolute left-3 top-3 rounded-md bg-white/90 backdrop-blur-md px-2 py-0.5 text-[9px] font-bold text-neutral-800 uppercase tracking-wide border shadow-sm">
                    {course.category}
                  </span>
                  {isCompleted && (
                    <span className="absolute right-3 top-3 rounded-md bg-emerald-600 px-2.5 py-1 text-[10px] font-bold text-white shadow-sm flex items-center gap-1">
                      <CheckCircle className="h-3 w-3" />
                      <span>Certified</span>
                    </span>
                  )}
                </div>

                {/* Body details */}
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] font-semibold text-neutral-400 uppercase tracking-wider">Instructed by {course.instructorName}</span>
                    <h3 className="text-base font-bold text-neutral-900 leading-tight mt-1 mb-4 line-clamp-2 min-h-[2.5rem] hover:text-blue-600">
                      <Link to={`/course/${course.id}`}>{course.title}</Link>
                    </h3>

                    {/* Progress details */}
                    <div className="flex flex-col mb-4">
                      <div className="flex justify-between text-[10px] font-semibold text-neutral-400 mb-1">
                        <span>Progress Indicator</span>
                        <span>{progress}% Completed</span>
                      </div>
                      <div className="h-1.5 w-full bg-neutral-100 rounded-full overflow-hidden">
                        <div className="h-full bg-blue-600 transition-all duration-500" style={{ width: `${progress}%` }} />
                      </div>
                    </div>
                  </div>

                  {/* Actions footer row */}
                  <div className="mt-4 pt-3 border-t border-neutral-50 flex items-center justify-between gap-4">
                    <Link
                      to={`/course/${course.id}`}
                      className="text-xs font-semibold text-neutral-400 hover:text-neutral-700"
                    >
                      View Syllabus
                    </Link>
                    
                    <Link
                      to={`/course-player/${course.id}`}
                      className="inline-flex h-9 items-center justify-center gap-1.5 rounded-full bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-4 transition-all shadow-md shadow-blue-100"
                    >
                      <Play className="h-3.5 w-3.5 fill-current" />
                      <span>{isCompleted ? 'Review Class' : progress > 0 ? 'Resume Class' : 'Start Class'}</span>
                    </Link>
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
