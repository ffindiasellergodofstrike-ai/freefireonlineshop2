import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Code, Palette, Cpu, TrendingUp, DollarSign, UserCheck, ArrowRight } from 'lucide-react';
import { CATEGORIES, COURSES } from '../data';

export const Categories: React.FC = () => {
  // Map string names to lucide icons
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Code':
        return Code;
      case 'Palette':
        return Palette;
      case 'Cpu':
        return Cpu;
      case 'TrendingUp':
        return TrendingUp;
      case 'DollarSign':
        return DollarSign;
      case 'UserCheck':
        return UserCheck;
      default:
        return BookOpen;
    }
  };

  return (
    <div id="categories-page" className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 pb-16">
      
      {/* Page Header */}
      <div className="text-center max-w-3xl mx-auto mb-12">
        <h1 className="text-3xl font-extrabold tracking-tight text-neutral-900 sm:text-4xl">
          Browse Subject Directories
        </h1>
        <p className="mt-3 text-sm text-neutral-500">
          Find highly structured curriculums organized meticulously by professional capabilities. Master code, designs, models, or funnels.
        </p>
      </div>

      {/* Grid of Categories */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {CATEGORIES.map((cat) => {
          const IconComponent = getIcon(cat.icon);
          const courseCount = COURSES.filter(c => c.categorySlug === cat.slug).length;

          return (
            <div
              key={cat.id}
              className="group flex flex-col rounded-2xl border border-neutral-100 bg-white overflow-hidden shadow-sm hover:border-blue-100 hover:shadow-xl transition-all duration-300"
            >
              {/* Banner Backdrop */}
              <div className="relative h-32 w-full overflow-hidden bg-neutral-100">
                <img
                  src={cat.banner}
                  alt={cat.name}
                  className="h-full w-full object-cover brightness-75 transition-transform duration-500 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                
                {/* Floating Icon */}
                <div className="absolute left-6 bottom-4 flex h-12 w-12 items-center justify-center rounded-xl bg-white text-blue-600 shadow-md">
                  <IconComponent className="h-6 w-6" />
                </div>
              </div>

              {/* Content body */}
              <div className="flex-1 p-6 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <h2 className="text-lg font-bold text-neutral-900 group-hover:text-blue-600 transition-colors">
                      {cat.name}
                    </h2>
                    <span className="rounded-full bg-blue-50 px-2.5 py-0.5 text-[10px] font-bold text-blue-600 uppercase tracking-wide">
                      {courseCount} programs
                    </span>
                  </div>
                  
                  <p className="text-xs text-neutral-500 leading-relaxed mt-2">
                    {cat.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-neutral-50">
                  <Link
                    to={`/courses?category=${cat.slug}`}
                    className="group/btn inline-flex items-center gap-1.5 text-xs font-bold text-blue-600 hover:text-blue-700"
                  >
                    <span>Browse Syllabi</span>
                    <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover/btn:translate-x-0.5" />
                  </Link>
                </div>
              </div>

            </div>
          );
        })}
      </div>

    </div>
  );
};
