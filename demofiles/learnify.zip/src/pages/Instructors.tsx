import React from 'react';
import { Link } from 'react-router-dom';
import { Star, GraduationCap, Users, ArrowRight } from 'lucide-react';
import { INSTRUCTORS } from '../data';

export const Instructors: React.FC = () => {
  return (
    <div id="instructors-page" className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 pb-16">
      
      {/* Page Header */}
      <div className="text-center max-w-3xl mx-auto mb-12">
        <h1 className="text-3xl font-extrabold tracking-tight text-neutral-900 sm:text-4xl">
          Learn from Active Experts
        </h1>
        <p className="mt-3 text-sm text-neutral-500">
          Meet the builders, consultants, and leaders driving modern web architecture, interface ergonomics, data models, and business growth.
        </p>
      </div>

      {/* Instructors Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {INSTRUCTORS.map((inst) => (
          <div
            key={inst.id}
            className="group flex flex-col sm:flex-row gap-6 p-6 rounded-2xl border border-neutral-100 bg-white shadow-sm hover:shadow-xl hover:border-blue-100 transition-all duration-300"
          >
            {/* Left Side - Avatar & Key stats */}
            <div className="flex flex-col items-center text-center shrink-0">
              <img
                src={inst.avatarUrl}
                alt={inst.name}
                className="h-24 w-24 rounded-2xl object-cover shadow-inner mb-4"
                referrerPolicy="no-referrer"
              />
              <div className="flex items-center gap-1 text-xs font-bold text-amber-500">
                <Star className="h-3.5 w-3.5 fill-amber-500" />
                <span>{inst.rating.toFixed(2)} Rating</span>
              </div>
            </div>

            {/* Right Side - Bio & Specialties */}
            <div className="flex-1 flex flex-col justify-between">
              <div>
                <h2 className="text-lg font-bold text-neutral-900 group-hover:text-blue-600 transition-colors">
                  <Link to={`/instructor/${inst.id}`}>
                    {inst.name}
                  </Link>
                </h2>
                <p className="text-xs font-medium text-neutral-400 mt-0.5 leading-tight">{inst.role}</p>
                
                <p className="text-xs text-neutral-500 mt-4 line-clamp-3 leading-relaxed">
                  {inst.bio}
                </p>

                {/* Specialties tags */}
                <div className="flex flex-wrap gap-1.5 mt-4">
                  {inst.specialties.map((spec, index) => (
                    <span
                      key={index}
                      className="rounded bg-neutral-50 px-2 py-0.5 text-[9px] font-semibold text-neutral-500 tracking-wider uppercase border border-neutral-100"
                    >
                      {spec}
                    </span>
                  ))}
                </div>
              </div>

              {/* Stats Footer Row */}
              <div className="mt-6 pt-4 border-t border-neutral-50 flex items-center justify-between text-[11px] text-neutral-400">
                <div className="flex gap-4">
                  <span className="flex items-center gap-1">
                    <Users className="h-3.5 w-3.5 text-neutral-300" />
                    <strong>{inst.studentsCount.toLocaleString()}</strong> students
                  </span>
                  <span className="flex items-center gap-1">
                    <GraduationCap className="h-3.5 w-3.5 text-neutral-300" />
                    <strong>{inst.coursesCount}</strong> programs
                  </span>
                </div>
                
                <Link
                  to={`/instructor/${inst.id}`}
                  className="inline-flex h-8 items-center justify-center gap-1 rounded-full bg-neutral-50 hover:bg-blue-50 hover:text-blue-600 px-3 text-xs font-bold text-neutral-700 transition-all border border-neutral-100/50"
                >
                  <span>Profile</span>
                  <ArrowRight className="h-3 w-3" />
                </Link>
              </div>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
};
