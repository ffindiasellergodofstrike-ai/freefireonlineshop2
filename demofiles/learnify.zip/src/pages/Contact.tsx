import React, { useState } from 'react';
import { Mail, Phone, MapPin, Clock, CheckCircle, Send, ShieldAlert } from 'lucide-react';

export const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.name && formData.email && formData.message) {
      setIsSubmitted(true);
      setFormData({ name: '', email: '', subject: '', message: '' });
      setTimeout(() => setIsSubmitted(false), 6000);
    }
  };

  const coordinates = [
    { title: 'Support Email', val: 'support@learnify.io', desc: 'Average response: < 2 hours', icon: Mail },
    { title: 'Help Hotline', val: '+1 (800) 555-0190', desc: 'Mon-Fri, 9am - 6pm EST', icon: Phone },
    { title: 'Headquarters', val: '548 Market St, Suite 403', desc: 'San Francisco, CA 94104', icon: MapPin },
    { title: 'SLA Availability', val: '99.9% uptime guaranteed', desc: 'Worldwide CDN mirrors', icon: Clock },
  ];

  return (
    <div id="contact-page" className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 pb-16">
      
      {/* Page Header */}
      <div className="text-center max-w-3xl mx-auto mb-12">
        <h1 className="text-3xl font-extrabold tracking-tight text-neutral-900 sm:text-4xl">
          Get in Touch with Learnify
        </h1>
        <p className="mt-3 text-sm text-neutral-500">
          Have queries about corporate seat billing, custom curriculum roadmaps, or billing portals? Reach out. Our success squad responds promptly.
        </p>
      </div>

      {/* Core Layout Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Side: Contact Coordinates */}
        <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-4">
          {coordinates.map((coord, idx) => {
            const Icon = coord.icon;
            return (
              <div
                key={idx}
                className="flex items-start gap-4 p-5 rounded-2xl border border-neutral-100 bg-white shadow-sm"
              >
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-blue-600">
                  <Icon className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-wider">{coord.title}</h3>
                  <p className="text-sm font-extrabold text-neutral-900 mt-1">{coord.val}</p>
                  <p className="text-xs text-neutral-500 mt-0.5">{coord.desc}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Side: Contact Form Card */}
        <div className="lg:col-span-7 rounded-2xl border border-neutral-100 bg-white p-6 sm:p-8 shadow-sm">
          <h2 className="text-lg font-bold text-neutral-900 mb-6">Send an Inquiry</h2>
          
          {isSubmitted ? (
            <div className="flex flex-col items-center justify-center text-center py-8 px-4 border border-emerald-100 bg-emerald-50/20 rounded-xl">
              <CheckCircle className="h-12 w-12 text-emerald-500 mb-3" />
              <h3 className="text-base font-bold text-neutral-900">Inquiry Sent Successfully</h3>
              <p className="text-xs text-neutral-500 max-w-md mt-1 leading-relaxed">
                Thank you for reaching out. A Learnify coordinator has received your message and will reply via email shortly.
              </p>
            </div>
          ) : (
            <form onSubmit={handleFormSubmit} className="space-y-5">
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="name" className="block text-xs font-bold text-neutral-500 uppercase tracking-wide mb-1.5">Full Name</label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    required
                    value={formData.name}
                    onChange={handleInputChange}
                    placeholder="e.g. Liam Cooper"
                    className="w-full rounded-xl border border-neutral-200 bg-neutral-50 py-2.5 px-4 text-xs outline-none focus:border-blue-500 focus:bg-white"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-xs font-bold text-neutral-500 uppercase tracking-wide mb-1.5">Email Address</label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    required
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="e.g. liam@work.com"
                    className="w-full rounded-xl border border-neutral-200 bg-neutral-50 py-2.5 px-4 text-xs outline-none focus:border-blue-500 focus:bg-white"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="subject" className="block text-xs font-bold text-neutral-500 uppercase tracking-wide mb-1.5">Inquiry Subject</label>
                <input
                  type="text"
                  id="subject"
                  name="subject"
                  required
                  value={formData.subject}
                  onChange={handleInputChange}
                  placeholder="e.g. Enterprise Team Billing Options"
                  className="w-full rounded-xl border border-neutral-200 bg-neutral-50 py-2.5 px-4 text-xs outline-none focus:border-blue-500 focus:bg-white"
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-xs font-bold text-neutral-500 uppercase tracking-wide mb-1.5">Your Message</label>
                <textarea
                  id="message"
                  name="message"
                  required
                  rows={4}
                  value={formData.message}
                  onChange={handleInputChange}
                  placeholder="Describe your inquiry details here..."
                  className="w-full rounded-xl border border-neutral-200 bg-neutral-50 py-2.5 px-4 text-xs outline-none focus:border-blue-500 focus:bg-white resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full sm:w-auto inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-6 transition-all shadow-md shadow-blue-100"
              >
                <span>Send Message</span>
                <Send className="h-3.5 w-3.5" />
              </button>

            </form>
          )}
        </div>

      </div>

    </div>
  );
};
