import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Play, ArrowLeft, CheckCircle, Circle, ChevronLeft, ChevronRight, FileText, Download, Code, Layers, Save, Trash2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { COURSES } from '../data';

export const CoursePlayer: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const {
    enrolledCourses,
    completedLessons,
    activeLessons,
    userNotes,
    toggleLessonCompletion,
    setActiveLesson,
    saveNote,
    getCourseProgress,
    enrollInCourse
  } = useApp();

  // Find course
  const course = COURSES.find((c) => c.id === id);

  // If not enrolled or course doesn't exist, handle nicely
  useEffect(() => {
    if (course) {
      // Auto-enroll if somehow not enrolled, just to prevent breaking the flow
      const isUserEnrolled = enrolledCourses.some((e) => e.courseId === course.id);
      if (!isUserEnrolled) {
        enrollInCourse(course.id);
      }
    }
  }, [course, enrolledCourses]);

  const [activeTab, setActiveTab] = useState<'overview' | 'notes' | 'resources'>('overview');
  const [noteText, setNoteText] = useState('');
  const [noteSavedFeedback, setNoteSavedFeedback] = useState(false);

  if (!course) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-16 text-center">
        <h2 className="text-2xl font-bold text-neutral-900">Program Not Found</h2>
        <p className="text-neutral-500 mt-2">The course content you requested is currently unavailable.</p>
        <Link to="/dashboard" className="mt-6 inline-flex items-center gap-2 rounded-full bg-blue-600 text-white px-6 py-2.5 text-xs font-bold">
          Back to Dashboard
        </Link>
      </div>
    );
  }

  // Get active lesson
  const allLessons = course.sections.flatMap((s) => s.lessons);
  const activeLessonIdFromState = activeLessons[course.id];
  const activeLesson = allLessons.find((l) => l.id === activeLessonIdFromState) || allLessons[0];

  useEffect(() => {
    if (activeLesson) {
      // Update note text when active lesson changes
      const existingNote = userNotes[course.id]?.[activeLesson.id] || '';
      setNoteText(existingNote);
    }
  }, [activeLesson, course.id, userNotes]);

  if (!activeLesson) return null;

  const progress = getCourseProgress(course.id);

  // Get next and previous lesson IDs
  const currentIdx = allLessons.findIndex((l) => l.id === activeLesson.id);
  const prevLesson = currentIdx > 0 ? allLessons[currentIdx - 1] : null;
  const nextLesson = currentIdx < allLessons.length - 1 ? allLessons[currentIdx + 1] : null;

  const handleNoteSave = () => {
    saveNote(course.id, activeLesson.id, noteText);
    setNoteSavedFeedback(true);
    setTimeout(() => setNoteSavedFeedback(false), 3000);
  };

  const handleLessonSelect = (lessonId: string) => {
    setActiveLesson(course.id, lessonId);
  };

  const handleNextLesson = () => {
    if (nextLesson) {
      handleLessonSelect(nextLesson.id);
    }
  };

  const handlePrevLesson = () => {
    if (prevLesson) {
      handleLessonSelect(prevLesson.id);
    }
  };

  // Mock resources depending on course
  const mockResources = [
    { name: 'Complete syllabus slides workbook.pdf', size: '4.2 MB', icon: FileText },
    { name: 'Annotated source templates repository.zip', size: '12.8 MB', icon: Code },
    { name: 'Figma interactive layout mockups.fig', size: '8.5 MB', icon: Layers },
  ];

  return (
    <div id="course-player-container" className="flex flex-col h-screen bg-neutral-950 text-neutral-200 overflow-hidden">
      
      {/* 1. TOP HEADER NAVIGATION BAR */}
      <header className="h-14 shrink-0 bg-neutral-900 border-b border-neutral-800 px-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link
            to="/dashboard"
            className="flex h-9 w-9 items-center justify-center rounded-lg bg-neutral-800 hover:bg-neutral-700 text-neutral-300 transition-colors border border-neutral-700/50"
            title="Back to Dashboard"
          >
            <ArrowLeft className="h-4 w-4" />
          </Link>
          <div className="min-w-0">
            <span className="block text-[10px] text-neutral-400 font-bold uppercase tracking-wider">Active Classroom Workspace</span>
            <h1 className="text-xs sm:text-sm font-extrabold text-white truncate max-w-sm sm:max-w-xl">{course.title}</h1>
          </div>
        </div>

        {/* Progress percent display */}
        <div className="hidden md:flex items-center gap-4 shrink-0">
          <div className="flex flex-col items-end">
            <span className="text-[10px] text-neutral-400 font-semibold uppercase">Overall Progress</span>
            <span className="text-xs font-bold text-white mt-0.5">{progress}% Completed</span>
          </div>
          <div className="h-2 w-32 bg-neutral-800 rounded-full overflow-hidden border border-neutral-700/30">
            <div className="h-full bg-blue-600 transition-all duration-500" style={{ width: `${progress}%` }} />
          </div>
        </div>
      </header>

      {/* 2. CORE WORKSPACE AREA */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* LEFT COMPONENT - VIDEO PLAYBACK AND NOTES WRAPPER */}
        <div className="flex-1 flex flex-col overflow-y-auto min-w-0 scrollbar-none">
          
          {/* Simulated Premium Video Canvas */}
          <div className="relative aspect-video w-full bg-neutral-900 flex flex-col justify-between border-b border-neutral-800">
            
            {/* Ambient blur overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent z-10" />

            {/* Title HUD overlay */}
            <div className="p-4 z-20 flex justify-between items-start">
              <span className="rounded bg-blue-600 px-2 py-0.5 text-[9px] font-bold text-white uppercase tracking-wider">
                Module lecture file
              </span>
              <span className="text-xs font-bold text-neutral-400">
                {activeLesson.duration}
              </span>
            </div>

            {/* Big Simulated Play Button overlay */}
            <div className="absolute inset-0 flex items-center justify-center z-10">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-white text-neutral-950 shadow-2xl scale-100 hover:scale-105 transition-transform duration-200 cursor-pointer">
                <Play className="h-7 w-7 text-blue-600 fill-blue-600 ml-1.5" />
              </div>
            </div>

            {/* Video HUD Bottom Overlay Controls */}
            <div className="p-4 z-20 flex justify-between items-center bg-gradient-to-t from-neutral-950/95 to-neutral-950/0 pt-16">
              <div>
                <p className="text-[10px] text-neutral-400 font-medium">Currently Streaming Lecture</p>
                <h2 className="text-xs sm:text-sm font-extrabold text-white mt-0.5">{activeLesson.title}</h2>
              </div>

              {/* Lesson Navigate controls */}
              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrevLesson}
                  disabled={!prevLesson}
                  className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 disabled:opacity-30 disabled:pointer-events-none text-neutral-300 transition-colors"
                  title="Previous Lecture"
                >
                  <ChevronLeft className="h-4 w-4" />
                </button>
                <button
                  onClick={handleNextLesson}
                  disabled={!nextLesson}
                  className="p-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 disabled:opacity-30 disabled:pointer-events-none text-neutral-300 transition-colors"
                  title="Next Lecture"
                >
                  <ChevronRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Dynamic Tab Workspace under Video Canvas */}
          <div className="flex-1 p-6">
            
            {/* Tab navigation selection */}
            <div className="flex gap-4 border-b border-neutral-800 pb-2 mb-6">
              {[
                { key: 'overview', label: 'Lecture Overview' },
                { key: 'notes', label: 'My Notes Workspace' },
                { key: 'resources', label: 'Supplemental Resources' },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key as any)}
                  className={`pb-3 text-xs font-bold transition-all relative ${
                    activeTab === tab.key
                      ? 'text-blue-500 font-extrabold'
                      : 'text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  {tab.label}
                  {activeTab === tab.key && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-blue-500 rounded-full" />
                  )}
                </button>
              ))}
            </div>

            {/* OVERVIEW CONTENT VIEW */}
            {activeTab === 'overview' && (
              <div className="flex flex-col gap-4 animate-in fade-in duration-200 text-xs sm:text-sm text-neutral-400 leading-relaxed">
                <h3 className="text-sm font-bold text-white">{activeLesson.title}</h3>
                <p>
                  Welcome to this in-depth modular lecture. In this segment, your instructor Alex Rivers breaks down the core concepts step-by-step. Grab a notebook, configure your developer workspace environment on your local machine, and write down any critical syntax structures.
                </p>
                <p>
                  Ensure you complete the corresponding portfolio lab folders attached to this section in the Resources drawer. Once you fully complete the module, check the completion circle in the right navigation bar to log your progress toward your verified platform certificate.
                </p>
              </div>
            )}

            {/* NOTES WRITER INTERACTIVE VIEW */}
            {activeTab === 'notes' && (
              <div className="flex flex-col gap-4 animate-in fade-in duration-200">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="text-xs font-bold text-white">Dynamic Notes Workspace</h3>
                    <p className="text-[10px] text-neutral-500 mt-0.5">Your entries save securely and persist to your personal Learnify profile.</p>
                  </div>
                  
                  {noteSavedFeedback && (
                    <span className="text-[10px] text-green-500 font-bold flex items-center gap-1 animate-pulse">
                      <CheckCircle className="h-3.5 w-3.5" />
                      <span>Saved successfully!</span>
                    </span>
                  )}
                </div>

                <textarea
                  value={noteText}
                  onChange={(e) => setNoteText(e.target.value)}
                  placeholder="Draft your lecture summary definitions, key syntax patterns, or personal bookmarks here..."
                  className="w-full h-36 rounded-xl border border-neutral-800 bg-neutral-900 py-3.5 px-4 text-xs text-neutral-200 outline-none focus:border-blue-500 resize-none placeholder:text-neutral-600 focus:ring-1 focus:ring-blue-500/20"
                />

                <div className="flex gap-2">
                  <button
                    onClick={handleNoteSave}
                    className="inline-flex h-9 items-center justify-center gap-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-4 transition-all shadow-sm"
                  >
                    <Save className="h-3.5 w-3.5" />
                    <span>Save Note</span>
                  </button>
                  {noteText.trim() && (
                    <button
                      onClick={() => setNoteText('')}
                      className="inline-flex h-9 items-center justify-center p-2.5 rounded-lg border border-neutral-800 hover:bg-neutral-900 text-neutral-400 transition-all"
                      title="Clear editor space"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* RESOURCES DOWNLOAD VIEW */}
            {activeTab === 'resources' && (
              <div className="flex flex-col gap-4 animate-in fade-in duration-200">
                <h3 className="text-xs font-bold text-white">Supplemental Resource files</h3>
                <p className="text-[10px] text-neutral-500 -mt-1 leading-normal">
                  Download supplemental materials designed by your mentor to fast-track your practical lab portfolios.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-2">
                  {mockResources.map((res, idx) => {
                    const Icon = res.icon;
                    return (
                      <div
                        key={idx}
                        className="p-3.5 rounded-xl border border-neutral-800 bg-neutral-900 flex items-center justify-between gap-4"
                      >
                        <div className="flex items-center gap-3">
                          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-neutral-800 text-blue-400 border border-neutral-700/50">
                            <Icon className="h-4 w-4" />
                          </div>
                          <div>
                            <span className="block text-xs font-bold text-neutral-200 line-clamp-1">{res.name}</span>
                            <span className="block text-[10px] text-neutral-500 mt-0.5">{res.size}</span>
                          </div>
                        </div>

                        <button
                          onClick={() => alert(`Starting supplemental asset download: ${res.name}`)}
                          className="flex h-8 w-8 items-center justify-center rounded-lg hover:bg-neutral-800 text-neutral-400 hover:text-white transition-colors border border-transparent hover:border-neutral-700"
                          title="Download asset"
                        >
                          <Download className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

          </div>

        </div>

        {/* RIGHT COMPONENT - DETAILED CURRICULUM SIDEBAR */}
        <div className="hidden lg:flex w-80 shrink-0 flex-col border-l border-neutral-800 bg-neutral-900/40 overflow-y-auto">
          <div className="p-4 border-b border-neutral-800 bg-neutral-900/60 sticky top-0 z-10 flex justify-between items-center">
            <span className="text-xs font-bold text-white uppercase tracking-wider">Class Lectures Syllabus</span>
            <span className="text-[10px] text-neutral-400 font-semibold">{completedLessons.length} completed</span>
          </div>

          <div className="flex-1 divide-y divide-neutral-800/80">
            {course.sections.map((sec) => (
              <div key={sec.id} className="p-4">
                <h3 className="text-xs font-bold text-white tracking-tight leading-snug mb-2.5">{sec.title}</h3>
                
                <div className="flex flex-col gap-1.5">
                  {sec.lessons.map((lesson) => {
                    const isSelected = activeLesson.id === lesson.id;
                    const isCompleted = completedLessons.includes(lesson.id);

                    return (
                      <div
                        key={lesson.id}
                        className={`flex items-start justify-between gap-3 p-2.5 rounded-lg border transition-all ${
                          isSelected
                            ? 'border-blue-500 bg-blue-500/10 text-white font-semibold'
                            : 'border-transparent text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/40'
                        }`}
                      >
                        {/* Completion Check & select */}
                        <div
                          className="flex-1 min-w-0 cursor-pointer flex gap-3"
                          onClick={() => handleLessonSelect(lesson.id)}
                        >
                          <div className="mt-0.5 shrink-0">
                            {isCompleted ? (
                              <CheckCircle className="h-4 w-4 text-emerald-500 fill-emerald-500/10" />
                            ) : (
                              <Circle className="h-4 w-4 text-neutral-600" />
                            )}
                          </div>
                          <div>
                            <span className="block text-xs leading-normal">{lesson.title}</span>
                            <span className="block text-[10px] text-neutral-500 mt-0.5">{lesson.duration}</span>
                          </div>
                        </div>

                        {/* Mark complete interactive checkbox */}
                        <button
                          onClick={() => toggleLessonCompletion(course.id, lesson.id)}
                          className="shrink-0 text-[10px] hover:text-blue-400 border border-neutral-800 rounded px-1.5 py-0.5 font-bold tracking-wide transition-colors"
                          title="Toggle Completion Status"
                        >
                          {isCompleted ? 'Reset' : 'Check'}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
