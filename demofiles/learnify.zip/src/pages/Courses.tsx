import React, { useState, useEffect, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, SlidersHorizontal, BookOpen, RotateCcw, LayoutGrid } from 'lucide-react';
import { COURSES, CATEGORIES } from '../data';
import { CourseCard } from '../components/CourseCard';

export const Courses: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedLevel, setSelectedLevel] = useState('all');

  // Read query params on mount/update
  useEffect(() => {
    const searchParam = searchParams.get('search');
    const categoryParam = searchParams.get('category');
    
    if (searchParam) {
      setSearchQuery(searchParam);
    } else {
      setSearchQuery('');
    }

    if (categoryParam) {
      setSelectedCategory(categoryParam);
    } else {
      setSelectedCategory('all');
    }
  }, [searchParams]);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setSearchQuery(val);
    
    // Update URL params
    const nextParams = new URLSearchParams(searchParams);
    if (val) {
      nextParams.set('search', val);
    } else {
      nextParams.delete('search');
    }
    setSearchParams(nextParams);
  };

  const handleCategorySelect = (slug: string) => {
    setSelectedCategory(slug);
    const nextParams = new URLSearchParams(searchParams);
    if (slug !== 'all') {
      nextParams.set('category', slug);
    } else {
      nextParams.delete('category');
    }
    setSearchParams(nextParams);
  };

  const resetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setSelectedLevel('all');
    setSearchParams(new URLSearchParams());
  };

  // Memoized course filtration logic
  const filteredCourses = useMemo(() => {
    return COURSES.filter((course) => {
      // 1. Search Query Match
      const matchesSearch =
        course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        course.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        course.instructorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        course.category.toLowerCase().includes(searchQuery.toLowerCase());

      // 2. Category Match
      const matchesCategory = selectedCategory === 'all' || course.categorySlug === selectedCategory;

      // 3. Level Match
      const matchesLevel = selectedLevel === 'all' || course.level.toLowerCase().includes(selectedLevel.toLowerCase());

      return matchesSearch && matchesCategory && matchesLevel;
    });
  }, [searchQuery, selectedCategory, selectedLevel]);

  return (
    <div id="courses-page" className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 pb-16">
      
      {/* Page Header */}
      <div className="mb-10 text-center sm:text-left">
        <h1 className="text-3xl font-extrabold tracking-tight text-neutral-900 sm:text-4xl">
          Browse Learning Programs
        </h1>
        <p className="mt-2 text-sm text-neutral-500 max-w-3xl">
          Explore complete masterclass tracks designed to bridge skills gaps. Find your next tech, design, AI, or business milestone.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 items-start">
        
        {/* Filters Sidebar - Desktop */}
        <div className="hidden lg:flex flex-col gap-6 p-6 rounded-2xl border border-neutral-100 bg-white shadow-sm sticky top-24">
          <div className="flex items-center justify-between border-b border-neutral-50 pb-4">
            <div className="flex items-center gap-2 font-bold text-neutral-800">
              <SlidersHorizontal className="h-4 w-4 text-blue-600" />
              <span>Syllabus Filters</span>
            </div>
            <button
              onClick={resetFilters}
              className="text-xs font-semibold text-neutral-400 hover:text-blue-600 flex items-center gap-1"
            >
              <RotateCcw className="h-3 w-3" />
              <span>Reset</span>
            </button>
          </div>

          {/* Categories Filter */}
          <div>
            <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-wider mb-3">Categories</h3>
            <div className="flex flex-col gap-1.5">
              <button
                onClick={() => handleCategorySelect('all')}
                className={`text-left text-sm py-1.5 px-2.5 rounded-lg transition-colors font-medium ${
                  selectedCategory === 'all'
                    ? 'text-blue-600 bg-blue-50/50 font-bold'
                    : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-50'
                }`}
              >
                All Categories ({COURSES.length})
              </button>
              {CATEGORIES.map((cat) => {
                const count = COURSES.filter(c => c.categorySlug === cat.slug).length;
                return (
                  <button
                    key={cat.id}
                    onClick={() => handleCategorySelect(cat.slug)}
                    className={`text-left text-sm py-1.5 px-2.5 rounded-lg transition-colors font-medium flex justify-between items-center ${
                      selectedCategory === cat.slug
                        ? 'text-blue-600 bg-blue-50/50 font-bold'
                        : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-50'
                    }`}
                  >
                    <span>{cat.name}</span>
                    <span className="text-[10px] text-neutral-400 font-bold">{count}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Difficulty Level Filter */}
          <div className="border-t border-neutral-50 pt-5">
            <h3 className="text-xs font-bold text-neutral-400 uppercase tracking-wider mb-3">Difficulty</h3>
            <div className="flex flex-col gap-1.5">
              {['all', 'Beginner', 'Intermediate', 'Advanced', 'All Levels'].map((lvl) => (
                <button
                  key={lvl}
                  onClick={() => setSelectedLevel(lvl)}
                  className={`text-left text-sm py-1.5 px-2.5 rounded-lg transition-colors font-medium uppercase text-[11px] tracking-wide ${
                    selectedLevel === lvl
                      ? 'text-blue-600 bg-blue-50/50 font-bold'
                      : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-50'
                  }`}
                >
                  {lvl === 'all' ? 'Any Skill Level' : lvl}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Courses Listing & Mobile Filters */}
        <div className="lg:col-span-3 flex flex-col gap-6">
          
          {/* Active Search & Count Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-xl border border-neutral-100 bg-white shadow-sm">
            
            {/* Search Input Box */}
            <div className="relative flex-1 max-w-md">
              <input
                type="text"
                placeholder="Filter catalog by key terms..."
                value={searchQuery}
                onChange={handleSearchChange}
                className="w-full rounded-xl border border-neutral-200 bg-neutral-50 py-2 pl-10 pr-4 text-sm outline-none transition-all placeholder:text-neutral-400 focus:border-blue-500 focus:bg-white"
              />
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-400" />
            </div>

            {/* Stats count */}
            <div className="flex items-center gap-2 text-xs font-semibold text-neutral-500">
              <LayoutGrid className="h-4 w-4 text-neutral-400" />
              <span>Showing {filteredCourses.length} of {COURSES.length} courses</span>
            </div>
          </div>

          {/* Mobile Quick Category Selector */}
          <div className="flex lg:hidden gap-1.5 overflow-x-auto pb-2 -mx-4 px-4 scrollbar-none">
            <button
              onClick={() => handleCategorySelect('all')}
              className={`whitespace-nowrap px-3.5 py-1.5 rounded-full text-xs font-semibold border ${
                selectedCategory === 'all'
                  ? 'border-blue-500 bg-blue-600 text-white'
                  : 'border-neutral-200 bg-white text-neutral-700'
              }`}
            >
              All
            </button>
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => handleCategorySelect(cat.slug)}
                className={`whitespace-nowrap px-3.5 py-1.5 rounded-full text-xs font-semibold border ${
                  selectedCategory === cat.slug
                    ? 'border-blue-500 bg-blue-600 text-white'
                    : 'border-neutral-200 bg-white text-neutral-700'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>

          {/* Fallback Empty State */}
          {filteredCourses.length === 0 ? (
            <div className="flex flex-col items-center justify-center text-center p-12 border border-dashed border-neutral-200 rounded-2xl bg-white">
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-neutral-100 text-neutral-400 mb-4">
                <BookOpen className="h-7 w-7" />
              </div>
              <h3 className="text-base font-bold text-neutral-900">No courses match your criteria</h3>
              <p className="text-xs text-neutral-500 max-w-md mt-1 leading-relaxed">
                We couldn't find any learning programs fitting your search term or active level filters. Please try revising your search.
              </p>
              <button
                onClick={resetFilters}
                className="mt-5 rounded-full bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-5 py-2 transition-all shadow-sm"
              >
                Clear Catalog Filters
              </button>
            </div>
          ) : (
            /* Courses Cards Grid */
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredCourses.map((course) => (
                <CourseCard key={course.id} course={course} />
              ))}
            </div>
          )}

        </div>

      </div>

    </div>
  );
};
