import React from 'react';
import { Link } from 'react-router-dom';
import { Layout, BookOpen, GraduationCap, Award, Play, CheckCircle, Clock, ArrowRight, Star, Heart } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { COURSES } from '../data';

export const Dashboard: React.FC = () => {
  const {
    enrolledCourses,
    userProfile,
    completedLessons,
    getCourseProgress,
    activeLessons
  } = useApp();

  // Map enrolled courses IDs to full course models
  const enrolledFullCourses = enrolledCourses.map((e) => {
    const course = COURSES.find((c) => c.id === e.courseId);
    return {
      ...course,
      progressPercent: e.progressPercent,
      enrolledAt: e.enrolledAt,
      lastAccessedAt: e.lastAccessedAt
    };
  }).filter(c => c.id !== undefined);

  // Statistics calculation
  const totalEnrolled = enrolledCourses.length;
  const completedCount = enrolledCourses.filter(e => e.progressPercent === 100).length;
  const averageProgress = enrolledCourses.length > 0
    ? Math.round(enrolledCourses.reduce((acc, curr) => acc + curr.progressPercent, 0) / enrolledCourses.length)
    : 0;

  const stats = [
    { label: 'Enrolled Courses', value: totalEnrolled, icon: BookOpen, color: 'text-blue-600 bg-blue-50' },
    { label: 'Overall Progress', value: `${averageProgress}%`, icon: Clock, color: 'text-indigo-600 bg-indigo-50' },
    { label: 'Completed Tracks', value: completedCount, icon: CheckCircle, color: 'text-emerald-600 bg-emerald-50' },
    { label: 'Certificates Earned', value: completedCount, icon: Award, color: 'text-amber-600 bg-amber-50' },
  ];

  // Activities logs simulation
  const activities = [
    { type: 'complete', title: 'Completed lecture: Welcome & Curriculum Overview', time: '1 day ago', item: 'The Ultimate Web Development Bootcamp' },
    { type: 'note', title: 'Created supplemental notes inside Advanced JavaScript', time: '2 days ago', item: 'The Ultimate Web Development Bootcamp' },
    { type: 'enroll', title: 'Enrolled in masterclass curriculum', time: '5 days ago', item: 'The Ultimate Web Development Bootcamp' },
  ];

  return (
    <div id="student-dashboard-page" className="bg-neutral-50/50 pb-20 pt-8">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Dashboard Header Banner */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10 bg-white border border-neutral-100 p-6 sm:p-8 rounded-2xl shadow-sm">
          <div className="flex items-center gap-4">
            <img
              src={userProfile.avatarUrl}
              alt={userProfile.name}
              className="h-16 w-16 rounded-full object-cover border"
              referrerPolicy="no-referrer"
            />
            <div>
              <span className="text-xs text-neutral-400 font-semibold uppercase tracking-wider">Student Dashboard</span>
              <h1 className="text-2xl font-extrabold text-neutral-900 mt-0.5">Welcome Back, {userProfile.name}!</h1>
              <p className="text-xs text-neutral-500 mt-1 leading-normal max-w-xl">{userProfile.headline}</p>
            </div>
          </div>
          
          <div className="flex gap-3">
            <Link
              to="/profile"
              className="flex h-10 items-center justify-center rounded-full border border-neutral-200 bg-white hover:bg-neutral-50 text-neutral-800 text-xs font-bold px-5 transition-all"
            >
              Update Settings
            </Link>
            <Link
              to="/courses"
              className="flex h-10 items-center justify-center rounded-full bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-5 transition-all shadow-md shadow-blue-100"
            >
              Explore Catalog
            </Link>
          </div>
        </div>

        {/* 1. Statistics Cards Row */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
          {stats.map((s, idx) => {
            const Icon = s.icon;
            return (
              <div
                key={idx}
                className="rounded-2xl border border-neutral-100 bg-white p-5 shadow-sm flex items-center gap-4"
              >
                <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl ${s.color} shadow-sm`}>
                  <Icon className="h-6 w-6" />
                </div>
                <div>
                  <span className="block text-xl font-extrabold text-neutral-900">{s.value}</span>
                  <span className="block text-[10px] font-bold text-neutral-400 uppercase tracking-wide mt-0.5">{s.label}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* 2. Main content Layout grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Continue Learning Enrolled Courses */}
          <div className="lg:col-span-8 flex flex-col gap-8">
            
            <div className="flex items-center justify-between border-b border-neutral-100 pb-3">
              <h2 className="text-base font-bold text-neutral-950">Active Enrolled Curriculums</h2>
              <Link to="/my-courses" className="text-xs font-bold text-blue-600 hover:text-blue-700">View all</Link>
            </div>

            {enrolledFullCourses.length === 0 ? (
              <div className="flex flex-col items-center justify-center text-center p-12 border border-dashed border-neutral-200 rounded-2xl bg-white shadow-sm">
                <div className="flex h-14 w-14 items-center justify-center rounded-full bg-neutral-100 text-neutral-400 mb-4">
                  <BookOpen className="h-7 w-7" />
                </div>
                <h3 className="text-base font-bold text-neutral-900">No active enrollments</h3>
                <p className="text-xs text-neutral-500 max-w-sm mt-1 leading-relaxed">
                  You are not currently enrolled in any learning programs. Find a masterclass course to add to your workspace!
                </p>
                <Link
                  to="/courses"
                  className="mt-6 rounded-full bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-6 py-2.5 transition-all shadow-sm shadow-blue-100"
                >
                  Explore Syllabi Directory
                </Link>
              </div>
            ) : (
              <div className="flex flex-col gap-4">
                {enrolledFullCourses.map((course) => {
                  if (!course || !course.id) return null;
                  const progress = course.progressPercent;
                  const isCompleted = progress === 100;
                  const resumeLessonId = activeLessons[course.id] || '';

                  return (
                    <div
                      key={course.id}
                      className="p-5 rounded-2xl border border-neutral-100 bg-white shadow-sm hover:border-blue-100 hover:shadow-md transition-all flex flex-col sm:flex-row gap-5 items-center justify-between"
                    >
                      {/* Course Details Thumbnail & Title */}
                      <div className="flex items-center gap-4 w-full sm:w-auto">
                        <img
                          src={course.thumbnailUrl}
                          alt={course.title}
                          className="h-14 w-14 rounded-xl object-cover shrink-0 border"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <span className="rounded bg-neutral-100 px-1.5 py-0.5 text-[9px] font-bold text-neutral-500 uppercase tracking-wide">
                            {course.category}
                          </span>
                          <h3 className="text-sm font-bold text-neutral-900 mt-1 hover:text-blue-600 transition-colors">
                            <Link to={`/course/${course.id}`}>{course.title}</Link>
                          </h3>
                        </div>
                      </div>

                      {/* Course progress scale and active resume */}
                      <div className="flex flex-col sm:flex-row items-center gap-6 w-full sm:w-auto shrink-0 justify-between sm:justify-end">
                        
                        {/* Progress slider bar */}
                        <div className="flex flex-col w-36">
                          <div className="flex justify-between text-[10px] text-neutral-400 font-bold mb-1">
                            <span>Progress</span>
                            <span>{progress}%</span>
                          </div>
                          <div className="h-1.5 w-full bg-neutral-100 rounded-full overflow-hidden">
                            <div className="h-full bg-blue-600 transition-all duration-500" style={{ width: `${progress}%` }} />
                          </div>
                        </div>

                        {/* Button control depending on progress */}
                        {isCompleted ? (
                          <div className="flex gap-2">
                            <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-600 bg-emerald-50 px-3 py-1.5 rounded-full border border-emerald-100">
                              <CheckCircle className="h-3.5 w-3.5" />
                              <span>Completed</span>
                            </span>
                            <Link
                              to={`/course-player/${course.id}`}
                              className="flex h-9 items-center justify-center rounded-full bg-neutral-50 hover:bg-neutral-100 text-neutral-800 text-xs font-bold px-4 transition-all"
                            >
                              Review
                            </Link>
                          </div>
                        ) : (
                          <Link
                            to={`/course-player/${course.id}`}
                            className="flex h-9 items-center justify-center gap-1.5 rounded-full bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-4 transition-all shadow-sm shadow-blue-100"
                          >
                            <Play className="h-3.5 w-3.5 fill-current" />
                            <span>{progress > 0 ? 'Resume' : 'Start'}</span>
                          </Link>
                        )}

                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Certificates section (renders only completed courses certificates) */}
            <div className="flex flex-col gap-4 mt-4">
              <div className="flex items-center gap-2 border-b border-neutral-100 pb-3">
                <Award className="h-5 w-5 text-amber-500" />
                <h2 className="text-base font-bold text-neutral-950">Earned Qualifications & Certificates</h2>
              </div>

              {completedCount === 0 ? (
                <div className="rounded-2xl border border-neutral-100 bg-white p-6 shadow-sm flex flex-col items-center text-center">
                  <p className="text-xs text-neutral-500 leading-normal max-w-sm">
                    Complete 100% of curriculum lectures in any enrolled program to automatically unlock high-resolution platform certificate downloads.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {enrolledFullCourses.filter(c => c.progressPercent === 100).map((course) => {
                    if (!course) return null;
                    return (
                      <div
                        key={course.id}
                        className="p-5 rounded-2xl border border-amber-200 bg-amber-50/20 shadow-sm flex flex-col gap-4"
                      >
                        <div>
                          <Award className="h-8 w-8 text-amber-500" />
                          <h3 className="text-sm font-extrabold text-neutral-900 mt-2">{course.title}</h3>
                          <p className="text-[10px] text-neutral-400 font-semibold mt-1 uppercase tracking-wide">
                            Authorized certificate issued by {course.instructorName}
                          </p>
                        </div>
                        
                        <button
                          onClick={() => alert(`Certificate successfully generated for ${userProfile.name} in high-resolution PDF and exported to LinkedIn verification systems.`)}
                          className="w-full flex h-9 items-center justify-center rounded-xl bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold transition-all shadow-sm shadow-amber-100"
                        >
                          Download Verified Certificate
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

          </div>

          {/* Right Column: Activity log tracker */}
          <div className="lg:col-span-4 flex flex-col gap-6">
            
            {/* Activity log tracking box */}
            <div className="rounded-2xl border border-neutral-100 bg-white p-6 shadow-sm flex flex-col gap-4">
              <h2 className="text-base font-bold text-neutral-950">Recent Activities</h2>
              
              <div className="flex flex-col gap-4">
                {activities.map((act, i) => (
                  <div key={i} className="flex items-start gap-3 text-xs leading-normal">
                    <div className="h-2 w-2 rounded-full bg-blue-500 shrink-0 mt-1.5" />
                    <div>
                      <p className="font-semibold text-neutral-800">{act.title}</p>
                      <p className="text-[10px] text-neutral-400 mt-0.5">{act.time} • <span className="text-blue-600 font-medium">{act.item}</span></p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Profile brief shortcuts card */}
            <div className="rounded-2xl border border-neutral-100 bg-white p-6 shadow-sm flex flex-col gap-4">
              <h2 className="text-base font-bold text-neutral-950">Skills Mastery Map</h2>
              
              <div className="flex flex-wrap gap-1.5">
                {userProfile.skills.map((skill, idx) => (
                  <span
                    key={idx}
                    className="rounded-lg bg-neutral-50 px-2.5 py-1.5 text-xs font-medium text-neutral-600 border border-neutral-100"
                  >
                    {skill}
                  </span>
                ))}
              </div>
              <Link to="/profile" className="text-xs font-bold text-blue-600 hover:text-blue-700 mt-2 inline-flex items-center gap-1">
                <span>Configure profile skills</span>
                <ArrowRight className="h-3 w-3" />
              </Link>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
