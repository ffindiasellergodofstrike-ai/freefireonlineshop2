import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Search, Sparkles, BookOpen, Layers, Award, Target, HelpCircle, ChevronDown, Check, ArrowRight, UserCheck, Star } from 'lucide-react';
import { COURSES, CATEGORIES, INSTRUCTORS, PRICING_PLANS, FAQS, TESTIMONIALS } from '../data';
import { CourseCard } from '../components/CourseCard';

export const Home: React.FC = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [faqOpenIndex, setFaqOpenIndex] = useState<number | null>(null);
  const [isAnnual, setIsAnnual] = useState(false);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/courses?search=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const toggleFaq = (index: number) => {
    setFaqOpenIndex(faqOpenIndex === index ? null : index);
  };

  // Get first 3 courses as featured courses
  const featuredCourses = COURSES.slice(0, 3);
  // Get first 4 instructors
  const featuredInstructors = INSTRUCTORS.slice(0, 4);

  const stats = [
    { label: 'Enrolled Learners', value: '45,000+' },
    { label: 'Active Mentors', value: '80+' },
    { label: 'SaaS Case Studies', value: '120+' },
    { label: 'Student Rating Avg', value: '4.8/5.0' },
  ];

  const benefits = [
    {
      title: 'Expert Mentors Only',
      description: 'Bypass academic lectures. Learn from product leaders, netflix developers, and silicon valley specialists.',
      icon: UserCheck,
      color: 'bg-emerald-50 text-emerald-600',
    },
    {
      title: 'Production Labs',
      description: 'Write compile-ready code, construct real UI layout files, and build real applications on your machine.',
      icon: Target,
      color: 'bg-blue-50 text-blue-600',
    },
    {
      title: 'Shareable Credentials',
      description: 'Showcase your capabilities. Download high-res verified certificates of completion with secure tracking.',
      icon: Award,
      color: 'bg-indigo-50 text-indigo-600',
    },
  ];

  return (
    <div id="home-page" className="flex flex-col gap-16 md:gap-24 pb-16">
      
      {/* 1. Hero Section & Search */}
      <section id="hero-section" className="relative overflow-hidden bg-gradient-to-b from-blue-50/70 via-white to-white py-16 sm:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            <div className="lg:col-span-7 flex flex-col items-start">
              {/* Badge */}
              <div className="inline-flex items-center gap-1.5 rounded-full bg-blue-50 px-3 py-1 text-xs font-semibold text-blue-700 mb-6">
                <Sparkles className="h-3.5 w-3.5 animate-pulse" />
                <span>Voted #1 Online Upskilling Platform of the Year</span>
              </div>
              
              {/* Heading */}
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-neutral-900 leading-none mb-6">
                Learn skills that <span className="text-blue-600">move you</span> forward.
              </h1>
              
              {/* Subheading */}
              <p className="text-lg text-neutral-600 max-w-2xl mb-8 leading-relaxed">
                Join over 45,000 students mastering web architecture, Figma systems, machine learning, and business growth hooks. Build production-grade portfolios guided by active industry leads.
              </p>

              {/* Dynamic Search Box */}
              <form onSubmit={handleSearchSubmit} className="w-full max-w-lg mb-8">
                <div className="relative flex items-center bg-white rounded-2xl border border-neutral-200 p-2 shadow-lg shadow-neutral-100 focus-within:border-blue-500 focus-within:ring-4 focus-within:ring-blue-100 transition-all">
                  <div className="pl-3 text-neutral-400">
                    <Search className="h-5 w-5" />
                  </div>
                  <input
                    type="text"
                    placeholder="What capability would you like to master today?"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full border-none outline-none bg-transparent px-3 text-sm text-neutral-800 placeholder:text-neutral-400 focus:ring-0"
                  />
                  <button
                    type="submit"
                    className="rounded-xl bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 text-xs font-bold tracking-wide transition-all shrink-0 shadow-md shadow-blue-200"
                  >
                    Find Course
                  </button>
                </div>
              </form>

              {/* Quick tags */}
              <div className="flex flex-wrap gap-2 items-center text-xs text-neutral-500">
                <span className="font-semibold text-neutral-700">Popular:</span>
                <Link to="/courses?search=React" className="hover:text-blue-600 border border-neutral-100 rounded-full px-3 py-1 bg-neutral-50 hover:bg-blue-50/50 transition-all">React</Link>
                <Link to="/courses?search=UX" className="hover:text-blue-600 border border-neutral-100 rounded-full px-3 py-1 bg-neutral-50 hover:bg-blue-50/50 transition-all">UI/UX Figma</Link>
                <Link to="/courses?search=Python" className="hover:text-blue-600 border border-neutral-100 rounded-full px-3 py-1 bg-neutral-50 hover:bg-blue-50/50 transition-all">Python AI</Link>
              </div>
            </div>

            {/* Hero Image / Illustration */}
            <div className="lg:col-span-5 relative hidden lg:block">
              <div className="relative rounded-3xl border border-neutral-100 bg-white p-4 shadow-2xl">
                <img
                  src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=500&q=80"
                  alt="Students learning"
                  className="rounded-2xl w-full object-cover aspect-[4/3] shadow-inner"
                  referrerPolicy="no-referrer"
                />
                
                {/* Floating card 1 */}
                <div className="absolute -left-6 bottom-12 rounded-2xl bg-white p-4 shadow-xl border border-neutral-50 flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-green-50 text-green-600">
                    <BookOpen className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-xs text-neutral-400">Lessons Completed</p>
                    <p className="text-sm font-bold text-neutral-800">1,240 lessons today</p>
                  </div>
                </div>

                {/* Floating card 2 */}
                <div className="absolute -right-6 top-12 rounded-2xl bg-white p-4 shadow-xl border border-neutral-50 flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-50 text-blue-600">
                    <Layers className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-xs text-neutral-400">Success Rate</p>
                    <p className="text-sm font-bold text-neutral-800">94% Certified</p>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 2. Statistics Bar */}
      <section id="statistics-section" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 -mt-8">
        <div className="rounded-2xl border border-neutral-100 bg-white p-6 sm:p-8 shadow-xl shadow-neutral-100/50 grid grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8 items-center text-center">
          {stats.map((stat, i) => (
            <div key={i} className="flex flex-col gap-1">
              <span className="text-2xl sm:text-3xl font-extrabold text-blue-600">{stat.value}</span>
              <span className="text-xs font-semibold uppercase tracking-wider text-neutral-400">{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      {/* 3. Learning Benefits */}
      <section id="benefits-section" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-xs font-extrabold tracking-widest text-blue-600 uppercase mb-2">The Learnify Advantage</h2>
          <p className="text-3xl font-bold text-neutral-900 tracking-tight sm:text-4xl">
            Why professional builders learn here.
          </p>
          <p className="mt-4 text-neutral-500 text-sm">
            We bypass academic fillers to focus on actual job outcomes. Every course is crafted directly by senior industry leaders who write production code daily.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {benefits.map((b, i) => {
            const IconComponent = b.icon;
            return (
              <div key={i} className="flex flex-col p-6 rounded-2xl border border-neutral-100 bg-white shadow-sm hover:shadow-md transition-shadow">
                <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${b.color} mb-5 shadow-sm`}>
                  <IconComponent className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-bold text-neutral-900 mb-2">{b.title}</h3>
                <p className="text-sm text-neutral-500 leading-relaxed">{b.description}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* 4. Popular Categories */}
      <section id="categories-section" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
          <div>
            <h2 className="text-xs font-extrabold tracking-widest text-blue-600 uppercase mb-2">Subject Directories</h2>
            <p className="text-3xl font-bold text-neutral-900 tracking-tight">
              Explore Popular Categories
            </p>
          </div>
          <Link
            to="/categories"
            className="group inline-flex items-center gap-1.5 text-sm font-bold text-blue-600 hover:text-blue-700"
          >
            <span>Browse all categories</span>
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {CATEGORIES.slice(0, 6).map((cat) => (
            <Link
              key={cat.id}
              to={`/courses?category=${cat.slug}`}
              className="group flex items-start gap-4 p-5 rounded-2xl border border-neutral-100 bg-white hover:border-blue-100 hover:shadow-md transition-all duration-200"
            >
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-blue-50 text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors duration-200">
                <BookOpen className="h-6 w-6" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-base font-bold text-neutral-900 group-hover:text-blue-600 transition-colors">{cat.name}</h3>
                <p className="text-xs text-neutral-400 mt-0.5">{cat.count} curated programs</p>
                <p className="text-xs text-neutral-500 mt-2 line-clamp-2 leading-relaxed">{cat.description}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* 5. Featured Courses */}
      <section id="featured-courses-section" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-10">
          <div>
            <h2 className="text-xs font-extrabold tracking-widest text-blue-600 uppercase mb-2">Curated syllabi</h2>
            <p className="text-3xl font-bold text-neutral-900 tracking-tight">
              Featured Programs
            </p>
          </div>
          <Link
            to="/courses"
            className="group inline-flex items-center gap-1.5 text-sm font-bold text-blue-600 hover:text-blue-700"
          >
            <span>View all courses</span>
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredCourses.map((course) => (
            <CourseCard key={course.id} course={course} />
          ))}
        </div>
      </section>

      {/* 6. Instructor Section */}
      <section id="instructors-section" className="bg-neutral-50 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-xs font-extrabold tracking-widest text-blue-600 uppercase mb-2">Learn from the experts</h2>
            <p className="text-3xl font-bold text-neutral-900 tracking-tight sm:text-4xl">
              Meet our Lead Instructors
            </p>
            <p className="mt-4 text-neutral-500 text-sm">
              Our active developers and managers teach you the techniques, templates, and patterns they use at Netflix, Uber, Airbnb, and Google Brain.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {featuredInstructors.map((inst) => (
              <div
                key={inst.id}
                className="group flex flex-col items-center text-center p-6 rounded-2xl bg-white border border-neutral-100 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="relative mb-4">
                  <div className="absolute inset-0 rounded-full border-2 border-dashed border-blue-200 group-hover:rotate-180 transition-transform duration-700" />
                  <img
                    src={inst.avatarUrl}
                    alt={inst.name}
                    className="h-24 w-24 rounded-full object-cover p-1.5 relative z-10"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <h3 className="text-base font-bold text-neutral-900">
                  <Link to={`/instructor/${inst.id}`} className="hover:text-blue-600 transition-colors">
                    {inst.name}
                  </Link>
                </h3>
                <p className="text-xs font-medium text-neutral-400 mt-1 min-h-[2rem] leading-tight px-2">{inst.role}</p>
                <div className="flex items-center gap-1.5 mt-3 text-xs font-bold text-amber-500">
                  <Star className="h-3.5 w-3.5 fill-amber-500" />
                  <span>{inst.rating.toFixed(2)} Rating</span>
                </div>
                <p className="text-xs text-neutral-500 mt-4 line-clamp-3 leading-relaxed px-1">
                  {inst.bio}
                </p>
                <Link
                  to={`/instructor/${inst.id}`}
                  className="mt-5 text-xs font-bold text-blue-600 hover:text-blue-700 inline-flex items-center gap-1"
                >
                  <span>Read Profile</span>
                  <ArrowRight className="h-3 w-3" />
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. Pricing Section */}
      <section id="pricing-section" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-10">
          <h2 className="text-xs font-extrabold tracking-widest text-blue-600 uppercase mb-2">Transparent pricing</h2>
          <p className="text-3xl font-bold text-neutral-900 tracking-tight sm:text-4xl">
            Flexible Plans for Every Stage
          </p>
          <p className="mt-4 text-neutral-500 text-sm">
            Enroll in single courses individually with lifetime access, or unlock the entire 50+ curriculum directory with our All-Access subscription.
          </p>

          {/* Monthly/Annual Toggle */}
          <div className="mt-8 inline-flex items-center gap-3 bg-neutral-100 p-1 rounded-full border border-neutral-200">
            <button
              onClick={() => setIsAnnual(false)}
              className={`rounded-full px-4 py-1.5 text-xs font-bold transition-all ${
                !isAnnual ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-500 hover:text-neutral-900'
              }`}
            >
              Monthly Billing
            </button>
            <button
              onClick={() => setIsAnnual(true)}
              className={`rounded-full px-4 py-1.5 text-xs font-bold transition-all ${
                isAnnual ? 'bg-white text-neutral-900 shadow-sm' : 'text-neutral-500 hover:text-neutral-900'
              }`}
            >
              Annual Billing <span className="text-[10px] text-green-600 font-bold ml-1">Save 35%</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
          {PRICING_PLANS.map((plan, i) => {
            const price = isAnnual ? plan.priceAnnually : plan.priceMonthly;
            const period = isAnnual ? '/yr' : '/mo';
            
            return (
              <div
                key={i}
                className={`relative flex flex-col p-6 sm:p-8 rounded-2xl bg-white border ${
                  plan.isPopular
                    ? 'border-blue-500 shadow-xl ring-1 ring-blue-500/20'
                    : 'border-neutral-100 shadow-sm'
                }`}
              >
                {plan.isPopular && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-blue-600 px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-white shadow-md">
                    Most Popular
                  </span>
                )}
                
                <h3 className="text-lg font-bold text-neutral-900">{plan.name}</h3>
                <p className="mt-2 text-xs text-neutral-500 min-h-[2.5rem] leading-relaxed">{plan.description}</p>
                
                <div className="mt-5 flex items-baseline gap-1">
                  <span className="text-4xl font-extrabold text-neutral-900">${price}</span>
                  {plan.priceMonthly > 0 && <span className="text-sm font-semibold text-neutral-400">{period}</span>}
                </div>

                <div className="my-6 border-t border-neutral-100" />

                <ul className="space-y-3.5 flex-1 mb-8">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2.5 text-xs text-neutral-600">
                      <Check className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
                      <span className="leading-tight">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Link
                  to={plan.priceMonthly === 0 ? '/courses' : '/pricing'}
                  className={`flex h-11 items-center justify-center rounded-xl text-xs font-bold transition-all shadow-sm ${
                    plan.isPopular
                      ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-100'
                      : 'bg-neutral-50 hover:bg-neutral-100 text-neutral-800'
                  }`}
                >
                  {plan.ctaText}
                </Link>
              </div>
            );
          })}
        </div>
      </section>

      {/* 8. Testimonials Section */}
      <section id="testimonials-section" className="bg-neutral-50/50 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-xs font-extrabold tracking-widest text-blue-600 uppercase mb-2">In their own words</h2>
            <p className="text-3xl font-bold text-neutral-900 tracking-tight sm:text-4xl">
              What Learnify Graduates Say
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {TESTIMONIALS.map((test) => (
              <div
                key={test.id}
                className="flex flex-col bg-white p-6 rounded-2xl border border-neutral-100 shadow-sm relative justify-between"
              >
                <div>
                  <div className="flex items-center gap-0.5 mb-4 text-amber-400">
                    {[...Array(test.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-current" />
                    ))}
                  </div>
                  <p className="text-sm text-neutral-600 italic leading-relaxed">
                    "{test.comment}"
                  </p>
                </div>
                
                <div className="flex items-center gap-3.5 mt-6 pt-4 border-t border-neutral-50">
                  <img
                    src={test.avatarUrl}
                    alt={test.name}
                    className="h-10 w-10 rounded-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <h4 className="text-xs font-bold text-neutral-900">{test.name}</h4>
                    <p className="text-[10px] text-neutral-400">{test.role}</p>
                    <p className="text-[10px] font-semibold text-blue-600 mt-0.5 line-clamp-1">{test.courseName}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 9. FAQ Accordion */}
      <section id="faq-section" className="mx-auto max-w-3xl px-4 sm:px-6">
        <div className="text-center mb-10">
          <h2 className="text-xs font-extrabold tracking-widest text-blue-600 uppercase mb-2">Got questions?</h2>
          <p className="text-3xl font-bold text-neutral-900 tracking-tight">
            Frequently Asked Questions
          </p>
        </div>

        <div className="space-y-3">
          {FAQS.map((faq, index) => {
            const isOpen = faqOpenIndex === index;
            return (
              <div
                key={index}
                className="rounded-xl border border-neutral-100 bg-white shadow-sm overflow-hidden"
              >
                <button
                  onClick={() => toggleFaq(index)}
                  className="flex w-full items-center justify-between gap-4 p-5 text-left text-sm font-bold text-neutral-800 hover:text-neutral-900 transition-colors"
                >
                  <span>{faq.question}</span>
                  <ChevronDown className={`h-4 w-4 text-neutral-400 shrink-0 transition-transform duration-200 ${isOpen ? 'rotate-180 text-blue-600' : ''}`} />
                </button>
                
                {isOpen && (
                  <div className="border-t border-neutral-50 px-5 py-4 text-xs text-neutral-500 leading-relaxed bg-neutral-50/20">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

      {/* 10. Call to Action (CTA) */}
      <section id="cta-section" className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl bg-blue-600 px-6 py-12 sm:px-12 sm:py-16 text-center shadow-xl shadow-blue-200 overflow-hidden">
          {/* Subtle background graphics */}
          <div className="absolute -left-12 -top-12 h-44 w-44 rounded-full bg-blue-500/30 blur-2xl" />
          <div className="absolute -right-12 -bottom-12 h-44 w-44 rounded-full bg-blue-500/30 blur-2xl" />
          
          <div className="relative z-10 max-w-2xl mx-auto flex flex-col items-center">
            <h2 className="text-3xl font-extrabold text-white tracking-tight sm:text-4xl">
              Ready to move your skills forward?
            </h2>
            <p className="mt-4 text-sm text-blue-100 leading-relaxed max-w-lg">
              Unlock life-changing development patterns and design frameworks with Learnify. Start learning today. No strings attached.
            </p>
            
            <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Link
                to="/courses"
                className="flex h-12 items-center justify-center rounded-full bg-white text-blue-600 hover:bg-neutral-50 px-8 text-sm font-bold transition-all shadow-lg shrink-0"
              >
                Explore Courses
              </Link>
              <Link
                to="/pricing"
                className="flex h-12 items-center justify-center rounded-full border border-blue-400 hover:border-white text-white px-8 text-sm font-bold transition-all shrink-0"
              >
                View Memberships
              </Link>
            </div>
            
            <p className="mt-6 text-xs text-blue-200">
              Join 45,000+ graduates already scaling companies worldwide.
            </p>
          </div>
        </div>
      </section>

    </div>
  );
};
