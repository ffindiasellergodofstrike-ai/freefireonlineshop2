import React, { useState } from 'react';
import { useApp, UserProfile } from '../context/AppContext';
import { CheckCircle, Save, User, FileText, Settings, Award, Compass, Sparkles } from 'lucide-react';

export const Profile: React.FC = () => {
  const { userProfile, updateProfile } = useApp();
  const [formData, setFormData] = useState<UserProfile>({ ...userProfile });
  const [isSaved, setIsSaved] = useState(false);
  const [newSkill, setNewSkill] = useState('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSaveSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile(formData);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 4000);
  };

  const handleAddSkill = (e: React.FormEvent) => {
    e.preventDefault();
    if (newSkill.trim() && !formData.skills.includes(newSkill.trim())) {
      const updatedSkills = [...formData.skills, newSkill.trim()];
      setFormData(prev => ({ ...prev, skills: updatedSkills }));
      setNewSkill('');
    }
  };

  const handleRemoveSkill = (skillToRemove: string) => {
    const updatedSkills = formData.skills.filter(s => s !== skillToRemove);
    setFormData(prev => ({ ...prev, skills: updatedSkills }));
  };

  const presetAvatars = [
    'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150&q=80',
    'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&h=150&q=80',
    'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=150&h=150&q=80',
    'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=150&h=150&q=80'
  ];

  return (
    <div id="profile-settings-page" className="bg-neutral-50/50 pb-20 pt-8">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
        
        {/* Page Header */}
        <div className="mb-10 text-center sm:text-left">
          <h1 className="text-3xl font-extrabold tracking-tight text-neutral-900">
            Account & Profile Settings
          </h1>
          <p className="mt-2 text-sm text-neutral-500">
            Configure your personal student bio, avatar images, and professional skills map visible on Learnify.
          </p>
        </div>

        {/* Form panel card */}
        <div className="rounded-2xl border border-neutral-100 bg-white shadow-sm p-6 sm:p-8">
          
          <form onSubmit={handleSaveSubmit} className="space-y-8">
            
            {/* SAVED NOTIFICATION HUD */}
            {isSaved && (
              <div className="flex items-center gap-3 p-4 rounded-xl border border-emerald-100 bg-emerald-50/20 text-emerald-800 text-xs font-semibold animate-in fade-in slide-in-from-top-2">
                <CheckCircle className="h-5 w-5 text-emerald-500 shrink-0" />
                <div>
                  <p className="font-extrabold text-neutral-900">Changes Saved Successfully</p>
                  <p className="text-neutral-500 font-medium mt-0.5">Your student profile is up to date and synchronized across your catalog.</p>
                </div>
              </div>
            )}

            {/* Profile Avatar choice */}
            <div>
              <label className="block text-xs font-bold text-neutral-500 uppercase tracking-wide mb-3">Choose Profile Photo</label>
              <div className="flex flex-col sm:flex-row items-center gap-6">
                
                {/* Active Photo */}
                <img
                  src={formData.avatarUrl}
                  alt={formData.name}
                  className="h-20 w-20 rounded-full object-cover border-2 p-1 border-blue-500 shadow"
                  referrerPolicy="no-referrer"
                />

                {/* Preset select */}
                <div className="flex-1">
                  <span className="text-[10px] text-neutral-400 font-bold block uppercase mb-2">Preset Avatars</span>
                  <div className="flex flex-wrap gap-3">
                    {presetAvatars.map((av, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => setFormData(prev => ({ ...prev, avatarUrl: av }))}
                        className={`h-10 w-10 rounded-full overflow-hidden border-2 transition-all ${
                          formData.avatarUrl === av
                            ? 'border-blue-500 scale-105 shadow-sm'
                            : 'border-neutral-200 hover:border-neutral-400'
                        }`}
                      >
                        <img src={av} alt="Preset avatar option" className="h-full w-full object-cover" />
                      </button>
                    ))}
                  </div>
                </div>

              </div>
            </div>

            <div className="border-t border-neutral-50 pt-6 grid grid-cols-1 sm:grid-cols-2 gap-6">
              
              {/* Full Name */}
              <div>
                <label htmlFor="name-input" className="block text-xs font-bold text-neutral-500 uppercase tracking-wide mb-1.5">Full Name</label>
                <input
                  type="text"
                  id="name-input"
                  name="name"
                  required
                  value={formData.name}
                  onChange={handleInputChange}
                  className="w-full rounded-xl border border-neutral-200 bg-neutral-50 py-2.5 px-4 text-xs outline-none focus:border-blue-500 focus:bg-white"
                />
              </div>

              {/* Email */}
              <div>
                <label htmlFor="email-input" className="block text-xs font-bold text-neutral-500 uppercase tracking-wide mb-1.5">Email Address</label>
                <input
                  type="email"
                  id="email-input"
                  name="email"
                  required
                  value={formData.email}
                  onChange={handleInputChange}
                  className="w-full rounded-xl border border-neutral-200 bg-neutral-50 py-2.5 px-4 text-xs outline-none focus:border-blue-500 focus:bg-white"
                />
              </div>

            </div>

            {/* Headline */}
            <div>
              <label htmlFor="headline-input" className="block text-xs font-bold text-neutral-500 uppercase tracking-wide mb-1.5">Headline</label>
              <input
                type="text"
                id="headline-input"
                name="headline"
                required
                value={formData.headline}
                onChange={handleInputChange}
                className="w-full rounded-xl border border-neutral-200 bg-neutral-50 py-2.5 px-4 text-xs outline-none focus:border-blue-500 focus:bg-white"
              />
            </div>

            {/* Biography */}
            <div>
              <label htmlFor="bio-input" className="block text-xs font-bold text-neutral-500 uppercase tracking-wide mb-1.5">Biography</label>
              <textarea
                id="bio-input"
                name="bio"
                required
                rows={4}
                value={formData.bio}
                onChange={handleInputChange}
                className="w-full rounded-xl border border-neutral-200 bg-neutral-50 py-2.5 px-4 text-xs outline-none focus:border-blue-500 focus:bg-white resize-none"
              />
            </div>

            {/* Specialties tag builder */}
            <div className="border-t border-neutral-50 pt-6">
              <label className="block text-xs font-bold text-neutral-500 uppercase tracking-wide mb-1.5">Active Skills Map</label>
              <div className="flex flex-wrap gap-2 mb-4">
                {formData.skills.map((skill, index) => (
                  <span
                    key={index}
                    className="rounded-lg bg-neutral-50 border border-neutral-100 px-3 py-1 text-xs font-semibold text-neutral-600 flex items-center gap-2 shadow-sm"
                  >
                    <span>{skill}</span>
                    <button
                      type="button"
                      onClick={() => handleRemoveSkill(skill)}
                      className="text-neutral-400 hover:text-rose-600 font-extrabold text-xs"
                      title="Remove skill"
                    >
                      ×
                    </button>
                  </span>
                ))}
              </div>

              {/* Add skill input */}
              <div className="flex max-w-sm gap-2">
                <input
                  type="text"
                  placeholder="e.g. Next.js, Figma, Python"
                  value={newSkill}
                  onChange={(e) => setNewSkill(e.target.value)}
                  className="rounded-xl border border-neutral-200 bg-neutral-50 py-2 px-3 text-xs outline-none focus:border-blue-500 focus:bg-white flex-1"
                />
                <button
                  type="button"
                  onClick={handleAddSkill}
                  className="rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-bold px-4 transition-all"
                >
                  Add
                </button>
              </div>
            </div>

            {/* Form actions */}
            <div className="border-t border-neutral-50 pt-6 flex justify-end gap-3">
              <button
                type="submit"
                className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-6 transition-all shadow-md shadow-blue-100"
              >
                <Save className="h-3.5 w-3.5" />
                <span>Save Profile Changes</span>
              </button>
            </div>

          </form>

        </div>

      </div>
    </div>
  );
};
