import React, { createContext, useContext, useState, useEffect } from 'react';
import { Course } from '../types';
import { COURSES } from '../data';

export interface EnrolledCourse {
  courseId: string;
  progressPercent: number;
  enrolledAt: string;
  lastAccessedAt: string;
}

export interface UserProfile {
  name: string;
  email: string;
  headline: string;
  bio: string;
  avatarUrl: string;
  skills: string[];
}

export interface AppContextType {
  enrolledCourses: EnrolledCourse[];
  userProfile: UserProfile;
  completedLessons: string[];
  activeLessons: Record<string, string>; // courseId -> lessonId
  userNotes: Record<string, Record<string, string>>; // courseId -> lessonId -> notes
  enrollInCourse: (courseId: string) => void;
  toggleLessonCompletion: (courseId: string, lessonId: string) => void;
  setActiveLesson: (courseId: string, lessonId: string) => void;
  saveNote: (courseId: string, lessonId: string, noteContent: string) => void;
  updateProfile: (profile: Partial<UserProfile>) => void;
  isEnrolled: (courseId: string) => boolean;
  getCourseProgress: (courseId: string) => number;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load initial state from localStorage or defaults
  const [enrolledCourses, setEnrolledCourses] = useState<EnrolledCourse[]>(() => {
    const stored = localStorage.getItem('learnify_enrolled');
    if (stored) return JSON.parse(stored);
    // Enroll the user in the first course as a default so they have something to see in their dashboard immediately!
    return [
      {
        courseId: 'course-1',
        progressPercent: 33,
        enrolledAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        lastAccessedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
      }
    ];
  });

  const [userProfile, setUserProfile] = useState<UserProfile>(() => {
    const stored = localStorage.getItem('learnify_profile');
    if (stored) return JSON.parse(stored);
    return {
      name: 'Alex Mercer',
      email: 'alex.mercer@dev.com',
      headline: 'Aspiring Full-Stack Developer & Tech Enthusiast',
      bio: 'Self-taught coder passionate about mastering React, Node.js, and high-fidelity product design. Building web applications one lesson at a time with Learnify!',
      avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&h=150&q=80',
      skills: ['HTML5', 'CSS3', 'JavaScript', 'Tailwind CSS']
    };
  });

  const [completedLessons, setCompletedLessons] = useState<string[]>(() => {
    const stored = localStorage.getItem('learnify_completed');
    if (stored) return JSON.parse(stored);
    // Seed some initial completed lessons for the enrolled course-1
    return ['c1-l1', 'c1-l2'];
  });

  const [activeLessons, setActiveLessons] = useState<Record<string, string>>(() => {
    const stored = localStorage.getItem('learnify_active');
    if (stored) return JSON.parse(stored);
    return {
      'course-1': 'c1-l3'
    };
  });

  const [userNotes, setUserNotes] = useState<Record<string, Record<string, string>>>(() => {
    const stored = localStorage.getItem('learnify_notes');
    if (stored) return JSON.parse(stored);
    return {
      'course-1': {
        'c1-l1': 'Welcome session notes: Excellent breakdown of HTML tags, semantic elements, and modern DOM configurations.'
      }
    };
  });

  // Persist to localStorage when changes occur
  useEffect(() => {
    localStorage.setItem('learnify_enrolled', JSON.stringify(enrolledCourses));
  }, [enrolledCourses]);

  useEffect(() => {
    localStorage.setItem('learnify_profile', JSON.stringify(userProfile));
  }, [userProfile]);

  useEffect(() => {
    localStorage.setItem('learnify_completed', JSON.stringify(completedLessons));
  }, [completedLessons]);

  useEffect(() => {
    localStorage.setItem('learnify_active', JSON.stringify(activeLessons));
  }, [activeLessons]);

  useEffect(() => {
    localStorage.setItem('learnify_notes', JSON.stringify(userNotes));
  }, [userNotes]);

  const enrollInCourse = (courseId: string) => {
    if (enrolledCourses.some(e => e.courseId === courseId)) return;
    
    // Find course first lesson to set as active
    const course = COURSES.find(c => c.id === courseId);
    const firstLessonId = course?.sections[0]?.lessons[0]?.id || '';

    const newEnrollment: EnrolledCourse = {
      courseId,
      progressPercent: 0,
      enrolledAt: new Date().toISOString(),
      lastAccessedAt: new Date().toISOString()
    };

    setEnrolledCourses(prev => [...prev, newEnrollment]);
    if (firstLessonId) {
      setActiveLessons(prev => ({ ...prev, [courseId]: firstLessonId }));
    }
  };

  const isEnrolled = (courseId: string) => {
    return enrolledCourses.some(e => e.courseId === courseId);
  };

  const toggleLessonCompletion = (courseId: string, lessonId: string) => {
    let newCompleted: string[];
    if (completedLessons.includes(lessonId)) {
      newCompleted = completedLessons.filter(id => id !== lessonId);
    } else {
      newCompleted = [...completedLessons, lessonId];
    }
    setCompletedLessons(newCompleted);

    // Calculate new progress for this course
    const course = COURSES.find(c => c.id === courseId);
    if (!course) return;

    const allLessonIds = course.sections.flatMap(s => s.lessons.map(l => l.id));
    const courseCompletedCount = allLessonIds.filter(id => newCompleted.includes(id)).length;
    const progressPercent = Math.round((courseCompletedCount / allLessonIds.length) * 100);

    setEnrolledCourses(prev => prev.map(e => {
      if (e.courseId === courseId) {
        return {
          ...e,
          progressPercent,
          lastAccessedAt: new Date().toISOString()
        };
      }
      return e;
    }));
  };

  const setActiveLesson = (courseId: string, lessonId: string) => {
    setActiveLessons(prev => ({ ...prev, [courseId]: lessonId }));
    setEnrolledCourses(prev => prev.map(e => {
      if (e.courseId === courseId) {
        return {
          ...e,
          lastAccessedAt: new Date().toISOString()
        };
      }
      return e;
    }));
  };

  const saveNote = (courseId: string, lessonId: string, noteContent: string) => {
    setUserNotes(prev => {
      const courseNotes = prev[courseId] || {};
      return {
        ...prev,
        [courseId]: {
          ...courseNotes,
          [lessonId]: noteContent
        }
      };
    });
  };

  const updateProfile = (profile: Partial<UserProfile>) => {
    setUserProfile(prev => ({
      ...prev,
      ...profile
    }));
  };

  const getCourseProgress = (courseId: string) => {
    const enrollment = enrolledCourses.find(e => e.courseId === courseId);
    return enrollment ? enrollment.progressPercent : 0;
  };

  return (
    <AppContext.Provider value={{
      enrolledCourses,
      userProfile,
      completedLessons,
      activeLessons,
      userNotes,
      enrollInCourse,
      toggleLessonCompletion,
      setActiveLesson,
      saveNote,
      updateProfile,
      isEnrolled,
      getCourseProgress
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used inside an AppProvider');
  return context;
};
