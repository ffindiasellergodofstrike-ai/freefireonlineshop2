import React from 'react';
import { Link } from 'react-router-dom';
import { Star, Clock, GraduationCap, Users, ArrowRight } from 'lucide-react';
import { Course } from '../types';

interface CourseCardProps {
  course: Course;
}

export const CourseCard: React.FC<CourseCardProps> = ({ course }) => {
  const {
    id,
    title,
    instructorName,
    rating,
    studentsCount,
    duration,
    level,
    price,
    discountPercent,
    thumbnailUrl,
    category
  } = course;

  // Calculate final discounted price
  const hasDiscount = discountPercent > 0;
  const finalPrice = hasDiscount ? price * (1 - discountPercent / 100) : price;

  return (
    <div
      id={`course-card-${id}`}
      className="group flex flex-col overflow-hidden rounded-2xl border border-neutral-100 bg-white transition-all hover:border-blue-100 hover:shadow-xl hover:-translate-y-0.5 duration-300"
    >
      {/* Thumbnail Container */}
      <div className="relative aspect-video w-full overflow-hidden bg-neutral-100">
        <img
          src={thumbnailUrl}
          alt={title}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          referrerPolicy="no-referrer"
          loading="lazy"
        />
        {/* Category Tag */}
        <span className="absolute left-3 top-3 rounded-md bg-white/90 backdrop-blur-md px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-neutral-800 shadow-sm border border-neutral-100/50">
          {category}
        </span>
        {/* Discount Badge */}
        {hasDiscount && (
          <span className="absolute right-3 top-3 rounded-md bg-rose-600 px-2 py-1 text-xs font-bold text-white shadow-sm">
            {discountPercent}% OFF
          </span>
        )}
      </div>

      {/* Content */}
      <div className="flex flex-1 flex-col p-5">
        
        {/* Instructor */}
        <p className="text-xs font-medium text-neutral-500 mb-1">{instructorName}</p>
        
        {/* Title */}
        <h3 className="text-base font-bold text-neutral-900 line-clamp-2 leading-snug group-hover:text-blue-600 transition-colors mb-2 min-h-[2.75rem]">
          <Link to={`/course/${id}`}>
            {title}
          </Link>
        </h3>

        {/* Rating & Students */}
        <div className="flex items-center gap-4 mb-4 text-xs text-neutral-600 border-b border-neutral-50 pb-3">
          <div className="flex items-center gap-1 text-amber-500 font-bold">
            <Star className="h-3.5 w-3.5 fill-amber-500" />
            <span>{rating.toFixed(2)}</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="h-3.5 w-3.5 text-neutral-400" />
            <span>{studentsCount.toLocaleString()} students</span>
          </div>
        </div>

        {/* Level & Duration Metadata */}
        <div className="grid grid-cols-2 gap-2 mb-4 text-xs text-neutral-500">
          <div className="flex items-center gap-1.5">
            <Clock className="h-3.5 w-3.5 text-neutral-400 shrink-0" />
            <span className="truncate">{duration}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <GraduationCap className="h-3.5 w-3.5 text-neutral-400 shrink-0" />
            <span className="truncate">{level}</span>
          </div>
        </div>

        {/* Price & CTA at bottom */}
        <div className="mt-auto flex items-center justify-between pt-3 border-t border-neutral-50">
          <div className="flex flex-col">
            {hasDiscount ? (
              <div className="flex items-baseline gap-1.5">
                <span className="text-lg font-extrabold text-neutral-900">${finalPrice.toFixed(2)}</span>
                <span className="text-xs text-neutral-400 line-through">${price.toFixed(2)}</span>
              </div>
            ) : (
              <span className="text-lg font-extrabold text-neutral-900">${price.toFixed(2)}</span>
            )}
          </div>
          
          <Link
            to={`/course/${id}`}
            className="inline-flex h-9 items-center justify-center gap-1.5 rounded-full bg-neutral-50 hover:bg-blue-50 hover:text-blue-600 px-4 text-xs font-bold text-neutral-700 transition-all border border-neutral-100"
          >
            <span>Details</span>
            <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
          </Link>
        </div>

      </div>
    </div>
  );
};
