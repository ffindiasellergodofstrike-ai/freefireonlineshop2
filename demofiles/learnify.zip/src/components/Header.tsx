import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { BookOpen, Search, Menu, X, User, LogOut, Layout, BookOpenCheck, Settings } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Header: React.FC = () => {
  const { userProfile } = useApp();
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const navigation = [
    { name: 'Home', href: '/' },
    { name: 'Courses', href: '/courses' },
    { name: 'Categories', href: '/categories' },
    { name: 'Instructors', href: '/instructors' },
    { name: 'Pricing', href: '/pricing' },
    { name: 'About', href: '/about' },
    { name: 'Contact', href: '/contact' },
  ];

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/courses?search=${encodeURIComponent(searchQuery.trim())}`);
      setSearchQuery('');
    }
  };

  const isActive = (path: string) => {
    if (path === '/') {
      return location.pathname === '/';
    }
    return location.pathname.startsWith(path);
  };

  return (
    <header id="app-header" className="sticky top-0 z-40 w-full border-b border-neutral-100 bg-white/90 backdrop-blur-md">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between gap-4">
          
          {/* Logo */}
          <div className="flex items-center">
            <Link id="logo-link" to="/" className="flex items-center gap-2 group">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600 text-white shadow-md shadow-blue-200 transition-transform group-hover:scale-105">
                <BookOpen className="h-5 w-5" />
              </div>
              <div>
                <span className="text-xl font-bold tracking-tight text-neutral-900">Learnify</span>
                <span className="block text-[10px] font-medium text-blue-600 -mt-1">Move forward</span>
              </div>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            {navigation.map((item) => (
              <Link
                key={item.name}
                id={`nav-${item.name.toLowerCase().replace(/\s+/g, '-')}`}
                to={item.href}
                className={`px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                  isActive(item.href)
                    ? 'text-blue-600 bg-blue-50/50'
                    : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-50'
                }`}
              >
                {item.name}
              </Link>
            ))}
          </nav>

          {/* Search Bar - Desktop */}
          <div className="hidden md:flex flex-1 max-w-xs items-center">
            <form onSubmit={handleSearchSubmit} className="relative w-full">
              <input
                type="text"
                placeholder="Search courses, skills..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full rounded-full border border-neutral-200 bg-neutral-50 py-1.5 pl-4 pr-10 text-sm outline-none transition-all placeholder:text-neutral-400 focus:border-blue-500 focus:bg-white focus:ring-2 focus:ring-blue-100"
              />
              <button
                type="submit"
                className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-700"
              >
                <Search className="h-4 w-4" />
              </button>
            </form>
          </div>

          {/* Actions & Profile Dropdown */}
          <div className="flex items-center gap-4">
            
            {/* Quick Access Dashboard */}
            <Link
              id="header-dashboard-link"
              to="/dashboard"
              className="hidden sm:inline-flex items-center gap-2 text-sm font-semibold text-blue-600 hover:text-blue-700 bg-blue-50 px-4 py-2 rounded-full transition-all hover:bg-blue-100"
            >
              <Layout className="h-4 w-4" />
              <span>Dashboard</span>
            </Link>

            {/* User Profile Menu */}
            <div className="relative">
              <button
                id="profile-dropdown-btn"
                onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                className="flex items-center gap-2 rounded-full p-1 border border-neutral-100 bg-neutral-50 hover:bg-neutral-100 hover:border-neutral-200 transition-all outline-none"
                aria-expanded={profileDropdownOpen}
              >
                <img
                  src={userProfile.avatarUrl}
                  alt={userProfile.name}
                  className="h-8 w-8 rounded-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <span className="hidden md:block text-xs font-semibold text-neutral-700 px-1">
                  {userProfile.name.split(' ')[0]}
                </span>
              </button>

              {profileDropdownOpen && (
                <>
                  <div
                    className="fixed inset-0 z-10"
                    onClick={() => setProfileDropdownOpen(false)}
                  />
                  <div
                    id="profile-dropdown-menu"
                    className="absolute right-0 mt-2 w-56 origin-top-right rounded-xl border border-neutral-100 bg-white p-2 shadow-xl ring-1 ring-black/5 focus:outline-none z-20 animate-in fade-in slide-in-from-top-2 duration-150"
                  >
                    <div className="border-b border-neutral-50 px-3 py-2 text-xs text-neutral-400">
                      Signed in as <span className="font-semibold text-neutral-700">{userProfile.email}</span>
                    </div>
                    
                    <Link
                      to="/dashboard"
                      onClick={() => setProfileDropdownOpen(false)}
                      className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm text-neutral-700 hover:bg-neutral-50"
                    >
                      <Layout className="h-4 w-4 text-neutral-400" />
                      <span>Dashboard Home</span>
                    </Link>

                    <Link
                      to="/my-courses"
                      onClick={() => setProfileDropdownOpen(false)}
                      className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm text-neutral-700 hover:bg-neutral-50"
                    >
                      <BookOpenCheck className="h-4 w-4 text-neutral-400" />
                      <span>My Learning</span>
                    </Link>

                    <Link
                      to="/profile"
                      onClick={() => setProfileDropdownOpen(false)}
                      className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm text-neutral-700 hover:bg-neutral-50"
                    >
                      <Settings className="h-4 w-4 text-neutral-400" />
                      <span>Profile Settings</span>
                    </Link>

                    <div className="my-1 border-t border-neutral-50" />

                    <button
                      onClick={() => {
                        setProfileDropdownOpen(false);
                        localStorage.clear();
                        window.location.reload();
                      }}
                      className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm text-rose-600 hover:bg-rose-50"
                    >
                      <LogOut className="h-4 w-4" />
                      <span>Reset State</span>
                    </button>
                  </div>
                </>
              )}
            </div>

            {/* Mobile Menu Toggle */}
            <button
              id="mobile-menu-toggle-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-1.5 text-neutral-500 hover:text-neutral-900 rounded-lg lg:hidden hover:bg-neutral-50 transition-colors"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div id="mobile-drawer" className="lg:hidden border-t border-neutral-100 bg-white py-4 px-4 shadow-lg animate-in fade-in slide-in-from-top-5 duration-200">
          
          {/* Mobile Search */}
          <form onSubmit={handleSearchSubmit} className="relative w-full mb-4 md:hidden">
            <input
              type="text"
              placeholder="Search courses, skills..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-full border border-neutral-200 bg-neutral-50 py-2 pl-4 pr-10 text-sm outline-none transition-all placeholder:text-neutral-400 focus:border-blue-500 focus:bg-white"
            />
            <button
              type="submit"
              className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-700"
            >
              <Search className="h-4 w-4" />
            </button>
          </form>

          {/* Links */}
          <nav className="flex flex-col gap-1 mb-4">
            {navigation.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`px-3 py-2.5 text-base font-semibold rounded-lg transition-colors ${
                  isActive(item.href)
                    ? 'text-blue-600 bg-blue-50/50'
                    : 'text-neutral-700 hover:text-neutral-900 hover:bg-neutral-50'
                }`}
              >
                {item.name}
              </Link>
            ))}
          </nav>

          {/* Dashboard Quick Link in Mobile */}
          <div className="border-t border-neutral-100 pt-4 flex flex-col gap-2">
            <Link
              to="/dashboard"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white shadow-md shadow-blue-100"
            >
              <Layout className="h-4 w-4" />
              <span>Go to Dashboard</span>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
};
