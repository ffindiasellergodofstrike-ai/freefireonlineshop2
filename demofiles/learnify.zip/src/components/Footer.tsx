import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Twitter, Linkedin, Github, Youtube, Check, Mail } from 'lucide-react';

export const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setSubscribed(true);
      setEmail('');
      setTimeout(() => setSubscribed(false), 4000);
    }
  };

  return (
    <footer id="app-footer" className="border-t border-neutral-100 bg-neutral-50/50">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8 lg:py-16">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4 lg:grid-cols-5">
          
          {/* Brand Column */}
          <div className="md:col-span-2 lg:col-span-2">
            <Link to="/" className="flex items-center gap-2 group">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-blue-600 text-white shadow-md shadow-blue-200">
                <BookOpen className="h-5 w-5" />
              </div>
              <span className="text-xl font-bold tracking-tight text-neutral-900">Learnify</span>
            </Link>
            <p className="mt-4 text-sm text-neutral-500 max-w-xs leading-relaxed">
              Learn skills that move you forward. Premium, expert-led online courses designed for modern industry builders.
            </p>
            <div className="mt-6 flex gap-4">
              <a href="https://twitter.com" target="_blank" rel="noreferrer" className="text-neutral-400 hover:text-blue-500 transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noreferrer" className="text-neutral-400 hover:text-blue-700 transition-colors">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="https://github.com" target="_blank" rel="noreferrer" className="text-neutral-400 hover:text-neutral-900 transition-colors">
                <Github className="h-5 w-5" />
              </a>
              <a href="https://youtube.com" target="_blank" rel="noreferrer" className="text-neutral-400 hover:text-rose-600 transition-colors">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider">Learning</h3>
            <ul className="mt-4 space-y-2.5">
              <li>
                <Link to="/courses" className="text-sm text-neutral-600 hover:text-neutral-900 transition-colors">
                  All Courses
                </Link>
              </li>
              <li>
                <Link to="/categories" className="text-sm text-neutral-600 hover:text-neutral-900 transition-colors">
                  Browse Categories
                </Link>
              </li>
              <li>
                <Link to="/pricing" className="text-sm text-neutral-600 hover:text-neutral-900 transition-colors">
                  Membership Plans
                </Link>
              </li>
              <li>
                <Link to="/dashboard" className="text-sm text-neutral-600 hover:text-neutral-900 transition-colors">
                  Student Dashboard
                </Link>
              </li>
            </ul>
          </div>

          {/* Platform Links */}
          <div>
            <h3 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider">Platform</h3>
            <ul className="mt-4 space-y-2.5">
              <li>
                <Link to="/about" className="text-sm text-neutral-600 hover:text-neutral-900 transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/instructors" className="text-sm text-neutral-600 hover:text-neutral-900 transition-colors">
                  Our Instructors
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-sm text-neutral-600 hover:text-neutral-900 transition-colors">
                  Contact Support
                </Link>
              </li>
              <li>
                <Link to="/privacy" className="text-sm text-neutral-600 hover:text-neutral-900 transition-colors">
                  Privacy Policy
                </Link>
              </li>
            </ul>
          </div>

          {/* Newsletter Column */}
          <div className="md:col-span-2 lg:col-span-1">
            <h3 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider">Stay Updated</h3>
            <p className="mt-4 text-xs text-neutral-500 leading-relaxed">
              Subscribe to receive weekly insights, course launches, and free resource links.
            </p>
            <form onSubmit={handleSubmit} className="mt-4">
              <div className="relative">
                <input
                  type="email"
                  required
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full rounded-xl border border-neutral-200 bg-white py-2 pl-3 pr-10 text-sm outline-none placeholder:text-neutral-400 focus:border-blue-500 focus:ring-1 focus:ring-blue-100"
                />
                <button
                  type="submit"
                  className="absolute right-1.5 top-1/2 -translate-y-1/2 flex h-7 w-7 items-center justify-center rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition-all shadow-sm"
                >
                  {subscribed ? <Check className="h-3.5 w-3.5" /> : <Mail className="h-3.5 w-3.5" />}
                </button>
              </div>
              {subscribed && (
                <p className="mt-1.5 text-[10px] text-green-600 font-medium">
                  Subscribed successfully! Thank you.
                </p>
              )}
            </form>
          </div>

        </div>

        {/* Legal Row */}
        <div className="mt-12 border-t border-neutral-100 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-neutral-400">
          <p>© {new Date().getFullYear()} Learnify Inc. All rights reserved. Made for professional learners.</p>
          <div className="flex gap-6">
            <Link to="/terms" className="hover:text-neutral-600 transition-colors">Terms of Service</Link>
            <Link to="/privacy" className="hover:text-neutral-600 transition-colors">Cookie settings</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};
