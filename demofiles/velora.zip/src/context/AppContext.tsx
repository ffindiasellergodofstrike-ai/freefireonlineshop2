/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, CartItem, Toast, ShippingAddress, Order, Coupon, ProductVariant } from '../types';
import { PRODUCTS, DEFAULT_SHIPPING_ADDRESSES, DEFAULT_ORDERS, COUPONS } from '../data/mockData';

interface AppContextType {
  // Navigation
  currentRoute: string;
  currentRouteParams: any;
  navigateTo: (route: string, params?: any) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;

  // Theme
  theme: 'light' | 'dark';
  toggleTheme: () => void;

  // E-Commerce Core
  cart: CartItem[];
  addToCart: (product: Product, quantity: number, color?: ProductVariant, size?: ProductVariant) => void;
  removeFromCart: (cartItemId: string) => void;
  updateCartQuantity: (cartItemId: string, quantity: number) => void;
  clearCart: () => void;
  cartTotal: number;
  cartCount: number;

  // Wishlist
  wishlist: Product[];
  toggleWishlist: (product: Product) => void;
  isInWishlist: (productId: string) => boolean;

  // Recently Viewed
  recentlyViewed: Product[];
  addToRecentlyViewed: (product: Product) => void;

  // Authentication
  user: { name: string; email: string; isLoggedIn: boolean } | null;
  loginUser: (email: string, password: string) => boolean;
  registerUser: (name: string, email: string, password: string) => boolean;
  logoutUser: () => void;
  forgotPassword: (email: string) => boolean;

  // Address & Checkout
  shippingAddresses: ShippingAddress[];
  addAddress: (address: Omit<ShippingAddress, 'id'>) => void;
  updateAddress: (address: ShippingAddress) => void;
  deleteAddress: (id: string) => void;
  setDefaultAddress: (id: string) => void;

  // Coupons
  activeCoupon: Coupon | null;
  applyCoupon: (code: string) => boolean;
  removeCoupon: () => void;

  // Orders
  orders: Order[];
  placeOrder: (address: ShippingAddress, paymentMethod: string) => Order | null;
  trackOrder: (orderId: string) => Order | undefined;

  // Notification / Toast
  toasts: Toast[];
  addToast: (message: string, type: 'success' | 'error' | 'info') => void;
  removeToast: (id: string) => void;

  // Global Drawers/Modals state
  isCartOpen: boolean;
  setCartOpen: (open: boolean) => void;
  isWishlistOpen: boolean;
  setWishlistOpen: (open: boolean) => void;
  quickViewProduct: Product | null;
  setQuickViewProduct: (product: Product | null) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Navigation & Route states sync with hash
  const [currentRoute, setCurrentRoute] = useState<string>('home');
  const [currentRouteParams, setCurrentRouteParams] = useState<any>({});
  const [searchQuery, setSearchQuery] = useState<string>('');

  // UI state
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [isCartOpen, setCartOpen] = useState(false);
  const [isWishlistOpen, setWishlistOpen] = useState(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);

  // Core E-commerce states (synced with localStorage)
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<Product[]>([]);
  const [recentlyViewed, setRecentlyViewed] = useState<Product[]>([]);
  const [user, setUser] = useState<{ name: string; email: string; isLoggedIn: boolean } | null>(null);
  const [shippingAddresses, setShippingAddresses] = useState<ShippingAddress[]>(DEFAULT_SHIPPING_ADDRESSES);
  const [orders, setOrders] = useState<Order[]>(DEFAULT_ORDERS);
  const [activeCoupon, setActiveCoupon] = useState<Coupon | null>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Parse window.location.hash for routing
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash || '#home';
      const cleanHash = hash.replace('#', '');
      
      if (cleanHash === 'home' || cleanHash === '') {
        setCurrentRoute('home');
        setCurrentRouteParams({});
      } else if (cleanHash === 'shop') {
        setCurrentRoute('shop');
        setCurrentRouteParams({});
      } else if (cleanHash.startsWith('product/')) {
        const id = cleanHash.split('product/')[1];
        setCurrentRoute('product');
        setCurrentRouteParams({ id });
      } else if (cleanHash.startsWith('category/')) {
        const id = cleanHash.split('category/')[1];
        setCurrentRoute('category');
        setCurrentRouteParams({ id });
      } else if (cleanHash.startsWith('blog/')) {
        const id = cleanHash.split('blog/')[1];
        setCurrentRoute('blog-details');
        setCurrentRouteParams({ id });
      } else {
        setCurrentRoute(cleanHash);
        setCurrentRouteParams({});
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    handleHashChange(); // Trigger on mount

    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // Theme persistence & effect
  useEffect(() => {
    const savedTheme = localStorage.getItem('velora-theme') as 'light' | 'dark';
    if (savedTheme) {
      setTheme(savedTheme);
      document.documentElement.classList.toggle('dark', savedTheme === 'dark');
    } else {
      const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      setTheme(systemPrefersDark ? 'dark' : 'light');
      document.documentElement.classList.toggle('dark', systemPrefersDark);
    }
  }, []);

  const toggleTheme = () => {
    const nextTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(nextTheme);
    localStorage.setItem('velora-theme', nextTheme);
    document.documentElement.classList.toggle('dark', nextTheme === 'dark');
    addToast(`Switched to ${nextTheme} mode`, 'info');
  };

  // Load cart, wishlist, user, etc. from localStorage on startup
  useEffect(() => {
    const savedCart = localStorage.getItem('velora-cart');
    const savedWishlist = localStorage.getItem('velora-wishlist');
    const savedUser = localStorage.getItem('velora-user');
    const savedAddresses = localStorage.getItem('velora-addresses');
    const savedOrders = localStorage.getItem('velora-orders');
    const savedRecently = localStorage.getItem('velora-recently-viewed');

    if (savedCart) setCart(JSON.parse(savedCart));
    if (savedWishlist) setWishlist(JSON.parse(savedWishlist));
    if (savedUser) setUser(JSON.parse(savedUser));
    if (savedAddresses) setShippingAddresses(JSON.parse(savedAddresses));
    if (savedOrders) setOrders(JSON.parse(savedOrders));
    if (savedRecently) setRecentlyViewed(JSON.parse(savedRecently));
  }, []);

  // Sync state helpers to localStorage
  const saveCart = (newCart: CartItem[]) => {
    setCart(newCart);
    localStorage.setItem('velora-cart', JSON.stringify(newCart));
  };

  const saveWishlist = (newWishlist: Product[]) => {
    setWishlist(newWishlist);
    localStorage.setItem('velora-wishlist', JSON.stringify(newWishlist));
  };

  const saveUserState = (newUser: typeof user) => {
    setUser(newUser);
    if (newUser) {
      localStorage.setItem('velora-user', JSON.stringify(newUser));
    } else {
      localStorage.removeItem('velora-user');
    }
  };

  // Toast System
  const addToast = (message: string, type: 'success' | 'error' | 'info') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => removeToast(id), 4000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Navigation controller
  const navigateTo = (route: string, params: any = {}) => {
    let hash = `#${route}`;
    if (route === 'product' && params.id) {
      hash = `#product/${params.id}`;
    } else if (route === 'category' && params.id) {
      hash = `#category/${params.id}`;
    } else if (route === 'blog-details' && params.id) {
      hash = `#blog/${params.id}`;
    }
    
    window.location.hash = hash;
    setCurrentRoute(route);
    setCurrentRouteParams(params);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Cart Operations
  const addToCart = (product: Product, quantity: number, color?: ProductVariant, size?: ProductVariant) => {
    const cartItemId = `${product.id}-${color?.id || 'none'}-${size?.id || 'none'}`;
    const existingIndex = cart.findIndex((item) => item.id === cartItemId);

    let newCart = [...cart];
    if (existingIndex > -1) {
      newCart[existingIndex].quantity += quantity;
    } else {
      newCart.push({
        id: cartItemId,
        product,
        quantity,
        selectedColor: color,
        selectedSize: size,
      });
    }
    saveCart(newCart);
    addToast(`Added ${quantity}x ${product.name} to cart`, 'success');
  };

  const removeFromCart = (cartItemId: string) => {
    const item = cart.find((i) => i.id === cartItemId);
    const newCart = cart.filter((i) => i.id !== cartItemId);
    saveCart(newCart);
    if (item) {
      addToast(`Removed ${item.product.name} from cart`, 'info');
    }
  };

  const updateCartQuantity = (cartItemId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(cartItemId);
      return;
    }
    const newCart = cart.map((item) =>
      item.id === cartItemId ? { ...item, quantity } : item
    );
    saveCart(newCart);
  };

  const clearCart = () => {
    saveCart([]);
  };

  const cartTotal = cart.reduce((total, item) => {
    const price = item.product.price;
    const colorOffset = item.selectedColor?.priceOffset || 0;
    const sizeOffset = item.selectedSize?.priceOffset || 0;
    return total + (price + colorOffset + sizeOffset) * item.quantity;
  }, 0);

  const cartCount = cart.reduce((count, item) => count + item.quantity, 0);

  // Wishlist Operations
  const toggleWishlist = (product: Product) => {
    const isFav = wishlist.some((item) => item.id === product.id);
    let newWishlist;
    if (isFav) {
      newWishlist = wishlist.filter((item) => item.id !== product.id);
      addToast(`Removed ${product.name} from wishlist`, 'info');
    } else {
      newWishlist = [...wishlist, product];
      addToast(`Added ${product.name} to wishlist`, 'success');
    }
    saveWishlist(newWishlist);
  };

  const isInWishlist = (productId: string) => {
    return wishlist.some((item) => item.id === productId);
  };

  // Recently Viewed
  const addToRecentlyViewed = (product: Product) => {
    const exists = recentlyViewed.some((item) => item.id === product.id);
    let newRecent = [product, ...recentlyViewed.filter((item) => item.id !== product.id)];
    newRecent = newRecent.slice(0, 6); // Keep only 6 recently viewed
    setRecentlyViewed(newRecent);
    localStorage.setItem('velora-recently-viewed', JSON.stringify(newRecent));
  };

  // Auth Operations
  const loginUser = (email: string, password: string): boolean => {
    // Highly resilient template auth simulation
    if (email && password.length >= 6) {
      const name = email.split('@')[0].replace('.', ' ');
      const formattedName = name.charAt(0).toUpperCase() + name.slice(1);
      const newUser = { name: formattedName, email, isLoggedIn: true };
      saveUserState(newUser);
      addToast(`Welcome back, ${formattedName}!`, 'success');
      return true;
    }
    addToast('Invalid credentials. Password must be at least 6 characters.', 'error');
    return false;
  };

  const registerUser = (name: string, email: string, password: string): boolean => {
    if (name && email && password.length >= 6) {
      const newUser = { name, email, isLoggedIn: true };
      saveUserState(newUser);
      addToast('Account created successfully!', 'success');
      return true;
    }
    addToast('Please fill out all fields. Password must be at least 6 characters.', 'error');
    return false;
  };

  const logoutUser = () => {
    saveUserState(null);
    addToast('Logged out successfully', 'info');
    navigateTo('home');
  };

  const forgotPassword = (email: string): boolean => {
    if (email) {
      addToast(`Reset link successfully sent to ${email}`, 'success');
      return true;
    }
    addToast('Please enter a valid email address', 'error');
    return false;
  };

  // Address Operations
  const addAddress = (addr: Omit<ShippingAddress, 'id'>) => {
    const id = `addr-${Math.random().toString(36).substring(2, 9)}`;
    const newAddr: ShippingAddress = { ...addr, id, isDefault: shippingAddresses.length === 0 ? true : addr.isDefault };
    
    let updated = [...shippingAddresses];
    if (newAddr.isDefault) {
      updated = updated.map((a) => ({ ...a, isDefault: false }));
    }
    updated.push(newAddr);
    
    setShippingAddresses(updated);
    localStorage.setItem('velora-addresses', JSON.stringify(updated));
    addToast('Address added successfully', 'success');
  };

  const updateAddress = (addr: ShippingAddress) => {
    let updated = shippingAddresses.map((a) => (a.id === addr.id ? addr : a));
    if (addr.isDefault) {
      updated = updated.map((a) => (a.id === addr.id ? a : { ...a, isDefault: false }));
    }
    setShippingAddresses(updated);
    localStorage.setItem('velora-addresses', JSON.stringify(updated));
    addToast('Address updated successfully', 'success');
  };

  const deleteAddress = (id: string) => {
    const filtered = shippingAddresses.filter((a) => a.id !== id);
    // If we deleted default, set another as default
    if (shippingAddresses.find((a) => a.id === id)?.isDefault && filtered.length > 0) {
      filtered[0].isDefault = true;
    }
    setShippingAddresses(filtered);
    localStorage.setItem('velora-addresses', JSON.stringify(filtered));
    addToast('Address removed', 'info');
  };

  const setDefaultAddress = (id: string) => {
    const updated = shippingAddresses.map((a) => ({
      ...a,
      isDefault: a.id === id,
    }));
    setShippingAddresses(updated);
    localStorage.setItem('velora-addresses', JSON.stringify(updated));
    addToast('Default address set', 'success');
  };

  // Coupon System
  const applyCoupon = (code: string): boolean => {
    const cleanedCode = code.toUpperCase().trim();
    const coupon = COUPONS.find((c) => c.code === cleanedCode);

    if (!coupon) {
      addToast('Invalid coupon code', 'error');
      return false;
    }

    if (coupon.minSpend && cartTotal < coupon.minSpend) {
      addToast(`This coupon requires a minimum spend of $${coupon.minSpend}`, 'error');
      return false;
    }

    setActiveCoupon(coupon);
    addToast(`Coupon "${cleanedCode}" applied successfully!`, 'success');
    return true;
  };

  const removeCoupon = () => {
    setActiveCoupon(null);
    addToast('Coupon removed', 'info');
  };

  // Place Order
  const placeOrder = (address: ShippingAddress, paymentMethod: string): Order | null => {
    if (cart.length === 0) {
      addToast('Your cart is empty', 'error');
      return null;
    }

    const subtotal = cartTotal;
    const shipping = subtotal > 150 ? 0 : 15;
    const tax = Number((subtotal * 0.08).toFixed(2));
    
    let discount = 0;
    if (activeCoupon) {
      if (activeCoupon.type === 'percentage') {
        discount = Number((subtotal * (activeCoupon.value / 100)).toFixed(2));
      } else {
        discount = activeCoupon.value;
      }
    }

    const total = Number((subtotal + shipping + tax - discount).toFixed(2));
    const trackingNumber = `TRACK-${paymentMethod.split(' ')[0].toUpperCase()}-${Math.floor(1000000 + Math.random() * 9000000)}`;

    const newOrder: Order = {
      id: `VEL-${Math.floor(100000 + Math.random() * 900000)}`,
      date: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
      items: cart.map((item) => ({
        productId: item.product.id,
        productName: item.product.name,
        productImage: item.product.images[0],
        price: item.product.price + (item.selectedColor?.priceOffset || 0) + (item.selectedSize?.priceOffset || 0),
        quantity: item.quantity,
        selectedColor: item.selectedColor?.name,
        selectedSize: item.selectedSize?.name,
      })),
      subtotal,
      shipping,
      tax,
      discount,
      total,
      status: 'pending',
      trackingNumber,
      trackingSteps: [
        { status: 'pending', title: 'Order Placed', description: 'We have received your order and payment verification.', date: new Date().toLocaleString('en-US', { hour: '2-digit', minute: '2-digit', month: 'short', day: 'numeric', year: 'numeric' }), completed: true, active: true },
        { status: 'processing', title: 'Quality Audited & Packaged', description: 'Item inspected under white gloves and placed in rigid wooden storage boxes.', date: 'Pending', completed: false, active: false },
        { status: 'shipped', title: 'In Transit via Express Courier', description: 'Departing local sorting facility. On its way to delivery hub.', date: 'Pending', completed: false, active: false },
        { status: 'delivered', title: 'Out for Delivery / Delivered', description: 'Unlocking white-glove courier dispatch.', date: 'Pending', completed: false, active: false }
      ],
      shippingAddress: address,
      paymentMethod,
    };

    const updatedOrders = [newOrder, ...orders];
    setOrders(updatedOrders);
    localStorage.setItem('velora-orders', JSON.stringify(updatedOrders));
    
    // Clear cart and coupons
    saveCart([]);
    setActiveCoupon(null);
    
    addToast('Order placed successfully!', 'success');
    return newOrder;
  };

  const trackOrder = (orderId: string): Order | undefined => {
    return orders.find((o) => o.id === orderId.toUpperCase().trim());
  };

  return (
    <AppContext.Provider
      value={{
        currentRoute,
        currentRouteParams,
        navigateTo,
        searchQuery,
        setSearchQuery,
        theme,
        toggleTheme,
        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        cartTotal,
        cartCount,
        wishlist,
        toggleWishlist,
        isInWishlist,
        recentlyViewed,
        addToRecentlyViewed,
        user,
        loginUser,
        registerUser,
        logoutUser,
        forgotPassword,
        shippingAddresses,
        addAddress,
        updateAddress,
        deleteAddress,
        setDefaultAddress,
        activeCoupon,
        applyCoupon,
        removeCoupon,
        orders,
        placeOrder,
        trackOrder,
        toasts,
        addToast,
        removeToast,
        isCartOpen,
        setCartOpen,
        isWishlistOpen,
        setWishlistOpen,
        quickViewProduct,
        setQuickViewProduct,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
