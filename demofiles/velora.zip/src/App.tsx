/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { AnnouncementBar } from './components/AnnouncementBar';
import { Footer } from './components/Footer';
import { MobileBottomNav } from './components/MobileBottomNav';
import { CartDrawer } from './components/CartDrawer';
import { QuickViewModal } from './components/QuickViewModal';
import { ToastContainer } from './components/ToastContainer';

// Import Views
import { HomeView } from './views/HomeView';
import { ShopView } from './views/ShopView';
import { ProductDetailView } from './views/ProductDetailView';
import { CartView } from './views/CartView';
import { WishlistView } from './views/WishlistView';
import { CheckoutView } from './views/CheckoutView';
import { MyAccountView } from './views/MyAccountView';
import { LoginView, RegisterView, ForgotPasswordView } from './views/AuthViews';
import { AboutView, ContactView, FAQView, LegalView, BlogView, BlogDetailsView } from './views/StaticViews';

const AppContent: React.FC = () => {
  const { currentRoute } = useApp();

  // Render current active view based on global hash state
  const renderView = () => {
    switch (currentRoute) {
      case 'home':
        return <HomeView />;
      case 'shop':
      case 'category':
        return <ShopView />;
      case 'product':
        return <ProductDetailView />;
      case 'cart':
        return <CartView />;
      case 'wishlist':
        return <WishlistView />;
      case 'checkout':
        return <CheckoutView />;
      case 'my-account':
        return <MyAccountView />;
      case 'login':
        return <LoginView />;
      case 'register':
        return <RegisterView />;
      case 'forgot-password':
        return <ForgotPasswordView />;
      case 'about':
        return <AboutView />;
      case 'contact':
        return <ContactView />;
      case 'faq':
        return <FAQView />;
      case 'shipping':
      case 'returns':
      case 'privacy':
      case 'terms':
        return <LegalView />;
      case 'blog':
        return <BlogView />;
      case 'blog-details':
        return <BlogDetailsView />;
      default:
        return <HomeView />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F9F9FB] dark:bg-[#0E0E10] text-neutral-850 dark:text-neutral-200 transition-colors duration-300">
      
      {/* Dynamic top promo announcements */}
      <AnnouncementBar />

      {/* Main sticky glass header */}
      <Header />

      {/* Primary responsive view stage */}
      <main className="flex-grow">
        {renderView()}
      </main>

      {/* Detailed footer with links and social references */}
      <Footer />

      {/* Mobile devices quick nav panel */}
      <MobileBottomNav />

      {/* Dynamic side drawers and modals overlay triggers */}
      <CartDrawer />
      <QuickViewModal />
      <ToastContainer />

    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
