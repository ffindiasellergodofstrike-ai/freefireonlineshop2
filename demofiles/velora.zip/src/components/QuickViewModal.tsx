/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { motion, AnimatePresence } from 'motion/react';
import { X, Heart, Star, ShoppingBag, Eye } from 'lucide-react';
import { ProductVariant } from '../types';

export const QuickViewModal: React.FC = () => {
  const {
    quickViewProduct,
    setQuickViewProduct,
    addToCart,
    toggleWishlist,
    isInWishlist,
    navigateTo,
  } = useApp();

  const [activeImage, setActiveImage] = useState('');
  const [selectedColor, setSelectedColor] = useState<ProductVariant | undefined>(undefined);
  const [selectedSize, setSelectedSize] = useState<ProductVariant | undefined>(undefined);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    if (quickViewProduct) {
      setActiveImage(quickViewProduct.images[0]);
      
      const colors = quickViewProduct.variants.filter((v) => v.type === 'color');
      const sizes = quickViewProduct.variants.filter((v) => v.type === 'size');
      
      setSelectedColor(colors.length > 0 ? colors[0] : undefined);
      setSelectedSize(sizes.length > 0 ? sizes[0] : undefined);
      setQuantity(1);
    }
  }, [quickViewProduct]);

  if (!quickViewProduct) return null;

  const colors = quickViewProduct.variants.filter((v) => v.type === 'color');
  const sizes = quickViewProduct.variants.filter((v) => v.type === 'size');

  const getPrice = () => {
    let p = quickViewProduct.price;
    if (selectedColor?.priceOffset) p += selectedColor.priceOffset;
    if (selectedSize?.priceOffset) p += selectedSize.priceOffset;
    return p;
  };

  const handleAddToCart = () => {
    addToCart(quickViewProduct, quantity, selectedColor, selectedSize);
  };

  const handleBuyNow = () => {
    addToCart(quickViewProduct, quantity, selectedColor, selectedSize);
    setQuickViewProduct(null);
    navigateTo('checkout');
  };

  return (
    <AnimatePresence>
      <div id="quick-view-overlay" className="fixed inset-0 z-50 overflow-y-auto pointer-events-auto flex items-center justify-center p-4 sm:p-6 lg:p-8">
        
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => setQuickViewProduct(null)}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm"
        />

        {/* Modal Panel */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ type: 'spring', damping: 25, stiffness: 220 }}
          className="relative bg-white dark:bg-[#121214] border border-neutral-100 dark:border-neutral-900 rounded-2xl max-w-4xl w-full shadow-2xl overflow-hidden z-10 grid grid-cols-1 md:grid-cols-2"
        >
          {/* Close button */}
          <button
            onClick={() => setQuickViewProduct(null)}
            className="absolute top-4 right-4 z-20 p-2 bg-white/80 dark:bg-neutral-900/80 backdrop-blur-md rounded-full border border-neutral-200/40 dark:border-neutral-800 text-neutral-400 hover:text-neutral-600 dark:hover:text-white transition cursor-pointer"
            aria-label="Close Modal"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Left: Images Column */}
          <div className="p-6 bg-neutral-50 dark:bg-[#1A1A1E]/30 flex flex-col justify-center border-b md:border-b-0 md:border-r border-neutral-100 dark:border-neutral-900">
            <div className="aspect-[3/4] relative w-full overflow-hidden rounded-xl bg-white dark:bg-neutral-900 border border-neutral-200/50 dark:border-neutral-800/50">
              <img
                src={activeImage}
                alt={quickViewProduct.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              {quickViewProduct.discountBadge && (
                <span className="absolute top-3 left-3 bg-[#C19A6B] text-white text-[10px] font-bold tracking-widest uppercase px-2.5 py-1 rounded-full">
                  {quickViewProduct.discountBadge}
                </span>
              )}
            </div>

            {/* Micro Gallery Thumbnails */}
            {quickViewProduct.images.length > 1 && (
              <div className="flex gap-2.5 mt-4 overflow-x-auto py-1">
                {quickViewProduct.images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImage(img)}
                    className={`w-14 h-16 rounded-md overflow-hidden border transition shrink-0 cursor-pointer ${
                      activeImage === img
                        ? 'border-[#C19A6B] ring-2 ring-[#C19A6B]/15'
                        : 'border-neutral-200 dark:border-neutral-800 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="Thumbnail" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right: Info Column */}
          <div className="p-6 sm:p-8 flex flex-col justify-between overflow-y-auto max-h-[85vh] md:max-h-[750px]">
            <div>
              <div className="flex items-center gap-1.5 text-[10px] tracking-widest font-bold text-[#C19A6B] uppercase">
                <span>{quickViewProduct.brand}</span>
                <span>•</span>
                <span>{quickViewProduct.category}</span>
              </div>
              
              <h2 className="text-xl sm:text-2xl font-serif font-extrabold text-neutral-900 dark:text-white mt-1 leading-snug">
                {quickViewProduct.name}
              </h2>
              {quickViewProduct.tagline && (
                <p className="text-xs text-neutral-400 dark:text-neutral-500 font-light mt-0.5 italic">{quickViewProduct.tagline}</p>
              )}

              {/* Rating & Reviews */}
              <div className="flex items-center gap-2 mt-3">
                <div className="flex items-center gap-0.5">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-3.5 h-3.5 ${
                        i < Math.floor(quickViewProduct.rating)
                          ? 'fill-[#C19A6B] text-[#C19A6B]'
                          : 'text-neutral-300 dark:text-neutral-700'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-xs font-bold text-neutral-800 dark:text-neutral-200">{quickViewProduct.rating}</span>
                <span className="text-xs text-neutral-400 font-light">({quickViewProduct.reviewsCount} reviews)</span>
              </div>

              {/* Price Row */}
              <div className="flex items-baseline gap-3 mt-4">
                <span className="text-xl font-bold font-mono text-neutral-900 dark:text-white">
                  ${getPrice()}
                </span>
                {quickViewProduct.originalPrice && (
                  <span className="text-sm font-light font-mono text-neutral-400 line-through">
                    ${quickViewProduct.originalPrice}
                  </span>
                )}
              </div>

              <p className="text-xs text-neutral-500 dark:text-neutral-400 font-light mt-4 leading-relaxed">
                {quickViewProduct.description}
              </p>

              {/* Variant selections */}
              <div className="space-y-4 mt-6 pt-5 border-t border-neutral-100 dark:border-neutral-900">
                {/* Colors */}
                {colors.length > 0 && (
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block mb-2">
                      Color: <strong className="text-neutral-800 dark:text-white font-semibold">{selectedColor?.name}</strong>
                    </span>
                    <div className="flex flex-wrap gap-2.5">
                      {colors.map((col) => (
                        <button
                          key={col.id}
                          onClick={() => setSelectedColor(col)}
                          className={`w-7 h-7 rounded-full flex items-center justify-center border transition relative cursor-pointer ${
                            selectedColor?.id === col.id
                              ? 'border-[#C19A6B] ring-2 ring-[#C19A6B]/20 scale-105'
                              : 'border-neutral-200 dark:border-neutral-800 hover:scale-105'
                          }`}
                        >
                          <span
                            className="w-5 h-5 rounded-full border border-black/5 block"
                            style={{ backgroundColor: col.value }}
                          />
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Sizes */}
                {sizes.length > 0 && (
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block mb-2">
                      Size: <strong className="text-neutral-800 dark:text-white font-semibold font-mono">{selectedSize?.name}</strong>
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {sizes.map((sz) => (
                        <button
                          key={sz.id}
                          onClick={() => setSelectedSize(sz)}
                          className={`min-w-10 h-8 rounded-md text-xs font-semibold font-mono border transition flex items-center justify-center px-2 cursor-pointer ${
                            selectedSize?.id === sz.id
                              ? 'bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 border-neutral-900 dark:border-white'
                              : 'bg-white dark:bg-neutral-800 border-neutral-200 dark:border-neutral-700 text-neutral-600 dark:text-neutral-400 hover:border-neutral-400'
                          }`}
                        >
                          {sz.name}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Purchase Options Row */}
            <div className="mt-8 pt-5 border-t border-neutral-100 dark:border-neutral-900 space-y-4">
              <div className="flex items-center gap-4">
                {/* Quantity Controls */}
                <div className="flex items-center border border-neutral-200 dark:border-neutral-800 rounded-md py-2 px-3 bg-white dark:bg-neutral-900">
                  <button
                    onClick={() => setQuantity((prev) => Math.max(1, prev - 1))}
                    className="text-neutral-400 hover:text-neutral-700 dark:hover:text-white transition cursor-pointer"
                  >
                    -
                  </button>
                  <span className="text-sm font-bold font-mono w-10 text-center text-neutral-800 dark:text-white">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity((prev) => prev + 1)}
                    className="text-neutral-400 hover:text-neutral-700 dark:hover:text-white transition cursor-pointer"
                  >
                    +
                  </button>
                </div>

                <button
                  onClick={handleAddToCart}
                  className="flex-1 bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 hover:bg-neutral-850 dark:hover:bg-neutral-100 py-3 rounded-md text-xs font-bold tracking-widest uppercase transition flex items-center justify-center gap-2 cursor-pointer shadow-md"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Add To Bag</span>
                </button>

                {/* Wishlist Button */}
                <button
                  onClick={() => toggleWishlist(quickViewProduct)}
                  className={`p-3 border rounded-md transition cursor-pointer ${
                    isInWishlist(quickViewProduct.id)
                      ? 'border-red-200 bg-red-50 dark:bg-red-950/20 text-red-500'
                      : 'border-neutral-200 dark:border-neutral-800 text-neutral-400 hover:text-neutral-600'
                  }`}
                  aria-label="Add to Wishlist"
                >
                  <Heart className="w-5 h-5" />
                </button>
              </div>

              {/* Direct Purchase & Full View */}
              <div className="flex gap-2">
                <button
                  onClick={handleBuyNow}
                  className="flex-1 bg-[#C19A6B] text-white hover:bg-[#A17C52] py-2.5 rounded-md text-xs font-bold tracking-widest uppercase transition cursor-pointer"
                >
                  Buy It Now
                </button>
                <button
                  onClick={() => {
                    setQuickViewProduct(null);
                    navigateTo('product', { id: quickViewProduct.id });
                  }}
                  className="border border-neutral-200 dark:border-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-900 py-2.5 px-4 rounded-md text-xs font-semibold transition text-neutral-600 dark:text-neutral-400 flex items-center gap-1 cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Full details</span>
                </button>
              </div>
            </div>

          </div>

        </motion.div>
      </div>
    </AnimatePresence>
  );
};
