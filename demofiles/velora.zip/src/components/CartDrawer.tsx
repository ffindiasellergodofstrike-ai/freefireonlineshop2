/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { motion, AnimatePresence } from 'motion/react';
import { X, ShoppingBag, Plus, Minus, Trash2, Tag, ArrowRight } from 'lucide-react';

export const CartDrawer: React.FC = () => {
  const {
    isCartOpen,
    setCartOpen,
    cart,
    updateCartQuantity,
    removeFromCart,
    cartTotal,
    cartCount,
    activeCoupon,
    applyCoupon,
    removeCoupon,
    navigateTo,
  } = useApp();

  const [couponCode, setCouponCode] = useState('');

  const handleCouponSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (couponCode.trim()) {
      applyCoupon(couponCode);
      setCouponCode('');
    }
  };

  const getPrice = (item: typeof cart[0]) => {
    const base = item.product.price;
    const colorOffset = item.selectedColor?.priceOffset || 0;
    const sizeOffset = item.selectedSize?.priceOffset || 0;
    return base + colorOffset + sizeOffset;
  };

  const calculatedDiscount = () => {
    if (!activeCoupon) return 0;
    if (activeCoupon.type === 'percentage') {
      return Number((cartTotal * (activeCoupon.value / 100)).toFixed(2));
    }
    return activeCoupon.value;
  };

  const finalTotal = () => {
    const ship = cartTotal > 150 ? 0 : 15;
    const tax = Number((cartTotal * 0.08).toFixed(2));
    return Number((cartTotal + ship + tax - calculatedDiscount()).toFixed(2));
  };

  return (
    <AnimatePresence>
      {isCartOpen && (
        <div id="cart-drawer-overlay" className="fixed inset-0 z-50 overflow-hidden pointer-events-auto">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setCartOpen(false)}
            className="absolute inset-0 bg-black/40 backdrop-blur-sm"
          />

          {/* Drawer Container */}
          <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 220 }}
              className="w-screen max-w-md bg-white dark:bg-[#121214] flex flex-col shadow-2xl h-full border-l border-neutral-100 dark:border-neutral-900"
            >
              {/* Header */}
              <div className="px-6 py-5 border-b border-neutral-100 dark:border-neutral-900 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-[#C19A6B]" />
                  <h3 className="text-base font-bold tracking-widest uppercase text-neutral-900 dark:text-white">
                    Shopping Bag
                  </h3>
                  <span className="text-xs text-neutral-400 font-light font-mono">
                    ({cartCount})
                  </span>
                </div>
                <button
                  onClick={() => setCartOpen(false)}
                  className="p-1 rounded-full text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200 hover:bg-neutral-50 dark:hover:bg-neutral-800 transition cursor-pointer"
                  aria-label="Close Cart"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Cart List */}
              <div className="flex-1 overflow-y-auto px-6 py-4 space-y-5">
                {cart.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center px-4">
                    <div className="p-4 bg-neutral-50 dark:bg-neutral-800/40 rounded-full text-neutral-400 mb-4 border border-neutral-100 dark:border-neutral-800">
                      <ShoppingBag className="w-8 h-8" />
                    </div>
                    <h4 className="text-sm font-semibold text-neutral-800 dark:text-neutral-200">Your bag is empty</h4>
                    <p className="text-xs text-neutral-400 dark:text-neutral-500 font-light max-w-xs mt-1.5 leading-relaxed">
                      Explore our handcrafted contemporary tailored wardrobe items, precision automatic watches and organic skincare.
                    </p>
                    <button
                      onClick={() => {
                        setCartOpen(false);
                        navigateTo('shop');
                      }}
                      className="mt-6 text-xs font-semibold text-[#C19A6B] hover:text-[#A17C52] tracking-wider uppercase flex items-center gap-1"
                    >
                      Browse Boutique &rarr;
                    </button>
                  </div>
                ) : (
                  cart.map((item) => (
                    <motion.div
                      key={item.id}
                      layout
                      className="flex gap-4 p-3 bg-neutral-50 dark:bg-neutral-800/40 rounded-xl border border-neutral-100 dark:border-neutral-800/40 relative group"
                    >
                      <img
                        src={item.product.images[0]}
                        alt={item.product.name}
                        referrerPolicy="no-referrer"
                        className="w-20 h-24 object-cover rounded-lg shrink-0 border border-neutral-200/50 dark:border-neutral-700/50"
                      />
                      <div className="flex-1 flex flex-col justify-between min-w-0">
                        <div>
                          <div className="flex justify-between items-start gap-2">
                            <h4 className="text-xs font-bold text-neutral-800 dark:text-neutral-100 truncate group-hover:text-[#C19A6B] transition-colors">
                              {item.product.name}
                            </h4>
                            <span className="text-xs font-bold text-neutral-900 dark:text-white font-mono">
                              ${getPrice(item) * item.quantity}
                            </span>
                          </div>
                          <p className="text-[10px] text-[#C19A6B] uppercase tracking-wider font-light mt-0.5">
                            {item.product.brand}
                          </p>
                          
                          {/* Selected Variants */}
                          <div className="flex flex-wrap gap-1.5 mt-2">
                            {item.selectedColor && (
                              <span className="inline-flex items-center gap-1 text-[10px] bg-white dark:bg-neutral-800 border border-neutral-200/80 dark:border-neutral-700 py-0.5 px-2 rounded-full text-neutral-500 dark:text-neutral-400 font-medium">
                                <span
                                  className="w-2 h-2 rounded-full border border-black/10 shrink-0"
                                  style={{ backgroundColor: item.selectedColor.value }}
                                />
                                {item.selectedColor.name}
                              </span>
                            )}
                            {item.selectedSize && (
                              <span className="inline-flex items-center text-[10px] bg-white dark:bg-neutral-800 border border-neutral-200/80 dark:border-neutral-700 py-0.5 px-2 rounded-full text-neutral-500 dark:text-neutral-400 font-semibold font-mono">
                                Size: {item.selectedSize.name}
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Controls */}
                        <div className="flex items-center justify-between mt-3">
                          <div className="flex items-center bg-white dark:bg-neutral-900 border border-neutral-200/80 dark:border-neutral-800 rounded-md py-0.5 px-1.5">
                            <button
                              onClick={() => updateCartQuantity(item.id, item.quantity - 1)}
                              className="text-neutral-400 hover:text-neutral-700 dark:hover:text-white p-1 cursor-pointer"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="text-xs font-mono font-bold w-6 text-center text-neutral-800 dark:text-white">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => updateCartQuantity(item.id, item.quantity + 1)}
                              className="text-neutral-400 hover:text-neutral-700 dark:hover:text-white p-1 cursor-pointer"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>

                          <button
                            onClick={() => removeFromCart(item.id)}
                            className="p-1.5 text-neutral-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/25 rounded-md transition cursor-pointer"
                            aria-label="Remove Item"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  ))
                )}
              </div>

              {/* Cart Footer Summaries & Checkout */}
              {cart.length > 0 && (
                <div className="px-6 py-5 border-t border-neutral-100 dark:border-neutral-900 bg-neutral-50/40 dark:bg-[#1A1A1E]/30 space-y-4 shrink-0">
                  
                  {/* Coupon Block */}
                  <div className="pt-1.5 pb-2">
                    {activeCoupon ? (
                      <div className="flex items-center justify-between bg-[#C19A6B]/10 dark:bg-[#C19A6B]/5 border border-[#C19A6B]/25 py-2 px-3 rounded-md">
                        <div className="flex items-center gap-1.5 text-xs font-medium text-[#C19A6B]">
                          <Tag className="w-3.5 h-3.5" />
                          <span>Code Applied: <strong>{activeCoupon.code}</strong></span>
                        </div>
                        <button onClick={removeCoupon} className="text-neutral-400 hover:text-neutral-600 text-xs font-bold cursor-pointer">
                          Remove
                        </button>
                      </div>
                    ) : (
                      <form onSubmit={handleCouponSubmit} className="flex gap-2">
                        <input
                          type="text"
                          placeholder="Promo code (e.g., VELORA10)..."
                          value={couponCode}
                          onChange={(e) => setCouponCode(e.target.value)}
                          className="flex-1 bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white"
                        />
                        <button
                          type="submit"
                          className="bg-neutral-800 hover:bg-neutral-900 dark:bg-neutral-700 dark:hover:bg-neutral-650 text-white text-xs px-4 py-2 rounded-md font-semibold transition tracking-wider uppercase cursor-pointer"
                        >
                          Apply
                        </button>
                      </form>
                    )}
                  </div>

                  {/* Calculations Grid */}
                  <div className="space-y-2.5 text-xs text-neutral-500 dark:text-neutral-400">
                    <div className="flex justify-between">
                      <span className="font-light">Bag Subtotal</span>
                      <span className="font-mono font-semibold text-neutral-850 dark:text-neutral-100">${cartTotal}</span>
                    </div>
                    {activeCoupon && (
                      <div className="flex justify-between text-emerald-600 dark:text-emerald-450">
                        <span className="font-medium">Promo Discount ({activeCoupon.value}{activeCoupon.type === 'percentage' ? '%' : '$'})</span>
                        <span className="font-mono font-semibold">-${calculatedDiscount()}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="font-light">Tax (8%)</span>
                      <span className="font-mono font-semibold text-neutral-850 dark:text-neutral-100">${(cartTotal * 0.08).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-light">Luxury Courier Dispatch</span>
                      {cartTotal > 150 ? (
                        <span className="text-[10px] tracking-widest text-[#C19A6B] uppercase font-bold">Complimentary</span>
                      ) : (
                        <span className="font-mono font-semibold text-neutral-850 dark:text-neutral-100">$15</span>
                      )}
                    </div>
                    
                    <hr className="border-neutral-200 dark:border-neutral-800 my-1" />

                    <div className="flex justify-between text-sm">
                      <span className="font-semibold text-neutral-850 dark:text-neutral-100">Estimated Total</span>
                      <span className="font-mono font-bold text-neutral-900 dark:text-white text-base">${finalTotal()}</span>
                    </div>
                  </div>

                  {/* Checkout buttons */}
                  <div className="pt-2 flex flex-col gap-2">
                    <button
                      onClick={() => {
                        setCartOpen(false);
                        navigateTo('checkout');
                      }}
                      className="w-full bg-[#121214] dark:bg-white text-white dark:text-[#121214] hover:bg-neutral-850 dark:hover:bg-neutral-100 text-xs py-3.5 px-4 rounded-md font-bold transition tracking-widest uppercase flex items-center justify-center gap-2 group cursor-pointer shadow-md"
                    >
                      <span>Proceed to Checkout</span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </button>
                    <button
                      onClick={() => setCartOpen(false)}
                      className="w-full bg-transparent text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200 text-xs py-2 text-center transition font-semibold"
                    >
                      Continue Shopping
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        </div>
      )}
    </AnimatePresence>
  );
};
