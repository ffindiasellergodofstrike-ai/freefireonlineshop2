/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, X, ChevronRight } from 'lucide-react';
import { useApp } from '../context/AppContext';

const ANNOUNCEMENTS = [
  { text: 'Complimentary white-glove express shipping on orders over $150', actionText: 'Learn More', route: 'shipping' },
  { text: 'Unveiling the Vanguard Automatics: Horology at its finest', actionText: 'Explore', route: 'category', params: { id: 'watches' } },
  { text: 'New Season Drop: Tailored luxury staples are now live', actionText: 'Shop New', route: 'shop' }
];

export const AnnouncementBar: React.FC = () => {
  const { navigateTo } = useApp();
  const [index, setIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    if (!isVisible) return;
    const interval = setInterval(() => {
      setIndex((prev) => (prev + 1) % ANNOUNCEMENTS.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [isVisible]);

  if (!isVisible) return null;

  const current = ANNOUNCEMENTS[index];

  return (
    <div id="announcement-bar" className="bg-[#121214] text-white py-2 px-4 relative z-50 text-xs sm:text-sm border-b border-white/5 font-light tracking-wide flex items-center justify-between">
      <div className="flex-1 flex justify-center items-center">
        <AnimatePresence mode="wait">
          <motion.div
            key={index}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            transition={{ duration: 0.4, ease: 'easeInOut' }}
            className="flex items-center gap-2 flex-wrap justify-center text-center text-[11px] sm:text-xs"
          >
            <Sparkles className="w-3 h-3 text-[#E5D3B3] animate-pulse" />
            <span>{current.text}</span>
            <button
              onClick={() => navigateTo(current.route, current.params || {})}
              className="text-[#E5D3B3] underline font-medium hover:text-white transition duration-200 ml-1 inline-flex items-center cursor-pointer"
            >
              {current.actionText}
              <ChevronRight className="w-3 h-3" />
            </button>
          </motion.div>
        </AnimatePresence>
      </div>
      <button
        onClick={() => setIsVisible(false)}
        className="text-white/60 hover:text-white transition p-1 cursor-pointer"
        aria-label="Close Announcement"
      >
        <X className="w-3 h-3" />
      </button>
    </div>
  );
};
