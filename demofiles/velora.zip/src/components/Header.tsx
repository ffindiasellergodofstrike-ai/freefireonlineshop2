/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CATEGORIES } from '../data/mockData';
import {
  Search,
  Heart,
  ShoppingBag,
  User as UserIcon,
  Sun,
  Moon,
  Menu,
  X,
  ChevronDown,
  LogOut,
  Settings,
  Package,
  MapPin,
  HelpCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const Header: React.FC = () => {
  const {
    currentRoute,
    navigateTo,
    theme,
    toggleTheme,
    cartCount,
    wishlist,
    user,
    logoutUser,
    setCartOpen,
    setWishlistOpen,
    searchQuery,
    setSearchQuery,
  } = useApp();

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchExpanded, setIsSearchExpanded] = useState(false);
  const [isMegaMenuOpen, setIsMegaMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigateTo('shop');
      setIsSearchExpanded(false);
    }
  };

  const menuItems = [
    { name: 'Home', route: 'home' },
    { name: 'Shop All', route: 'shop' },
  ];

  return (
    <header id="main-header" className="sticky top-0 z-40 w-full border-b border-neutral-100 dark:border-neutral-800 bg-white/80 dark:bg-[#121214]/80 backdrop-blur-md transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          
          {/* Mobile Menu Trigger */}
          <div className="flex md:hidden">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-neutral-700 dark:text-neutral-300 hover:text-[#C19A6B] p-2"
              aria-label="Toggle Menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Logo / Brand */}
          <div className="flex-1 md:flex-none flex justify-center md:justify-start">
            <button
              onClick={() => navigateTo('home')}
              className="text-2xl sm:text-3xl font-extrabold tracking-[0.18em] text-[#121214] dark:text-white font-serif focus:outline-none cursor-pointer"
            >
              VELORA
            </button>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8 text-[13px] tracking-widest uppercase font-medium">
            {menuItems.map((item) => (
              <button
                key={item.name}
                onClick={() => navigateTo(item.route)}
                className={`transition-colors duration-200 py-2 cursor-pointer ${
                  currentRoute === item.route
                    ? 'text-[#C19A6B]'
                    : 'text-neutral-600 dark:text-neutral-300 hover:text-[#C19A6B]'
                }`}
              >
                {item.name}
              </button>
            ))}

            {/* Categories Dropdown/Mega Menu */}
            <div
              className="relative"
              onMouseEnter={() => setIsMegaMenuOpen(true)}
              onMouseLeave={() => setIsMegaMenuOpen(false)}
            >
              <button
                className="flex items-center gap-1 text-neutral-600 dark:text-neutral-300 hover:text-[#C19A6B] py-2 transition-colors cursor-pointer"
                onClick={() => navigateTo('shop')}
              >
                <span>Categories</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </button>

              <AnimatePresence>
                {isMegaMenuOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    transition={{ duration: 0.2 }}
                    className="absolute left-1/2 -translate-x-1/2 mt-1 w-[600px] bg-white dark:bg-[#1A1A1E] border border-neutral-100 dark:border-neutral-800 rounded-lg shadow-xl p-6 grid grid-cols-3 gap-6"
                  >
                    <div className="col-span-2 grid grid-cols-2 gap-4">
                      {CATEGORIES.map((cat) => (
                        <button
                          key={cat.id}
                          onClick={() => {
                            navigateTo('category', { id: cat.id });
                            setIsMegaMenuOpen(false);
                          }}
                          className="flex flex-col text-left p-2 rounded-md hover:bg-neutral-50 dark:hover:bg-neutral-800/50 transition group"
                        >
                          <span className="text-sm font-semibold text-neutral-800 dark:text-white group-hover:text-[#C19A6B] transition-colors">
                            {cat.name}
                          </span>
                          <span className="text-[11px] text-neutral-400 dark:text-neutral-500 font-light mt-0.5 line-clamp-1">
                            {cat.description}
                          </span>
                        </button>
                      ))}
                    </div>
                    <div className="bg-neutral-50 dark:bg-neutral-800/40 rounded-lg p-4 flex flex-col justify-between border border-neutral-100 dark:border-neutral-800">
                      <div>
                        <span className="text-[10px] font-bold tracking-wider text-[#C19A6B] uppercase block">Featured Season</span>
                        <h4 className="text-sm font-semibold text-neutral-800 dark:text-white mt-1 leading-snug">The Wool Tailoring Collection</h4>
                        <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-2 font-light">Italian-crafted trench coats and fluid slip silhouettes designed for the contemporary lifestyle.</p>
                      </div>
                      <button
                        onClick={() => {
                          navigateTo('shop');
                          setIsMegaMenuOpen(false);
                        }}
                        className="text-xs font-semibold text-[#C19A6B] hover:text-[#A17C52] transition flex items-center gap-1 mt-4 cursor-pointer text-left uppercase tracking-wider"
                      >
                        Explore Lookbook &rarr;
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            <button
              onClick={() => navigateTo('blog')}
              className={`transition-colors duration-200 py-2 cursor-pointer ${
                currentRoute === 'blog' || currentRoute === 'blog-details'
                  ? 'text-[#C19A6B]'
                  : 'text-neutral-600 dark:text-neutral-300 hover:text-[#C19A6B]'
              }`}
            >
              Editorial
            </button>
            <button
              onClick={() => navigateTo('about')}
              className={`transition-colors duration-200 py-2 cursor-pointer ${
                currentRoute === 'about'
                  ? 'text-[#C19A6B]'
                  : 'text-neutral-600 dark:text-neutral-300 hover:text-[#C19A6B]'
              }`}
            >
              Atelier
            </button>
          </nav>

          {/* User Controls and Action Icons */}
          <div className="flex items-center space-x-2 sm:space-x-4">
            
            {/* Search Toggle */}
            <div className="relative">
              <AnimatePresence>
                {isSearchExpanded ? (
                  <motion.form
                    initial={{ width: 0, opacity: 0 }}
                    animate={{ width: 220, opacity: 1 }}
                    exit={{ width: 0, opacity: 0 }}
                    onSubmit={handleSearchSubmit}
                    className="absolute right-0 top-1/2 -translate-y-1/2 z-10 flex items-center bg-neutral-100 dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-full py-1.5 px-3"
                  >
                    <input
                      type="text"
                      placeholder="Search bespoke design..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="bg-transparent border-none text-xs focus:ring-0 outline-none w-full text-neutral-800 dark:text-white pr-2"
                      autoFocus
                    />
                    <button type="button" onClick={() => setIsSearchExpanded(false)} className="text-neutral-400 hover:text-neutral-600">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </motion.form>
                ) : (
                  <button
                    onClick={() => setIsSearchExpanded(true)}
                    className="p-2.5 text-neutral-600 dark:text-neutral-300 hover:text-[#C19A6B] rounded-full hover:bg-neutral-50 dark:hover:bg-neutral-800/40 transition cursor-pointer"
                    aria-label="Search"
                  >
                    <Search className="w-5 h-5" />
                  </button>
                )}
              </AnimatePresence>
            </div>

            {/* Dark/Light Mode toggle */}
            <button
              onClick={toggleTheme}
              className="p-2.5 text-neutral-600 dark:text-neutral-300 hover:text-[#C19A6B] rounded-full hover:bg-neutral-50 dark:hover:bg-neutral-800/40 transition cursor-pointer"
              aria-label="Toggle Theme"
            >
              {theme === 'light' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
            </button>

            {/* Wishlist Icon */}
            <button
              onClick={() => navigateTo('wishlist')}
              className="p-2.5 text-neutral-600 dark:text-neutral-300 hover:text-[#C19A6B] rounded-full hover:bg-neutral-50 dark:hover:bg-neutral-800/40 transition relative cursor-pointer"
              aria-label="Wishlist"
            >
              <Heart className="w-5 h-5" />
              {wishlist.length > 0 && (
                <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-[#C19A6B] text-white text-[9px] font-bold rounded-full flex items-center justify-center animate-pulse">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* Cart Icon */}
            <button
              onClick={() => setCartOpen(true)}
              className="p-2.5 text-neutral-600 dark:text-neutral-300 hover:text-[#C19A6B] rounded-full hover:bg-neutral-50 dark:hover:bg-neutral-800/40 transition relative cursor-pointer"
              aria-label="Cart"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-[#121214] dark:bg-white text-white dark:text-[#121214] text-[9px] font-extrabold rounded-full flex items-center justify-center border border-white dark:border-[#121214]">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Profile Dropdown / Trigger */}
            <div className="relative">
              <button
                onClick={() => {
                  if (user?.isLoggedIn) {
                    setIsUserMenuOpen(!isUserMenuOpen);
                  } else {
                    navigateTo('login');
                  }
                }}
                className="p-2.5 text-neutral-600 dark:text-neutral-300 hover:text-[#C19A6B] rounded-full hover:bg-neutral-50 dark:hover:bg-neutral-800/40 transition flex items-center cursor-pointer"
                aria-label="User Account"
              >
                <UserIcon className="w-5 h-5" />
                {user?.isLoggedIn && (
                  <span className="hidden sm:inline text-xs font-medium ml-1.5 max-w-[80px] truncate text-neutral-700 dark:text-neutral-300">
                    {user.name.split(' ')[0]}
                  </span>
                )}
              </button>

              <AnimatePresence>
                {isUserMenuOpen && user?.isLoggedIn && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    transition={{ duration: 0.15 }}
                    onMouseLeave={() => setIsUserMenuOpen(false)}
                    className="absolute right-0 mt-2 w-56 bg-white dark:bg-[#1A1A1E] border border-neutral-100 dark:border-neutral-800 rounded-lg shadow-xl py-2 z-50 text-xs text-neutral-700 dark:text-neutral-300"
                  >
                    <div className="px-4 py-2 border-b border-neutral-100 dark:border-neutral-800">
                      <p className="font-semibold text-neutral-800 dark:text-white">{user.name}</p>
                      <p className="text-[10px] text-neutral-400 dark:text-neutral-500 font-light truncate mt-0.5">{user.email}</p>
                    </div>

                    <button
                      onClick={() => {
                        navigateTo('my-account', { tab: 'profile' });
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-4 py-2.5 hover:bg-neutral-50 dark:hover:bg-neutral-800/50 text-left transition"
                    >
                      <Settings className="w-4 h-4 text-neutral-400" />
                      <span>Profile Settings</span>
                    </button>

                    <button
                      onClick={() => {
                        navigateTo('my-account', { tab: 'orders' });
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-4 py-2.5 hover:bg-neutral-50 dark:hover:bg-neutral-800/50 text-left transition"
                    >
                      <Package className="w-4 h-4 text-neutral-400" />
                      <span>My Orders & Returns</span>
                    </button>

                    <button
                      onClick={() => {
                        navigateTo('my-account', { tab: 'addresses' });
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-4 py-2.5 hover:bg-neutral-50 dark:hover:bg-neutral-800/50 text-left transition"
                    >
                      <MapPin className="w-4 h-4 text-neutral-400" />
                      <span>Address Management</span>
                    </button>

                    <button
                      onClick={() => {
                        navigateTo('my-account', { tab: 'track' });
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-4 py-2.5 hover:bg-neutral-50 dark:hover:bg-neutral-800/50 text-left transition"
                    >
                      <HelpCircle className="w-4 h-4 text-neutral-400" />
                      <span>Track Shipment</span>
                    </button>

                    <hr className="my-1.5 border-neutral-100 dark:border-neutral-800" />

                    <button
                      onClick={() => {
                        logoutUser();
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2.5 px-4 py-2.5 hover:bg-red-50 dark:hover:bg-red-950/20 text-red-600 dark:text-red-400 text-left transition font-medium"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Sign Out</span>
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

          </div>
        </div>
      </div>

      {/* Mobile Menu Panel */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25 }}
            className="md:hidden border-t border-neutral-100 dark:border-neutral-800 bg-white dark:bg-[#121214]"
          >
            <div className="px-4 py-6 space-y-3 font-medium text-sm tracking-widest uppercase">
              <button
                onClick={() => {
                  navigateTo('home');
                  setIsMobileMenuOpen(false);
                }}
                className="block w-full text-left py-2 text-neutral-800 dark:text-white"
              >
                Home
              </button>
              <button
                onClick={() => {
                  navigateTo('shop');
                  setIsMobileMenuOpen(false);
                }}
                className="block w-full text-left py-2 text-neutral-800 dark:text-white"
              >
                Shop All
              </button>

              <div className="border-t border-neutral-100 dark:border-neutral-800 my-2 pt-2">
                <span className="text-[10px] tracking-widest font-semibold text-[#C19A6B] block mb-2 uppercase">Collections</span>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {CATEGORIES.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => {
                        navigateTo('category', { id: cat.id });
                        setIsMobileMenuOpen(false);
                      }}
                      className="block text-left py-1.5 text-neutral-600 dark:text-neutral-400 hover:text-[#C19A6B]"
                    >
                      {cat.name}
                    </button>
                  ))}
                </div>
              </div>

              <button
                onClick={() => {
                  navigateTo('blog');
                  setIsMobileMenuOpen(false);
                }}
                className="block w-full text-left py-2 text-neutral-800 dark:text-white border-t border-neutral-100 dark:border-neutral-800 pt-2"
              >
                Editorial / Blog
              </button>
              <button
                onClick={() => {
                  navigateTo('about');
                  setIsMobileMenuOpen(false);
                }}
                className="block w-full text-left py-2 text-neutral-800 dark:text-white"
              >
                Atelier (About)
              </button>
              <button
                onClick={() => {
                  navigateTo('contact');
                  setIsMobileMenuOpen(false);
                }}
                className="block w-full text-left py-2 text-neutral-800 dark:text-white"
              >
                Contact
              </button>

              {user?.isLoggedIn ? (
                <div className="border-t border-neutral-100 dark:border-neutral-800 my-2 pt-4 flex items-center justify-between">
                  <div>
                    <p className="text-xs font-semibold text-neutral-800 dark:text-white">{user.name}</p>
                    <button
                      onClick={() => {
                        navigateTo('my-account');
                        setIsMobileMenuOpen(false);
                      }}
                      className="text-[11px] text-[#C19A6B] font-light mt-0.5"
                    >
                      Go to Account Panel &rarr;
                    </button>
                  </div>
                  <button
                    onClick={() => {
                      logoutUser();
                      setIsMobileMenuOpen(false);
                    }}
                    className="p-2 text-red-500 rounded-full hover:bg-red-50 dark:hover:bg-red-950/20"
                    aria-label="Logout"
                  >
                    <LogOut className="w-5 h-5" />
                  </button>
                </div>
              ) : (
                <div className="border-t border-neutral-100 dark:border-neutral-800 pt-4 flex gap-3">
                  <button
                    onClick={() => {
                      navigateTo('login');
                      setIsMobileMenuOpen(false);
                    }}
                    className="flex-1 text-center py-2 border border-neutral-200 dark:border-neutral-700 text-neutral-700 dark:text-neutral-300 rounded-md text-xs font-semibold"
                  >
                    Sign In
                  </button>
                  <button
                    onClick={() => {
                      navigateTo('register');
                      setIsMobileMenuOpen(false);
                    }}
                    className="flex-1 text-center py-2 bg-[#121214] dark:bg-white text-white dark:text-[#121214] rounded-md text-xs font-semibold"
                  >
                    Register
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};
