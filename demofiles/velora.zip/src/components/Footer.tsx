/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Mail, Globe, ArrowRight, ShieldCheck, Truck, RefreshCw } from 'lucide-react';

export const Footer: React.FC = () => {
  const { navigateTo, addToast } = useApp();
  const [email, setEmail] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      addToast(`Subscribed! Exclusive seasonal newsletters sent to ${email}`, 'success');
      setEmail('');
    }
  };

  const categories = [
    { name: 'Fashion & Tailoring', id: 'fashion' },
    { name: 'Aero Sneakers', id: 'sneakers' },
    { name: 'Bespoke Horology', id: 'watches' },
    { name: 'Fine Accessories', id: 'accessories' },
    { name: 'Advanced Skincare', id: 'beauty' },
    { name: 'Ceramics & Decor', id: 'home' },
  ];

  const clientLinks = [
    { name: 'Frequently Asked Questions', route: 'faq' },
    { name: 'Shipping & White-Glove Dispatch', route: 'shipping' },
    { name: 'Returns & Exchange Policy', route: 'returns' },
    { name: 'Atelier Story (About)', route: 'about' },
    { name: 'Contact Our Conciege', route: 'contact' },
  ];

  const legalLinks = [
    { name: 'Privacy Policy', route: 'privacy' },
    { name: 'Terms of Use', route: 'terms' },
  ];

  return (
    <footer id="main-footer" className="bg-[#FAF9F6] dark:bg-[#0D0D0F] border-t border-neutral-100 dark:border-neutral-900 pt-16 pb-24 md:pb-16 transition-colors duration-300">
      
      {/* Brand Values Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12 border-b border-neutral-200/60 dark:border-neutral-800/60">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="flex gap-4 items-start p-4 rounded-xl hover:bg-white dark:hover:bg-neutral-850/20 transition duration-300">
            <div className="p-3 bg-white dark:bg-neutral-900 rounded-lg text-[#C19A6B] shadow-sm">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-neutral-850 dark:text-neutral-100">100% Authenticity Guaranteed</h4>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1.5 font-light leading-relaxed">Directly sourced luxury pieces carrying full certified brand credentials and dual-level inspection.</p>
            </div>
          </div>

          <div className="flex gap-4 items-start p-4 rounded-xl hover:bg-white dark:hover:bg-neutral-850/20 transition duration-300">
            <div className="p-3 bg-white dark:bg-neutral-900 rounded-lg text-[#C19A6B] shadow-sm">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-neutral-850 dark:text-neutral-100">Complementary White-Glove Shipping</h4>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1.5 font-light leading-relaxed">Complimentary climate-controlled premium express dispatch worldwide on all orders exceeding $150.</p>
            </div>
          </div>

          <div className="flex gap-4 items-start p-4 rounded-xl hover:bg-white dark:hover:bg-neutral-850/20 transition duration-300">
            <div className="p-3 bg-white dark:bg-neutral-900 rounded-lg text-[#C19A6B] shadow-sm">
              <RefreshCw className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-neutral-850 dark:text-neutral-100">Complimentary 30-Day Returns</h4>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1.5 font-light leading-relaxed">Sealable, unused items may be returned seamlessly with pre-paid high-priority shipping envelopes.</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
        
        {/* Brand Information */}
        <div className="space-y-6">
          <button
            onClick={() => navigateTo('home')}
            className="text-3xl font-extrabold tracking-[0.18em] text-[#121214] dark:text-white font-serif focus:outline-none"
          >
            VELORA
          </button>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 font-light leading-relaxed">
            Curating luxury contemporary wardrobes, precision electronic devices, exquisite mechanical horology, and cold-pressed botanical skin wellness since 2018. Designed for high-end lifestyle enthusiasts.
          </p>
          <div className="flex items-center gap-3 text-neutral-400 dark:text-neutral-500">
            <Globe className="w-4 h-4" />
            <span className="text-[11px] tracking-widest uppercase font-semibold">Worldwide Atelier Operations</span>
          </div>
        </div>

        {/* Categories Links */}
        <div>
          <h5 className="text-[11px] font-bold tracking-widest text-[#C19A6B] uppercase mb-6">Collections</h5>
          <ul className="space-y-3.5 text-xs">
            {categories.map((cat) => (
              <li key={cat.id}>
                <button
                  onClick={() => navigateTo('category', { id: cat.id })}
                  className="text-neutral-500 dark:text-neutral-400 hover:text-[#C19A6B] dark:hover:text-[#E5D3B3] transition-colors cursor-pointer"
                >
                  {cat.name}
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* Concierge/Client Services Links */}
        <div>
          <h5 className="text-[11px] font-bold tracking-widest text-[#C19A6B] uppercase mb-6">Concierge & Care</h5>
          <ul className="space-y-3.5 text-xs">
            {clientLinks.map((link) => (
              <li key={link.name}>
                <button
                  onClick={() => navigateTo(link.route)}
                  className="text-neutral-500 dark:text-neutral-400 hover:text-[#C19A6B] dark:hover:text-[#E5D3B3] transition-colors cursor-pointer text-left"
                >
                  {link.name}
                </button>
              </li>
            ))}
          </ul>
        </div>

        {/* Newsletter Subscription */}
        <div className="space-y-4">
          <h5 className="text-[11px] font-bold tracking-widest text-[#C19A6B] uppercase">Seasonal Newsletters</h5>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 font-light leading-relaxed">
            Subscribe to lock in early access to bespoke seasonal collections, private drop lookbooks, and private discount offers.
          </p>
          <form onSubmit={handleSubscribe} className="flex flex-col gap-2">
            <div className="relative flex items-center bg-white dark:bg-[#1A1A1E] border border-neutral-200 dark:border-neutral-800 rounded-md focus-within:border-[#C19A6B] transition">
              <Mail className="w-4 h-4 text-neutral-400 ml-3 shrink-0" />
              <input
                type="email"
                placeholder="Enter email address..."
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-transparent border-none text-xs focus:ring-0 outline-none w-full py-3 px-3 text-neutral-800 dark:text-white"
                required
              />
              <button
                type="submit"
                className="bg-[#121214] hover:bg-neutral-800 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-[#121214] p-2.5 rounded-r-md transition shrink-0 cursor-pointer"
                aria-label="Subscribe"
              >
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>
        </div>

      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16 pt-8 border-t border-neutral-200/50 dark:border-neutral-800/50 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-neutral-400 dark:text-neutral-500">
        <div>
          &copy; {new Date().getFullYear()} Velora Inc. All Rights Reserved. Designed for Luxury Retail.
        </div>
        <div className="flex gap-4">
          {legalLinks.map((link) => (
            <button
              key={link.name}
              onClick={() => navigateTo(link.route)}
              className="hover:text-neutral-600 dark:hover:text-neutral-300 transition-colors"
            >
              {link.name}
            </button>
          ))}
        </div>
      </div>
    </footer>
  );
};
