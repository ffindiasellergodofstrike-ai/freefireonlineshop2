/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useApp } from '../context/AppContext';
import { Home, ShoppingBag, Heart, User, Sparkles } from 'lucide-react';

export const MobileBottomNav: React.FC = () => {
  const { currentRoute, navigateTo, cartCount, wishlist, user } = useApp();

  return (
    <nav
      id="mobile-bottom-nav"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-[#121214]/95 backdrop-blur-md border-t border-neutral-100 dark:border-neutral-800 px-2 py-2.5 flex justify-around items-center shadow-[0_-4px_12px_rgba(0,0,0,0.03)] transition-colors"
    >
      <button
        onClick={() => navigateTo('home')}
        className={`flex flex-col items-center gap-1.5 focus:outline-none py-1 px-3 rounded-xl transition ${
          currentRoute === 'home' ? 'text-[#C19A6B]' : 'text-neutral-400 dark:text-neutral-500 hover:text-neutral-600'
        }`}
      >
        <Home className="w-5 h-5" />
        <span className="text-[10px] tracking-wider font-medium uppercase">Home</span>
      </button>

      <button
        onClick={() => navigateTo('shop')}
        className={`flex flex-col items-center gap-1.5 focus:outline-none py-1 px-3 rounded-xl transition ${
          currentRoute === 'shop' ? 'text-[#C19A6B]' : 'text-neutral-400 dark:text-neutral-500 hover:text-neutral-600'
        }`}
      >
        <Sparkles className="w-5 h-5" />
        <span className="text-[10px] tracking-wider font-medium uppercase">Shop</span>
      </button>

      <button
        onClick={() => navigateTo('wishlist')}
        className={`flex flex-col items-center gap-1.5 focus:outline-none py-1 px-3 rounded-xl transition relative ${
          currentRoute === 'wishlist' ? 'text-[#C19A6B]' : 'text-neutral-400 dark:text-neutral-500 hover:text-neutral-600'
        }`}
      >
        <Heart className="w-5 h-5" />
        {wishlist.length > 0 && (
          <span className="absolute top-0 right-3 w-4 h-4 bg-[#C19A6B] text-white text-[9px] font-bold rounded-full flex items-center justify-center animate-pulse">
            {wishlist.length}
          </span>
        )}
        <span className="text-[10px] tracking-wider font-medium uppercase">Wishlist</span>
      </button>

      <button
        onClick={() => navigateTo('cart')}
        className={`flex flex-col items-center gap-1.5 focus:outline-none py-1 px-3 rounded-xl transition relative ${
          currentRoute === 'cart' ? 'text-[#C19A6B]' : 'text-neutral-400 dark:text-neutral-500 hover:text-neutral-600'
        }`}
      >
        <ShoppingBag className="w-5 h-5" />
        {cartCount > 0 && (
          <span className="absolute top-0 right-3 w-4 h-4 bg-[#121214] dark:bg-white text-white dark:text-[#121214] text-[9px] font-bold rounded-full flex items-center justify-center border border-white dark:border-[#121214]">
            {cartCount}
          </span>
        )}
        <span className="text-[10px] tracking-wider font-medium uppercase">Cart</span>
      </button>

      <button
        onClick={() => {
          if (user?.isLoggedIn) {
            navigateTo('my-account');
          } else {
            navigateTo('login');
          }
        }}
        className={`flex flex-col items-center gap-1.5 focus:outline-none py-1 px-3 rounded-xl transition ${
          currentRoute === 'my-account' || currentRoute === 'login' || currentRoute === 'register'
            ? 'text-[#C19A6B]'
            : 'text-neutral-400 dark:text-neutral-500 hover:text-neutral-600'
        }`}
      >
        <User className="w-5 h-5" />
        <span className="text-[10px] tracking-wider font-medium uppercase">Account</span>
      </button>
    </nav>
  );
};
