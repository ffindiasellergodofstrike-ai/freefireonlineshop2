/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Product, Category, BlogPost, Coupon, ShippingAddress, Order, Review } from '../types';

export const CATEGORIES: Category[] = [
  {
    id: 'fashion',
    name: 'Fashion',
    description: 'Elevated staples and high-end contemporary tailoring designed for the modern wardrobe.',
    image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&q=80&w=800',
    count: 24,
  },
  {
    id: 'sneakers',
    name: 'Sneakers',
    description: 'Limited editions, high-performance athletic wear, and classic casual street silhouettes.',
    image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&q=80&w=800',
    count: 18,
  },
  {
    id: 'electronics',
    name: 'Electronics',
    description: 'Cutting-edge technology and pristine audio engineering to empower your daily workflow.',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&q=80&w=800',
    count: 12,
  },
  {
    id: 'watches',
    name: 'Watches',
    description: 'Exquisite horology, precision automatic movements, and timeless craftsmanship.',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=800',
    count: 15,
  },
  {
    id: 'accessories',
    name: 'Accessories',
    description: 'Finely crafted leather goods, premium travel gear, and everyday luxury essentials.',
    image: 'https://images.unsplash.com/photo-1524498250077-390f9e378db0?auto=format&fit=crop&q=80&w=800',
    count: 32,
  },
  {
    id: 'beauty',
    name: 'Beauty & Skincare',
    description: 'Clean formulations, active botanicals, and scientific skin wellness for radiant health.',
    image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&q=80&w=800',
    count: 20,
  },
  {
    id: 'home',
    name: 'Home & Lifestyle',
    description: 'Minimalist decor, organic linen, and custom ceramics to curate a serene living space.',
    image: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&q=80&w=800',
    count: 16,
  },
];

export const PRODUCTS: Product[] = [
  // FASHION
  {
    id: 'fashion-1',
    name: 'Signature Wool Trench Coat',
    tagline: 'Timeless luxury tailoring',
    description: 'An elegant, double-breasted trench coat tailored in Italy from a luxurious virgin wool and cashmere blend. Designed with a clean silhouette, structured shoulders, and an adjustable belted waist.',
    longDescription: 'Our Signature Wool Trench Coat epitomizes modern timelessness. Spun from water-repellent Italian wool and fine cashmere, it provides exceptional warmth without the weight. The interior is fully lined with silk satin for smooth layering. Finished with genuine horn buttons and traditional storm flaps, it transitions seamlessly from professional mornings to high-society dinners.',
    price: 450,
    originalPrice: 580,
    rating: 4.9,
    reviewsCount: 128,
    images: [
      'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&q=80&w=800'
    ],
    category: 'fashion',
    subCategory: 'Outerwear',
    brand: 'Velora Atelier',
    variants: [
      { id: 'v-c1', name: 'Camel', type: 'color', value: '#C19A6B', stock: 15 },
      { id: 'v-c2', name: 'Charcoal', type: 'color', value: '#36454F', stock: 10 },
      { id: 'v-s1', name: 'S', type: 'size', value: 'S', stock: 5 },
      { id: 'v-s2', name: 'M', type: 'size', value: 'M', stock: 8 },
      { id: 'v-s3', name: 'L', type: 'size', value: 'L', stock: 12 },
    ],
    features: [
      'Virgin wool & cashmere blend sourced from Biella, Italy',
      'Water-repellent finish protects against elements',
      'Full premium silk-satin lining',
      'Genuine buffalo horn buttons',
      'Removable throat latch and matching waist belt'
    ],
    specs: {
      'Material': '85% Virgin Wool, 15% Cashmere',
      'Lining': '100% Silk Satin',
      'Fit': 'Tailored, true to size',
      'Care': 'Professional Dry Clean Only',
      'Origin': 'Made in Italy'
    },
    isFeatured: true,
    discountBadge: 'Save 22%',
    createdAt: '2026-08-10',
  },
  {
    id: 'fashion-2',
    name: 'Minimalist Silk Slip Dress',
    tagline: 'Liquid silk elegance',
    description: 'An absolute staple. Crafted from heavy-gauge mulberry silk that drapes fluidly along the body. Features adjustable delicate spaghetti straps and a soft bias cut.',
    longDescription: 'Cut on the bias to hug curves elegantly, our Minimalist Silk Slip Dress feels like liquid air. Made from premium 22-momme pure mulberry silk, it is hypoallergenic, thermoregulating, and incredibly soft. Perfect for styling under an oversized blazer for day-wear, or solo with high-end heels for an evening event.',
    price: 180,
    rating: 4.7,
    reviewsCount: 84,
    images: [
      'https://images.unsplash.com/photo-1485462537746-965f33f7f6a7?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&q=80&w=800'
    ],
    category: 'fashion',
    subCategory: 'Dresses',
    brand: 'Velora Silk',
    variants: [
      { id: 'v-c3', name: 'Emerald', type: 'color', value: '#046307', stock: 12 },
      { id: 'v-c4', name: 'Champagne', type: 'color', value: '#F0E6D2', stock: 18 },
      { id: 'v-c5', name: 'Midnight', type: 'color', value: '#121214', stock: 8 },
      { id: 'v-s4', name: 'XS', type: 'size', value: 'XS', stock: 4 },
      { id: 'v-s5', name: 'S', type: 'size', value: 'S', stock: 12 },
      { id: 'v-s6', name: 'M', type: 'size', value: 'M', stock: 15 },
    ],
    features: [
      '100% Pure Grade 6A Mulberry Silk',
      'Heavyweight 22-momme fabric for premium drape',
      'Bias cut for natural, forgiving stretch',
      'Fully adjustable, high-strength micro shoulder straps',
      'Finished with high-end French seams'
    ],
    specs: {
      'Material': '100% Grade 6A Mulberry Silk (22-Momme)',
      'Thread Count': '600 TC equivalent',
      'Fit': 'Slim, bias cut drape',
      'Care': 'Hand wash cold or dry clean',
      'Origin': 'Designed in Milan, Made in Shanghai'
    },
    isNew: true,
    createdAt: '2026-09-12',
  },

  // SNEAKERS
  {
    id: 'sneakers-1',
    name: 'AeroGlide Elite Sneakers',
    tagline: 'High-performance luxury streetwear',
    description: 'Engineered for absolute comfort and street aesthetic. Handcrafted in Portugal with premium Italian calf leather paneling, technical mesh, and an ultra-lightweight responsive outsole.',
    longDescription: 'The AeroGlide Elite represents the intersection of luxury materials and ergonomic footwear design. Featuring structured calfskin leather overlays paired with a breathable recycled knit upper, it provides unparalleled support. The high-rebound compound foam midsole cushions every step while maintaining structured heel stability.',
    price: 220,
    originalPrice: 280,
    rating: 4.8,
    reviewsCount: 312,
    images: [
      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&q=80&w=800'
    ],
    category: 'sneakers',
    subCategory: 'Athletic Luxury',
    brand: 'Aero Labs',
    variants: [
      { id: 'v-c6', name: 'Scarlet Orange', type: 'color', value: '#FF3B30', stock: 14 },
      { id: 'v-c7', name: 'Triple White', type: 'color', value: '#FFFFFF', stock: 25 },
      { id: 'v-c8', name: 'Monochrome Onyx', type: 'color', value: '#1A1A1A', stock: 19 },
      { id: 'v-sz1', name: 'US 8', type: 'size', value: '8', stock: 10 },
      { id: 'v-sz2', name: 'US 9', type: 'size', value: '9', stock: 15 },
      { id: 'v-sz3', name: 'US 10', type: 'size', value: '10', stock: 20 },
      { id: 'v-sz4', name: 'US 11', type: 'size', value: '11', stock: 8 },
    ],
    features: [
      'Premium Italian calf leather and suede paneling',
      'Highly breathable recycled nylon knit structure',
      'Custom AeroFlow responsive high-rebound foam sole',
      'Removable memory-foam anatomical cork footbed',
      'Reflective micro-accents for visibility'
    ],
    specs: {
      'Upper': 'Italian Calf Leather, Suede & Recycled Mesh',
      'Midsole': 'Proprietary AeroFlow EVA Copolymer',
      'Outsole': 'Carbon-infused high-grip vulcanized rubber',
      'Weight': '290g (Size US 9)',
      'Origin': 'Handcrafted in Porto, Portugal'
    },
    isBestSeller: true,
    discountBadge: 'Save 21%',
    createdAt: '2026-07-01',
  },

  // ELECTRONICS
  {
    id: 'elec-1',
    name: 'Acoustix Aura ANC Headphones',
    tagline: 'Pristine sound, absolute silence',
    description: 'Audiophile-grade wireless over-ear headphones with custom hybrid active noise cancellation, custom-tuned 40mm drivers, and an astonishing 45-hour battery life.',
    longDescription: 'Escape into pure acoustic brilliance. The Acoustix Aura utilizes advanced feedforward and feedback hybrid ANC technology, cancelling out 98% of ambient noise. High-fidelity beryllium-coated 40mm drivers deliver crystalline highs, warm organic mid-ranges, and deeply controlled, chest-thumping bass. Comfort is guaranteed via adaptive memory foam ear cushions enveloped in soft vegan lambskin leather.',
    price: 350,
    rating: 4.9,
    reviewsCount: 245,
    images: [
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&q=80&w=800'
    ],
    category: 'electronics',
    subCategory: 'Audio',
    brand: 'Acoustix',
    variants: [
      { id: 'v-c9', name: 'Nordic Silver', type: 'color', value: '#C0C0C0', stock: 8 },
      { id: 'v-c10', name: 'Midnight Obsidian', type: 'color', value: '#101115', stock: 12 },
    ],
    features: [
      'Ultra-high performance 40mm Beryllium-coated dynamic drivers',
      'Hybrid Adaptive Active Noise Cancelling (up to -42dB)',
      'Bluetooth 5.3 with high-definition LDAC & aptX Adaptive support',
      'Up to 45 hours battery life with ANC on (USB-C Fast Charging)',
      'Built-in beamforming multi-microphone array for ultra-clear calls'
    ],
    specs: {
      'Frequency Range': '4Hz - 40,000Hz (Hi-Res Audio Certified)',
      'Impedance': '32 Ohms',
      'Driver Size': '40mm Custom Dynamic Beryllium',
      'Connectivity': 'Bluetooth 5.3 / 3.5mm Aux Support',
      'Weight': '265g'
    },
    isFeatured: true,
    createdAt: '2026-06-15',
  },

  // WATCHES
  {
    id: 'watch-1',
    name: 'Vanguard Automatic Chronograph',
    tagline: 'Mastery in mechanical horology',
    description: 'An exquisite mechanical watch featuring a Swiss Sellita automatic movement, brushed grade 5 titanium case, and hand-stitched Horween leather strap.',
    longDescription: 'Designed for the modern connoisseur, the Vanguard Automatic Chronograph bridges historical watchmaking with high-tech materials. Encased in extremely light and scratch-resistant Grade 5 Titanium, the dial features a dual-register layout with custom applied indices and Swiss Super-LumiNova for perfect readability in the dark. The sapphire exhibition caseback exposes the gorgeously finished automatic rotor and balance wheel in full motion.',
    price: 890,
    originalPrice: 1150,
    rating: 5.0,
    reviewsCount: 42,
    images: [
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1524592094714-0f0654e20314?auto=format&fit=crop&q=80&w=800'
    ],
    category: 'watches',
    subCategory: 'Automatic Watches',
    brand: 'Horology Lab',
    variants: [
      { id: 'v-c11', name: 'Raw Titanium', type: 'color', value: '#8D918D', stock: 5 },
      { id: 'v-c12', name: 'Rose Gold Accent', type: 'color', value: '#B76E79', stock: 3 },
    ],
    features: [
      'Swiss-made Sellita SW510 Automatic Chronograph movement',
      'Ultra-tough Grade 5 Titanium case with anti-scratch coating',
      'Dual curved sapphire crystal with 5 layers of anti-reflective inner coating',
      'Exhibition back showing personalized pearled automatic rotor',
      'Water resistant to 100 meters (10 ATM)'
    ],
    specs: {
      'Movement': 'Automatic Caliber SW510 (28,800 bph, 27 Jewels)',
      'Power Reserve': 'Up to 62 Hours',
      'Case Diameter': '41mm',
      'Case Thickness': '13.8mm',
      'Lug Width': '20mm'
    },
    isNew: true,
    discountBadge: 'Save 23%',
    createdAt: '2026-09-01',
  },

  // ACCESSORIES
  {
    id: 'acc-1',
    name: 'Nomad Premium Leather Weekender',
    tagline: 'Refined adventure travel companion',
    description: 'Handcrafted with vegetable-tanned full-grain Tuscan leather and reinforced with Solid brass hardware. Designed to comply with flight cabin dimensions.',
    longDescription: 'Crafted for the frequent flyer, the Nomad Weekender features an elegant, structurally reinforced design that grows even more beautiful over time as a rich, unique patina develops. The interior is fully lined with durable cotton herringbone canvas, featuring a dedicated laptop sleeve, passport slip, shoe compartment, and mesh zipper pockets.',
    price: 295,
    rating: 4.8,
    reviewsCount: 176,
    images: [
      'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1547949003-9792a18a2601?auto=format&fit=crop&q=80&w=800'
    ],
    category: 'accessories',
    subCategory: 'Bags & Luggage',
    brand: 'Nomad Goods',
    variants: [
      { id: 'v-c13', name: 'Cognac', type: 'color', value: '#9E5B2F', stock: 14 },
      { id: 'v-c14', name: 'Classic Black', type: 'color', value: '#0C0D0E', stock: 22 },
    ],
    features: [
      '100% full-grain, vegetable-tanned Italian Tuscan leather',
      'Solid sand-cast brass rivets and high-strength YKK Excella zippers',
      'Dedicated outer access waterproof shoe compartment',
      'Adjustable padded leather shoulder strap',
      'Reinforced base panel with protective solid brass feet'
    ],
    specs: {
      'Dimensions': '52cm x 28cm x 26cm (Cabin Approved)',
      'Capacity': '38 Liters',
      'Weight': '1.8kg',
      'Material': 'Italian Vachetta Leather'
    },
    isBestSeller: true,
    createdAt: '2026-04-20',
  },

  // BEAUTY
  {
    id: 'beauty-1',
    name: 'Advanced Botanical Glow Serum',
    tagline: 'Radiance by molecular biology',
    description: 'An active, cold-pressed facial serum concentrated with stabilized Vitamin C, Bakuchiol, botanical Squalane, and micro-molecular Hyaluronic Acid.',
    longDescription: 'Reveal your skin’s biological luminosity. Our Botanical Glow Serum delivers intensive hydration, smooths fine lines, and fades dark spots within 14 days of use. Formulated in cold, light-locked chambers, we preserve the molecular integrity of our active botanicals, entirely without parabens, synthetic fillers, or artificial fragrances.',
    price: 78,
    originalPrice: 95,
    rating: 4.7,
    reviewsCount: 420,
    images: [
      'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&q=80&w=800'
    ],
    category: 'beauty',
    subCategory: 'Serums',
    brand: 'Velora Skincare',
    variants: [
      { id: 'v-s7', name: '30ml', type: 'size', value: '30ml', stock: 50 },
      { id: 'v-s8', name: '50ml', type: 'size', value: '50ml', priceOffset: 32, stock: 35 },
    ],
    features: [
      '15% Stabilized Ascorbyl Glucoside (Vitamin C) prevents oxidative aging',
      '1% Bakuchiol — a gentle, non-irritating natural Retinol alternative',
      'Pure Spanish Olive Squalane matches skin barrier lipids',
      '99% natural organic cold-pressed botanicals',
      'Phthalate-free, Cruelty-free, Vegan, and FSC recyclable glass bottle'
    ],
    specs: {
      'Skin Type': 'All skin types, especially sensitive or dull skin',
      'Key Ingredients': 'Bakuchiol, Vitamin C, Hyaluronic Acid, Olive Squalane',
      'pH Level': '5.5 (Balanced)',
      'Texture': 'Lightweight, silky non-greasy micro-emulsion',
      'Origin': 'Formulated in Grasse, France'
    },
    isFeatured: true,
    discountBadge: 'Save 18%',
    createdAt: '2026-08-01',
  },

  // HOME
  {
    id: 'home-1',
    name: 'Zen Minimalist Ceramic Vase Set',
    tagline: 'Artisanal organic silhouettes',
    description: 'A set of three hand-thrown ceramic vessels. Features a raw, matte limestone texture with custom asymmetrical organic shapes.',
    longDescription: 'Curated to bring quiet, meditative energy to your living room. Every vase is individual, spun on wood potter wheels and kiln-fired using natural wood ashes in Kyoto, Japan. Perfect on floating wooden shelves, minimal coffee tables, or hosting delicate dried botanical branches.',
    price: 110,
    rating: 4.6,
    reviewsCount: 58,
    images: [
      'https://images.unsplash.com/photo-1612196808214-b8e1d6145a8c?auto=format&fit=crop&q=80&w=800',
      'https://images.unsplash.com/photo-1581591524425-c7e0978865fc?auto=format&fit=crop&q=80&w=800'
    ],
    category: 'home',
    subCategory: 'Ceramics & Decor',
    brand: 'Zen Studio',
    variants: [
      { id: 'v-c15', name: 'Off-White Limestone', type: 'color', value: '#F5F5DC', stock: 15 },
      { id: 'v-c16', name: 'Sandstone Beige', type: 'color', value: '#E5D3B3', stock: 12 },
    ],
    features: [
      'Hand-thrown by independent third-generation ceramic artists',
      'Matte volcanic limestone glaze provides organic tactility',
      'Heavyweight base structures prevent accidental tipping',
      'Fully watertight interiors for holding fresh seasonal blooms',
      'Comes packaged in a beautiful, padded wood collection box'
    ],
    specs: {
      'Materials': '100% Organic Kaolin Clay & Volcanic Glaze',
      'Vase A Height': '24cm (Slender)',
      'Vase B Height': '18cm (Spherical)',
      'Vase C Height': '12cm (Conical)',
      'Weight Set': '2.4kg total'
    },
    isNew: true,
    createdAt: '2026-09-05',
  }
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: 'blog-1',
    title: 'The Art of Essentialism: Crafting a Timeless Wardrobe',
    excerpt: 'In a world driven by micro-trends, discover the core principles of building a modular capsule wardrobe that outlasts seasons.',
    content: `We live in an age of hyper-consumption. Wardrobe styles shift weekly, fueled by micro-trends and low-grade fabrics. However, true elegance lies in restraint. The "Capsule Wardrobe" is not just a style choice; it is a philosophy of lifestyle.

### Why Quality Over Quantity?
Investing in premium pieces like wool trenches, silk dresses, and fine leather goods has immediate, measurable benefits:
1. **Durability:** Heavy-gauge silks and virgin wools easily withstand years of wear, gaining character over time.
2. **Mental Clarity:** A curated drawer of 15 perfectly fitting garments reduces decision fatigue every single morning.
3. **True Sustainability:** Extending the life of your apparel by just nine months reduces carbon, waste, and water footprints by 20–30%.

### How to Begin
Start by cleansing your wardrobe. Keep only the items that meet three metrics: they are structurally flawless, fit your current body perfectly, and can be paired into at least four separate outfits. Invest next in premium neutral foundational pieces. A heavy-gauge double-breasted coat in Camel or Charcoal, or a fluid slip dress in neutral tones, are ideal canvas pieces that adapt dynamically across events.`,
    category: 'Fashion & Style',
    image: 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&q=80&w=800',
    author: {
      name: 'Elena Rostova',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150',
    },
    date: 'Sep 15, 2026',
    readTime: '6 min read',
    tags: ['Capsule Wardrobe', 'Minimalism', 'Sustainable Luxury'],
  },
  {
    id: 'blog-2',
    title: 'Understanding Beryllium and Acoustics',
    excerpt: 'Deep-dive into driver mechanics and why top tier sound engineers utilize rare element coatings for pristine high-resolution sound.',
    content: `Sound is not just digital. Sound is physical compression waves traveling through our air. When headphone drivers receive electricity, they physically flex and recoil to create these waves. The lighter and stiffer the driver material, the more precise the sound.

### The Beryllium Difference
Beryllium is a rare alkaline earth metal that possesses an exceptionally high stiffness-to-weight ratio. It is nearly 4 times stiffer than titanium and conducts sound at nearly 12,000 meters per second.
- **Zero Distortions:** Because of its stiffness, beryllium drivers do not flex out of shape when hit with heavy base signals, preventing harmonic distortion.
- **Perfect Highs:** It extends the high frequency threshold up to 40,000Hz, providing an airy, crystalline spatial acoustic landscape.
- **Instant Response:** Transients (the sudden snap of a snare drum, or pluck of an acoustic guitar string) are rendered with lightning-fast accuracy.

While expensive to extract and shape, incorporating beryllium into acoustic diaphragms is the absolute gold standard for true audiophiles.`,
    category: 'Audio Technology',
    image: 'https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&q=80&w=800',
    author: {
      name: 'Marcus Vance',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150',
    },
    date: 'Sep 08, 2026',
    readTime: '8 min read',
    tags: ['Hi-Fi Audio', 'Beryllium Drivers', 'Acoustic Science'],
  },
  {
    id: 'blog-3',
    title: 'The Organic Skincare Revolution: Active Botanicals',
    excerpt: 'Cold-pressed vs. synthetic. Learn the scientific evidence backing cold-temperature botanical skin preservation.',
    content: `For decades, mass-market skincare relied heavily on petroleum derivatives and synthetic preservatives to extend shelf life indefinitely. However, synthetic shortcuts often trigger deep skin irritation. Today, cellular molecular skin wellness is shifting back to nature, supported by high-precision cold extraction.

### Cold-Pressed Efficacy
When botanical ingredients (like Olive Squalane or Rosehip oil) are heated to simplify mass extraction, their cellular vitamins and fatty acids oxidize and decay.
- **Molecular Integrity:** Cold pressing isolates pure active components at controlled, low temperatures under nitrogen shields, keeping the raw botanical active.
- **Bakuchiol over Retinol:** Traditional Retinol is highly unstable and can cause intense skin peeling and sunlight sensitivity. Bakuchiol, a molecular extract from the Babchi plant, triggers the exact same collagen-producing receptors in the skin but is entirely stable and soothing.
- **Micro-hyaluronic Delivery:** Squalane is structurally identical to our skin’s natural lipid barrier. When paired with active botanicals, it acts as a molecular carrier, drawing hydration deep past the dead stratum corneum layer into the living dermis.`,
    category: 'Skincare Science',
    image: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?auto=format&fit=crop&q=80&w=800',
    author: {
      name: 'Dr. Clara Cho',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=150',
    },
    date: 'Aug 28, 2026',
    readTime: '5 min read',
    tags: ['Clean Beauty', 'Bakuchiol', 'Organic Chemistry'],
  }
];

export const FAQS = [
  {
    question: 'Are all products authentic and verified?',
    answer: 'Absolutely. Every single product listed in the Velora boutique is sourced directly from certified manufacturers or verified authorized luxury distributors. We guarantee 100% authenticity, backed by certified brand documentation.',
  },
  {
    question: 'What is your shipping policy and delivery timeline?',
    answer: 'We provide complimentary premium express shipping on all orders over $150. Orders are processed within 24 business hours. Typical delivery windows are 2–4 business days domestically, and 4–8 business days worldwide via DHL Express or FedEx, complete with climate-controlled transit.',
  },
  {
    question: 'How do I return a product?',
    answer: 'We offer a complimentary 30-day hassle-free return window for all unused, sealed items in original packaging. To initiate a return, navigate to your Orders section, select Return, and print your prepaid return label. Once received, your original payment method is credited within 48 hours.',
  },
  {
    question: 'Do you offer warranty on high-end watches and electronics?',
    answer: 'Yes, all watches and electronics come backed by our comprehensive 2-year Velora Platinum warranty, covering any internal mechanical, electronic, or manufacturing failure. We also facilitate original manufacturer warranties on your behalf.',
  },
];

export const COUPONS: Coupon[] = [
  { code: 'VELORA10', type: 'percentage', value: 10, description: '10% off your entire order, no minimum' },
  { code: 'LUXURY50', type: 'fixed', value: 50, minSpend: 250, description: '$50 off orders over $250' },
  { code: 'WELCOME20', type: 'percentage', value: 20, minSpend: 100, description: '20% off for new customers over $100' },
];

export const MOCK_REVIEWS: Review[] = [
  {
    id: 'rev-1',
    userName: 'Sophia L.',
    userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150',
    rating: 5,
    date: '2026-09-10',
    title: 'Exquisite Quality!',
    comment: 'The wool-cashmere blend is unbelievably soft. It feels dense and keeps me extremely warm, yet it has this beautiful fluid drape. The Camel color matches everything. Truly an investment piece.',
    verified: true,
    helpfulCount: 24,
  },
  {
    id: 'rev-2',
    userName: 'Alexander K.',
    userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=150',
    rating: 5,
    date: '2026-09-18',
    title: 'Precision Horology',
    comment: 'The Grade 5 Titanium is exceptionally light and has this stunning dark brushed matte appearance. Sapphire glass is pristine. The Sellita sweep is dead silent and absolutely butter-smooth.',
    verified: true,
    helpfulCount: 15,
  },
  {
    id: 'rev-3',
    userName: 'Isabella M.',
    rating: 4,
    date: '2026-09-02',
    title: 'Stunning Hydration, slightly oily',
    comment: 'Using this for 2 weeks now. My skin has an undeniable healthy satin sheen. Small hyperpigmentations are fading beautifully. Dropped one star only because it takes about 5 minutes to fully absorb.',
    verified: true,
    helpfulCount: 8,
  }
];

export const DEFAULT_SHIPPING_ADDRESSES: ShippingAddress[] = [
  {
    id: 'addr-1',
    fullName: 'Jane Doe',
    phone: '+1 (555) 019-2834',
    addressLine1: '742 Evergreen Terrace',
    city: 'Springfield',
    state: 'OR',
    postalCode: '97477',
    country: 'United States',
    isDefault: true,
  },
  {
    id: 'addr-2',
    fullName: 'Jane Doe Office',
    phone: '+1 (555) 019-5839',
    addressLine1: '100 Infinite Loop',
    addressLine2: 'Suite 300',
    city: 'Cupertino',
    state: 'CA',
    postalCode: '95014',
    country: 'United States',
    isDefault: false,
  }
];

export const DEFAULT_ORDERS: Order[] = [
  {
    id: 'VEL-829471',
    date: '2026-09-14',
    items: [
      {
        productId: 'fashion-1',
        productName: 'Signature Wool Trench Coat',
        productImage: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?auto=format&fit=crop&q=80&w=800',
        price: 450,
        quantity: 1,
        selectedColor: 'Camel',
        selectedSize: 'M'
      }
    ],
    subtotal: 450,
    shipping: 0,
    tax: 36,
    discount: 45,
    total: 441,
    status: 'shipped',
    trackingNumber: 'TRACK-DHL-9204829',
    trackingSteps: [
      { status: 'pending', title: 'Order Placed', description: 'We have received your order and payment verification.', date: 'Sep 14, 2026, 10:30 AM', completed: true, active: false },
      { status: 'processing', title: 'Quality Audited & Packaged', description: 'Item inspected under white gloves and placed in rigid wooden storage boxes.', date: 'Sep 14, 2026, 03:15 PM', completed: true, active: false },
      { status: 'shipped', title: 'In Transit via DHL Express', description: 'Departed Munich Sort Facility. On its way to delivery hub.', date: 'Sep 15, 2026, 08:00 AM', completed: true, active: true },
      { status: 'delivered', title: 'Out for Delivery / Delivered', description: 'Unlocking white-glove courier dispatch.', date: 'Pending', completed: false, active: false }
    ],
    shippingAddress: DEFAULT_SHIPPING_ADDRESSES[0],
    paymentMethod: 'Credit Card (Visa ending in 4242)'
  },
  {
    id: 'VEL-382910',
    date: '2026-08-02',
    items: [
      {
        productId: 'beauty-1',
        productName: 'Advanced Botanical Glow Serum',
        productImage: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=800',
        price: 78,
        quantity: 2,
        selectedSize: '30ml'
      }
    ],
    subtotal: 156,
    shipping: 15,
    tax: 12.48,
    discount: 0,
    total: 183.48,
    status: 'delivered',
    trackingNumber: 'TRACK-FEDEX-1048293',
    trackingSteps: [
      { status: 'pending', title: 'Order Placed', description: 'We have received your order.', date: 'Aug 02, 2026', completed: true, active: false },
      { status: 'processing', title: 'Packaged', description: 'Your order was securely packaged.', date: 'Aug 02, 2026', completed: true, active: false },
      { status: 'shipped', title: 'Shipped', description: 'In transit via FedEx Priority.', date: 'Aug 03, 2026', completed: true, active: false },
      { status: 'delivered', title: 'Delivered', description: 'Hand-delivered to front door. Signed by J. Doe.', date: 'Aug 05, 2026', completed: true, active: true }
    ],
    shippingAddress: DEFAULT_SHIPPING_ADDRESSES[0],
    paymentMethod: 'Apple Pay'
  }
];
