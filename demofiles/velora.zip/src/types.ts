/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface ProductVariant {
  id: string;
  name: string; // e.g. "Matte Black", "S"
  type: 'color' | 'size' | 'material' | 'style';
  value: string; // hex value for color, or text label
  priceOffset?: number;
  stock: number;
}

export interface Review {
  id: string;
  userName: string;
  userAvatar?: string;
  rating: number;
  date: string;
  title: string;
  comment: string;
  verified: boolean;
  helpfulCount: number;
}

export interface Product {
  id: string;
  name: string;
  tagline?: string;
  description: string;
  longDescription?: string;
  price: number;
  originalPrice?: number; // for discount display
  rating: number;
  reviewsCount: number;
  images: string[];
  category: string;
  subCategory?: string;
  brand: string;
  variants: ProductVariant[];
  features: string[];
  specs: { [key: string]: string };
  isNew?: boolean;
  isBestSeller?: boolean;
  isFeatured?: boolean;
  discountBadge?: string;
  createdAt: string;
}

export interface Category {
  id: string;
  name: string;
  description: string;
  image: string;
  count?: number;
}

export interface CartItem {
  id: string; // combination of product.id + variants configuration
  product: Product;
  quantity: number;
  selectedColor?: ProductVariant;
  selectedSize?: ProductVariant;
}

export interface ShippingAddress {
  id: string;
  fullName: string;
  phone: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  isDefault: boolean;
}

export interface OrderItem {
  productId: string;
  productName: string;
  productImage: string;
  price: number;
  quantity: number;
  selectedColor?: string;
  selectedSize?: string;
}

export type OrderStatus = 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';

export interface OrderTrackingStep {
  status: string;
  title: string;
  description: string;
  date: string;
  completed: boolean;
  active: boolean;
}

export interface Order {
  id: string;
  date: string;
  items: OrderItem[];
  subtotal: number;
  shipping: number;
  tax: number;
  discount: number;
  total: number;
  status: OrderStatus;
  trackingNumber?: string;
  trackingSteps?: OrderTrackingStep[];
  shippingAddress: ShippingAddress;
  paymentMethod: string;
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  image: string;
  author: {
    name: string;
    avatar: string;
  };
  date: string;
  readTime: string;
  tags: string[];
}

export interface Toast {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
  duration?: number;
}

export interface Coupon {
  code: string;
  type: 'percentage' | 'fixed';
  value: number;
  minSpend?: number;
  description: string;
}
