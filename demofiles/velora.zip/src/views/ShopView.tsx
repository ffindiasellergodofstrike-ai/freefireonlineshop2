/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { PRODUCTS, CATEGORIES } from '../data/mockData';
import { Product } from '../types';
import { Star, Eye, Heart, Filter, ChevronDown, RefreshCw, SlidersHorizontal, Search, ArrowUpDown, X } from 'lucide-react';

export const ShopView: React.FC = () => {
  const {
    currentRouteParams,
    navigateTo,
    setQuickViewProduct,
    toggleWishlist,
    isInWishlist,
    searchQuery,
    setSearchQuery,
  } = useApp();

  // Loading indicator simulator
  const [isLoading, setIsLoading] = useState(false);

  // Filters state
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState<number>(1200);
  const [minRating, setMinRating] = useState<number>(0);
  const [sortBy, setSortBy] = useState<string>('featured');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const itemsPerPage = 6;

  // Toggle visual filters on mobile
  const [isMobileFiltersOpen, setIsMobileFiltersOpen] = useState(false);

  // Synchronize route category param if available
  useEffect(() => {
    if (currentRouteParams?.id) {
      setSelectedCategory(currentRouteParams.id);
      setCurrentPage(1);
    } else {
      setSelectedCategory('all');
    }
  }, [currentRouteParams]);

  // Handle mock loading on filter updates
  const triggerLoading = () => {
    setIsLoading(true);
    setTimeout(() => setIsLoading(false), 400);
  };

  const handleCategorySelect = (catId: string) => {
    triggerLoading();
    setSelectedCategory(catId);
    setCurrentPage(1);
    // Sync URL hash
    if (catId === 'all') {
      window.location.hash = 'shop';
    } else {
      window.location.hash = `category/${catId}`;
    }
  };

  const handleBrandToggle = (brand: string) => {
    triggerLoading();
    setSelectedBrands((prev) =>
      prev.includes(brand) ? prev.filter((b) => b !== brand) : [...prev, brand]
    );
    setCurrentPage(1);
  };

  const handlePriceChange = (val: number) => {
    setPriceRange(val);
    setCurrentPage(1);
  };

  const handleRatingSelect = (rating: number) => {
    triggerLoading();
    setMinRating(rating === minRating ? 0 : rating);
    setCurrentPage(1);
  };

  const clearAllFilters = () => {
    triggerLoading();
    setSelectedCategory('all');
    setSelectedBrands([]);
    setPriceRange(1200);
    setMinRating(0);
    setSortBy('featured');
    setSearchQuery('');
    setCurrentPage(1);
    window.location.hash = 'shop';
  };

  // Get unique brands dynamically
  const brandsList = Array.from(new Set(PRODUCTS.map((p) => p.brand)));

  // Filter & Sort Logic
  const filteredProducts = PRODUCTS.filter((product) => {
    // 1. Category Filter
    if (selectedCategory !== 'all' && product.category !== selectedCategory) {
      return false;
    }
    // 2. Brand Filter
    if (selectedBrands.length > 0 && !selectedBrands.includes(product.brand)) {
      return false;
    }
    // 3. Price Filter
    if (product.price > priceRange) {
      return false;
    }
    // 4. Rating Filter
    if (product.rating < minRating) {
      return false;
    }
    // 5. Search Filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      const matchName = product.name.toLowerCase().includes(query);
      const matchBrand = product.brand.toLowerCase().includes(query);
      const matchCat = product.category.toLowerCase().includes(query);
      const matchDesc = product.description.toLowerCase().includes(query);
      if (!matchName && !matchBrand && !matchCat && !matchDesc) {
        return false;
      }
    }
    return true;
  });

  // Sorting
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortBy === 'price-low') {
      return a.price - b.price;
    }
    if (sortBy === 'price-high') {
      return b.price - a.price;
    }
    if (sortBy === 'rating') {
      return b.rating - a.rating;
    }
    if (sortBy === 'newest') {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    }
    // Default: Featured
    return (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0);
  });

  // Pagination bounds
  const totalPages = Math.ceil(sortedProducts.length / itemsPerPage);
  const paginatedProducts = sortedProducts.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  return (
    <div id="shop-view" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
      
      {/* Breadcrumbs */}
      <div className="py-6 flex items-center gap-2 text-[11px] tracking-widest uppercase text-neutral-400 dark:text-neutral-500 font-semibold border-b border-neutral-100 dark:border-neutral-900/65">
        <button onClick={() => navigateTo('home')} className="hover:text-[#C19A6B] transition">Home</button>
        <span>/</span>
        <button onClick={() => handleCategorySelect('all')} className="hover:text-[#C19A6B] transition">Shop</button>
        {selectedCategory !== 'all' && (
          <>
            <span>/</span>
            <span className="text-neutral-700 dark:text-neutral-300">
              {CATEGORIES.find((c) => c.id === selectedCategory)?.name}
            </span>
          </>
        )}
      </div>

      {/* Hero Header */}
      <div className="py-8">
        <span className="text-xs font-bold text-[#C19A6B] uppercase tracking-widest block">
          {selectedCategory !== 'all'
            ? CATEGORIES.find((c) => c.id === selectedCategory)?.description
            : 'Explore all exquisite drops'}
        </span>
        <h1 className="text-3xl font-serif font-extrabold text-neutral-900 dark:text-white mt-1.5 leading-snug">
          {selectedCategory !== 'all'
            ? CATEGORIES.find((c) => c.id === selectedCategory)?.name
            : 'The Bespoke Collection'}
        </h1>
      </div>

      {/* Main Grid: Filters + Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-10 mt-6 items-start">
        
        {/* Left: Filters Sidebar (Desktop) */}
        <aside id="shop-filters-sidebar" className="hidden lg:block space-y-8 pr-4 border-r border-neutral-100 dark:border-neutral-900">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-800 dark:text-neutral-200 flex items-center gap-1.5">
              <SlidersHorizontal className="w-4 h-4 text-[#C19A6B]" />
              <span>Filter Atelier</span>
            </span>
            <button
              onClick={clearAllFilters}
              className="text-[10px] font-bold tracking-wider uppercase text-neutral-400 hover:text-red-500 transition cursor-pointer"
            >
              Clear All
            </button>
          </div>

          {/* Search Box */}
          <div className="space-y-2">
            <label className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block">Keyword Search</label>
            <div className="relative flex items-center bg-neutral-50 dark:bg-neutral-900 border border-neutral-200/60 dark:border-neutral-800 rounded-md">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3" />
              <input
                type="text"
                placeholder="Search pieces..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-transparent border-none text-xs focus:ring-0 outline-none w-full py-2.5 pl-9 pr-3 text-neutral-800 dark:text-white"
              />
              {searchQuery && (
                <button onClick={() => setSearchQuery('')} className="p-1 mr-2 text-neutral-400 hover:text-neutral-600">
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>

          {/* Categories */}
          <div className="space-y-3">
            <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block">Departments</span>
            <div className="flex flex-col gap-2">
              <button
                onClick={() => handleCategorySelect('all')}
                className={`text-xs text-left py-1 px-2.5 rounded-md transition font-medium flex justify-between items-center ${
                  selectedCategory === 'all'
                    ? 'bg-neutral-900 dark:bg-white text-white dark:text-neutral-900'
                    : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-50 dark:hover:bg-neutral-850/20'
                }`}
              >
                <span>All Departments</span>
                <span className="font-mono text-[10px] opacity-70">{PRODUCTS.length}</span>
              </button>
              {CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => handleCategorySelect(cat.id)}
                  className={`text-xs text-left py-1.5 px-2.5 rounded-md transition font-medium flex justify-between items-center ${
                    selectedCategory === cat.id
                      ? 'bg-neutral-900 dark:bg-white text-white dark:text-neutral-900'
                      : 'text-neutral-600 dark:text-neutral-400 hover:bg-neutral-50 dark:hover:bg-neutral-850/20'
                  }`}
                >
                  <span>{cat.name}</span>
                  <span className="font-mono text-[10px] opacity-70">
                    {PRODUCTS.filter((p) => p.category === cat.id).length}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Brand Checklist */}
          <div className="space-y-3">
            <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block">Brand Houses</span>
            <div className="space-y-2">
              {brandsList.map((brand) => (
                <label key={brand} className="flex items-center gap-2.5 text-xs text-neutral-600 dark:text-neutral-400 cursor-pointer hover:text-neutral-850 dark:hover:text-white transition">
                  <input
                    type="checkbox"
                    checked={selectedBrands.includes(brand)}
                    onChange={() => handleBrandToggle(brand)}
                    className="w-4 h-4 rounded border-neutral-300 text-[#C19A6B] focus:ring-[#C19A6B] cursor-pointer"
                  />
                  <span>{brand}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Price Range */}
          <div className="space-y-3">
            <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-wider text-neutral-400">
              <span>Max Price Limit</span>
              <span className="font-mono font-bold text-neutral-800 dark:text-white">${priceRange}</span>
            </div>
            <input
              type="range"
              min="20"
              max="1200"
              step="10"
              value={priceRange}
              onChange={(e) => handlePriceChange(Number(e.target.value))}
              className="w-full h-1 bg-neutral-200 dark:bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-[#C19A6B]"
            />
            <div className="flex justify-between text-[10px] text-neutral-450 font-mono">
              <span>$20</span>
              <span>$1200</span>
            </div>
          </div>

          {/* Ratings Filter */}
          <div className="space-y-3">
            <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block">Minimum Rating</span>
            <div className="space-y-2">
              {[4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => handleRatingSelect(star)}
                  className={`w-full flex items-center justify-between text-xs py-1.5 px-2 rounded-md border text-left transition cursor-pointer ${
                    minRating === star
                      ? 'bg-[#C19A6B]/10 border-[#C19A6B]/30 text-[#C19A6B]'
                      : 'border-neutral-100 dark:border-neutral-900 hover:bg-neutral-50 dark:hover:bg-neutral-850/20 text-neutral-600 dark:text-neutral-400'
                  }`}
                >
                  <div className="flex items-center gap-1.5">
                    <div className="flex gap-0.5">
                      {[...Array(5)].map((_, index) => (
                        <Star
                          key={index}
                          className={`w-3.5 h-3.5 ${
                            index < star ? 'fill-current' : 'text-neutral-200 dark:text-neutral-800'
                          }`}
                        />
                      ))}
                    </div>
                    <span>{star === 5 ? 'Only 5 Stars' : `${star} Stars & Up`}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </aside>

        {/* Right: Products Grid Area */}
        <div className="lg:col-span-3 space-y-8">
          
          {/* Action Row: Sort + Result Count + Mobile Filter Toggle */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 py-3 border-b border-neutral-100 dark:border-neutral-900">
            <div className="text-xs text-neutral-500 dark:text-neutral-400 font-light">
              Showing <strong className="text-neutral-800 dark:text-white">{sortedProducts.length}</strong> luxurious products found
            </div>

            <div className="flex items-center gap-3">
              {/* Mobile Filter Toggle */}
              <button
                onClick={() => setIsMobileFiltersOpen(true)}
                className="lg:hidden flex items-center gap-1.5 py-2 px-3 border border-neutral-200 dark:border-neutral-800 text-xs font-semibold rounded-md text-neutral-700 dark:text-neutral-300 hover:bg-neutral-50 transition cursor-pointer"
              >
                <SlidersHorizontal className="w-3.5 h-3.5 text-[#C19A6B]" />
                <span>Filters</span>
              </button>

              {/* Sorting */}
              <div className="flex items-center gap-2 text-xs">
                <ArrowUpDown className="w-3.5 h-3.5 text-neutral-400" />
                <span className="text-neutral-400 font-light">Sort By</span>
                <select
                  value={sortBy}
                  onChange={(e) => {
                    triggerLoading();
                    setSortBy(e.target.value);
                  }}
                  className="bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-850 rounded-md py-1.5 px-3 text-xs text-neutral-800 dark:text-white outline-none focus:border-[#C19A6B]"
                >
                  <option value="featured">Featured Drops</option>
                  <option value="newest">Newest Additions</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="rating">Top Customer Rated</option>
                </select>
              </div>
            </div>
          </div>

          {/* Grid View */}
          {isLoading ? (
            /* Skeleton Loading State Grid */
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(itemsPerPage)].map((_, idx) => (
                <div key={idx} className="border border-neutral-100 dark:border-neutral-900 rounded-xl overflow-hidden p-4 space-y-4 animate-pulse bg-neutral-50/20 dark:bg-neutral-900/10">
                  <div className="aspect-[3/4] bg-neutral-200/75 dark:bg-neutral-800/75 rounded-lg w-full" />
                  <div className="h-3 bg-neutral-200/75 dark:bg-neutral-800/75 rounded w-1/3" />
                  <div className="h-4 bg-neutral-200/75 dark:bg-neutral-800/75 rounded w-3/4" />
                  <div className="h-3 bg-neutral-200/75 dark:bg-neutral-800/75 rounded w-1/2" />
                  <div className="flex justify-between pt-2 border-t border-neutral-100 dark:border-neutral-900">
                    <div className="h-4 bg-neutral-200/75 dark:bg-neutral-800/75 rounded w-1/4" />
                    <div className="h-3 bg-neutral-200/75 dark:bg-neutral-800/75 rounded w-1/4" />
                  </div>
                </div>
              ))}
            </div>
          ) : paginatedProducts.length === 0 ? (
            /* Empty State */
            <div className="text-center py-16 bg-neutral-50/50 dark:bg-[#1A1A1E]/10 rounded-2xl border border-neutral-100 dark:border-neutral-900/60 max-w-xl mx-auto px-4">
              <div className="p-4 bg-neutral-100 dark:bg-neutral-800/60 rounded-full text-neutral-400 mb-4 inline-block">
                <Search className="w-8 h-8" />
              </div>
              <h3 className="text-sm font-bold text-neutral-800 dark:text-neutral-200">No pieces match your specifications</h3>
              <p className="text-xs text-neutral-400 dark:text-neutral-500 font-light mt-1.5 leading-relaxed">
                Try widening your price filters, selecting a different brand house, or modifying your search keywords.
              </p>
              <button
                onClick={clearAllFilters}
                className="mt-6 bg-neutral-950 hover:bg-neutral-850 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-neutral-950 text-xs font-bold tracking-widest uppercase py-3 px-6 rounded-md transition shadow-md cursor-pointer"
              >
                Clear All Filters
              </button>
            </div>
          ) : (
            /* Products Grid mapping */
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {paginatedProducts.map((product) => {
                const isFav = isInWishlist(product.id);
                return (
                  <div
                    key={product.id}
                    className="group relative flex flex-col bg-white dark:bg-[#1A1A1E]/40 border border-neutral-100 dark:border-neutral-900 rounded-xl overflow-hidden transition-all duration-300 hover:shadow-lg"
                  >
                    {/* Favorite overlay */}
                    <button
                      onClick={() => toggleWishlist(product)}
                      className={`absolute top-3.5 right-3.5 z-10 p-2 bg-white/90 dark:bg-neutral-900/90 backdrop-blur-md rounded-full border transition cursor-pointer shadow-sm ${
                        isFav
                          ? 'border-red-100 bg-red-50/80 dark:bg-red-950/20 text-red-500'
                          : 'border-neutral-200/40 dark:border-neutral-800 text-neutral-400 hover:text-neutral-600'
                      }`}
                      aria-label="Wishlist"
                    >
                      <Heart className="w-4 h-4" />
                    </button>

                    {/* Image Stage */}
                    <div
                      onClick={() => navigateTo('product', { id: product.id })}
                      className="aspect-[3/4] relative w-full overflow-hidden bg-neutral-50 dark:bg-neutral-900/50 cursor-pointer border-b border-neutral-100 dark:border-neutral-900"
                    >
                      <img
                        src={product.images[0]}
                        alt={product.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                      />
                      
                      {/* Image Zoom / Quick view triggers */}
                      <div className="absolute inset-0 bg-black/10 dark:bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center p-4">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setQuickViewProduct(product);
                          }}
                          className="w-full bg-white/95 dark:bg-neutral-900/95 backdrop-blur-md text-neutral-850 dark:text-white hover:text-[#C19A6B] py-2.5 px-4 rounded-lg text-[11px] font-bold tracking-widest uppercase transition flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Quick View</span>
                        </button>
                      </div>

                      {/* Badges */}
                      <div className="absolute top-3 left-3 flex flex-col gap-1">
                        {product.isNew && (
                          <span className="bg-[#C19A6B] text-white text-[9px] font-bold tracking-widest uppercase px-2.5 py-1 rounded-full shadow-sm">
                            New
                          </span>
                        )}
                        {product.discountBadge && (
                          <span className="bg-red-500 text-white text-[9px] font-bold tracking-widest uppercase px-2.5 py-1 rounded-full shadow-sm">
                            {product.discountBadge}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Product Metadata */}
                    <div className="p-4 flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between text-[10px] tracking-wider text-[#C19A6B] uppercase font-bold">
                          <span>{product.brand}</span>
                          <span className="text-neutral-400 dark:text-neutral-550 font-light">
                            {product.subCategory || product.category}
                          </span>
                        </div>

                        <h4
                          onClick={() => navigateTo('product', { id: product.id })}
                          className="text-xs sm:text-sm font-semibold text-neutral-800 dark:text-neutral-100 hover:text-[#C19A6B] transition-colors mt-1.5 cursor-pointer line-clamp-1"
                        >
                          {product.name}
                        </h4>

                        {/* Stars */}
                        <div className="flex items-center gap-1.5 mt-2">
                          <div className="flex items-center gap-0.5">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`w-3 h-3 ${
                                  i < Math.floor(product.rating) ? 'fill-[#C19A6B] text-[#C19A6B]' : 'text-neutral-200 dark:text-neutral-800'
                                }`}
                              />
                            ))}
                          </div>
                          <span className="text-[10px] text-neutral-450 dark:text-neutral-500 font-mono">
                            ({product.reviewsCount})
                          </span>
                        </div>
                      </div>

                      {/* Footer Actions */}
                      <div className="flex items-center justify-between mt-4 pt-3 border-t border-neutral-100/60 dark:border-neutral-900/60">
                        <div className="flex items-baseline gap-2">
                          <span className="text-sm font-bold font-mono text-neutral-850 dark:text-neutral-100">
                            ${product.price}
                          </span>
                          {product.originalPrice && (
                            <span className="text-[11px] font-light font-mono text-neutral-400 line-through">
                              ${product.originalPrice}
                            </span>
                          )}
                        </div>
                        
                        <button
                          onClick={() => setQuickViewProduct(product)}
                          className="text-xs font-semibold text-[#C19A6B] hover:text-[#A17C52] transition flex items-center gap-1"
                        >
                          <span>Options</span>
                          <ChevronDown className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Pagination Controls */}
          {totalPages > 1 && (
            <div className="flex justify-center items-center gap-2 pt-6 border-t border-neutral-100 dark:border-neutral-900">
              <button
                disabled={currentPage === 1}
                onClick={() => {
                  triggerLoading();
                  setCurrentPage((prev) => Math.max(1, prev - 1));
                }}
                className="p-2 border border-neutral-200 dark:border-neutral-800 text-xs font-semibold rounded-md hover:bg-neutral-50 dark:hover:bg-neutral-850/20 disabled:opacity-40 transition cursor-pointer"
              >
                &larr; Prev
              </button>
              {[...Array(totalPages)].map((_, i) => {
                const page = i + 1;
                return (
                  <button
                    key={page}
                    onClick={() => {
                      triggerLoading();
                      setCurrentPage(page);
                    }}
                    className={`w-9 h-9 rounded-md text-xs font-semibold border transition ${
                      currentPage === page
                        ? 'bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 border-neutral-900 dark:border-white font-bold'
                        : 'bg-white dark:bg-neutral-800 border-neutral-200 dark:border-neutral-700 text-neutral-600 dark:text-neutral-400 hover:border-neutral-400'
                    }`}
                  >
                    {page}
                  </button>
                );
              })}
              <button
                disabled={currentPage === totalPages}
                onClick={() => {
                  triggerLoading();
                  setCurrentPage((prev) => Math.min(totalPages, prev + 1));
                }}
                className="p-2 border border-neutral-200 dark:border-neutral-800 text-xs font-semibold rounded-md hover:bg-neutral-50 dark:hover:bg-neutral-850/20 disabled:opacity-40 transition cursor-pointer"
              >
                Next &rarr;
              </button>
            </div>
          )}

        </div>

      </div>

      {/* Slide-out filters for Mobile Devices */}
      {isMobileFiltersOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden lg:hidden">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setIsMobileFiltersOpen(false)} />
          <div className="absolute inset-y-0 right-0 pl-10 max-w-full flex">
            <div className="w-screen max-w-xs bg-white dark:bg-[#121214] border-l border-neutral-200 dark:border-neutral-900 flex flex-col shadow-2xl h-full p-6 space-y-6 overflow-y-auto">
              <div className="flex items-center justify-between border-b border-neutral-100 dark:border-neutral-900 pb-4">
                <span className="text-xs font-extrabold uppercase tracking-wider text-neutral-850 dark:text-white">Filter Collection</span>
                <button onClick={() => setIsMobileFiltersOpen(false)} className="text-neutral-400">
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Mobile search */}
              <div className="space-y-1.5">
                <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">Search</span>
                <input
                  type="text"
                  placeholder="Keywords..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2 px-3 w-full text-neutral-800 dark:text-white focus:outline-none"
                />
              </div>

              {/* Mobile categories list */}
              <div className="space-y-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">Department</span>
                <div className="flex flex-col gap-1.5 text-xs">
                  <button
                    onClick={() => {
                      handleCategorySelect('all');
                      setIsMobileFiltersOpen(false);
                    }}
                    className={`text-left py-1 px-2.5 rounded ${
                      selectedCategory === 'all' ? 'bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 font-bold' : 'text-neutral-600 dark:text-neutral-400'
                    }`}
                  >
                    All Departments ({PRODUCTS.length})
                  </button>
                  {CATEGORIES.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => {
                        handleCategorySelect(cat.id);
                        setIsMobileFiltersOpen(false);
                      }}
                      className={`text-left py-1 px-2.5 rounded ${
                        selectedCategory === cat.id ? 'bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 font-bold' : 'text-neutral-600 dark:text-neutral-400'
                      }`}
                    >
                      {cat.name} ({PRODUCTS.filter((p) => p.category === cat.id).length})
                    </button>
                  ))}
                </div>
              </div>

              {/* Mobile Brands */}
              <div className="space-y-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">Brand houses</span>
                <div className="space-y-1.5">
                  {brandsList.map((brand) => (
                    <label key={brand} className="flex items-center gap-2 text-xs text-neutral-600 dark:text-neutral-400">
                      <input
                        type="checkbox"
                        checked={selectedBrands.includes(brand)}
                        onChange={() => handleBrandToggle(brand)}
                        className="w-4 h-4 rounded border-neutral-300 text-[#C19A6B]"
                      />
                      <span>{brand}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Mobile pricing limit */}
              <div className="space-y-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">Max Price: ${priceRange}</span>
                <input
                  type="range"
                  min="20"
                  max="1200"
                  step="10"
                  value={priceRange}
                  onChange={(e) => handlePriceChange(Number(e.target.value))}
                  className="w-full accent-[#C19A6B]"
                />
              </div>

              {/* Action buttons */}
              <div className="pt-4 border-t border-neutral-100 dark:border-neutral-900 flex gap-2">
                <button
                  onClick={clearAllFilters}
                  className="flex-1 py-2 text-center text-xs font-semibold text-neutral-400 uppercase tracking-wider"
                >
                  Clear All
                </button>
                <button
                  onClick={() => setIsMobileFiltersOpen(false)}
                  className="flex-1 bg-[#C19A6B] text-white py-2 text-center text-xs font-bold rounded uppercase tracking-wider"
                >
                  Apply Filters
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
