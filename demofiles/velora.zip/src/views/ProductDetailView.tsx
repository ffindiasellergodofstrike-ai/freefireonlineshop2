/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { PRODUCTS, MOCK_REVIEWS } from '../data/mockData';
import { Product, ProductVariant, Review } from '../types';
import { Star, ShieldCheck, Truck, RefreshCw, ShoppingBag, Heart, CheckCircle2, ChevronRight, Eye, ThumbsUp } from 'lucide-react';

export const ProductDetailView: React.FC = () => {
  const {
    currentRouteParams,
    navigateTo,
    addToCart,
    toggleWishlist,
    isInWishlist,
    addToRecentlyViewed,
    recentlyViewed,
    setQuickViewProduct,
  } = useApp();

  const [product, setProduct] = useState<Product | null>(null);
  const [activeImage, setActiveImage] = useState('');
  const [selectedColor, setSelectedColor] = useState<ProductVariant | undefined>(undefined);
  const [selectedSize, setSelectedSize] = useState<ProductVariant | undefined>(undefined);
  const [quantity, setQuantity] = useState(1);
  const [reviews, setReviews] = useState<Review[]>(MOCK_REVIEWS);
  const [newReviewTitle, setNewReviewTitle] = useState('');
  const [newReviewComment, setNewReviewComment] = useState('');
  const [newReviewRating, setNewReviewRating] = useState(5);
  const [reviewSuccess, setReviewSuccess] = useState(false);

  // Load product based on currentRouteParams.id
  useEffect(() => {
    const id = currentRouteParams?.id || 'fashion-1';
    const found = PRODUCTS.find((p) => p.id === id);
    if (found) {
      setProduct(found);
      setActiveImage(found.images[0]);
      
      const colors = found.variants.filter((v) => v.type === 'color');
      const sizes = found.variants.filter((v) => v.type === 'size');
      
      setSelectedColor(colors.length > 0 ? colors[0] : undefined);
      setSelectedSize(sizes.length > 0 ? sizes[0] : undefined);
      setQuantity(1);
      
      // Add to recently viewed
      addToRecentlyViewed(found);
    }
  }, [currentRouteParams?.id]);

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-16 text-center">
        <h2 className="text-xl font-serif text-neutral-800 dark:text-white">Analyzing Product Credentials...</h2>
        <button onClick={() => navigateTo('shop')} className="mt-4 text-xs font-semibold text-[#C19A6B] tracking-wider uppercase">
          Return to Shop Boutique &rarr;
        </button>
      </div>
    );
  }

  const colors = product.variants.filter((v) => v.type === 'color');
  const sizes = product.variants.filter((v) => v.type === 'size');

  const getPrice = () => {
    let p = product.price;
    if (selectedColor?.priceOffset) p += selectedColor.priceOffset;
    if (selectedSize?.priceOffset) p += selectedSize.priceOffset;
    return p;
  };

  const handleAddToCart = () => {
    addToCart(product, quantity, selectedColor, selectedSize);
  };

  const handleBuyNow = () => {
    addToCart(product, quantity, selectedColor, selectedSize);
    navigateTo('checkout');
  };

  const handleHelpfulClick = (id: string) => {
    setReviews((prev) =>
      prev.map((r) => (r.id === id ? { ...r, helpfulCount: r.helpfulCount + 1 } : r))
    );
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newReviewComment.trim() && newReviewTitle.trim()) {
      const added: Review = {
        id: `rev-${Date.now()}`,
        userName: 'Guest Patron',
        rating: newReviewRating,
        date: new Date().toISOString().split('T')[0],
        title: newReviewTitle,
        comment: newReviewComment,
        verified: true,
        helpfulCount: 0,
      };
      setReviews([added, ...reviews]);
      setNewReviewTitle('');
      setNewReviewComment('');
      setReviewSuccess(true);
      setTimeout(() => setReviewSuccess(false), 3000);
    }
  };

  // Extract related products
  const relatedProducts = PRODUCTS.filter(
    (p) => p.category === product.category && p.id !== product.id
  ).slice(0, 4);

  return (
    <div id="product-detail-view" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
      
      {/* Breadcrumb path */}
      <div className="py-6 flex items-center gap-2 text-[11px] tracking-widest uppercase text-neutral-400 dark:text-neutral-500 font-semibold border-b border-neutral-100 dark:border-neutral-900/65">
        <button onClick={() => navigateTo('home')} className="hover:text-[#C19A6B] transition">Home</button>
        <span>/</span>
        <button onClick={() => navigateTo('shop')} className="hover:text-[#C19A6B] transition">Shop</button>
        <span>/</span>
        <button onClick={() => navigateTo('category', { id: product.category })} className="hover:text-[#C19A6B] transition">
          {product.category}
        </button>
        <span>/</span>
        <span className="text-neutral-700 dark:text-neutral-300 truncate">{product.name}</span>
      </div>

      {/* Primary Detail Block */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 mt-10">
        
        {/* Left column: Image Gallery stage (col span 7) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="aspect-[3/4] relative w-full overflow-hidden rounded-2xl bg-neutral-50 dark:bg-neutral-900/40 border border-neutral-100 dark:border-neutral-900">
            <img
              src={activeImage}
              alt={product.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            {product.discountBadge && (
              <span className="absolute top-4 left-4 bg-red-500 text-white text-[10px] font-bold tracking-widest uppercase px-3 py-1.5 rounded-full shadow-md">
                {product.discountBadge}
              </span>
            )}
          </div>

          {/* Thumbnail strip */}
          {product.images.length > 1 && (
            <div className="flex gap-3 overflow-x-auto py-1">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImage(img)}
                  className={`w-20 h-24 rounded-xl overflow-hidden border transition shrink-0 cursor-pointer ${
                    activeImage === img
                      ? 'border-[#C19A6B] ring-2 ring-[#C19A6B]/20'
                      : 'border-neutral-200 dark:border-neutral-800 opacity-75 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="Thumbnail details" referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right column: Action Information (col span 5) */}
        <div className="lg:col-span-5 space-y-8">
          
          {/* Headline details */}
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-[10px] font-extrabold tracking-widest text-[#C19A6B] uppercase">
              <span>{product.brand}</span>
              <span>•</span>
              <span>{product.subCategory || product.category}</span>
            </div>
            
            <h1 className="text-2xl sm:text-3xl font-serif font-extrabold text-neutral-900 dark:text-white leading-tight">
              {product.name}
            </h1>
            {product.tagline && (
              <p className="text-xs text-neutral-400 dark:text-neutral-550 italic font-light">{product.tagline}</p>
            )}

            {/* Stars rating stats */}
            <div className="flex items-center gap-3 pt-1">
              <div className="flex items-center gap-0.5">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${
                      i < Math.floor(product.rating) ? 'fill-[#C19A6B] text-[#C19A6B]' : 'text-neutral-200 dark:text-neutral-800'
                    }`}
                  />
                ))}
              </div>
              <span className="text-xs font-bold text-neutral-800 dark:text-neutral-200">{product.rating}</span>
              <span className="text-xs text-neutral-400 dark:text-neutral-500 font-light">({product.reviewsCount} customer reviews)</span>
            </div>
          </div>

          {/* Pricing tier */}
          <div className="flex items-baseline gap-3 pb-6 border-b border-neutral-100 dark:border-neutral-900">
            <span className="text-2xl sm:text-3xl font-extrabold font-mono text-neutral-900 dark:text-white">
              ${getPrice()}
            </span>
            {product.originalPrice && (
              <span className="text-base font-light font-mono text-neutral-400 line-through">
                ${product.originalPrice}
              </span>
            )}
          </div>

          {/* Editorial summaries */}
          <div className="space-y-4">
            <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 font-light leading-relaxed">
              {product.longDescription || product.description}
            </p>
          </div>

          {/* Configuration selections */}
          <div className="space-y-5 pt-6 border-t border-neutral-100 dark:border-neutral-900">
            {/* Colors */}
            {colors.length > 0 && (
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block mb-2">
                  Atelier Color: <strong className="text-neutral-850 dark:text-white font-semibold">{selectedColor?.name}</strong>
                </span>
                <div className="flex flex-wrap gap-3">
                  {colors.map((col) => (
                    <button
                      key={col.id}
                      onClick={() => setSelectedColor(col)}
                      className={`w-8 h-8 rounded-full flex items-center justify-center border transition relative cursor-pointer ${
                        selectedColor?.id === col.id
                          ? 'border-[#C19A6B] ring-2 ring-[#C19A6B]/25 scale-105'
                          : 'border-neutral-200 dark:border-neutral-800 hover:scale-105'
                      }`}
                    >
                      <span
                        className="w-6 h-6 rounded-full border border-black/5"
                        style={{ backgroundColor: col.value }}
                      />
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Sizes */}
            {sizes.length > 0 && (
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400 block mb-2">
                  Spec size: <strong className="text-neutral-850 dark:text-white font-semibold font-mono">{selectedSize?.name}</strong>
                </span>
                <div className="flex flex-wrap gap-2">
                  {sizes.map((sz) => (
                    <button
                      key={sz.id}
                      onClick={() => setSelectedSize(sz)}
                      className={`min-w-12 h-9 rounded-md text-xs font-semibold font-mono border transition flex items-center justify-center px-3.5 cursor-pointer ${
                        selectedSize?.id === sz.id
                          ? 'bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 border-neutral-900 dark:border-white'
                          : 'bg-white dark:bg-neutral-800 border-neutral-200 dark:border-neutral-700 text-neutral-600 dark:text-neutral-400 hover:border-neutral-400'
                      }`}
                    >
                      {sz.name}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Quantities & Purchase Controls */}
          <div className="pt-6 border-t border-neutral-100 dark:border-neutral-900 space-y-4">
            <div className="flex items-center gap-4">
              {/* Quantities input block */}
              <div className="flex items-center border border-neutral-200 dark:border-neutral-800 rounded-md py-2.5 px-3 bg-white dark:bg-neutral-900">
                <button
                  onClick={() => setQuantity((prev) => Math.max(1, prev - 1))}
                  className="text-neutral-400 hover:text-neutral-700 dark:hover:text-white text-sm"
                >
                  -
                </button>
                <span className="text-sm font-bold font-mono w-10 text-center text-neutral-800 dark:text-white">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity((prev) => prev + 1)}
                  className="text-neutral-400 hover:text-neutral-700 dark:hover:text-white text-sm"
                >
                  +
                </button>
              </div>

              {/* Add To Bag */}
              <button
                onClick={handleAddToCart}
                className="flex-1 bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 hover:bg-neutral-850 dark:hover:bg-neutral-100 py-3.5 px-4 rounded-lg text-xs font-bold tracking-widest uppercase transition flex items-center justify-center gap-2 cursor-pointer shadow-md"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Add to Bag</span>
              </button>

              {/* Wishlist triggers */}
              <button
                onClick={() => toggleWishlist(product)}
                className={`p-3.5 border rounded-lg transition cursor-pointer ${
                  isInWishlist(product.id)
                    ? 'border-red-200 bg-red-50 dark:bg-red-950/20 text-red-500'
                    : 'border-neutral-200 dark:border-neutral-850 text-neutral-400 hover:text-neutral-600'
                }`}
                aria-label="Wishlist"
              >
                <Heart className="w-5 h-5" />
              </button>
            </div>

            {/* Buy Now Direct */}
            <button
              onClick={handleBuyNow}
              className="w-full bg-[#C19A6B] hover:bg-[#A17C52] text-white py-3 px-4 rounded-lg text-xs font-bold tracking-widest uppercase transition cursor-pointer shadow-md"
            >
              Express Purchase / Buy Now
            </button>
          </div>

          {/* Certified Brand value anchors */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-6 border-t border-neutral-100 dark:border-neutral-900 text-[11px] text-neutral-550 dark:text-neutral-450">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#C19A6B]" />
              <span>Full Authenticity</span>
            </div>
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-[#C19A6B]" />
              <span>Complimentary Courier</span>
            </div>
            <div className="flex items-center gap-2">
              <RefreshCw className="w-4 h-4 text-[#C19A6B]" />
              <span>Free 30-Day Returns</span>
            </div>
          </div>

        </div>

      </div>

      {/* Detailed Specifications Specs Drawer/Section */}
      {product.features && (
        <section className="mt-20 pt-10 border-t border-neutral-100 dark:border-neutral-900 grid grid-cols-1 lg:grid-cols-12 gap-10">
          <div className="lg:col-span-5 space-y-4">
            <h3 className="text-lg font-serif font-bold text-neutral-900 dark:text-white">Bespoke Structural Details</h3>
            <p className="text-xs text-neutral-400 dark:text-neutral-500 font-light leading-relaxed">
              Every detail is designed with architectural discipline, ensuring exceptional durability and timeless aesthetics.
            </p>
            <ul className="space-y-3 pt-2">
              {product.features.map((feat, i) => (
                <li key={i} className="flex gap-2 text-xs text-neutral-600 dark:text-neutral-400 font-light items-start">
                  <CheckCircle2 className="w-4 h-4 text-[#C19A6B] shrink-0 mt-0.5" />
                  <span>{feat}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Specs Table */}
          {product.specs && (
            <div className="lg:col-span-7 bg-neutral-50 dark:bg-neutral-900/40 border border-neutral-100 dark:border-neutral-900/80 rounded-2xl p-6 sm:p-8">
              <span className="text-[10px] font-bold text-[#C19A6B] uppercase tracking-wider block mb-4">Product Specifications</span>
              <div className="divide-y divide-neutral-200/50 dark:divide-neutral-800/50 text-xs">
                {Object.entries(product.specs).map(([key, val]) => (
                  <div key={key} className="py-3 flex justify-between gap-4">
                    <span className="text-neutral-400 font-light">{key}</span>
                    <span className="text-neutral-850 dark:text-neutral-200 font-medium text-right">{val}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </section>
      )}

      {/* Product Reviews & Ratings Block */}
      <section className="mt-20 pt-10 border-t border-neutral-100 dark:border-neutral-900 grid grid-cols-1 lg:grid-cols-3 gap-12">
        
        {/* Left: Stats & Form */}
        <div className="space-y-6">
          <h3 className="text-xl font-serif font-bold text-neutral-900 dark:text-white">Customer Reviews</h3>
          <div className="flex items-center gap-4">
            <span className="text-4xl font-extrabold font-mono text-neutral-900 dark:text-white">{product.rating}</span>
            <div>
              <div className="flex items-center gap-0.5">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-4 h-4 ${
                      i < Math.floor(product.rating) ? 'fill-[#C19A6B] text-[#C19A6B]' : 'text-neutral-200 dark:text-neutral-800'
                    }`}
                  />
                ))}
              </div>
              <p className="text-xs text-neutral-400 dark:text-neutral-500 font-light mt-1">Based on {product.reviewsCount} reviews</p>
            </div>
          </div>

          {/* Review writing form */}
          <form onSubmit={handleReviewSubmit} className="space-y-4 bg-neutral-50 dark:bg-[#1A1A1E]/30 p-5 rounded-2xl border border-neutral-100 dark:border-neutral-900/80">
            <span className="text-xs font-bold text-neutral-850 dark:text-neutral-200 uppercase tracking-wider block">Write a Review</span>
            
            {reviewSuccess && (
              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-300 text-xs rounded-md border border-emerald-100 dark:border-emerald-900/30">
                Thank you! Your review has been logged.
              </div>
            )}

            {/* Stars picker */}
            <div>
              <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1.5">Your Rating</span>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setNewReviewRating(star)}
                    className="p-1 cursor-pointer"
                  >
                    <Star
                      className={`w-5 h-5 ${
                        star <= newReviewRating ? 'fill-[#C19A6B] text-[#C19A6B]' : 'text-neutral-300 dark:text-neutral-800'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1.5">Review Title</label>
              <input
                type="text"
                placeholder="Ex. Exquisite texture, fits true to size..."
                value={newReviewTitle}
                onChange={(e) => setNewReviewTitle(e.target.value)}
                className="w-full bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2.5 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white"
                required
              />
            </div>

            <div>
              <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1.5">Detailed Comment</label>
              <textarea
                rows={4}
                placeholder="Share your personal experience with material quality, tailoring, and fit..."
                value={newReviewComment}
                onChange={(e) => setNewReviewComment(e.target.value)}
                className="w-full bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2.5 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white resize-none"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full bg-neutral-900 hover:bg-neutral-850 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-neutral-950 py-2.5 text-xs font-bold tracking-widest uppercase rounded-md transition cursor-pointer"
            >
              Submit Review
            </button>
          </form>
        </div>

        {/* Right: Reviews List */}
        <div className="lg:col-span-2 space-y-6">
          <span className="text-xs font-bold text-[#C19A6B] uppercase tracking-wider block">Customer Testimonials</span>
          <div className="divide-y divide-neutral-200/50 dark:divide-neutral-850/50 space-y-6">
            {reviews.map((rev) => (
              <div key={rev.id} className="pt-6 first:pt-0 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-neutral-850 dark:text-white">{rev.userName}</span>
                    {rev.verified && (
                      <span className="inline-flex items-center gap-1 text-[9px] text-[#C19A6B] uppercase tracking-wider font-bold ml-2">
                        <CheckCircle2 className="w-3 h-3 text-[#C19A6B]" />
                        <span>Verified Buyer</span>
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] text-neutral-400 font-mono">{rev.date}</span>
                </div>

                {/* Rating stars */}
                <div className="flex items-center gap-0.5">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-3.5 h-3.5 ${
                        i < rev.rating ? 'fill-[#C19A6B] text-[#C19A6B]' : 'text-neutral-200 dark:text-neutral-850'
                      }`}
                    />
                  ))}
                </div>

                <div className="space-y-1">
                  <h5 className="text-xs font-bold text-neutral-850 dark:text-neutral-200">{rev.title}</h5>
                  <p className="text-xs text-neutral-500 dark:text-neutral-450 font-light leading-relaxed">{rev.comment}</p>
                </div>

                {/* Helpful count */}
                <div className="flex items-center gap-2 pt-1 text-[10px] text-neutral-400">
                  <span>Was this review helpful?</span>
                  <button
                    onClick={() => handleHelpfulClick(rev.id)}
                    className="flex items-center gap-1.5 hover:text-[#C19A6B] transition py-0.5 px-2 rounded border border-neutral-200/50 dark:border-neutral-800 cursor-pointer"
                  >
                    <ThumbsUp className="w-3 h-3" />
                    <span>Helpful ({rev.helpfulCount})</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

      </section>

      {/* Related / Recommended Carousel */}
      {relatedProducts.length > 0 && (
        <section className="mt-24 pt-10 border-t border-neutral-100 dark:border-neutral-900">
          <div className="mb-8">
            <span className="text-xs font-bold text-[#C19A6B] uppercase tracking-wider block">Coordinated Curation</span>
            <h2 className="text-xl sm:text-2xl font-serif font-bold text-neutral-900 dark:text-white mt-1">You May Also Appreciate</h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {relatedProducts.map((related) => {
              const isFav = isInWishlist(related.id);
              return (
                <div
                  key={related.id}
                  className="group relative flex flex-col bg-white dark:bg-[#1A1A1E]/40 border border-neutral-100 dark:border-neutral-900 rounded-xl overflow-hidden transition duration-300 hover:shadow-lg"
                >
                  <button
                    onClick={() => toggleWishlist(related)}
                    className={`absolute top-2.5 right-2.5 z-10 p-2 bg-white/95 dark:bg-neutral-900/95 backdrop-blur-md rounded-full border transition cursor-pointer shadow-sm ${
                      isFav ? 'border-red-100 text-red-500' : 'border-neutral-200/40 text-neutral-400'
                    }`}
                  >
                    <Heart className="w-3.5 h-3.5" />
                  </button>
                  <div
                    onClick={() => navigateTo('product', { id: related.id })}
                    className="aspect-[3/4] overflow-hidden bg-neutral-50 dark:bg-neutral-900/40 cursor-pointer"
                  >
                    <img
                      src={related.images[0]}
                      alt={related.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-102 transition duration-500"
                    />
                  </div>
                  <div className="p-3.5 flex-1 flex flex-col justify-between">
                    <div>
                      <span className="text-[9px] font-bold text-[#C19A6B] uppercase tracking-wider">{related.brand}</span>
                      <h4
                        onClick={() => navigateTo('product', { id: related.id })}
                        className="text-xs font-semibold text-neutral-800 dark:text-neutral-100 hover:text-[#C19A6B] transition-colors mt-0.5 cursor-pointer line-clamp-1"
                      >
                        {related.name}
                      </h4>
                    </div>
                    <div className="flex justify-between items-baseline mt-3 border-t border-neutral-100/60 dark:border-neutral-900/60 pt-2 text-xs">
                      <span className="font-bold font-mono text-neutral-850 dark:text-neutral-100">${related.price}</span>
                      <button
                        onClick={() => setQuickViewProduct(related)}
                        className="text-[10px] font-bold text-[#C19A6B] hover:text-[#A17C52] uppercase tracking-wider"
                      >
                        Quick Add
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Recently Viewed Strip */}
      {recentlyViewed.length > 1 && (
        <section className="mt-20 pt-10 border-t border-neutral-100 dark:border-neutral-900">
          <div className="mb-6 flex justify-between items-center">
            <h3 className="text-sm font-bold uppercase tracking-widest text-neutral-400 dark:text-neutral-500">Recently Viewed</h3>
          </div>
          <div className="flex gap-4 overflow-x-auto py-2">
            {recentlyViewed
              .filter((p) => p.id !== product.id)
              .map((recent) => (
                <div
                  key={recent.id}
                  onClick={() => navigateTo('product', { id: recent.id })}
                  className="flex gap-3 p-2 rounded-xl bg-neutral-50 dark:bg-[#1A1A1E]/20 border border-neutral-200/30 dark:border-neutral-800/60 hover:bg-white dark:hover:bg-neutral-850/20 shadow-sm cursor-pointer transition shrink-0 w-64 items-center"
                >
                  <img
                    src={recent.images[0]}
                    alt={recent.name}
                    referrerPolicy="no-referrer"
                    className="w-12 h-16 object-cover rounded-lg bg-white border border-neutral-200/50"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="text-[9px] font-bold text-[#C19A6B] uppercase tracking-wider">{recent.brand}</p>
                    <h4 className="text-xs font-semibold text-neutral-800 dark:text-neutral-100 truncate mt-0.5">{recent.name}</h4>
                    <span className="text-xs font-mono font-bold text-neutral-950 dark:text-white mt-1.5 block">${recent.price}</span>
                  </div>
                </div>
              ))}
          </div>
        </section>
      )}

    </div>
  );
};
