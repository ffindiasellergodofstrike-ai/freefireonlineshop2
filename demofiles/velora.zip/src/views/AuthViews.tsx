/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Mail, Key, User, ShieldCheck, ArrowRight, Lock } from 'lucide-react';

/* ==========================================================================
   1. LOGIN VIEW
   ========================================================================== */
export const LoginView: React.FC = () => {
  const { loginUser, navigateTo, addToast } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && password) {
      const ok = loginUser(email, password);
      if (ok) {
        navigateTo('home');
      }
    }
  };

  const handleQuickLogin = () => {
    setEmail('jane@example.com');
    setPassword('password123');
    addToast('Prefilled Jane Doe credentials!', 'success');
  };

  return (
    <div id="login-view" className="max-w-md mx-auto px-4 py-16 space-y-6">
      <div className="text-center space-y-1.5">
        <span className="text-xs font-bold text-[#C19A6B] uppercase tracking-widest block">Atelier Member Access</span>
        <h1 className="text-2xl font-serif font-extrabold text-neutral-900 dark:text-white">Welcome Back</h1>
        <p className="text-xs text-neutral-400 dark:text-neutral-500 font-light">Sign in to track orders and save your boutique coordinates.</p>
      </div>

      <div className="bg-white dark:bg-[#1A1A1E]/30 p-6 sm:p-8 rounded-2xl border border-neutral-150/60 dark:border-neutral-900 shadow-sm space-y-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">Email Address</label>
            <div className="relative flex items-center bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md">
              <Mail className="w-4 h-4 text-neutral-400 absolute left-3" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-transparent border-none text-xs focus:ring-0 outline-none w-full py-2.5 pl-9 pr-3 text-neutral-850 dark:text-white"
                placeholder="jane@example.com"
                required
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">Password</label>
              <button
                type="button"
                onClick={() => navigateTo('forgot-password')}
                className="text-[10px] text-neutral-400 hover:text-[#C19A6B] transition font-bold uppercase tracking-wide cursor-pointer"
              >
                Forgot?
              </button>
            </div>
            <div className="relative flex items-center bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md">
              <Key className="w-4 h-4 text-neutral-400 absolute left-3" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-transparent border-none text-xs focus:ring-0 outline-none w-full py-2.5 pl-9 pr-3 text-neutral-850 dark:text-white"
                placeholder="••••••••"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-[#121214] dark:bg-white text-white dark:text-[#121214] hover:bg-neutral-850 dark:hover:bg-neutral-100 text-xs py-3.5 px-4 rounded-lg font-bold tracking-widest uppercase transition flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
          >
            <span>Sign In</span>
            <ArrowRight className="w-3.5 h-3.5 text-[#C19A6B]" />
          </button>
        </form>

        {/* Quick Demo Login */}
        <div className="border-t border-neutral-100 dark:border-neutral-800 pt-4 text-center">
          <button
            type="button"
            onClick={handleQuickLogin}
            className="text-[10px] text-[#C19A6B] hover:underline font-bold uppercase tracking-wider"
          >
            ⚡ Quick Demo Login (Jane Doe)
          </button>
        </div>
      </div>

      <p className="text-center text-xs text-neutral-400">
        Don't have an account?{' '}
        <button onClick={() => navigateTo('register')} className="text-[#C19A6B] hover:underline font-semibold cursor-pointer">
          Register here &rarr;
        </button>
      </p>
    </div>
  );
};

/* ==========================================================================
   2. REGISTER VIEW
   ========================================================================== */
export const RegisterView: React.FC = () => {
  const { registerUser, navigateTo } = useApp();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && email && password) {
      registerUser(name, email, password);
      navigateTo('home');
    }
  };

  return (
    <div id="register-view" className="max-w-md mx-auto px-4 py-16 space-y-6">
      <div className="text-center space-y-1.5">
        <span className="text-xs font-bold text-[#C19A6B] uppercase tracking-widest block">Atelier Sourcing Credentials</span>
        <h1 className="text-2xl font-serif font-extrabold text-neutral-900 dark:text-white">Create Member Account</h1>
        <p className="text-xs text-neutral-400 dark:text-neutral-550 font-light">Join Velora to receive limited drops newsletters and trace invoices.</p>
      </div>

      <div className="bg-white dark:bg-[#1A1A1E]/30 p-6 sm:p-8 rounded-2xl border border-neutral-150/65 dark:border-neutral-900 shadow-sm">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">Full Name</label>
            <div className="relative flex items-center bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md">
              <User className="w-4 h-4 text-neutral-400 absolute left-3" />
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="bg-transparent border-none text-xs focus:ring-0 outline-none w-full py-2.5 pl-9 pr-3 text-neutral-850 dark:text-white"
                placeholder="Jane Doe"
                required
              />
            </div>
          </div>

          <div>
            <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">Email Address</label>
            <div className="relative flex items-center bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md">
              <Mail className="w-4 h-4 text-neutral-400 absolute left-3" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-transparent border-none text-xs focus:ring-0 outline-none w-full py-2.5 pl-9 pr-3 text-neutral-850 dark:text-white"
                placeholder="jane@example.com"
                required
              />
            </div>
          </div>

          <div>
            <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">Create Password</label>
            <div className="relative flex items-center bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md">
              <Key className="w-4 h-4 text-neutral-400 absolute left-3" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-transparent border-none text-xs focus:ring-0 outline-none w-full py-2.5 pl-9 pr-3 text-neutral-850 dark:text-white"
                placeholder="••••••••"
                required
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-neutral-900 hover:bg-neutral-850 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-neutral-950 text-xs py-3.5 px-4 rounded-lg font-bold tracking-widest uppercase transition flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
          >
            <span>Register Account</span>
            <ArrowRight className="w-3.5 h-3.5 text-[#C19A6B]" />
          </button>
        </form>
      </div>

      <p className="text-center text-xs text-neutral-400">
        Already registered?{' '}
        <button onClick={() => navigateTo('login')} className="text-[#C19A6B] hover:underline font-semibold cursor-pointer">
          Sign in here &rarr;
        </button>
      </p>
    </div>
  );
};

/* ==========================================================================
   3. FORGOT PASSWORD VIEW
   ========================================================================== */
export const ForgotPasswordView: React.FC = () => {
  const { navigateTo, addToast } = useApp();
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubmitted(true);
      addToast('Reset credentials dispatched successfully!', 'success');
    }
  };

  return (
    <div id="forgot-password-view" className="max-w-md mx-auto px-4 py-16 space-y-6">
      <div className="text-center space-y-1.5">
        <span className="text-xs font-bold text-[#C19A6B] uppercase tracking-widest block">Security Recovery</span>
        <h1 className="text-2xl font-serif font-extrabold text-neutral-900 dark:text-white">Recover Password</h1>
        <p className="text-xs text-neutral-400 dark:text-neutral-550 font-light">Input your verified address, and we will dispatch a reset coordinate link.</p>
      </div>

      <div className="bg-white dark:bg-[#1A1A1E]/30 p-6 sm:p-8 rounded-2xl border border-neutral-150/65 dark:border-neutral-900 shadow-sm space-y-4">
        {submitted ? (
          <div className="space-y-4 text-center py-4">
            <div className="inline-flex p-3 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-100 text-emerald-600 rounded-full mb-2">
              <ShieldCheck className="w-8 h-8" />
            </div>
            <p className="text-xs text-neutral-500 leading-relaxed font-light">
              An encryption key and password reset link has been dispatched to <strong>{email}</strong>. Check your inbox and click the authentication token.
            </p>
            <button
              onClick={() => navigateTo('login')}
              className="mt-4 bg-[#C19A6B] text-white text-xs font-bold uppercase tracking-widest py-2.5 px-6 rounded-md"
            >
              Back to Login
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">Registered Email Address</label>
              <div className="relative flex items-center bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-850 rounded-md">
                <Mail className="w-4 h-4 text-neutral-400 absolute left-3" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-transparent border-none text-xs focus:ring-0 outline-none w-full py-2.5 pl-9 pr-3 text-neutral-850 dark:text-white"
                  placeholder="jane@example.com"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-neutral-900 hover:bg-neutral-850 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-neutral-950 text-xs py-3 px-4 rounded-lg font-bold tracking-widest uppercase transition flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span>Dispatch Recovery Link</span>
            </button>
          </form>
        )}
      </div>

      <p className="text-center text-xs text-neutral-400">
        Remember your password?{' '}
        <button onClick={() => navigateTo('login')} className="text-[#C19A6B] hover:underline font-semibold cursor-pointer">
          Sign in here &rarr;
        </button>
      </p>
    </div>
  );
};
