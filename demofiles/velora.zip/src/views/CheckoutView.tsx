/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { ShippingAddress, Order } from '../types';
import { ShieldCheck, Truck, CreditCard, CheckCircle2, Ticket, MapPin, Sparkles, ShoppingBag, Plus, ArrowRight, Clipboard } from 'lucide-react';

export const CheckoutView: React.FC = () => {
  const {
    cart,
    cartTotal,
    shippingAddresses,
    addAddress,
    activeCoupon,
    applyCoupon,
    removeCoupon,
    placeOrder,
    navigateTo,
    addToast
  } = useApp();

  const [checkoutStep, setCheckoutStep] = useState<'details' | 'payment' | 'success'>('details');
  const [selectedAddressId, setSelectedAddressId] = useState(shippingAddresses[0]?.id || '');
  const [paymentMethod, setPaymentMethod] = useState('Credit Card (Visa ending in 4242)');
  const [placedOrder, setPlacedOrder] = useState<Order | null>(null);

  // Address creation form
  const [isAddingAddress, setIsAddingAddress] = useState(false);
  const [newFullName, setNewFullName] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newAddressLine1, setNewAddressLine1] = useState('');
  const [newCity, setNewCity] = useState('');
  const [newState, setNewState] = useState('');
  const [newPostalCode, setNewPostalCode] = useState('');
  const [newCountry, setNewCountry] = useState('United States');

  // Coupon promo state
  const [promoCode, setPromoCode] = useState('');

  // Payment form simulation
  const [cardName, setCardName] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCVV, setCardCVV] = useState('');

  const calculatedDiscount = () => {
    if (!activeCoupon) return 0;
    if (activeCoupon.type === 'percentage') {
      return Number((cartTotal * (activeCoupon.value / 100)).toFixed(2));
    }
    return activeCoupon.value;
  };

  const finalTotal = () => {
    const ship = cartTotal > 150 ? 0 : 15;
    const tax = Number((cartTotal * 0.08).toFixed(2));
    return Number((cartTotal + ship + tax - calculatedDiscount()).toFixed(2));
  };

  const handleAddAddressSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newFullName && newAddressLine1 && newCity && newPostalCode) {
      addAddress({
        fullName: newFullName,
        phone: newPhone,
        addressLine1: newAddressLine1,
        city: newCity,
        state: newState,
        postalCode: newPostalCode,
        country: newCountry,
        isDefault: shippingAddresses.length === 0,
      });

      // Clear fields
      setNewFullName('');
      setNewPhone('');
      setNewAddressLine1('');
      setNewCity('');
      setNewState('');
      setNewPostalCode('');
      setIsAddingAddress(false);
    }
  };

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    if (promoCode) {
      applyCoupon(promoCode);
      setPromoCode('');
    }
  };

  const handlePlaceOrderSubmit = () => {
    const address = shippingAddresses.find((a) => a.id === selectedAddressId) || shippingAddresses[0];
    if (!address) {
      addToast('Please select or configure a shipping address', 'error');
      return;
    }

    const order = placeOrder(address, paymentMethod);
    if (order) {
      setPlacedOrder(order);
      setCheckoutStep('success');
    }
  };

  if (checkoutStep === 'success' && placedOrder) {
    return (
      <div id="checkout-success" className="max-w-3xl mx-auto px-4 py-16 text-center space-y-8">
        
        {/* Animated Check badge */}
        <div className="inline-flex p-5 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900 rounded-full text-emerald-600 dark:text-emerald-400">
          <CheckCircle2 className="w-12 h-12" />
        </div>

        <div>
          <span className="text-xs font-bold text-[#C19A6B] uppercase tracking-widest block">Transaction authorized</span>
          <h1 className="text-3xl font-serif font-extrabold text-neutral-900 dark:text-white mt-1.5 leading-snug">
            Your Bespoke Order is Placed
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 font-light max-w-md mx-auto mt-2 leading-relaxed">
            Thank you for shopping at Velora Boutique. Your order has been securely logged under invoice number: 
            <strong className="text-neutral-850 dark:text-white font-mono block text-sm mt-1">{placedOrder.id}</strong>
          </p>
        </div>

        {/* Invoice Summary Card */}
        <div className="bg-neutral-50 dark:bg-[#1A1A1E]/30 rounded-2xl border border-neutral-150/60 dark:border-neutral-900 p-6 text-left space-y-4">
          <span className="text-[10px] font-bold tracking-widest text-[#C19A6B] uppercase block">Bespoke Invoice Summary</span>
          
          <div className="divide-y divide-neutral-200/50 dark:divide-neutral-800/50 text-xs text-neutral-600 dark:text-neutral-400 space-y-3.5">
            {placedOrder.items.map((item, index) => (
              <div key={index} className="pt-3.5 flex gap-4 first:pt-0">
                <img src={item.productImage} alt={item.productName} referrerPolicy="no-referrer" className="w-12 h-16 object-cover rounded-lg bg-white border" />
                <div className="min-w-0 flex-1">
                  <h4 className="font-semibold text-neutral-850 dark:text-neutral-100 truncate">{item.productName}</h4>
                  <p className="text-[10px] font-mono mt-0.5">
                    Qty: {item.quantity} • {item.selectedColor || 'Default'} • {item.selectedSize || 'Default'}
                  </p>
                </div>
                <span className="font-mono font-bold text-neutral-900 dark:text-white">${item.price * item.quantity}</span>
              </div>
            ))}
          </div>

          <hr className="border-neutral-200 dark:border-neutral-800" />

          {/* Calculations */}
          <div className="text-xs text-neutral-500 dark:text-neutral-400 space-y-2">
            <div className="flex justify-between">
              <span>Invoice Subtotal</span>
              <span className="font-mono">${placedOrder.subtotal}</span>
            </div>
            {placedOrder.discount > 0 && (
              <div className="flex justify-between text-emerald-600 dark:text-emerald-400">
                <span>Promotional Savings</span>
                <span className="font-mono">-${placedOrder.discount}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span>Luxury Shipping Courier</span>
              <span className="font-mono">{placedOrder.shipping === 0 ? 'Complimentary' : `$${placedOrder.shipping}`}</span>
            </div>
            <div className="flex justify-between font-semibold text-neutral-850 dark:text-white">
              <span>Total Debited Amount</span>
              <span className="font-mono font-bold text-base">${placedOrder.total}</span>
            </div>
          </div>
        </div>

        {/* Live Order tracking flow preview */}
        <div className="bg-white dark:bg-[#121214] border border-neutral-150 dark:border-neutral-850 p-6 rounded-2xl text-left space-y-6">
          <span className="text-[10px] font-bold tracking-widest text-[#C19A6B] uppercase block">Current Tracking Node</span>
          
          <div className="relative border-l-2 border-[#C19A6B]/20 ml-3.5 pl-6 space-y-6">
            {placedOrder.trackingSteps?.map((step, idx) => (
              <div key={idx} className="relative">
                <div className={`absolute -left-[31px] top-0.5 w-4.5 h-4.5 rounded-full border-2 flex items-center justify-center transition ${
                  step.completed
                    ? 'bg-[#C19A6B] border-[#C19A6B] text-white'
                    : 'bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 text-neutral-400'
                }`}>
                  {step.completed && <CheckCircle2 className="w-3.5 h-3.5" />}
                </div>
                <div>
                  <h4 className={`text-xs font-bold ${step.active ? 'text-[#C19A6B]' : 'text-neutral-800 dark:text-neutral-200'}`}>
                    {step.title}
                  </h4>
                  <p className="text-[11px] text-neutral-400 dark:text-neutral-500 mt-1 font-light leading-relaxed">{step.description}</p>
                  <span className="text-[9px] font-mono text-neutral-400 block mt-1">{step.date}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 justify-center pt-4">
          <button
            onClick={() => navigateTo('my-account', { tab: 'orders' })}
            className="bg-[#121214] dark:bg-white text-white dark:text-[#121214] py-3.5 px-6 rounded-lg text-xs font-bold tracking-widest uppercase transition cursor-pointer"
          >
            Go to My Orders
          </button>
          <button
            onClick={() => navigateTo('shop')}
            className="border border-neutral-200 dark:border-neutral-800 py-3.5 px-6 rounded-lg text-xs font-bold tracking-widest uppercase transition text-neutral-600 dark:text-neutral-400 hover:bg-neutral-50 dark:hover:bg-neutral-900 cursor-pointer"
          >
            Continue Shopping
          </button>
        </div>

      </div>
    );
  }

  if (cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-16 text-center">
        <h2 className="text-xl font-serif text-neutral-800 dark:text-white">Empty Checkout credentials</h2>
        <button onClick={() => navigateTo('shop')} className="mt-4 text-xs font-semibold text-[#C19A6B] tracking-wider uppercase">
          Go To Boutique Catalog &rarr;
        </button>
      </div>
    );
  }

  return (
    <div id="checkout-view" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
      
      {/* Title */}
      <div className="py-8 border-b border-neutral-100 dark:border-neutral-900">
        <span className="text-xs font-bold text-[#C19A6B] uppercase tracking-widest block">Secure Payment Gateway</span>
        <h1 className="text-3xl font-serif font-extrabold text-neutral-900 dark:text-white mt-1.5 leading-snug">
          Bespoke Checkout Portal
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 mt-8 items-start">
        
        {/* Left column: Billing/Form stages (col span 7) */}
        <div className="lg:col-span-7 space-y-8">
          
          {/* Step 1: Shipping Addresses */}
          <div className="bg-white dark:bg-[#1A1A1E]/30 border border-neutral-150/65 dark:border-neutral-900 p-6 rounded-2xl space-y-6">
            <div className="flex items-center justify-between border-b border-neutral-100 dark:border-neutral-900 pb-3">
              <span className="text-xs font-extrabold tracking-widest text-neutral-850 dark:text-white uppercase flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#C19A6B]" />
                <span>1. Shipping Credentials</span>
              </span>
              
              {!isAddingAddress && (
                <button
                  onClick={() => setIsAddingAddress(true)}
                  className="text-xs font-bold text-[#C19A6B] hover:text-[#A17C52] cursor-pointer flex items-center gap-1 uppercase tracking-wider"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add New</span>
                </button>
              )}
            </div>

            {isAddingAddress ? (
              /* Add New Address Form */
              <form onSubmit={handleAddAddressSubmit} className="space-y-4">
                <span className="text-xs font-bold text-[#C19A6B] uppercase tracking-wider block">New Courier Destination</span>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2 sm:col-span-1">
                    <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">Full Name</label>
                    <input
                      type="text"
                      value={newFullName}
                      onChange={(e) => setNewFullName(e.target.value)}
                      className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2.5 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white"
                      placeholder="Ex. Jane Doe..."
                      required
                    />
                  </div>
                  <div className="col-span-2 sm:col-span-1">
                    <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">Phone Number</label>
                    <input
                      type="text"
                      value={newPhone}
                      onChange={(e) => setNewPhone(e.target.value)}
                      className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2.5 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white"
                      placeholder="Ex. +1 (555) 012-3456..."
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">Address Line 1</label>
                  <input
                    type="text"
                    value={newAddressLine1}
                    onChange={(e) => setNewAddressLine1(e.target.value)}
                    className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2.5 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white"
                    placeholder="Ex. 742 Evergreen Terrace..."
                    required
                  />
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="col-span-3 sm:col-span-1">
                    <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">City</label>
                    <input
                      type="text"
                      value={newCity}
                      onChange={(e) => setNewCity(e.target.value)}
                      className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2.5 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white"
                      placeholder="Springfield..."
                      required
                    />
                  </div>
                  <div className="col-span-3 sm:col-span-1">
                    <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">State</label>
                    <input
                      type="text"
                      value={newState}
                      onChange={(e) => setNewState(e.target.value)}
                      className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2.5 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white"
                      placeholder="OR..."
                      required
                    />
                  </div>
                  <div className="col-span-3 sm:col-span-1">
                    <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">ZIP / Postal Code</label>
                    <input
                      type="text"
                      value={newPostalCode}
                      onChange={(e) => setNewPostalCode(e.target.value)}
                      className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2.5 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white"
                      placeholder="97477..."
                      required
                    />
                  </div>
                </div>

                <div className="flex gap-2.5 pt-2">
                  <button
                    type="submit"
                    className="bg-[#C19A6B] hover:bg-[#A17C52] text-white text-xs py-2.5 px-5 rounded font-bold uppercase cursor-pointer"
                  >
                    Save Address
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsAddingAddress(false)}
                    className="border border-neutral-200 dark:border-neutral-800 hover:bg-neutral-100 text-xs py-2.5 px-5 rounded text-neutral-600 dark:text-neutral-400 cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            ) : shippingAddresses.length === 0 ? (
              <div className="text-center py-4">
                <p className="text-xs text-neutral-400 font-light">No shipping addresses configured. Please add one to continue.</p>
                <button
                  onClick={() => setIsAddingAddress(true)}
                  className="mt-3 bg-[#C19A6B] text-white text-xs font-bold uppercase py-2 px-4 rounded"
                >
                  Create Shipping Address
                </button>
              </div>
            ) : (
              /* Address picker Checklist */
              <div className="space-y-3">
                {shippingAddresses.map((addr) => (
                  <label
                    key={addr.id}
                    className={`flex items-start gap-4 p-4 rounded-xl border cursor-pointer transition ${
                      selectedAddressId === addr.id
                        ? 'border-[#C19A6B] bg-[#C19A6B]/5'
                        : 'border-neutral-150 dark:border-neutral-900 hover:bg-neutral-50 dark:hover:bg-neutral-850/15'
                    }`}
                  >
                    <input
                      type="radio"
                      name="shippingAddress"
                      value={addr.id}
                      checked={selectedAddressId === addr.id}
                      onChange={() => setSelectedAddressId(addr.id)}
                      className="mt-1 text-[#C19A6B] focus:ring-[#C19A6B] cursor-pointer"
                    />
                    <div className="text-xs space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-neutral-850 dark:text-white">{addr.fullName}</span>
                        {addr.isDefault && (
                          <span className="bg-[#C19A6B]/15 text-[#C19A6B] text-[8px] font-extrabold uppercase px-1.5 py-0.5 rounded tracking-wide">
                            Default
                          </span>
                        )}
                      </div>
                      <p className="text-neutral-500 dark:text-neutral-400 font-light">{addr.addressLine1}, {addr.city}, {addr.state} {addr.postalCode}</p>
                      <p className="text-[10px] text-neutral-400 dark:text-neutral-500 font-mono">{addr.phone}</p>
                    </div>
                  </label>
                ))}
              </div>
            )}
          </div>

          {/* Step 2: Payment Methods */}
          <div className="bg-white dark:bg-[#1A1A1E]/30 border border-neutral-150/65 dark:border-neutral-900 p-6 rounded-2xl space-y-6">
            <span className="text-xs font-extrabold tracking-widest text-neutral-850 dark:text-white uppercase flex items-center gap-2 border-b border-neutral-100 dark:border-neutral-900 pb-3">
              <CreditCard className="w-4 h-4 text-[#C19A6B]" />
              <span>2. Secure Settlement Gate</span>
            </span>

            {/* Selector list */}
            <div className="grid grid-cols-2 gap-3">
              {[
                { label: 'Credit Card / Visa', val: 'Credit Card (Visa ending in 4242)' },
                { label: 'Apple Pay / Digital Wallet', val: 'Apple Pay' },
                { label: 'PayPal secure wire', val: 'PayPal Wire Transfer' },
                { label: 'High Value Escrow / Wire', val: 'Direct Wire Escrow' },
              ].map((pay) => (
                <label
                  key={pay.val}
                  className={`p-3.5 rounded-xl border flex items-center gap-3 cursor-pointer transition ${
                    paymentMethod === pay.val
                      ? 'border-[#C19A6B] bg-[#C19A6B]/5 text-[#C19A6B] font-bold'
                      : 'border-neutral-150 dark:border-neutral-900 text-neutral-600 dark:text-neutral-400 hover:bg-neutral-50 dark:hover:bg-neutral-850/15'
                  }`}
                >
                  <input
                    type="radio"
                    name="paymentSelect"
                    value={pay.val}
                    checked={paymentMethod === pay.val}
                    onChange={() => setPaymentMethod(pay.val)}
                    className="text-[#C19A6B] focus:ring-[#C19A6B] cursor-pointer"
                  />
                  <span className="text-xs">{pay.label}</span>
                </label>
              ))}
            </div>

            {/* Credit card form simulator */}
            {paymentMethod.startsWith('Credit Card') && (
              <div className="space-y-4 bg-neutral-50 dark:bg-neutral-900/40 p-4 rounded-xl border border-neutral-150 dark:border-neutral-850">
                <span className="text-[10px] font-bold text-neutral-450 uppercase tracking-wider block">Enter Credit Card Details</span>
                
                <div className="grid grid-cols-3 gap-3">
                  <div className="col-span-3 sm:col-span-2">
                    <label className="text-[9px] text-neutral-400 block mb-0.5 uppercase tracking-wide">Card Holder</label>
                    <input
                      type="text"
                      value={cardName}
                      onChange={(e) => setCardName(e.target.value)}
                      className="w-full bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white"
                      placeholder="JANE DOE"
                    />
                  </div>
                  <div className="col-span-3 sm:col-span-1">
                    <label className="text-[9px] text-neutral-400 block mb-0.5 uppercase tracking-wide">CVV</label>
                    <input
                      type="text"
                      maxLength={3}
                      value={cardCVV}
                      onChange={(e) => setCardCVV(e.target.value)}
                      className="w-full bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white font-mono"
                      placeholder="000"
                    />
                  </div>
                  <div className="col-span-3 sm:col-span-2">
                    <label className="text-[9px] text-neutral-400 block mb-0.5 uppercase tracking-wide">Card Number</label>
                    <input
                      type="text"
                      maxLength={19}
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      className="w-full bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white font-mono"
                      placeholder="0000 0000 0000 0000"
                    />
                  </div>
                  <div className="col-span-3 sm:col-span-1">
                    <label className="text-[9px] text-neutral-400 block mb-0.5 uppercase tracking-wide">Expiry MM/YY</label>
                    <input
                      type="text"
                      maxLength={5}
                      value={cardExpiry}
                      onChange={(e) => setCardExpiry(e.target.value)}
                      className="w-full bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white font-mono"
                      placeholder="12/28"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

        </div>

        {/* Right column: Cart summary sticky review (col span 5) */}
        <div className="lg:col-span-5 bg-neutral-50 dark:bg-[#1A1A1E]/30 border border-neutral-100 dark:border-neutral-900 rounded-2xl p-6 sm:p-8 space-y-6 sticky top-24">
          <span className="text-[10px] font-bold tracking-widest text-[#C19A6B] uppercase block">Bespoke Checkout Summary</span>
          
          {/* List items briefly */}
          <div className="divide-y divide-neutral-200/40 dark:divide-neutral-800/40 text-xs text-neutral-500 max-h-56 overflow-y-auto space-y-2.5 pr-2">
            {cart.map((item) => (
              <div key={item.id} className="pt-2.5 first:pt-0 flex gap-3.5 items-center">
                <img src={item.product.images[0]} alt={item.product.name} referrerPolicy="no-referrer" className="w-10 h-12 object-cover rounded-md bg-white border" />
                <div className="min-w-0 flex-1">
                  <h5 className="font-semibold text-neutral-800 dark:text-neutral-100 truncate">{item.product.name}</h5>
                  <p className="text-[9px] font-mono mt-0.5">Qty: {item.quantity} • {item.selectedSize?.name || 'Default'}</p>
                </div>
                <span className="font-mono font-bold text-neutral-850 dark:text-white">
                  ${(item.product.price + (item.selectedColor?.priceOffset || 0) + (item.selectedSize?.priceOffset || 0)) * item.quantity}
                </span>
              </div>
            ))}
          </div>

          <hr className="border-neutral-200 dark:border-neutral-800" />

          {/* Coupon Entry */}
          <div>
            {activeCoupon ? (
              <div className="flex items-center justify-between bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30 py-2 px-3 rounded-md">
                <div className="flex items-center gap-1.5 text-xs text-emerald-800 dark:text-emerald-300">
                  <Ticket className="w-4 h-4" />
                  <span>Promo applied: <strong>{activeCoupon.code}</strong></span>
                </div>
                <button onClick={removeCoupon} className="text-neutral-400 hover:text-neutral-600 text-xs font-bold cursor-pointer">
                  Remove
                </button>
              </div>
            ) : (
              <form onSubmit={handleApplyPromo} className="flex gap-2">
                <input
                  type="text"
                  placeholder="Promo code (VELORA10)..."
                  value={promoCode}
                  onChange={(e) => setPromoCode(e.target.value)}
                  className="flex-1 bg-white dark:bg-neutral-900 border border-neutral-250 dark:border-neutral-800 rounded-md text-xs py-2 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white"
                />
                <button
                  type="submit"
                  className="bg-neutral-800 text-white text-xs px-4 py-2 rounded-md font-semibold tracking-wider uppercase cursor-pointer"
                >
                  Apply
                </button>
              </form>
            )}
          </div>

          {/* Checkout sums */}
          <div className="space-y-3.5 text-xs text-neutral-500 dark:text-neutral-400">
            <div className="flex justify-between">
              <span>Invoice Subtotal</span>
              <span className="font-mono font-bold text-neutral-850 dark:text-neutral-100">${cartTotal}</span>
            </div>
            {activeCoupon && (
              <div className="flex justify-between text-emerald-600 dark:text-emerald-400">
                <span>Promotional Savings</span>
                <span className="font-mono font-bold">-${calculatedDiscount()}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span>Estimated Shipping Courier</span>
              {cartTotal > 150 ? (
                <span className="text-[10px] tracking-widest text-[#C19A6B] font-extrabold uppercase">Complimentary</span>
              ) : (
                <span className="font-mono font-bold text-neutral-850 dark:text-neutral-100">$15</span>
              )}
            </div>
            <div className="flex justify-between">
              <span>Estimated Sales Tax (8%)</span>
              <span className="font-mono font-bold text-neutral-850 dark:text-neutral-100">${(cartTotal * 0.08).toFixed(2)}</span>
            </div>

            <hr className="border-neutral-200 dark:border-neutral-800" />

            <div className="flex justify-between text-sm">
              <span className="font-bold text-neutral-850 dark:text-neutral-100">Estimated Invoice Total</span>
              <span className="font-mono font-extrabold text-neutral-900 dark:text-white text-lg">${finalTotal()}</span>
            </div>
          </div>

          <button
            onClick={handlePlaceOrderSubmit}
            className="w-full bg-[#121214] dark:bg-white text-white dark:text-[#121214] hover:bg-neutral-850 dark:hover:bg-neutral-100 text-xs py-3.5 px-4 rounded-lg font-bold tracking-widest uppercase transition flex items-center justify-center gap-2 cursor-pointer shadow-md"
          >
            <Sparkles className="w-4 h-4 text-[#C19A6B]" />
            <span>Submit Bespoke Order</span>
          </button>

          {/* Secure gateway trust text */}
          <div className="flex items-center gap-2 pt-2 text-[10px] text-neutral-400 leading-relaxed">
            <Clipboard className="w-4 h-4 shrink-0 text-[#C19A6B]" />
            <span>Secure settlement. Your data is strictly encrypted and protected under Velora security guidelines.</span>
          </div>
        </div>

      </div>

    </div>
  );
};
