/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { BlogPost } from '../types';
import { BLOG_POSTS } from '../data/mockData';
import { Mail, Phone, MapPin, Compass, Search, HelpCircle, ChevronRight, ChevronDown, Check, Send, Sparkles, BookOpen, Clock, ArrowRight, Shield } from 'lucide-react';

/* ==========================================================================
   1. ABOUT VIEW
   ========================================================================== */
export const AboutView: React.FC = () => {
  const { navigateTo } = useApp();
  return (
    <div id="about-view" className="max-w-5xl mx-auto px-4 py-12 space-y-16">
      
      {/* Editorial Hero */}
      <div className="text-center space-y-4 py-8">
        <span className="text-xs font-bold text-[#C19A6B] uppercase tracking-widest block">Atelier Storytelling</span>
        <h1 className="text-3xl sm:text-5xl font-serif font-extrabold text-neutral-900 dark:text-white leading-tight">
          Redefining Everyday Luxury
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 font-light max-w-xl mx-auto leading-relaxed">
          Founded on principles of architectural discipline, pristine craftsmanship, and sustainable sourcing, Velora is a modern design atelier crafting everyday luxury.
        </p>
      </div>

      {/* Visual bento-box storytelling */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <img
          src="https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=800&q=80"
          alt="Atelier Craftsman"
          referrerPolicy="no-referrer"
          className="rounded-2xl shadow-lg w-full aspect-[4/3] object-cover border border-neutral-100"
        />
        <div className="space-y-6">
          <span className="text-[10px] font-bold text-[#C19A6B] uppercase tracking-widest block">The Genesis</span>
          <h2 className="text-2xl font-serif font-bold text-neutral-900 dark:text-white leading-snug">Precision in Every Stitch</h2>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 font-light leading-relaxed">
            Our materials are hand-selected from heritage mills in Italy, Japan, and Spain. Every automated mechanical watch, fine sneaker, and organic botanical represents months of dedicated design refinement.
          </p>
          <div className="grid grid-cols-2 gap-4 pt-4 border-t border-neutral-100 dark:border-neutral-900">
            <div>
              <span className="text-2xl font-extrabold font-mono text-neutral-900 dark:text-white">100%</span>
              <p className="text-[10px] text-neutral-400 dark:text-neutral-500 uppercase tracking-wider font-semibold">Verified Sourcing</p>
            </div>
            <div>
              <span className="text-2xl font-extrabold font-mono text-[#C19A6B]">15k+</span>
              <p className="text-[10px] text-neutral-400 dark:text-neutral-500 uppercase tracking-wider font-semibold">Luxury Patrons</p>
            </div>
          </div>
        </div>
      </div>

      {/* Core Values */}
      <section className="space-y-6 pt-10 border-t border-neutral-100 dark:border-neutral-900">
        <div className="text-center">
          <span className="text-xs font-bold text-[#C19A6B] uppercase tracking-wider block">Our Creed</span>
          <h3 className="text-xl font-serif font-bold text-neutral-900 dark:text-white mt-1">Bespoke Principles</h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          {[
            { title: 'Tailored Quality', desc: 'No mass production. We design in limited drops to maintain flawless visual detail and prevent redundant landfill waste.' },
            { title: 'Global Transparency', desc: 'Full lifecycle visibility. Trace the heritage of your sneakers, cashmere threads, and watch components with confidence.' },
            { title: 'Premium Comfort', desc: 'Luxury isn’t stiff. Our textiles feature adaptive fibers that conform perfectly to your active lifestyle.' }
          ].map((creed, i) => (
            <div key={i} className="p-6 bg-white dark:bg-[#1A1A1E]/30 border border-neutral-150/60 dark:border-neutral-900 rounded-2xl space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-[#C19A6B]">{creed.title}</h4>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 font-light leading-relaxed">{creed.desc}</p>
            </div>
          ))}
        </div>
      </section>

    </div>
  );
};

/* ==========================================================================
   2. CONTACT VIEW
   ========================================================================== */
export const ContactView: React.FC = () => {
  const { addToast } = useApp();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [msg, setMsg] = useState('');
  const [success, setSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && email && msg) {
      setSuccess(true);
      addToast('Message securely dispatched to Velora Atelier!', 'success');
      setName('');
      setEmail('');
      setMsg('');
      setTimeout(() => setSuccess(false), 4000);
    }
  };

  return (
    <div id="contact-view" className="max-w-5xl mx-auto px-4 py-12 grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
      
      {/* Left Details Panel (col span 5) */}
      <div className="lg:col-span-5 space-y-6">
        <div>
          <span className="text-xs font-bold text-[#C19A6B] uppercase tracking-widest block">Atelier Concierge</span>
          <h1 className="text-3xl font-serif font-extrabold text-neutral-900 dark:text-white mt-1">Connect With Us</h1>
          <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 font-light leading-relaxed mt-2">
            Our global support officers are available 24 hours a day, 7 days a week, providing bespoke assistance for sizes, custom engravings, or delivery coordinates.
          </p>
        </div>

        <div className="space-y-4 pt-4 border-t border-neutral-100 dark:border-neutral-900">
          <div className="flex items-center gap-3 text-xs text-neutral-600 dark:text-neutral-400">
            <Phone className="w-4 h-4 text-[#C19A6B]" />
            <span>+1 (800) VELORA-99 (Toll-Free)</span>
          </div>
          <div className="flex items-center gap-3 text-xs text-neutral-600 dark:text-neutral-400">
            <Mail className="w-4 h-4 text-[#C19A6B]" />
            <span>atelier@velorastore.com</span>
          </div>
          <div className="flex items-center gap-3 text-xs text-neutral-600 dark:text-neutral-400">
            <MapPin className="w-4 h-4 text-[#C19A6B]" />
            <span>742 Fifth Avenue, New York, NY 10019</span>
          </div>
        </div>

        {/* Brand hours */}
        <div className="bg-neutral-50 dark:bg-[#1A1A1E]/30 p-4 rounded-xl border border-neutral-150/50 text-xs space-y-2">
          <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest block">Atelier Showroom Hours</span>
          <div className="flex justify-between font-light">
            <span>Monday &ndash; Friday</span>
            <span>09:00 &ndash; 19:00 EST</span>
          </div>
          <div className="flex justify-between font-light">
            <span>Saturday &ndash; Sunday</span>
            <span>10:00 &ndash; 17:00 EST</span>
          </div>
        </div>
      </div>

      {/* Right Form Panel (col span 7) */}
      <div className="lg:col-span-7 bg-white dark:bg-[#1A1A1E]/30 border border-neutral-150/70 dark:border-neutral-900 p-6 sm:p-8 rounded-2xl">
        <form onSubmit={handleSubmit} className="space-y-4">
          <span className="text-xs font-bold text-neutral-850 dark:text-neutral-200 uppercase tracking-wider block">Dispatch an Inquiry</span>
          
          {success && (
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/20 text-emerald-800 dark:text-emerald-300 text-xs rounded-md border border-emerald-100 dark:border-emerald-900/30">
              Inquiry successfully processed! Our concierge officers will respond within 4 business hours.
            </div>
          )}

          <div>
            <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">Your Full Name</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2.5 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white"
              placeholder="Jane Doe"
              required
            />
          </div>

          <div>
            <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">Your Email Address</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2.5 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white"
              placeholder="jane@example.com"
              required
            />
          </div>

          <div>
            <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">Detailed Message</label>
            <textarea
              rows={5}
              value={msg}
              onChange={(e) => setMsg(e.target.value)}
              className="w-full bg-neutral-50 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2.5 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white resize-none"
              placeholder="Describe details regarding sizing queries, customization wishes, or order tracing..."
              required
            />
          </div>

          <button
            type="submit"
            className="w-full bg-neutral-900 hover:bg-neutral-850 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-neutral-900 text-xs font-bold tracking-widest uppercase py-3 rounded-md transition cursor-pointer shadow-sm flex items-center justify-center gap-1.5"
          >
            <Send className="w-3.5 h-3.5 text-[#C19A6B]" />
            <span>Submit Inquiry Dispatch</span>
          </button>
        </form>
      </div>

    </div>
  );
};

/* ==========================================================================
   3. FAQ VIEW (ACCORDION STYLE)
   ========================================================================== */
export const FAQView: React.FC = () => {
  const [activeFaq, setActiveFaq] = useState<number | null>(null);
  const [search, setSearch] = useState('');

  const faqs = [
    { q: 'How long does shipping courier take?', a: 'All US orders are shipped via white-glove complimentary courier and take 2-4 business days. International dispatches take 4-7 business days depending on customs clearances.' },
    { q: 'Are my watches and fine sneakers covered under warranty?', a: 'Yes. All automatic luxury watches feature a 3-year mechanical warranty. Fine sneakers and apparel include 12 months coverage against tailoring defects.' },
    { q: 'How can I execute a return or size exchange?', a: 'Returns are complimentary within 30 days of receipt. Simply head to your My Account portal, select the respective Order ID, and tap Return Item to fetch a pre-printed courier shipping label.' },
    { q: 'Where are Velora items manufactured?', a: 'We design entirely in-house. Our production is decentralized across elite heritage mills: shoes are crafted in Spain, textiles in Milan and Tokyo, and watches in Switzerland.' }
  ];

  const filteredFaqs = faqs.filter((f) =>
    f.q.toLowerCase().includes(search.toLowerCase()) || f.a.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div id="faq-view" className="max-w-3xl mx-auto px-4 py-12 space-y-8">
      <div className="text-center space-y-2">
        <span className="text-xs font-bold text-[#C19A6B] uppercase tracking-widest block">Concierge Center</span>
        <h1 className="text-3xl font-serif font-extrabold text-neutral-900 dark:text-white">Frequently Asked Questions</h1>
      </div>

      {/* Accordion Search */}
      <div className="relative flex items-center bg-neutral-50 dark:bg-neutral-900 border border-neutral-200/60 dark:border-neutral-800 rounded-md max-w-lg mx-auto">
        <Search className="w-4 h-4 text-neutral-400 absolute left-3.5" />
        <input
          type="text"
          placeholder="Search support questions..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="bg-transparent border-none text-xs focus:ring-0 outline-none w-full py-3.5 pl-10 pr-3 text-neutral-850 dark:text-white font-medium"
        />
      </div>

      {/* Accordion Blocks */}
      <div className="space-y-4 mt-8">
        {filteredFaqs.map((faq, idx) => {
          const isOpen = activeFaq === idx;
          return (
            <div
              key={idx}
              className="bg-white dark:bg-[#1A1A1E]/35 border border-neutral-150/60 dark:border-neutral-900 rounded-xl overflow-hidden transition"
            >
              <button
                onClick={() => setActiveFaq(isOpen ? null : idx)}
                className="w-full flex justify-between items-center py-4 px-5 text-left text-xs sm:text-sm font-bold text-neutral-850 dark:text-neutral-200 hover:text-[#C19A6B] transition"
              >
                <span>{faq.q}</span>
                <ChevronDown className={`w-4 h-4 text-neutral-400 transition-transform duration-300 ${isOpen ? 'rotate-180 text-[#C19A6B]' : ''}`} />
              </button>
              
              {isOpen && (
                <div className="py-4 px-5 border-t border-neutral-100 dark:border-neutral-900 bg-neutral-50/50 dark:bg-[#121214]/10 text-xs text-neutral-500 dark:text-neutral-400 font-light leading-relaxed">
                  {faq.a}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

/* ==========================================================================
   4. LEGAL VIEW (SHIPPING, RETURNS, PRIVACY, TERMS)
   ========================================================================== */
export const LegalView: React.FC = () => {
  const { currentRouteParams } = useApp();
  // tabs: 'shipping' | 'returns' | 'privacy' | 'terms'
  const [tab, setTab] = useState<'shipping' | 'returns' | 'privacy' | 'terms'>(
    (currentRouteParams?.id as any) || 'shipping'
  );

  return (
    <div id="legal-view" className="max-w-4xl mx-auto px-4 py-12 space-y-8">
      
      {/* Sub tabs list */}
      <div className="flex border-b border-neutral-200 dark:border-neutral-800 text-[10px] sm:text-xs font-bold uppercase tracking-wider text-neutral-450 justify-center gap-3 sm:gap-6 overflow-x-auto pb-1">
        {[
          { id: 'shipping', label: 'Shipping & Delivery' },
          { id: 'returns', label: 'Returns & Refunds' },
          { id: 'privacy', label: 'Privacy Policy' },
          { id: 'terms', label: 'Terms & Conditions' }
        ].map((item) => (
          <button
            key={item.id}
            onClick={() => setTab(item.id as any)}
            className={`py-2 px-1 transition ${
              tab === item.id ? 'border-b-2 border-[#C19A6B] text-neutral-900 dark:text-white font-extrabold' : 'hover:text-neutral-800'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      <div className="bg-white dark:bg-[#1A1A1E]/30 p-6 sm:p-10 rounded-2xl border border-neutral-150/60 dark:border-neutral-900 space-y-6 text-xs sm:text-sm text-neutral-600 dark:text-neutral-400 font-light leading-relaxed">
        
        {tab === 'shipping' && (
          <article className="space-y-4">
            <h2 className="text-xl font-serif font-bold text-neutral-900 dark:text-white">Complimentary White-Glove Shipping</h2>
            <p>Every Velora parcel is packaged with surgical care, wrapped in acid-free premium tissue inside robust double-wall matte boxes to prevent shipping scuffs.</p>
            <h4 className="font-bold text-neutral-850 dark:text-neutral-200 uppercase tracking-wider text-[11px] pt-2">Transit Rates & Times</h4>
            <ul className="list-disc pl-5 space-y-2">
              <li><strong>Continental United States:</strong> Complimentary 2-4 business days courier dispatch.</li>
              <li><strong>Express Secure Air:</strong> Flat rate of $45 for guaranteed 24-hour delivery on orders placed before 14:00 EST.</li>
              <li><strong>International Courier:</strong> Complimentary on all orders exceeding $300 USD. Otherwise, flat rate of $35. Takes 4-7 business days.</li>
            </ul>
          </article>
        )}

        {tab === 'returns' && (
          <article className="space-y-4">
            <h2 className="text-xl font-serif font-bold text-neutral-900 dark:text-white">Returns & Exchanges Policy</h2>
            <p>If your bespoke piece does not fit or conform precisely to your expectation, we provide a complimentary 30-day return policy for standard sizes.</p>
            <h4 className="font-bold text-neutral-850 dark:text-neutral-200 uppercase tracking-wider text-[11px] pt-2">Return Criteria</h4>
            <p>Items must remain in pristine unworn condition, with all branding swingtags, certificates, and accessories attached. Shoes must only be tried on clean carpeted surfaces to prevent sole scuffing.</p>
          </article>
        )}

        {tab === 'privacy' && (
          <article className="space-y-4">
            <h2 className="text-xl font-serif font-bold text-neutral-900 dark:text-white">Privacy & Data Encryptions</h2>
            <p>Your privacy is of vital significance. Velora Atelier employs state-of-the-art AES-256 secure socket layers (SSL) to guard personal data during transactions.</p>
            <p>We do not lease, trade, or distribute your email records or address information to third-party list houses. We only coordinate with verified secure checkout partners (e.g., Stripe, PayPal) to authorize transaction payments.</p>
          </article>
        )}

        {tab === 'terms' && (
          <article className="space-y-4">
            <h2 className="text-xl font-serif font-bold text-neutral-900 dark:text-white">Terms of Store Service</h2>
            <p>By accessing the Velora catalog boutique, you agree to comply with our Terms of Service. Prices and drops are subject to change based on material mill rates.</p>
            <p>Products are intended solely for personal, non-commercial retail use. Any unauthorized industrial resale of Swiss-made mechanical watches or serialized sneaker drops is strictly prohibited.</p>
          </article>
        )}

      </div>

    </div>
  );
};

/* ==========================================================================
   5. BLOG VIEW (CHRONICLE ARCHIVE)
   ========================================================================== */
export const BlogView: React.FC = () => {
  const { navigateTo } = useApp();
  const [searchTerm, setSearchTerm] = useState('');

  const filteredPosts = BLOG_POSTS.filter((post: BlogPost) =>
    post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    post.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div id="blog-view" className="max-w-6xl mx-auto px-4 py-12 space-y-12">
      
      {/* Title */}
      <div className="text-center space-y-3">
        <span className="text-xs font-bold text-[#C19A6B] uppercase tracking-widest block">Velora Chronicles</span>
        <h1 className="text-3xl sm:text-5xl font-serif font-extrabold text-neutral-900 dark:text-white">The Bespoke Editorial</h1>
        <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 font-light max-w-md mx-auto leading-relaxed">
          Unveiling artisan stories, horological heritage, and sneaker styling guides from our creative directors.
        </p>
      </div>

      {/* Search Input */}
      <div className="relative flex items-center bg-neutral-50 dark:bg-neutral-900 border border-neutral-200/60 dark:border-neutral-850 rounded-md max-w-sm mx-auto">
        <Search className="w-4 h-4 text-neutral-400 absolute left-3.5" />
        <input
          type="text"
          placeholder="Search articles..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="bg-transparent border-none text-xs focus:ring-0 outline-none w-full py-3 px-10 text-neutral-850 dark:text-white font-medium"
        />
      </div>

      {/* Grid List */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {filteredPosts.map((post: BlogPost) => (
          <article
            key={post.id}
            onClick={() => navigateTo('blog-details', { id: post.id })}
            className="group flex flex-col bg-white dark:bg-[#1A1A1E]/40 border border-neutral-150/60 dark:border-neutral-900 rounded-2xl overflow-hidden cursor-pointer hover:shadow-lg transition duration-300"
          >
            <div className="aspect-[16/10] overflow-hidden bg-neutral-100">
              <img
                src={post.image}
                alt={post.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-102"
              />
            </div>

            <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-[9px] font-bold tracking-widest text-[#C19A6B] uppercase">
                  <span>{post.category}</span>
                  <span>•</span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {post.readTime}
                  </span>
                </div>
                <h3 className="text-sm font-bold text-neutral-900 dark:text-neutral-150 group-hover:text-[#C19A6B] transition-colors leading-snug line-clamp-2">
                  {post.title}
                </h3>
                <p className="text-xs text-neutral-500 dark:text-neutral-400 font-light leading-relaxed line-clamp-3">
                  {post.excerpt}
                </p>
              </div>

              <div className="flex items-center justify-between border-t border-neutral-100 dark:border-neutral-800/80 pt-3 text-[10px] text-neutral-400 font-mono">
                <span>By {post.author.name}</span>
                <span>{post.date}</span>
              </div>
            </div>
          </article>
        ))}
      </div>

    </div>
  );
};

/* ==========================================================================
   6. BLOG DETAILS VIEW
   ========================================================================== */
export const BlogDetailsView: React.FC = () => {
  const { currentRouteParams, navigateTo } = useApp();
  const id = currentRouteParams?.id || 'post-1';
  const post = BLOG_POSTS.find((p: BlogPost) => p.id === id) || BLOG_POSTS[0];

  return (
    <div id="blog-details-view" className="max-w-3xl mx-auto px-4 py-12 space-y-8">
      
      {/* Return triggers */}
      <button
        onClick={() => navigateTo('blog')}
        className="text-xs font-bold text-[#C19A6B] hover:text-[#A17C52] flex items-center gap-1 uppercase tracking-wider transition cursor-pointer"
      >
        &larr; Return to Chronicle Editorial
      </button>

      {/* Header metadata */}
      <div className="space-y-3">
        <span className="text-[10px] font-bold tracking-widest text-[#C19A6B] uppercase">{post.category}</span>
        <h1 className="text-2xl sm:text-4xl font-serif font-extrabold text-neutral-900 dark:text-white leading-tight">
          {post.title}
        </h1>
        
        <div className="flex items-center gap-3 text-xs text-neutral-450 pt-2 border-b border-neutral-100 dark:border-neutral-900 pb-4">
          <span className="font-bold">By {post.author.name}</span>
          <span>•</span>
          <span className="font-mono">{post.date}</span>
          <span>•</span>
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-[#C19A6B]" />
            {post.readTime}
          </span>
        </div>
      </div>

      {/* Main Image */}
      <div className="aspect-[16/9] w-full rounded-2xl overflow-hidden bg-neutral-100 border">
        <img
          src={post.image}
          alt={post.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Rich Editorial Body */}
      <div className="text-xs sm:text-sm text-neutral-600 dark:text-neutral-400 font-light leading-relaxed space-y-6">
        <p className="text-neutral-800 dark:text-neutral-200 font-medium">
          In this exclusive installment, we dive into the core engineering and artisan techniques that govern Velora’s latest seasonal collection.
        </p>
        <p>
          Design is fundamentally about problem solving. When we crafted our sneakers, our mandate wasn’t simply to produce another aesthetic silhouette. We analyzed shock-absorption indices and partnered with regional Italian tanneries to produce calfskin leather that actively breathes.
        </p>
        
        {/* Quote Block */}
        <blockquote className="border-l-4 border-[#C19A6B] pl-4 py-1.5 italic font-medium text-neutral-800 dark:text-neutral-200">
          "True luxury represents absolute harmony between mathematical layout and raw human tactile response."
        </blockquote>

        <p>
          The Swiss watches inside our boutique utilize genuine Swiss caliber movements, calibrated to an precision rate of +/- 4 seconds daily. By offering direct-to-consumer templates, we make these elite specs accessible without traditional retail markups.
        </p>
      </div>

    </div>
  );
};
