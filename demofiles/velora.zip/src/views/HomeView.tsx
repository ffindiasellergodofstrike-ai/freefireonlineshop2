/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useApp } from '../context/AppContext';
import { PRODUCTS, CATEGORIES, BLOG_POSTS } from '../data/mockData';
import { Product } from '../types';
import { motion } from 'motion/react';
import { Star, Eye, ShoppingBag, Heart, ArrowRight, Compass, Sparkles } from 'lucide-react';

export const HomeView: React.FC = () => {
  const { navigateTo, setQuickViewProduct, toggleWishlist, isInWishlist } = useApp();

  const featuredProducts = PRODUCTS.filter((p) => p.isFeatured || p.isNew).slice(0, 4);
  const bestSellers = PRODUCTS.filter((p) => p.isBestSeller).slice(0, 4);

  const renderProductCard = (product: Product) => {
    const isFav = isInWishlist(product.id);
    return (
      <div
        key={product.id}
        className="group relative flex flex-col bg-white dark:bg-[#1A1A1E]/40 border border-neutral-100 dark:border-neutral-900 rounded-xl overflow-hidden transition-all duration-300 hover:shadow-lg"
      >
        {/* Wishlist Button */}
        <button
          onClick={() => toggleWishlist(product)}
          className={`absolute top-3.5 right-3.5 z-10 p-2.5 bg-white/90 dark:bg-neutral-900/90 backdrop-blur-md rounded-full border transition cursor-pointer shadow-sm ${
            isFav
              ? 'border-red-100 bg-red-50/80 dark:bg-red-950/20 text-red-500'
              : 'border-neutral-200/40 dark:border-neutral-800 text-neutral-400 hover:text-neutral-600'
          }`}
          aria-label="Wishlist Toggle"
        >
          <Heart className="w-4 h-4" />
        </button>

        {/* Product Image Stage */}
        <div
          onClick={() => navigateTo('product', { id: product.id })}
          className="aspect-[3/4] relative w-full overflow-hidden bg-neutral-50 dark:bg-neutral-900/50 cursor-pointer border-b border-neutral-100 dark:border-neutral-900"
        >
          <img
            src={product.images[0]}
            alt={product.name}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
          />
          
          {/* Quick Add To Bag Hover Overlay */}
          <div className="absolute inset-0 bg-black/10 dark:bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center p-4">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setQuickViewProduct(product);
              }}
              className="w-full bg-white/95 dark:bg-neutral-900/95 backdrop-blur-md text-neutral-850 dark:text-white hover:text-[#C19A6B] py-2.5 px-4 rounded-lg text-[11px] font-bold tracking-widest uppercase transition flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Quick View</span>
            </button>
          </div>

          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-col gap-1">
            {product.isNew && (
              <span className="bg-[#C19A6B] text-white text-[9px] font-bold tracking-widest uppercase px-2.5 py-1 rounded-full shadow-sm">
                New Arrival
              </span>
            )}
            {product.discountBadge && (
              <span className="bg-red-500 text-white text-[9px] font-bold tracking-widest uppercase px-2.5 py-1 rounded-full shadow-sm">
                {product.discountBadge}
              </span>
            )}
          </div>
        </div>

        {/* Card Metadata Details */}
        <div className="p-4 flex-1 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-[10px] tracking-wider text-[#C19A6B] uppercase font-bold">
              <span>{product.brand}</span>
              <span className="text-neutral-300 dark:text-neutral-700 font-normal">|</span>
              <span className="text-neutral-400 dark:text-neutral-500 font-light lowercase capitalize">
                {product.subCategory || product.category}
              </span>
            </div>

            <h4
              onClick={() => navigateTo('product', { id: product.id })}
              className="text-xs sm:text-sm font-semibold text-neutral-800 dark:text-neutral-100 hover:text-[#C19A6B] transition-colors mt-1.5 cursor-pointer line-clamp-1"
            >
              {product.name}
            </h4>

            {/* Stars rating */}
            <div className="flex items-center gap-1.5 mt-2">
              <div className="flex items-center gap-0.5">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-3 h-3 ${
                      i < Math.floor(product.rating) ? 'fill-[#C19A6B] text-[#C19A6B]' : 'text-neutral-200 dark:text-neutral-800'
                    }`}
                  />
                ))}
              </div>
              <span className="text-[10px] text-neutral-400 dark:text-neutral-500 font-mono font-bold">
                ({product.reviewsCount})
              </span>
            </div>
          </div>

          {/* Price detail footer */}
          <div className="flex items-center justify-between mt-4 pt-3 border-t border-neutral-100/60 dark:border-neutral-900/60">
            <div className="flex items-baseline gap-2">
              <span className="text-sm font-bold font-mono text-neutral-850 dark:text-neutral-100">
                ${product.price}
              </span>
              {product.originalPrice && (
                <span className="text-[11px] font-light font-mono text-neutral-400 line-through">
                  ${product.originalPrice}
                </span>
              )}
            </div>
            
            <button
              onClick={() => setQuickViewProduct(product)}
              className="text-xs font-semibold text-[#C19A6B] hover:text-[#A17C52] transition flex items-center gap-1"
            >
              <span>View Options</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div id="home-view" className="space-y-20 pb-16">
      
      {/* 1. EDITORIAL HERO SECTION */}
      <section className="relative h-[85vh] sm:h-[90vh] flex items-center overflow-hidden bg-neutral-900">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&q=80&w=1600"
            alt="Hero Background"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-60 mix-blend-multiply"
          />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full text-white">
          <div className="max-w-2xl space-y-6">
            <motion.span
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-xs sm:text-sm font-bold tracking-[0.25em] text-[#E5D3B3] uppercase block"
            >
              The Autumn / Winter Capsule 2026
            </motion.span>
            
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.15 }}
              className="text-4xl sm:text-5xl md:text-6xl font-serif font-extrabold leading-tight tracking-normal"
            >
              Crafting Elegance for the Modern Persona
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="text-sm sm:text-base text-neutral-250 font-light leading-relaxed max-w-lg"
            >
              Bespoke contemporary wardrobe garments, grade 5 titanium automatics, high-performance running sneakers and scientific botanical skincare. Curated with absolute minimalist precision.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.45 }}
              className="pt-4 flex flex-wrap gap-4"
            >
              <button
                onClick={() => navigateTo('shop')}
                className="bg-[#C19A6B] hover:bg-[#A17C52] text-white text-xs font-bold tracking-widest uppercase py-4 px-8 rounded-lg shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer"
              >
                Shop Bespoke
              </button>
              <button
                onClick={() => navigateTo('category', { id: 'fashion' })}
                className="bg-white/10 hover:bg-white/20 border border-white/25 text-white text-xs font-bold tracking-widest uppercase py-4 px-8 rounded-lg transition-all duration-300 backdrop-blur-sm cursor-pointer"
              >
                View Lookbook
              </button>
            </motion.div>
          </div>
        </div>

        {/* Dynamic scroll indicator */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1.5 text-white/50 animate-bounce">
          <span className="text-[10px] tracking-widest uppercase font-semibold">Explore</span>
          <div className="w-1 h-3 rounded-full bg-white/50" />
        </div>
      </section>

      {/* 2. CATEGORY HIGHLIGHT CAROUSEL */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-baseline justify-between mb-8 gap-2">
          <div>
            <span className="text-xs font-bold text-[#C19A6B] uppercase tracking-wider block">Browse curation</span>
            <h2 className="text-2xl font-serif font-bold text-neutral-900 dark:text-white mt-1">Curated Collections</h2>
          </div>
          <button
            onClick={() => navigateTo('shop')}
            className="text-xs font-semibold text-[#C19A6B] hover:text-[#A17C52] transition flex items-center gap-1"
          >
            <span>Browse All Departments</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Categories Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
          {CATEGORIES.map((cat, i) => (
            <div
              key={cat.id}
              onClick={() => navigateTo('category', { id: cat.id })}
              className="group cursor-pointer text-center space-y-3 p-3 bg-neutral-50/50 dark:bg-neutral-900/40 border border-neutral-100/80 dark:border-neutral-900 rounded-xl hover:bg-white dark:hover:bg-neutral-850/20 hover:shadow-md transition-all duration-300"
            >
              <div className="aspect-square relative overflow-hidden rounded-full max-w-[80px] mx-auto bg-neutral-100 dark:bg-neutral-800 border border-neutral-200/50 dark:border-neutral-700/50">
                <img
                  src={cat.image}
                  alt={cat.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div>
                <h4 className="text-xs font-bold text-neutral-800 dark:text-neutral-100 group-hover:text-[#C19A6B] transition-colors leading-tight">
                  {cat.name}
                </h4>
                <p className="text-[10px] text-neutral-400 dark:text-neutral-500 mt-0.5">{cat.count || 12} items</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. NEW & FEATURED SHOWCASE */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <span className="text-xs font-bold text-[#C19A6B] uppercase tracking-wider block">Exclusive arrivals</span>
          <h2 className="text-2xl font-serif font-bold text-neutral-900 dark:text-white mt-1">Featured Bespoke Designs</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredProducts.map((p) => renderProductCard(p))}
        </div>
      </section>

      {/* 4. EDITORIAL VALUES SPLIT FEATURE */}
      <section className="bg-neutral-50 dark:bg-[#1A1A1E]/40 border-y border-neutral-100 dark:border-neutral-900 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          
          <div className="relative aspect-[4/3] sm:aspect-[16/10] lg:aspect-square overflow-hidden rounded-2xl border border-neutral-200/50 dark:border-neutral-800/50">
            <img
              src="https://images.unsplash.com/photo-1524498250077-390f9e378db0?auto=format&fit=crop&q=80&w=1000"
              alt="Artisanal Handcrafting"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent flex items-end p-6">
              <p className="text-xs text-white/90 font-light leading-relaxed max-w-sm">
                Each Velora accessory is built by senior leather artisans in Tuscany using organic vegetable tanning.
              </p>
            </div>
          </div>

          <div className="space-y-6">
            <span className="text-xs font-bold text-[#C19A6B] uppercase tracking-widest flex items-center gap-1.5">
              <Compass className="w-4 h-4" />
              <span>THE VELORA ATELIER MANIFESTO</span>
            </span>
            
            <h3 className="text-3xl font-serif font-extrabold text-neutral-900 dark:text-white leading-snug">
              Every Stitch Tells a Tale of Mastery
            </h3>

            <p className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 font-light leading-relaxed">
              We reject the industrial assembly lines. At Velora, we partner with independent, multi-generational artisans who understand materials on a biological level. 
              Our Italian-crafted cashmere trench coats, titanium Sellita automatics, and natural skincare are made in small, exclusive drops. By focusing entirely on high-gauge natural fibers, certified raw elements, and active botanical enzymes, we build items that grow more refined over decades.
            </p>

            <div className="grid grid-cols-2 gap-6 pt-4">
              <div className="border-l-2 border-[#C19A6B] pl-4">
                <span className="text-lg font-bold text-neutral-800 dark:text-white font-mono">01 / Material</span>
                <p className="text-xs text-neutral-400 dark:text-neutral-500 font-light mt-1">22-momme heavy mulberry silks & grade 5 titanium blocks.</p>
              </div>
              <div className="border-l-2 border-[#C19A6B] pl-4">
                <span className="text-lg font-bold text-neutral-800 dark:text-white font-mono">02 / Integrity</span>
                <p className="text-xs text-neutral-400 dark:text-neutral-500 font-light mt-1">Completely organic, paraben-free formulations cold-pressed in France.</p>
              </div>
            </div>

            <button
              onClick={() => navigateTo('about')}
              className="mt-6 text-xs font-bold text-[#C19A6B] hover:text-[#A17C52] tracking-wider uppercase flex items-center gap-1.5 cursor-pointer"
            >
              <span>Explore Our Atelier Story</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </div>
      </section>

      {/* 5. BEST SELLERS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <span className="text-xs font-bold text-[#C19A6B] uppercase tracking-wider block">Timeless Favorites</span>
          <h2 className="text-2xl font-serif font-bold text-neutral-900 dark:text-white mt-1">The Best Sellers List</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {bestSellers.map((p) => renderProductCard(p))}
        </div>
      </section>

      {/* 6. EDITORIAL JOURNAL SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row items-baseline justify-between mb-8 gap-2">
          <div>
            <span className="text-xs font-bold text-[#C19A6B] uppercase tracking-wider block">Our Blog Journal</span>
            <h2 className="text-2xl font-serif font-bold text-neutral-900 dark:text-white mt-1">The Velora Journal</h2>
          </div>
          <button
            onClick={() => navigateTo('blog')}
            className="text-xs font-semibold text-[#C19A6B] hover:text-[#A17C52] transition flex items-center gap-1"
          >
            <span>Read All Editorial Stories</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {BLOG_POSTS.slice(0, 3).map((post) => (
            <article
              key={post.id}
              onClick={() => navigateTo('blog-details', { id: post.id })}
              className="group cursor-pointer flex flex-col bg-white dark:bg-[#1A1A1E]/30 border border-neutral-100 dark:border-neutral-900 rounded-xl overflow-hidden hover:shadow-lg transition duration-300"
            >
              <div className="aspect-[16/10] relative overflow-hidden bg-neutral-100 dark:bg-neutral-800">
                <img
                  src={post.image}
                  alt={post.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-102 transition duration-500"
                />
                <span className="absolute top-3 left-3 bg-white/90 dark:bg-neutral-900/90 backdrop-blur-sm text-neutral-800 dark:text-white text-[10px] font-bold uppercase tracking-wider py-1 px-2.5 rounded-md border border-neutral-200/20">
                  {post.category}
                </span>
              </div>
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-3 text-[10px] text-neutral-450 dark:text-neutral-500 uppercase tracking-widest font-semibold">
                    <span>{post.date}</span>
                    <span>•</span>
                    <span>{post.readTime}</span>
                  </div>
                  <h4 className="text-sm font-semibold text-neutral-800 dark:text-neutral-100 group-hover:text-[#C19A6B] transition-colors mt-2.5 line-clamp-2 leading-snug">
                    {post.title}
                  </h4>
                  <p className="text-xs text-neutral-500 dark:text-neutral-400 font-light mt-2 line-clamp-3 leading-relaxed">
                    {post.excerpt}
                  </p>
                </div>
                <span className="text-[10px] font-bold tracking-widest uppercase text-[#C19A6B] mt-4 block">
                  Read Article &rarr;
                </span>
              </div>
            </article>
          ))}
        </div>
      </section>

    </div>
  );
};
