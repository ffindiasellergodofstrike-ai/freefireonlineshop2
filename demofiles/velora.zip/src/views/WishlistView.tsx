/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useApp } from '../context/AppContext';
import { Heart, Star, ShoppingBag, Eye, Trash2, ArrowRight } from 'lucide-react';

export const WishlistView: React.FC = () => {
  const { wishlist, toggleWishlist, addToCart, setQuickViewProduct, navigateTo } = useApp();

  if (wishlist.length === 0) {
    return (
      <div id="wishlist-view" className="max-w-3xl mx-auto px-4 py-20 text-center">
        <div className="p-5 bg-neutral-50 dark:bg-neutral-900 rounded-full text-neutral-400 mb-5 border border-neutral-100 dark:border-neutral-800 inline-block">
          <Heart className="w-10 h-10" />
        </div>
        <h2 className="text-xl font-serif font-bold text-neutral-800 dark:text-white">Your Wishlist is empty</h2>
        <p className="text-xs text-neutral-500 dark:text-neutral-400 font-light max-w-sm mx-auto mt-2 leading-relaxed">
          Create custom lists of your favorite designs, automatic watches, and organic botanicals. Add them to your bag at any moment.
        </p>
        <button
          onClick={() => navigateTo('shop')}
          className="mt-8 bg-neutral-900 hover:bg-neutral-850 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-neutral-950 text-xs font-bold tracking-widest uppercase py-3.5 px-8 rounded-lg shadow-md cursor-pointer transition"
        >
          Browse Boutique
        </button>
      </div>
    );
  }

  return (
    <div id="wishlist-view" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
      
      {/* Page Title */}
      <div className="py-8 border-b border-neutral-100 dark:border-neutral-900">
        <span className="text-xs font-bold text-[#C19A6B] uppercase tracking-widest block">Saved bespoke pieces</span>
        <h1 className="text-3xl font-serif font-extrabold text-neutral-900 dark:text-white mt-1.5 leading-snug">
          My Saved Wishlist ({wishlist.length})
        </h1>
      </div>

      {/* Grid of Wishlist Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mt-8">
        {wishlist.map((product) => (
          <div
            key={product.id}
            className="group relative flex flex-col bg-white dark:bg-[#1A1A1E]/40 border border-neutral-100 dark:border-neutral-900 rounded-xl overflow-hidden transition-all duration-300 hover:shadow-lg"
          >
            {/* Delete button overlay */}
            <button
              onClick={() => toggleWishlist(product)}
              className="absolute top-3 right-3 z-10 p-2.5 bg-white/95 dark:bg-neutral-900/95 backdrop-blur-md rounded-full text-red-500 border border-red-50/50 hover:bg-red-50 dark:hover:bg-red-950/20 shadow-sm transition cursor-pointer"
              aria-label="Remove from Wishlist"
            >
              <Trash2 className="w-4 h-4" />
            </button>

            {/* Image Stage */}
            <div
              onClick={() => navigateTo('product', { id: product.id })}
              className="aspect-[3/4] relative overflow-hidden bg-neutral-50 dark:bg-neutral-900/50 cursor-pointer border-b border-neutral-100 dark:border-neutral-900"
            >
              <img
                src={product.images[0]}
                alt={product.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-550 ease-out group-hover:scale-102"
              />
              <div className="absolute inset-0 bg-black/10 dark:bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center p-4">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setQuickViewProduct(product);
                  }}
                  className="w-full bg-white/95 dark:bg-neutral-900/95 backdrop-blur-md text-neutral-850 dark:text-white hover:text-[#C19A6B] py-2 text-xs font-bold tracking-wider uppercase transition flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
                >
                  <Eye className="w-4 h-4" />
                  <span>Configure Options</span>
                </button>
              </div>
            </div>

            {/* Card Content Details */}
            <div className="p-4 flex-1 flex flex-col justify-between">
              <div>
                <span className="text-[10px] tracking-wider font-bold text-[#C19A6B] uppercase">{product.brand}</span>
                <h4
                  onClick={() => navigateTo('product', { id: product.id })}
                  className="text-xs sm:text-sm font-semibold text-neutral-850 dark:text-neutral-100 hover:text-[#C19A6B] transition-colors mt-1.5 cursor-pointer line-clamp-1"
                >
                  {product.name}
                </h4>
                
                {/* Rating */}
                <div className="flex items-center gap-1 mt-2">
                  <div className="flex items-center gap-0.5">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-3 h-3 ${
                          i < Math.floor(product.rating) ? 'fill-[#C19A6B] text-[#C19A6B]' : 'text-neutral-200 dark:text-neutral-800'
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-[10px] font-bold text-neutral-400 font-mono">({product.reviewsCount})</span>
                </div>
              </div>

              {/* Action and Price Row */}
              <div className="flex items-center justify-between mt-4 pt-3 border-t border-neutral-100/60 dark:border-neutral-900/60">
                <span className="text-xs sm:text-sm font-bold font-mono text-neutral-900 dark:text-white">
                  ${product.price}
                </span>
                
                <button
                  onClick={() => setQuickViewProduct(product)}
                  className="text-xs font-semibold text-[#C19A6B] hover:text-[#A17C52] transition flex items-center gap-1 uppercase tracking-widest text-[10px]"
                >
                  <span>Select Size</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

          </div>
        ))}
      </div>

    </div>
  );
};
