/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { ShippingAddress, Order } from '../types';
import { User, Package, MapPin, Compass, Search, ShieldCheck, CheckCircle2, ChevronRight, HelpCircle, Key, Mail, Phone, Map } from 'lucide-react';

export const MyAccountView: React.FC = () => {
  const {
    currentRouteParams,
    navigateTo,
    user,
    orders,
    shippingAddresses,
    addAddress,
    updateAddress,
    deleteAddress,
    setDefaultAddress,
    trackOrder,
    addToast
  } = useApp();

  // Selected tab state: 'profile' | 'orders' | 'addresses' | 'track'
  const [activeTab, setActiveTab] = useState<'profile' | 'orders' | 'addresses' | 'track'>('profile');

  // Address edit state
  const [isEditingAddress, setIsEditingAddress] = useState<string | null>(null);
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [addressLine1, setAddressLine1] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [country, setCountry] = useState('United States');

  // Order tracking input state
  const [trackingIdInput, setTrackingIdInput] = useState('');
  const [trackedResult, setTrackedResult] = useState<Order | null>(null);

  // Selected order details modal/subview
  const [selectedOrderDetails, setSelectedOrderDetails] = useState<Order | null>(null);

  // Profile fields state
  const [profileName, setProfileName] = useState(user?.name || 'Jane Doe');
  const [profileEmail, setProfileEmail] = useState(user?.email || 'jane@example.com');
  const [profilePassword, setProfilePassword] = useState('••••••••••••');

  useEffect(() => {
    if (currentRouteParams?.tab) {
      setActiveTab(currentRouteParams.tab);
    }
  }, [currentRouteParams]);

  // Synchronize on user update
  useEffect(() => {
    if (user) {
      setProfileName(user.name);
      setProfileEmail(user.email);
    }
  }, [user]);

  const handleProfileSave = (e: React.FormEvent) => {
    e.preventDefault();
    addToast('Atelier profile settings saved successfully!', 'success');
  };

  const handleTrackingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (trackingIdInput.trim()) {
      const found = trackOrder(trackingIdInput);
      if (found) {
        setTrackedResult(found);
        addToast('Invoice credentials successfully fetched!', 'success');
      } else {
        setTrackedResult(null);
        addToast('Invoice number not found in Velora logs', 'error');
      }
    }
  };

  const handleStartEditAddress = (addr: ShippingAddress) => {
    setIsEditingAddress(addr.id);
    setFullName(addr.fullName);
    setPhone(addr.phone);
    setAddressLine1(addr.addressLine1);
    setCity(addr.city);
    setState(addr.state);
    setPostalCode(addr.postalCode);
    setCountry(addr.country);
  };

  const handleUpdateAddressSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isEditingAddress) {
      updateAddress({
        id: isEditingAddress,
        fullName,
        phone,
        addressLine1,
        city,
        state,
        postalCode,
        country,
        isDefault: shippingAddresses.find((a) => a.id === isEditingAddress)?.isDefault || false,
      });
      setIsEditingAddress(null);
    }
  };

  return (
    <div id="my-account-view" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
      
      {/* Page Title */}
      <div className="py-8 border-b border-neutral-100 dark:border-neutral-900">
        <span className="text-xs font-bold text-[#C19A6B] uppercase tracking-widest block">Customer Dashboard</span>
        <h1 className="text-3xl font-serif font-extrabold text-neutral-900 dark:text-white mt-1.5 leading-snug">
          My Account Portal
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 mt-8 items-start">
        
        {/* Left Side: Tabs Navigation (Col Span 3) */}
        <aside className="lg:col-span-3 space-y-2.5">
          {[
            { id: 'profile', label: 'Profile Settings', icon: User },
            { id: 'orders', label: 'Order History', icon: Package },
            { id: 'addresses', label: 'Addresses', icon: MapPin },
            { id: 'track', label: 'Track Order', icon: Compass },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setActiveTab(tab.id as any);
                  setSelectedOrderDetails(null);
                  setTrackedResult(null);
                }}
                className={`w-full flex items-center gap-3.5 px-4 py-3.5 rounded-xl border text-left text-xs font-semibold uppercase tracking-wider transition cursor-pointer ${
                  activeTab === tab.id
                    ? 'bg-neutral-900 dark:bg-white text-white dark:text-neutral-900 border-neutral-900 dark:border-white font-bold shadow-md'
                    : 'border-neutral-100 dark:border-neutral-900/40 text-neutral-600 dark:text-neutral-400 hover:bg-neutral-50 dark:hover:bg-neutral-850/15'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </aside>

        {/* Right Side: Tab Panel Content (Col Span 9) */}
        <div className="lg:col-span-9 bg-neutral-50/50 dark:bg-[#1A1A1E]/30 rounded-2xl border border-neutral-150/60 dark:border-neutral-900 p-6 sm:p-8">
          
          {/* PROFILE SETTINGS TAB */}
          {activeTab === 'profile' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-serif font-bold text-neutral-900 dark:text-white">Atelier Profile Settings</h3>
                <p className="text-xs text-neutral-400 dark:text-neutral-500 font-light mt-0.5">Maintain your secure login identity credentials and newsletter preferences.</p>
              </div>

              <form onSubmit={handleProfileSave} className="space-y-4 max-w-xl">
                <div>
                  <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1.5">Full Name</label>
                  <div className="relative flex items-center bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md">
                    <User className="w-4 h-4 text-neutral-400 absolute left-3" />
                    <input
                      type="text"
                      value={profileName}
                      onChange={(e) => setProfileName(e.target.value)}
                      className="bg-transparent border-none text-xs focus:ring-0 outline-none w-full py-2.5 pl-9 pr-3 text-neutral-800 dark:text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1.5">Email Address</label>
                  <div className="relative flex items-center bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md">
                    <Mail className="w-4 h-4 text-neutral-400 absolute left-3" />
                    <input
                      type="email"
                      value={profileEmail}
                      onChange={(e) => setProfileEmail(e.target.value)}
                      className="bg-transparent border-none text-xs focus:ring-0 outline-none w-full py-2.5 pl-9 pr-3 text-neutral-800 dark:text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1.5">Account Password</label>
                  <div className="relative flex items-center bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md">
                    <Key className="w-4 h-4 text-neutral-400 absolute left-3" />
                    <input
                      type="password"
                      value={profilePassword}
                      onChange={(e) => setProfilePassword(e.target.value)}
                      className="bg-transparent border-none text-xs focus:ring-0 outline-none w-full py-2.5 pl-9 pr-3 text-neutral-850 dark:text-white"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="bg-[#C19A6B] hover:bg-[#A17C52] text-white text-xs font-bold tracking-widest uppercase py-3 px-6 rounded-md transition cursor-pointer shadow-md"
                >
                  Save Profile Changes
                </button>
              </form>
            </div>
          )}

          {/* ORDER HISTORY TAB */}
          {activeTab === 'orders' && (
            <div className="space-y-6">
              
              {selectedOrderDetails ? (
                /* Subview: Single Order Details & Tracking Steps */
                <div className="space-y-8">
                  <button
                    onClick={() => setSelectedOrderDetails(null)}
                    className="text-xs font-semibold text-[#C19A6B] hover:text-[#A17C52] transition flex items-center gap-1 uppercase tracking-wider"
                  >
                    &larr; Return to Orders List
                  </button>

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-neutral-100 dark:border-neutral-900 pb-4">
                    <div>
                      <span className="text-[9px] font-bold tracking-widest text-[#C19A6B] uppercase">Order ID Invoice</span>
                      <h3 className="text-base font-bold font-mono text-neutral-850 dark:text-white">{selectedOrderDetails.id}</h3>
                    </div>
                    <div className="text-xs sm:text-right">
                      <span className="text-[9px] font-bold tracking-widest text-[#C19A6B] uppercase block">Placed On</span>
                      <span className="font-medium text-neutral-600 dark:text-neutral-400">{selectedOrderDetails.date}</span>
                    </div>
                  </div>

                  {/* Order tracking stepper panel */}
                  <div className="bg-white dark:bg-[#121214] border border-neutral-200/50 dark:border-neutral-850 p-6 rounded-2xl space-y-6">
                    <h4 className="text-xs font-bold uppercase tracking-widest text-neutral-400">Shipment Tracking Steps</h4>
                    <div className="relative border-l-2 border-[#C19A6B]/25 ml-3 pl-6 space-y-6 text-xs">
                      {selectedOrderDetails.trackingSteps?.map((step, idx) => (
                        <div key={idx} className="relative">
                          <div className={`absolute -left-[30px] top-0.5 w-4 h-4 rounded-full border-2 flex items-center justify-center transition ${
                            step.completed
                              ? 'bg-[#C19A6B] border-[#C19A6B] text-white'
                              : 'bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 text-neutral-400'
                          }`}>
                            {step.completed && <CheckCircle2 className="w-3 h-3 text-white" />}
                          </div>
                          <div>
                            <h5 className={`font-bold ${step.active ? 'text-[#C19A6B]' : 'text-neutral-800 dark:text-neutral-200'}`}>
                              {step.title}
                            </h5>
                            <p className="text-[11px] text-neutral-400 dark:text-neutral-500 mt-1 font-light leading-relaxed">{step.description}</p>
                            <span className="text-[10px] font-mono text-neutral-400 block mt-1">{step.date}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Items List */}
                  <div className="space-y-3.5">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-450 block">Courier Items List</span>
                    <div className="bg-white dark:bg-[#121214] border border-neutral-150/60 dark:border-neutral-850 rounded-xl p-4 divide-y divide-neutral-100/50 dark:divide-neutral-800/50">
                      {selectedOrderDetails.items.map((item, idx) => (
                        <div key={idx} className="py-3 flex gap-4 first:pt-0">
                          <img src={item.productImage} alt={item.productName} className="w-12 h-16 object-cover rounded-lg bg-white border shrink-0" />
                          <div className="min-w-0 flex-1">
                            <h5 className="text-xs font-semibold text-neutral-850 dark:text-neutral-150 truncate">{item.productName}</h5>
                            <p className="text-[10px] text-neutral-400 mt-0.5 font-mono">
                              Qty: {item.quantity} • {item.selectedColor || 'Default'} • {item.selectedSize || 'Default'}
                            </p>
                          </div>
                          <span className="text-xs font-mono font-bold text-neutral-950 dark:text-white">${item.price * item.quantity}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Bottom financial details */}
                  <div className="bg-neutral-50 dark:bg-[#121214]/60 p-4 rounded-xl border border-neutral-200/50 dark:border-neutral-800 text-xs text-neutral-500 space-y-2">
                    <div className="flex justify-between">
                      <span>Subtotal</span>
                      <span className="font-mono">${selectedOrderDetails.subtotal}</span>
                    </div>
                    {selectedOrderDetails.discount > 0 && (
                      <div className="flex justify-between text-emerald-600 dark:text-emerald-400">
                        <span>Discount Savings</span>
                        <span className="font-mono">-${selectedOrderDetails.discount}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span>Luxury Courier</span>
                      <span className="font-mono">{selectedOrderDetails.shipping === 0 ? 'Complimentary' : `$${selectedOrderDetails.shipping}`}</span>
                    </div>
                    <div className="flex justify-between font-bold text-neutral-800 dark:text-white border-t border-neutral-100 dark:border-neutral-800 pt-2">
                      <span>Total Invoice Debited</span>
                      <span className="font-mono font-bold text-sm">${selectedOrderDetails.total}</span>
                    </div>
                  </div>
                </div>
              ) : (
                /* Primary Orders List */
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-serif font-bold text-neutral-900 dark:text-white">Bespoke Order History</h3>
                    <p className="text-xs text-neutral-400 dark:text-neutral-500 font-light mt-0.5">Trace shipping logs, delivery statuses, and request premium exchanges.</p>
                  </div>

                  {orders.length === 0 ? (
                    <div className="text-center py-12">
                      <p className="text-xs text-neutral-400 font-light">You haven't placed any orders yet.</p>
                      <button onClick={() => navigateTo('shop')} className="mt-4 bg-[#C19A6B] text-white text-xs font-bold uppercase py-2.5 px-5 rounded">
                        Shop Collection
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {orders.map((order) => (
                        <div
                          key={order.id}
                          className="bg-white dark:bg-neutral-900 border border-neutral-150/60 dark:border-neutral-800 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:shadow-sm transition"
                        >
                          <div className="space-y-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-xs font-extrabold font-mono text-neutral-850 dark:text-white">{order.id}</span>
                              <span className={`text-[9px] font-bold tracking-widest uppercase px-2 py-0.5 rounded-full ${
                                order.status === 'delivered'
                                  ? 'bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 dark:text-emerald-450'
                                  : order.status === 'shipped'
                                  ? 'bg-blue-50 dark:bg-blue-950/20 text-blue-600'
                                  : 'bg-yellow-50 dark:bg-yellow-950/20 text-yellow-650'
                              }`}>
                                {order.status}
                              </span>
                            </div>
                            <p className="text-[11px] text-neutral-450 dark:text-neutral-500">
                              Placed On {order.date} • {order.items.length} bespoke item(s)
                            </p>
                          </div>

                          <div className="flex items-center gap-4 justify-between sm:justify-end">
                            <span className="text-xs font-mono font-bold text-neutral-900 dark:text-white">${order.total}</span>
                            <button
                              onClick={() => setSelectedOrderDetails(order)}
                              className="text-[10px] font-bold text-[#C19A6B] hover:text-[#A17C52] uppercase tracking-wider flex items-center gap-1 cursor-pointer"
                            >
                              <span>Trace Invoice</span>
                              <ChevronRight className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* ADDRESS MANAGEMENT TAB */}
          {activeTab === 'addresses' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-serif font-bold text-neutral-900 dark:text-white">Courier Destinations</h3>
                <p className="text-xs text-neutral-400 dark:text-neutral-500 font-light mt-0.5 font-light">Set default destination addresses for white-glove shipping dispatches.</p>
              </div>

              {isEditingAddress ? (
                /* Edit Address Form */
                <form onSubmit={handleUpdateAddressSubmit} className="space-y-4 max-w-xl">
                  <span className="text-xs font-bold text-[#C19A6B] uppercase tracking-wider block">Update Address Details</span>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="col-span-2 sm:col-span-1">
                      <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">Full Name</label>
                      <input
                        type="text"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        className="w-full bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2.5 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white"
                        required
                      />
                    </div>
                    <div className="col-span-2 sm:col-span-1">
                      <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">Phone Number</label>
                      <input
                        type="text"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        className="w-full bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2.5 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">Address Line 1</label>
                    <input
                      type="text"
                      value={addressLine1}
                      onChange={(e) => setAddressLine1(e.target.value)}
                      className="w-full bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2.5 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">City</label>
                      <input
                        type="text"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        className="w-full bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2.5 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">State</label>
                      <input
                        type="text"
                        value={state}
                        onChange={(e) => setState(e.target.value)}
                        className="w-full bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2.5 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1">ZIP / Postal</label>
                      <input
                        type="text"
                        value={postalCode}
                        onChange={(e) => setPostalCode(e.target.value)}
                        className="w-full bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2.5 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white"
                        required
                      />
                    </div>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <button type="submit" className="bg-[#C19A6B] text-white text-xs py-2.5 px-5 rounded font-bold uppercase cursor-pointer">
                      Update Address
                    </button>
                    <button type="button" onClick={() => setIsEditingAddress(null)} className="border border-neutral-200 text-xs py-2.5 px-5 rounded cursor-pointer">
                      Cancel
                    </button>
                  </div>
                </form>
              ) : (
                /* Addresses list */
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {shippingAddresses.map((addr) => (
                    <div
                      key={addr.id}
                      className="bg-white dark:bg-neutral-900 border border-neutral-150/60 dark:border-neutral-800 rounded-xl p-4 flex flex-col justify-between hover:shadow-sm transition"
                    >
                      <div className="space-y-1.5 text-xs text-neutral-600 dark:text-neutral-400">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-neutral-850 dark:text-white">{addr.fullName}</span>
                          {addr.isDefault && (
                            <span className="bg-[#C19A6B]/15 text-[#C19A6B] text-[8px] font-extrabold uppercase px-1.5 py-0.5 rounded tracking-wide">
                              Default
                            </span>
                          )}
                        </div>
                        <p className="font-light leading-relaxed">{addr.addressLine1}, {addr.city}, {addr.state} {addr.postalCode}</p>
                        <p className="text-[10px] text-neutral-400 font-mono">{addr.phone}</p>
                      </div>

                      <div className="flex gap-3 mt-6 pt-3 border-t border-neutral-100 dark:border-neutral-800 text-[10px] font-bold uppercase tracking-wider text-neutral-450 dark:text-neutral-550">
                        <button onClick={() => handleStartEditAddress(addr)} className="hover:text-[#C19A6B] transition cursor-pointer">
                          Edit
                        </button>
                        <button onClick={() => deleteAddress(addr.id)} className="hover:text-red-500 transition cursor-pointer">
                          Delete
                        </button>
                        {!addr.isDefault && (
                          <button onClick={() => setDefaultAddress(addr.id)} className="hover:text-[#C19A6B] transition cursor-pointer ml-auto">
                            Set Default
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TRACK ORDER TAB */}
          {activeTab === 'track' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-serif font-bold text-neutral-900 dark:text-white">Courier Tracking System</h3>
                <p className="text-xs text-neutral-400 dark:text-neutral-500 font-light mt-0.5">Input your bespoke invoice number (e.g. VEL-829471) to extract shipping coordinates instantly.</p>
              </div>

              <form onSubmit={handleTrackingSubmit} className="flex gap-2 max-w-lg">
                <input
                  type="text"
                  placeholder="Enter Invoice ID (VEL-829471)..."
                  value={trackingIdInput}
                  onChange={(e) => setTrackingIdInput(e.target.value)}
                  className="flex-1 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2.5 px-3.5 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white font-mono"
                  required
                />
                <button
                  type="submit"
                  className="bg-neutral-800 hover:bg-neutral-900 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-neutral-900 text-xs px-5 py-2.5 rounded-md font-bold tracking-widest uppercase cursor-pointer transition flex items-center gap-1.5"
                >
                  <Search className="w-3.5 h-3.5" />
                  <span>Search Logs</span>
                </button>
              </form>

              {/* Display tracking result */}
              {trackedResult && (
                <div className="space-y-6 pt-6 border-t border-neutral-200/50 dark:border-neutral-850 mt-6">
                  <div className="flex justify-between items-baseline flex-wrap gap-2">
                    <div>
                      <span className="text-[9px] font-bold text-[#C19A6B] uppercase tracking-widest">Active Dispatch Log Found</span>
                      <h4 className="text-sm font-bold font-mono text-neutral-850 dark:text-white">{trackedResult.id}</h4>
                    </div>
                    <span className="text-xs text-neutral-400 font-light">Status: <strong className="text-[#C19A6B] font-semibold uppercase">{trackedResult.status}</strong></span>
                  </div>

                  {/* Stepper display */}
                  <div className="relative border-l-2 border-[#C19A6B]/20 ml-3.5 pl-6 space-y-6 text-xs text-neutral-500">
                    {trackedResult.trackingSteps?.map((step, idx) => (
                      <div key={idx} className="relative">
                        <div className={`absolute -left-[31px] top-0.5 w-4.5 h-4.5 rounded-full border-2 flex items-center justify-center transition ${
                          step.completed
                            ? 'bg-[#C19A6B] border-[#C19A6B] text-white'
                            : 'bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 text-neutral-400'
                        }`}>
                          {step.completed && <CheckCircle2 className="w-3 h-3 text-white" />}
                        </div>
                        <div>
                          <h5 className={`font-bold ${step.active ? 'text-[#C19A6B]' : 'text-neutral-800 dark:text-neutral-200'}`}>
                            {step.title}
                          </h5>
                          <p className="text-[11px] text-neutral-400 dark:text-neutral-500 mt-1 font-light leading-relaxed">{step.description}</p>
                          <span className="text-[10px] font-mono text-neutral-400 block mt-1">{step.date}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

        </div>

      </div>

    </div>
  );
};
