/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight, Tag, ShieldCheck } from 'lucide-react';

export const CartView: React.FC = () => {
  const {
    cart,
    updateCartQuantity,
    removeFromCart,
    cartTotal,
    cartCount,
    activeCoupon,
    applyCoupon,
    removeCoupon,
    navigateTo,
  } = useApp();

  const [couponCode, setCouponCode] = useState('');

  const handleCouponSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (couponCode.trim()) {
      applyCoupon(couponCode);
      setCouponCode('');
    }
  };

  const getPrice = (item: typeof cart[0]) => {
    const base = item.product.price;
    const colorOffset = item.selectedColor?.priceOffset || 0;
    const sizeOffset = item.selectedSize?.priceOffset || 0;
    return base + colorOffset + sizeOffset;
  };

  const calculatedDiscount = () => {
    if (!activeCoupon) return 0;
    if (activeCoupon.type === 'percentage') {
      return Number((cartTotal * (activeCoupon.value / 100)).toFixed(2));
    }
    return activeCoupon.value;
  };

  const finalTotal = () => {
    const ship = cartTotal > 150 ? 0 : 15;
    const tax = Number((cartTotal * 0.08).toFixed(2));
    return Number((cartTotal + ship + tax - calculatedDiscount()).toFixed(2));
  };

  if (cart.length === 0) {
    return (
      <div id="cart-view" className="max-w-3xl mx-auto px-4 py-20 text-center">
        <div className="p-5 bg-neutral-50 dark:bg-neutral-900 rounded-full text-neutral-400 mb-5 border border-neutral-100 dark:border-neutral-800 inline-block">
          <ShoppingBag className="w-10 h-10" />
        </div>
        <h2 className="text-xl font-serif font-bold text-neutral-800 dark:text-white">Your Shopping Bag is empty</h2>
        <p className="text-xs text-neutral-500 dark:text-neutral-400 font-light max-w-sm mx-auto mt-2 leading-relaxed">
          You haven't selected any bespoke designs yet. Head over to our all-products catalog and choose your seasonal fits.
        </p>
        <button
          onClick={() => navigateTo('shop')}
          className="mt-8 bg-neutral-900 hover:bg-neutral-850 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-neutral-950 text-xs font-bold tracking-widest uppercase py-3.5 px-8 rounded-lg shadow-md cursor-pointer transition"
        >
          Explore Collections
        </button>
      </div>
    );
  }

  return (
    <div id="cart-view" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
      {/* Page Title */}
      <div className="py-8 border-b border-neutral-100 dark:border-neutral-900">
        <span className="text-xs font-bold text-[#C19A6B] uppercase tracking-widest block">Review Selected Designs</span>
        <h1 className="text-3xl font-serif font-extrabold text-neutral-900 dark:text-white mt-1.5 leading-snug">
          My Shopping Bag ({cartCount})
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start mt-8">
        
        {/* Left Side: Items Table (Col Span 8) */}
        <div className="lg:col-span-8 space-y-6">
          <div className="hidden sm:grid grid-cols-12 gap-4 pb-3 border-b border-neutral-250/50 text-[10px] font-bold uppercase tracking-widest text-neutral-400 dark:text-neutral-550">
            <span className="col-span-6">Bespoke Item</span>
            <span className="col-span-2 text-center">Unit Price</span>
            <span className="col-span-2 text-center">Quantity</span>
            <span className="col-span-2 text-right">Subtotal</span>
          </div>

          <div className="divide-y divide-neutral-200/50 dark:divide-neutral-850/50">
            {cart.map((item) => (
              <div key={item.id} className="py-5 grid grid-cols-1 sm:grid-cols-12 gap-4 items-center">
                
                {/* Item Details (col-span-6) */}
                <div className="col-span-6 flex gap-4">
                  <img
                    src={item.product.images[0]}
                    alt={item.product.name}
                    referrerPolicy="no-referrer"
                    className="w-20 h-24 object-cover rounded-xl border border-neutral-200/50 dark:border-neutral-700/50 shrink-0"
                  />
                  <div className="min-w-0 flex flex-col justify-between">
                    <div>
                      <p className="text-[9px] font-bold text-[#C19A6B] uppercase tracking-widest">{item.product.brand}</p>
                      <h4
                        onClick={() => navigateTo('product', { id: item.product.id })}
                        className="text-xs sm:text-sm font-semibold text-neutral-800 dark:text-neutral-100 hover:text-[#C19A6B] cursor-pointer transition truncate mt-0.5"
                      >
                        {item.product.name}
                      </h4>
                    </div>

                    {/* Selected variants checklist */}
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {item.selectedColor && (
                        <span className="inline-flex items-center gap-1 text-[9px] bg-neutral-50 dark:bg-neutral-900 border border-neutral-200/50 dark:border-neutral-800 py-0.5 px-2 rounded-full text-neutral-500 dark:text-neutral-400 font-medium">
                          <span
                            className="w-1.5 h-1.5 rounded-full border border-black/5"
                            style={{ backgroundColor: item.selectedColor.value }}
                          />
                          {item.selectedColor.name}
                        </span>
                      )}
                      {item.selectedSize && (
                        <span className="inline-flex items-center text-[9px] bg-neutral-50 dark:bg-neutral-900 border border-neutral-200/50 dark:border-neutral-800 py-0.5 px-2 rounded-full text-neutral-500 dark:text-neutral-400 font-bold font-mono">
                          SIZE: {item.selectedSize.name}
                        </span>
                      )}
                    </div>

                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="text-[10px] font-semibold text-red-500 hover:text-red-650 flex items-center gap-1 mt-2.5"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Remove Item</span>
                    </button>
                  </div>
                </div>

                {/* Unit Price (col-span-2) */}
                <div className="col-span-2 text-center text-xs font-mono font-bold text-neutral-600 dark:text-neutral-400">
                  <span className="sm:hidden text-neutral-400 uppercase tracking-wider block font-sans font-normal text-[9px] mb-1">Unit Price</span>
                  ${getPrice(item)}
                </div>

                {/* Quantity Control (col-span-2) */}
                <div className="col-span-2 flex justify-center">
                  <div className="flex flex-col items-center sm:items-stretch">
                    <span className="sm:hidden text-neutral-400 uppercase tracking-wider block font-sans font-normal text-[9px] mb-1.5">Qty</span>
                    <div className="flex items-center border border-neutral-200 dark:border-neutral-800 rounded-md py-1 px-2.5 bg-white dark:bg-neutral-900">
                      <button
                        onClick={() => updateCartQuantity(item.id, item.quantity - 1)}
                        className="text-neutral-400 hover:text-neutral-700 dark:hover:text-white"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="text-xs font-mono font-bold w-6 text-center text-neutral-800 dark:text-white">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => updateCartQuantity(item.id, item.quantity + 1)}
                        className="text-neutral-400 hover:text-neutral-700 dark:hover:text-white"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Subtotal (col-span-2) */}
                <div className="col-span-2 text-right text-xs sm:text-sm font-mono font-extrabold text-neutral-900 dark:text-white">
                  <span className="sm:hidden text-neutral-400 uppercase tracking-wider block font-sans font-normal text-[9px] mb-1">Subtotal</span>
                  ${getPrice(item) * item.quantity}
                </div>

              </div>
            ))}
          </div>
        </div>

        {/* Right Side: Order summary (Col Span 4) */}
        <div className="lg:col-span-4 bg-neutral-50 dark:bg-[#1A1A1E]/30 border border-neutral-100 dark:border-neutral-900 rounded-2xl p-6 sm:p-8 space-y-6">
          <h3 className="text-base font-bold tracking-widest uppercase text-neutral-850 dark:text-white">Order Summary</h3>

          {/* Coupon Form */}
          <div className="pb-2">
            {activeCoupon ? (
              <div className="flex items-center justify-between bg-[#C19A6B]/10 dark:bg-[#C19A6B]/5 border border-[#C19A6B]/25 py-2 px-3 rounded-md">
                <div className="flex items-center gap-1.5 text-xs font-medium text-[#C19A6B]">
                  <Tag className="w-3.5 h-3.5" />
                  <span>Promo applied: <strong>{activeCoupon.code}</strong></span>
                </div>
                <button onClick={removeCoupon} className="text-neutral-400 hover:text-neutral-600 text-xs font-bold cursor-pointer">
                  Remove
                </button>
              </div>
            ) : (
              <form onSubmit={handleCouponSubmit} className="flex gap-2">
                <input
                  type="text"
                  placeholder="Enter code (VELORA10)..."
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  className="flex-1 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-md text-xs py-2 px-3 focus:outline-none focus:border-[#C19A6B] text-neutral-850 dark:text-white"
                />
                <button
                  type="submit"
                  className="bg-neutral-800 hover:bg-neutral-900 dark:bg-neutral-700 dark:hover:bg-neutral-650 text-white text-xs px-4 py-2 rounded-md font-semibold transition tracking-wider uppercase cursor-pointer"
                >
                  Apply
                </button>
              </form>
            )}
          </div>

          {/* Calculations Detail */}
          <div className="space-y-3.5 text-xs text-neutral-500 dark:text-neutral-400 border-t border-neutral-200/50 dark:border-neutral-800/50 pt-5">
            <div className="flex justify-between">
              <span className="font-light">Bags Subtotal</span>
              <span className="font-mono font-bold text-neutral-850 dark:text-neutral-100">${cartTotal}</span>
            </div>
            {activeCoupon && (
              <div className="flex justify-between text-emerald-600 dark:text-emerald-450">
                <span className="font-medium">Promo Discount ({activeCoupon.value}{activeCoupon.type === 'percentage' ? '%' : '$'})</span>
                <span className="font-mono font-bold">-${calculatedDiscount()}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span className="font-light">Estimated Shipping</span>
              {cartTotal > 150 ? (
                <span className="text-[10px] tracking-widest text-[#C19A6B] font-extrabold uppercase">Complimentary</span>
              ) : (
                <span className="font-mono font-bold text-neutral-850 dark:text-neutral-100">$15</span>
              )}
            </div>
            <div className="flex justify-between">
              <span className="font-light">Estimated Tax (8%)</span>
              <span className="font-mono font-bold text-neutral-850 dark:text-neutral-100">${(cartTotal * 0.08).toFixed(2)}</span>
            </div>
            
            <hr className="border-neutral-200 dark:border-neutral-800 my-2" />

            <div className="flex justify-between text-sm">
              <span className="font-bold text-neutral-850 dark:text-neutral-100">Estimated Total</span>
              <span className="font-mono font-extrabold text-neutral-900 dark:text-white text-lg">${finalTotal()}</span>
            </div>
          </div>

          <div className="pt-4 space-y-3">
            <button
              onClick={() => navigateTo('checkout')}
              className="w-full bg-[#121214] dark:bg-white text-white dark:text-[#121214] hover:bg-neutral-850 dark:hover:bg-neutral-100 text-xs py-3.5 px-4 rounded-lg font-bold tracking-widest uppercase transition flex items-center justify-center gap-2 group cursor-pointer shadow-md"
            >
              <span>Secure Checkout</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={() => navigateTo('shop')}
              className="w-full bg-transparent text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-200 text-xs py-2 text-center transition font-semibold"
            >
              Continue Shopping
            </button>
          </div>

          {/* Checkout trust highlights */}
          <div className="border-t border-neutral-200/50 dark:border-neutral-800/50 pt-5 flex gap-2 items-center text-[10px] text-neutral-400">
            <ShieldCheck className="w-5 h-5 text-[#C19A6B] shrink-0" />
            <span>Fully encrypted checkout portal. 256-bit SSL certified high security.</span>
          </div>
        </div>

      </div>
    </div>
  );
};
